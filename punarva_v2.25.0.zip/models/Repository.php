<?php
/**
 * Base Repository – thin data-access layer over PDO (prepared statements only).
 * Services may use this directly or wrap it; new repositories should extend this class.
 */
abstract class Repository
{
    protected string $table;

    public function find(int $id): ?array
    {
        return Database::one("SELECT * FROM `{$this->table}` WHERE id = ?", [$id]);
    }

    public function all(string $where = '1=1', array $params = [], string $order = 'id DESC', int $limit = 100): array
    {
        // v2.22.0 — identifiers cannot be bound as parameters, so $order must be an
        // allowlisted "col [ASC|DESC][, col2 DESC…]" list of plain identifiers.
        // (Defence-in-depth: current callers pass constants only, but this keeps a
        // future request-driven call from turning into an ORDER BY injection.)
        if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*(\s+(ASC|DESC))?(,\s*[A-Za-z_][A-Za-z0-9_]*(\s+(ASC|DESC))?)*$/', trim($order))) {
            $order = 'id DESC'; // safe fallback
        }
        return Database::all("SELECT * FROM `{$this->table}` WHERE $where ORDER BY $order LIMIT " . (int) $limit, $params);
    }

    public function insert(array $data): int { return Database::insert($this->table, $data); }

    public function update(int $id, array $data): int
    {
        return Database::update($this->table, $data, 'id = ?', [$id]);
    }

    public function delete(int $id): int
    {
        return Database::run("DELETE FROM `{$this->table}` WHERE id = ?", [$id])->rowCount();
    }

    public function count(string $where = '1=1', array $params = []): int
    {
        return (int) Database::val("SELECT COUNT(*) FROM `{$this->table}` WHERE $where", $params);
    }
}

/** Example concrete repositories (used by services where helpful). */
class UserRepository extends Repository
{
    protected string $table = 'users';

    public function findByEmail(string $email): ?array
    {
        return Database::one('SELECT u.*, r.code AS role_code FROM users u JOIN roles r ON r.id = u.role_id WHERE u.email = ?', [strtolower($email)]);
    }

    public function collectors(): array
    {
        return Database::all(
            'SELECT u.id, u.name FROM users u JOIN roles r ON r.id = u.role_id
             WHERE r.code = "collector" AND u.status = "ACTIVE" ORDER BY u.name');
    }
}

class WasteRepository extends Repository
{
    protected string $table = 'waste_transactions';

    public function findByWasteId(string $wasteId): ?array
    {
        return WasteJourneyService::trackByWasteId($wasteId);
    }

    public function timeline(int $txId): array
    {
        return WasteJourneyService::timeline($txId);
    }
}
