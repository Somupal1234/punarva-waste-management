<?php
require_once __DIR__ . '/includes/init.php';
$pageTitle = 'How It Works'; $activeNav = 'how';
view('layouts/public_header', compact('pageTitle', 'activeNav'));
?>
<section class="py-5">
  <div class="container">
    <div class="text-center mb-5">
      <div class="section-eyebrow"><?= t('how.eyebrow') ?></div>
      <h1 class="h2 fw-bold"><?= t('how.title') ?></h1>
      <p class="text-muted small mx-auto" style="max-width:520px"><?= t('how.sub') ?></p>
    </div>
    <div class="row g-4">
      <?php
      $steps = [
        ['bi-upc-scan', 'Identify', 'Snap a photo and pick the waste category yourself in the Waste Scanner. PUNARVA shows the right bin and segregation guidance for your selection.'],
        ['bi-trash2', 'Segregate', 'Keep wet, dry, sanitary and domestic-hazardous streams separate at source using the color-coded bin guidance.'],
        ['bi-calendar-check', 'Schedule a pickup', 'Choose a date, time slot and location. Businesses can place bulk pickup requests across multiple locations.'],
        ['bi-people-fill', 'Collector assignment', 'The municipality assigns a collector. You can follow the status live: accepted → on the way → arrived → collected.'],
        ['bi-passport', 'Waste Passport issued', 'On collection the system generates a unique Waste ID (PNV-YYYY-XXXXXX) — your waste now has a public, QR-traceable journey.'],
        ['bi-globe-americas', 'Recycling & impact', 'Facilities sort and process the waste. When a final outcome is recorded, estimated environmental impact is calculated and rewards credited.'],
      ];
      foreach ($steps as $i => $s): ?>
        <div class="col-md-6 col-lg-4">
          <div class="step-card">
            <div class="d-flex align-items-center gap-2 mb-2">
              <span class="step-num"><?= $i + 1 ?></span><i class="text-pnv bi <?= $s[0] ?> fs-4"></i>
            </div>
            <h5 class="fw-bold"><?= $s[1] ?></h5>
            <p class="text-muted small mb-0"><?= $s[2] ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="card mt-5">
      <div class="card-body p-4">
        <h5 class="fw-bold mb-3"><i class="text-pnv bi bi-diagram-2 me-2"></i><?= t('how.dataflow') ?></h5>
        <div class="d-flex flex-wrap align-items-center gap-2 small fw-semibold">
          <?php $flow = ['Citizen','Waste Scanner','Pickup Request','Collector Assignment','Collection','Waste ID','Sorting','Processing','Recycling','Impact + Reward','Waste Passport','QR Tracking','Admin Analytics'];
          foreach ($flow as $i => $f): ?>
            <span class="badge text-bg-light border p-2"><?= $f ?></span>
            <?php if ($i < count($flow) - 1): ?><i class="text-pnv bi bi-arrow-right"></i><?php endif; ?>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>
<?php view('layouts/public_footer');
