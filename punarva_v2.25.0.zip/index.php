<?php
require_once __DIR__ . '/includes/init.php';
$pageTitle = 'Home';
$activeNav = 'home';

// ---- live platform statistics (database-driven, no hard-coded numbers) ----
$stats = [
    'users'      => (int) Database::val('SELECT COUNT(*) FROM users WHERE status = "ACTIVE"'),
    'collected'  => (float) (Database::val('SELECT COALESCE(SUM(initial_weight),0) FROM waste_transactions') ?: 0),
    'recycled'   => (float) (Database::val('SELECT COALESCE(SUM(current_weight),0) FROM waste_transactions WHERE final_outcome IN ("RECYCLED","RECOVERED","COMPOSTED","REUSED")') ?: 0),
    'passports'  => (int) Database::val('SELECT COUNT(*) FROM waste_transactions'),
    'pickups'    => (int) Database::val('SELECT COUNT(*) FROM pickup_requests'),
    'reports'    => (int) Database::val('SELECT COUNT(*) FROM waste_reports WHERE status = "RESOLVED"'),
];
$impact = ImpactService::globalSummary();
$categories = Database::all('SELECT * FROM waste_categories WHERE status = "ACTIVE" ORDER BY id LIMIT 14');
$facilities = (int) Database::val('SELECT COUNT(*) FROM facilities WHERE status = "ACTIVE"');
$recentPassports = Database::all(
    'SELECT wt.waste_id, wt.current_stage, wc.name AS category, wc.color
     FROM waste_transactions wt JOIN waste_categories wc ON wc.id = wt.category_id
     ORDER BY wt.created_at DESC LIMIT 4');
view('layouts/public_header', compact('pageTitle', 'activeNav'));
?>

<!-- ================= HERO ================= -->
<section class="hero py-5">
  <div class="hero-particles" aria-hidden="true">
    <span class="leaf l1"><i class="bi bi-recycle"></i></span>
    <span class="leaf l2"><i class="bi bi-recycle"></i></span>
    <span class="leaf l3"><i class="bi bi-recycle"></i></span>
    <span class="leaf l4"><i class="bi bi-recycle"></i></span>
    <span class="leaf l5"><i class="bi bi-recycle"></i></span>
    <span class="leaf l6"><i class="bi bi-recycle"></i></span>
  </div>
  <div class="container py-4 position-relative">
    <div class="row align-items-center g-4">
      <div class="col-lg-7">
        <span class="badge-pill badge px-3 py-2"><i class="bi bi-qr-code-scan me-2"></i>Waste Passport — trace every kilogram</span>
        <h1 class="display-4 mt-4 mb-2"><?= e(t('home.hero_display')) ?></h1>
        <p class="hero-subline mb-2 fw-semibold"><?= e(t('home.hero_headline')) ?></p>
        <div class="tagline mb-3">PUNARVA · <?= e(APP_TAGLINE) ?></div>
        <p class="lead mb-4" style="max-width:560px"><?= e(APP_MESSAGE) ?><br>
          The smart digital ecosystem connecting citizens, collectors, recyclers and the municipality —
          making waste <strong>traceable</strong>, <strong>valuable</strong> and <strong>impactful</strong>.</p>
        <div class="d-flex flex-wrap gap-2">
          <a class="btn btn-pnv btn-lg px-4" href="<?= url('citizen/scanner.php') ?>"><i class="bi bi-stars me-2"></i><?= t('btn.scan') ?></a>
          <a class="btn btn-ghost-light btn-lg px-4" href="<?= url('citizen/pickup-create.php') ?>"><i class="bi bi-truck me-2"></i><?= t('btn.pickup') ?></a>
          <a class="btn btn-ghost-light btn-lg px-4" href="<?= url('track.php') ?>"><i class="bi bi-qr-code me-2"></i><?= t('btn.track') ?></a>
          <a class="btn btn-ghost-light btn-lg px-4" href="<?= url('report.php') ?>"><i class="bi bi-megaphone me-2"></i><?= t('nav.report') ?></a>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="pnv-eco mb-4 d-none d-md-block" aria-hidden="true">
          <svg class="eco-svg" viewBox="0 0 300 300" focusable="false">
            <g class="eco-spin"><circle class="eco-ring" cx="150" cy="150" r="126"/></g>
            <circle class="eco-arc" cx="150" cy="150" r="126" pathLength="100"/>
            <circle class="eco-comet" r="6">
              <animateMotion dur="14s" repeatCount="indefinite" path="M 150,24 a 126,126 0 1,1 -0.01,0 z"/>
            </circle>
          </svg>
          <?php
          $ecoNodes = [
              ['n1', 'bi-trash2',  t('eco.n1')],
              ['n2', 'bi-truck',   t('eco.n2')],
              ['n3', 'bi-qr-code', t('eco.n3')],
              ['n4', 'bi-funnel',  t('eco.n4')],
              ['n5', 'bi-recycle', t('eco.n5')],
              ['n6', 'bi-globe2',  t('eco.n6')],
          ];
          foreach ($ecoNodes as $en): ?>
            <div class="eco-node <?= $en[0] ?><?= $en[0] === 'n6' ? ' hl' : '' ?>"><i class="bi <?= $en[1] ?>"></i><em><?= $en[2] ?></em></div>
          <?php endforeach; ?>
          <div class="eco-core">
            <div>
              <div class="tiny">FROM WASTE</div>
              <div class="big">TO WORTH</div>
              <div class="eco-pill mt-1"><i class="bi bi-passport"></i> <?= t('eco.core') ?></div>
            </div>
          </div>
        </div>
        <div class="hero-card p-4">
          <div class="d-flex align-items-center flex-wrap gap-2 mb-3">
            <i class="bi bi-passport fs-4" style="color:#ffe9a8"></i>
            <strong>Sample Waste Passport</strong>
            <span class="hero-qr qr-box ms-auto" data-qr="<?= e(absolute_url('track.php?id=PNV-2026-000001')) ?>" data-size="46" title="Scan to open the live demo passport"></span>
            <span class="badge text-bg-light">PNV-2026-000001</span>
          </div>
          <div class="journey">
            <?php foreach ([['Waste Identified', 'bi-search', true], ['Collected by Collector', 'bi-truck', true],
                            ['Sorted at Facility', 'bi-funnel', true], ['Recycled ✔ Impact Created', 'bi-recycle', true]] as $j): ?>
              <div class="journey-item done pb-3">
                <span class="j-icon" style="width:30px;height:30px"><i class="bi <?= $j[1] ?>" style="font-size:.85rem"></i></span>
                <div class="j-title" style="font-size:.92rem"><?= $j[0] ?></div>
              </div>
            <?php endforeach; ?>
          </div>
          <div class="d-flex flex-wrap gap-3 mt-2 small">
            <span><i class="bi bi-cloud-arrow-down me-1"></i>CO₂e avoided: <strong><?= number_format((float) $impact['co2'], 1) ?> kg</strong></span>
            <span><i class="bi bi-droplet me-1"></i>Water saved: <strong><?= number_format((float) $impact['water']) ?> L</strong></span>
          </div>
          <a class="btn btn-light btn-sm mt-3 w-100 fw-bold" href="<?= url('track.php?id=PNV-2026-000001') ?>">Open the live passport demo <i class="bi bi-arrow-right"></i></a>
        </div>
      </div>
    </div>
  </div>
  <!-- v2.23.0 original decorative journey curve (hand-drawn path, aria-hidden) -->
  <svg class="journey-curve" viewBox="0 0 1440 90" fill="none" aria-hidden="true" focusable="false" preserveAspectRatio="none" style="max-height:90px">
    <path d="M-20 70 C 160 20, 320 96, 500 54 S 830 10, 980 52 S 1280 88, 1460 34" stroke="rgba(255,255,255,.28)" stroke-width="2.5" stroke-linecap="round" stroke-dasharray="1 10"/>
    <path d="M300 54 c 14 -20 34 -22 44 -8 c -12 16 -34 20 -44 8 Z" fill="rgba(140,207,107,.55)"/>
    <path d="M760 26 c 16 -14 34 -10 38 4 c -16 10 -34 8 -38 -4 Z" fill="rgba(224,160,47,.5)"/>
    <path d="M1180 66 c 12 -18 30 -20 40 -8 c -12 14 -32 18 -40 8 Z" fill="rgba(255,255,255,.4)"/>
    <circle cx="500" cy="54" r="4" fill="rgba(255,255,255,.65)"/>
    <circle cx="980" cy="52" r="4" fill="rgba(255,255,255,.65)"/>
  </svg>
</section>

<!-- ================= WHAT IS PUNARVA ================= -->
<section class="container py-5 reveal">
  <div class="row align-items-center g-4">
    <div class="col-lg-7">
      <div class="section-eyebrow mb-1"><?= t('brand.what_eyebrow') ?></div>
      <h2 class="fw-bold mb-3"><?= t('brand.what_title') ?></h2>
      <p class="text-muted"><?= t('brand.what_text') ?></p>
      <a class="btn btn-outline-pnv btn-sm px-3 mt-1" href="#journey"><?= t('brand.journey_link') ?> <i class="bi bi-arrow-down ms-1"></i></a>
    </div>
    <div class="col-lg-4">
      <div class="card h-100 p-4 brand-meaning">
        <div class="d-flex align-items-center gap-2 mb-2">
          <span class="j-dot" style="width:40px;height:40px;font-size:1rem"><i class="bi bi-arrow-repeat"></i></span>
          <strong><?= t('brand.meaning_title') ?></strong>
        </div>
        <p class="small text-muted mb-3"><?= t('brand.meaning_text') ?></p>
        <div class="brand-tagline">From Waste <i class="bi bi-arrow-right mx-1"></i> To Worth</div>
      </div>
    </div>
  </div>
</section>

<!-- ================= HOW IT WORKS ================= -->
<section class="container pb-2 reveal" id="journey">
  <div class="section-eyebrow mb-1"><?= t('home.how') ?></div>
  <h2 class="fw-bold mb-4"><?= t('home.how_sub') ?></h2>
  <div class="j-steps position-relative reveal">
    <div class="j-track d-none d-lg-block" aria-hidden="true"></div>
    <div class="row g-3">
      <?php foreach ([
          ['bi-trash2',  t('home.step1'), t('home.step1_d')],
          ['bi-truck',   t('home.step2'), t('home.step2_d')],
          ['bi-qr-code', t('home.step3'), t('home.step3_d')],
          ['bi-funnel',  t('home.step4'), t('home.step4_d')],
          ['bi-recycle', t('home.step5'), t('home.step5_d')],
          ['bi-globe2',  t('home.step6'), t('home.step6_d')],
      ] as $i => [$ic, $st, $d]): ?>
        <div class="col-6 col-lg-2">
          <div class="card h-100 p-3 text-center j-step">
            <span class="j-dot mx-auto mb-2"><i class="bi <?= $ic ?>"></i></span>
            <div class="fw-bold small text-muted mb-1">STEP <?= sprintf('%02d', $i + 1) ?></div>
            <div class="fw-bold small mb-1"><?= $st ?></div>
            <div class="small text-muted"><?= $d ?></div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================= LIVE STATS ================= -->
<section class="container py-5 reveal">
  <div class="section-eyebrow mb-1"><?= t('home.stats_eyebrow') ?></div>
  <h2 class="fw-bold mb-4"><?= t('home.stats_title') ?></h2>
  <div class="row g-3">
    <?php
    $cards = [
        ['kpi-green', 'bi-people-fill', fmt_num($stats['users']), 'Active users', 'Citizens, collectors, recyclers & businesses'],
        ['kpi-blue', 'bi-truck', fmt_num($stats['pickups']), 'Pickup requests', 'Scheduled and managed through PUNARVA'],
        ['kpi-teal', 'bi-passport', fmt_num($stats['passports']), 'Waste Passports', 'Unique waste IDs generated'],
        ['kpi-violet', 'bi-recycle', fmt_kg($stats['recycled']), 'Waste recycled', 'Recovered through partner facilities'],
    ];
    foreach ($cards as [$color, $icon, $value, $label, $sub]): ?>
      <div class="col-6 col-lg-3">
        <div class="kpi-card <?= $color ?> p-3 h-100">
          <i class="bi <?= $icon ?> kpi-icon"></i>
          <div class="kpi-value"><?= $value ?></div>
          <div class="kpi-label"><?= e($label) ?></div>
          <div class="small opacity-75 mt-1"><?= e($sub) ?></div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <div class="small text-muted mt-3"><i class="bi bi-database-check me-1"></i><?= t('home.stats_note') ?></div>
</section>

<!-- ================= HOW IT WORKS ================= -->
<section class="container pb-5 reveal">
  <div class="text-center mb-4">
    <div class="section-eyebrow">The ecosystem</div>
    <h2 class="fw-bold">How PUNARVA works</h2>
  </div>
  <div class="row g-3 step-cards">
    <?php
    $steps = [
        ['bi-stars', 'Identify', 'Scan waste with the scanner and learn the right bin instantly.'],
        ['bi-trash3', 'Segregate', 'Separate wet, dry, domestic hazardous and sanitary streams at source.'],
        ['bi-calendar-check', 'Schedule Pickup', 'Request a doorstep pickup — citizens, apartments, offices, schools.'],
        ['bi-qr-code-scan', 'Track Collection', 'Watch your collector move through live status updates.'],
        ['bi-passport', 'Waste Passport', 'Every load gets a unique Waste ID with a full journey timeline.'],
        ['bi-globe-americas', 'Impact & Rewards', 'See estimated CO₂ avoided and earn reward points.'],
    ];
    foreach ($steps as $i => [$icon, $title, $text]): ?>
      <div class="col-md-4">
        <div class="step-card">
          <div class="d-flex align-items-center gap-2 mb-2">
            <span class="step-num"><?= $i + 1 ?></span><i class="text-pnv bi <?= $icon ?> fs-5"></i>
          </div>
          <h5 class="fw-bold"><?= e($title) ?></h5>
          <p class="text-muted small mb-0"><?= e($text) ?></p>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <div class="text-center mt-4"><a class="btn btn-outline-pnv px-4" href="<?= url('how-it-works.php') ?>">See the full journey <i class="bi bi-arrow-right"></i></a></div>
</section>

<!-- ================= WASTE PASSPORT FEATURE ================= -->
<section class="py-5 reveal" style="background:#fff">
  <div class="container">
    <div class="row align-items-center g-4">
      <div class="col-lg-6">
        <div class="section-eyebrow mb-1">Our USP</div>
        <h2 class="fw-bold mb-3">The <span class="text-pnv">Waste Passport</span></h2>
        <p class="text-muted">Waste is usually invisible after the bin. PUNARVA gives every collected load a
          <strong>unique Waste ID</strong> — like a passport — that records its complete journey: identified, collected,
          sorted, processed and finally recycled, composted or recovered.</p>
        <ul class="list-unstyled d-grid gap-2 small">
          <li><i class="text-pnv bi bi-check-circle-fill me-2"></i>Unique ID: <code>PNV-2026-000001</code></li>
          <li><i class="text-pnv bi bi-check-circle-fill me-2"></i>Timeline of every stage with time, place and responsible party</li>
          <li><i class="text-pnv bi bi-check-circle-fill me-2"></i>Public QR tracking — no private data exposed</li>
          <li><i class="text-pnv bi bi-check-circle-fill me-2"></i>Estimated environmental impact attached to every passport</li>
        </ul>
        <div class="d-flex flex-wrap gap-2 mt-3">
          <?php foreach ($recentPassports as $rp): ?>
            <a class="text-pnv-dark badge text-bg-light border p-2" href="<?= url('track.php?id=' . urlencode($rp['waste_id'])) ?>">
              <span class="dot" style="background:<?= e($rp['color']) ?>"></span><?= e($rp['waste_id']) ?> · <?= e(WASTE_STAGE_LABELS[$rp['current_stage']] ?? '') ?>
            </a>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="passport mx-auto" style="max-width:460px">
          <div class="passport-head">
            <div class="passport-stamp"><i class="bi bi-patch-check-fill"></i><span>Verified</span></div>
            <div class="passport-title">Waste Passport</div>
            <div class="passport-waste-id mt-2"><?= e($recentPassports[0]['waste_id'] ?? 'PNV-2026-000001') ?></div>
            <div class="small mt-2 opacity-75">Category: <?= e($recentPassports[0]['category'] ?? 'Plastic') ?> · Public tracking enabled</div>
          </div>
          <div class="passport-body">
            <div class="passport-meta mb-3">
              <div><div class="meta-label">Origin</div><div class="meta-value">Citizen · Ward</div></div>
              <div><div class="meta-label">Current Status</div><div class="text-pnv meta-value"><?= e(WASTE_STAGE_LABELS[$recentPassports[0]['current_stage']] ?? 'Recycled') ?></div></div>
            </div>
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
              <div class="small text-muted">Scan to track publicly<br><span class="badge text-bg-success mt-1">No personal data exposed</span></div>
              <div class="qr-box" data-qr="<?= e(absolute_url('track.php?id=' . urlencode($recentPassports[0]['waste_id'] ?? 'PNV-2026-000001'))) ?>" data-size="110"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ================= CATEGORIES ================= -->
<section class="container py-5 reveal">
  <div class="text-center mb-4">
    <div class="section-eyebrow">Know your bins</div>
    <h2 class="fw-bold">Waste categories & segregation</h2>
    <p class="text-muted small">Managed by the municipality — always up to date from the database.</p>
  </div>
  <div class="row g-3">
    <?php foreach (array_slice($categories, 0, 8) as $c): ?>
      <div class="col-6 col-md-3">
        <a class="category-chip justify-content-between text-decoration-none h-100" style="background:<?= e($c['color']) ?>" href="<?= url('waste-guide.php#cat-' . e($c['code'])) ?>">
          <span><i class="bi <?= e(pnv_cat_icon((string) $c['code'], (string) ($c['icon'] ?? ''))) ?> fs-5"></i> <?= e($c['name']) ?></span>
          <i class="bi bi-arrow-right"></i>
        </a>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ================= WHY PUNARVA ================= -->
<section class="py-5 reveal" style="background:#fff">
  <div class="container">
    <div class="text-center mb-4">
      <div class="section-eyebrow"><?= t('brand.why_eyebrow') ?></div>
      <h2 class="fw-bold"><?= t('brand.why_title') ?></h2>
    </div>
    <div class="flow-band d-flex flex-wrap justify-content-center align-items-center gap-2 mb-4">
      <span class="flow-chip bad"><i class="bi bi-exclamation-triangle-fill me-1"></i><?= t('brand.flow_c1') ?></span>
      <i class="bi bi-arrow-right flow-arr d-none d-md-inline" aria-hidden="true"></i>
      <span class="flow-chip bad"><?= t('brand.flow_c2') ?></span>
      <i class="bi bi-arrow-right flow-arr d-none d-md-inline" aria-hidden="true"></i>
      <span class="flow-chip bad"><?= t('brand.flow_c3') ?></span>
      <i class="bi bi-arrow-right flow-arr d-none d-md-inline" aria-hidden="true"></i>
      <span class="flow-chip pnv"><i class="bi bi-recycle me-1"></i><strong>PUNARVA</strong></span>
      <i class="bi bi-arrow-right flow-arr d-none d-md-inline" aria-hidden="true"></i>
      <span class="flow-chip good"><?= t('brand.flow_s1') ?></span>
      <i class="bi bi-arrow-right flow-arr d-none d-md-inline" aria-hidden="true"></i>
      <span class="flow-chip good gold"><?= t('brand.flow_s2') ?></span>
    </div>
    <div class="row g-3">
      <div class="col-lg-6">
        <div class="card h-100 p-4 why-card">
          <div class="fw-bold mb-3"><i class="bi bi-search me-2" style="color:#c98a12"></i><?= t('brand.ch_t') ?></div>
          <ul class="list-unstyled d-grid gap-2 small mb-0">
            <?php foreach (['brand.ch1','brand.ch2','brand.ch3','brand.ch4','brand.ch5','brand.ch6'] as $k): ?>
              <li><i class="bi bi-dash-circle-fill me-2" style="color:#c98a12"></i><?= t($k) ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="card h-100 p-4 why-card">
          <div class="fw-bold mb-3"><i class="text-pnv bi bi-recycle me-2"></i><?= t('brand.an_t') ?></div>
          <ul class="list-unstyled d-grid gap-2 small mb-0">
            <?php foreach (['brand.an1','brand.an2','brand.an3','brand.an4','brand.an5','brand.an6'] as $k): ?>
              <li><i class="text-pnv bi bi-check-circle-fill me-2"></i><?= t($k) ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ================= VISION & MISSION ================= -->
<section class="container py-5 reveal">
  <div class="row g-4">
    <div class="col-lg-6">
      <div class="card h-100 p-4 vm-card">
        <span class="j-dot mb-3"><i class="bi bi-eye"></i></span>
        <h3 class="fw-bold mb-2"><?= t('brand.vision_t') ?></h3>
        <p class="text-muted mb-0"><?= t('brand.vision_d') ?></p>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="card h-100 p-4 vm-card vm-mission">
        <span class="j-dot mb-3" style="border-color:#c98a12;color:#c98a12"><i class="bi bi-bullseye"></i></span>
        <h3 class="fw-bold mb-2"><?= t('brand.mission_t') ?></h3>
        <p class="text-muted mb-0"><?= t('brand.mission_d') ?></p>
      </div>
    </div>
  </div>
</section>

<!-- ================= IMPACT + CTA ================= -->
<section class="py-5 reveal" style="background:linear-gradient(160deg,#0b3b28,var(--pnv-green-dark));color:#e8f5ec">
  <div class="container">
    <div class="row g-4 align-items-center">
      <div class="col-lg-8">
        <h3 class="fw-bold">Ready to turn your waste into worth?</h3>
        <p class="mb-1 opacity-75">Join <?= fmt_num($stats['users']) ?> users · <?= fmt_num($facilities) ?> active recycling facilities ·
          <?= fmt_num($stats['reports']) ?> reported hotspots resolved</p>
        <p class="small opacity-75">Estimated community impact so far: <strong><?= number_format((float) $impact['co2'], 1) ?> kg CO₂e avoided</strong>,
          <strong><?= number_format((float) $impact['water']) ?> L water saved</strong> — always labelled as <em>estimated impact</em>.</p>
      </div>
      <div class="col-lg-4 text-lg-end">
        <a class="btn btn-pnv btn-lg px-4" href="<?= url('register.php') ?>">Join PUNARVA <i class="bi bi-arrow-right"></i></a>
        <a class="btn btn-outline-light btn-lg px-4 ms-lg-2 mt-2 mt-lg-0" href="<?= url('login.php') ?>">Log in</a>
      </div>
    </div>
  </div>
</section>

<?php view('layouts/public_footer'); ?>
