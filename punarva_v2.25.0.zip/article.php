<?php
require_once __DIR__ . '/includes/init.php';
$slug = (string) get_val('slug', '');
$article = Database::one('SELECT a.*, u.name AS author FROM articles a LEFT JOIN users u ON u.id = a.author_id WHERE a.slug = ? AND a.status = "PUBLISHED"', [$slug]);
if (!$article) { http_response_code(404); include __DIR__ . '/404.php'; exit; }
Database::run('UPDATE articles SET views = views + 1 WHERE id = ?', [$article['id']]);
$pageTitle = $article['title']; $activeNav = 'learn';
view('layouts/public_header', compact('pageTitle', 'activeNav'));
?>
<section class="py-5">
  <div class="container" style="max-width:820px">
    <nav aria-label="breadcrumb"><ol class="breadcrumb small">
      <li class="breadcrumb-item"><a href="<?= url('learn.php') ?>">Learning Center</a></li>
      <li class="breadcrumb-item active"><?= e($article['topic']) ?></li></ol></nav>
    <span class="badge text-bg-light border mb-2"><?= e($article['topic']) ?></span>
    <h1 class="text-pnv-dark fw-bold"><?= e($article['title']) ?></h1>
    <div class="text-muted small mb-4">By <?= e($article['author'] ?? 'PUNARVA Team') ?> · <?= fmt_dt($article['created_at'], 'd F Y') ?></div>
    <div class="article-content"><?= nl2br(e($article['content'])) ?></div>
    <hr class="my-4">
    <a class="btn btn-outline-pnv" href="<?= url('learn.php') ?>"><i class="bi bi-arrow-left me-1"></i>All articles</a>
    <a class="btn btn-pnv ms-2" href="<?= url('citizen/scanner.php') ?>"><i class="bi bi-stars me-1"></i>Try the Waste Scanner</a>
  </div>
</section>
<?php view('layouts/public_footer');
