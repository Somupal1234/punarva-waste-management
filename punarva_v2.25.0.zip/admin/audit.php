<?php
/**
 * Admin → Audit Logs (v2.16.0 — professional municipal-grade audit trail).
 * Read-only by design: there is no edit/delete UI and audit rows are append-only.
 * Filters, search, server-side pagination (25/50/100), human-readable labels,
 * a details modal and CSV/PDF exports (admin/audit-export.php) — everything
 * enforced server-side with prepared statements. No secrets are ever rendered.
 */
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_ADMIN);
$pageTitle = 'Audit Logs'; $activeMenu = 'audit';

$f = audit_filters();
$baseFrom = 'admin/audit.php';

$total = (int) Database::val(
    "SELECT COUNT(*) FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE {$f['where']}",
    $f['params']);
$pg = paginate_request($total, $f['per']);
$shownFrom = $total ? $pg['offset'] + 1 : 0;
$shownTo = min($pg['offset'] + $pg['limit'], $total);

$rows = Database::all(
    "SELECT a.*, u.name AS user_name, u.email AS user_email, r.name AS user_role
     FROM audit_logs a
     LEFT JOIN users u ON u.id = a.user_id
     LEFT JOIN roles r ON r.id = u.role_id
     WHERE {$f['where']}
     ORDER BY a.created_at DESC, a.id DESC
     LIMIT {$pg['limit']} OFFSET {$pg['offset']}",
    $f['params']);

$modules = Database::all('SELECT DISTINCT module FROM audit_logs ORDER BY module');
$users = Database::all('SELECT DISTINCT u.id, u.name FROM audit_logs a JOIN users u ON u.id = a.user_id ORDER BY u.name');
// Action dropdown = readable CATEGORIES only (mapping only — history untouched);
// a category is listed when at least one of its events actually exists in the audit table.
$existingActions = array_column(Database::all('SELECT DISTINCT action FROM audit_logs'), 'action');
$actCats = [];
foreach (audit_action_categories() as $k => $c) {
    if (array_intersect($c['actions'], $existingActions)) $actCats[$k] = $c;
}

require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<h1 class="h4 fw-bold mb-1"><i class="text-pnv bi bi-clipboard-data me-2"></i>Audit Logs</h1>
<p class="text-muted small mb-3">Complete, tamper-evident activity trail — read-only and append-only by design. Sensitive values are never displayed.</p>

<div class="card mb-3">
  <div class="card-body py-3">
    <form method="get" action="<?= url($baseFrom) ?>" id="auditFilterForm">
      <div class="row g-2">
        <div class="col-6 col-md-3">
          <label class="form-label small fw-semibold mb-1" for="f_module">Module</label>
          <select name="module" id="f_module" class="form-select form-select-sm">
            <option value="">All Modules</option>
            <?php foreach ($modules as $m): ?><option value="<?= e($m['module']) ?>" <?= $f['mod'] === $m['module'] ? 'selected' : '' ?>><?= e(audit_module_label($m['module'])) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-6 col-md-3">
          <label class="form-label small fw-semibold mb-1" for="f_action">Action</label>
          <select name="action" id="f_action" class="form-select form-select-sm">
            <option value="">All Actions</option>
            <?php foreach ($actCats as $k => $c): ?><option value="<?= e($k) ?>" <?= $f['act'] === $k ? 'selected' : '' ?>><?= e($c['label']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-6 col-md-3">
          <label class="form-label small fw-semibold mb-1" for="f_user">User</label>
          <select name="user" id="f_user" class="form-select form-select-sm">
            <option value="">All Users</option>
            <option value="none" <?= $f['uid'] === 'none' ? 'selected' : '' ?>>system</option>
            <?php foreach ($users as $u): ?><option value="<?= (int) $u['id'] ?>" <?= $f['uid'] === (string) $u['id'] ? 'selected' : '' ?>><?= e($u['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-6 col-md-3">
          <label class="form-label small fw-semibold mb-1" for="f_range">Date Range</label>
          <select name="range" id="f_range" class="form-select form-select-sm">
            <option value="">Any Time</option>
            <option value="today" <?= $f['range'] === 'today' ? 'selected' : '' ?>>Today</option>
            <option value="7" <?= $f['range'] === '7' ? 'selected' : '' ?>>Last 7 Days</option>
            <option value="30" <?= $f['range'] === '30' ? 'selected' : '' ?>>Last 30 Days</option>
            <option value="custom" <?= $f['range'] === 'custom' ? 'selected' : '' ?>>Custom Range</option>
          </select>
        </div>
      </div>
      <div class="row g-2 mt-0 <?= $f['range'] === 'custom' ? '' : 'd-none' ?>" id="customRangeRow">
        <div class="col-6 col-md-3">
          <label class="form-label small fw-semibold mb-1" for="f_from">From</label>
          <input type="date" name="from" id="f_from" value="<?= e($f['from']) ?>" class="form-control form-control-sm">
        </div>
        <div class="col-6 col-md-3">
          <label class="form-label small fw-semibold mb-1" for="f_to">To</label>
          <input type="date" name="to" id="f_to" value="<?= e($f['to']) ?>" class="form-control form-control-sm">
        </div>
      </div>
      <div class="row g-2 mt-0">
        <div class="col-md-7 col-lg-8">
          <label class="form-label small fw-semibold mb-1" for="f_q">Search</label>
          <input name="q" id="f_q" value="<?= e($f['q']) ?>" class="form-control form-control-sm" placeholder="Search user, action, module, record or reference…" maxlength="100">
        </div>
        <div class="col-md-5 col-lg-4 d-flex align-items-end gap-2">
          <button class="btn btn-sm btn-pnv px-4">Search</button>
          <a class="btn btn-sm btn-outline-secondary" href="<?= url($baseFrom) ?>">Reset</a>
        </div>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
    <span><i class="text-pnv bi bi-journal-text me-2"></i>Activity trail
      <span class="badge text-bg-light border ms-1"><?= number_format((float) $total) ?></span></span>
    <div class="d-flex gap-2 align-items-center flex-wrap">
      <a class="btn btn-sm btn-outline-secondary" href="<?= e(url('admin/audit-export.php?format=csv&' . http_build_query(array_filter($_GET, fn($v) => $v !== '', ARRAY_FILTER_USE_BOTH)))) ?>"><i class="bi bi-filetype-csv me-1"></i>Export CSV</a>
      <a class="btn btn-sm btn-outline-danger" href="<?= e(url('admin/audit-export.php?format=pdf&' . http_build_query(array_filter($_GET, fn($v) => $v !== '', ARRAY_FILTER_USE_BOTH)))) ?>"><i class="bi bi-filetype-pdf me-1"></i>Export PDF</a>
    </div>
  </div>
  <div class="card-body py-2">
    <div class="small text-muted mb-2 d-flex justify-content-between flex-wrap gap-2">
      <span>Showing <?= $shownFrom ?>–<?= $shownTo ?> of <?= number_format((float) $total) ?></span>
      <span class="d-inline-flex align-items-center gap-1">Rows per page:
        <?php foreach ([25, 50, 100] as $pp): $qs = http_build_query(array_merge($_GET, ['per' => $pp, 'page' => 1])); ?>
          <a class="btn btn-sm py-0 px-2 <?= $f['per'] === $pp ? 'btn-pnv' : 'btn-outline-secondary' ?>" href="?<?= e($qs) ?>"><?= $pp ?></a>
        <?php endforeach; ?>
      </span>
    </div>
    <?php if (!$rows): ?>
      <div class="empty-state py-4"><i class="bi bi-inbox"></i><div class="mt-2">No audit entries match the selected filters.</div></div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-hover table-sm align-middle small">
          <thead><tr><th>Time</th><th>User</th><th>Action</th><th>Module</th><th>Record</th><th>Details</th><th>IP Address</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($rows as $a):
              $isSystem = $a['user_id'] === null;
              $userLabel = $isSystem ? 'system' : ($a['user_name'] ?? 'Deleted/Unavailable User');
              $roleLabel = $isSystem ? '' : (string) ($a['user_role'] ?? '');
              $pairs = audit_details_pairs($a['old_value'], $a['new_value']);
              $detail = [
                  'action' => audit_action_label($a['action']), 'code' => $a['action'],
                  'module' => audit_module_label($a['module']), 'record' => $a['record_id'] !== null ? '#' . (int) $a['record_id'] : '—',
                  'user' => $userLabel, 'role' => $roleLabel !== '' ? $roleLabel : ($isSystem ? 'System' : '—'),
                  'time' => fmt_dt($a['created_at'], 'd M Y, H:i'), 'ip' => audit_display_ip($a['ip']),
                  'pairs' => $pairs,
              ];
          ?>
            <tr>
              <td class="text-nowrap"><?= fmt_dt($a['created_at'], 'd M Y, H:i') ?></td>
              <td>
                <?php if ($isSystem): ?><span class="badge text-bg-light border">system</span>
                <?php else: ?><strong><?= e($userLabel) ?></strong>
                  <div class="text-muted" style="font-size:.72rem"><?= e($roleLabel !== '' ? $roleLabel : ($a['user_email'] ?? '')) ?></div>
                <?php endif; ?>
              </td>
              <td><span class="badge text-bg-light border"><?= e(audit_action_label($a['action'])) ?></span></td>
              <td><?= e(audit_module_label($a['module'])) ?></td>
              <td><?= $a['record_id'] !== null ? '#' . (int) $a['record_id'] : '—' ?></td>
              <td style="max-width:260px"><?= e(audit_details_summary($a['old_value'], $a['new_value'])) ?></td>
              <td class="text-muted text-nowrap"><?= e(audit_display_ip($a['ip'])) ?></td>
              <td><button type="button" class="btn btn-sm btn-outline-secondary py-0" data-ud="<?= e(json_encode($detail, JSON_UNESCAPED_UNICODE)) ?>">View Details</button></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?= pagination_links($pg) ?>
    <?php endif; ?>
  </div>
</div>

<div class="modal fade" id="auditDetailModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header py-2">
        <h6 class="modal-title fw-bold"><i class="text-pnv bi bi-card-checklist me-2"></i>Audit entry details</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="auditDetailBody"></div>
      <div class="modal-footer py-2">
        <span class="small text-muted me-auto"><i class="bi bi-shield-lock me-1"></i>Secrets are redacted automatically — audit entries are read-only.</span>
        <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?php
$pageScripts = <<<'HTML'
<script>
// Date Range = Custom Range → From/To appear; otherwise hidden (v2.17.0)
document.getElementById('f_range').addEventListener('change', function () {
  document.getElementById('customRangeRow').classList.toggle('d-none', this.value !== 'custom');
});
document.addEventListener('click', function (e) {
  const b = e.target.closest('[data-ud]');
  if (!b) return;
  let d;
  try { d = JSON.parse(b.getAttribute('data-ud')); } catch (err) { return; }
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const rows = [
    ['Action', d.action + ' <span class="badge text-bg-light border ms-1" style="font-size:.68rem">' + esc(d.code) + '</span>'],
    ['Module', esc(d.module)], ['Record', esc(d.record)], ['User', esc(d.user)], ['Role', esc(d.role)],
    ['Date / time', esc(d.time)], ['IP address', esc(d.ip)],
  ];
  let html = '<div class="row g-2 small">';
  rows.forEach(([k, v]) => {
    html += '<div class="col-md-6"><div class="border rounded-3 p-2 h-100"><div class="text-muted fw-bold text-uppercase" style="font-size:.68rem">' + k + '</div><div>' + v + '</div></div></div>';
  });
  html += '</div>';
  if (d.pairs && d.pairs.length) {
    html += '<h6 class="fw-bold small text-uppercase text-muted mt-3 mb-1">Reference / metadata</h6><div class="border rounded-3 p-2 small">';
    d.pairs.forEach((p) => {
      const i = p.indexOf(': ');
      const k = i > 0 ? p.slice(0, i) : '';
      const v = i > 0 ? p.slice(i + 2) : p;
      html += '<div class="d-flex gap-2 border-bottom py-1"><span class="fw-semibold text-muted" style="min-width:130px">' + esc(k) + '</span><span class="text-break">' + esc(v) + '</span></div>';
    });
    html += '</div>';
  }
  document.getElementById('auditDetailBody').innerHTML = html;
  new bootstrap.Modal(document.getElementById('auditDetailModal')).show();
});
</script>
HTML;
require dirname(__DIR__) . '/views/layouts/dash_footer.php';
