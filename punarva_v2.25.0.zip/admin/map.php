<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_ADMIN);
$pageTitle = 'Live Map'; $activeMenu = 'map';
$facilities = Database::all('SELECT id, name, facility_type, latitude, longitude, city FROM facilities WHERE status = "ACTIVE"');
$reports = Database::all('SELECT id, report_code, description, latitude, longitude, status, ward, image_path, created_at, category_id FROM waste_reports WHERE latitude IS NOT NULL');
$reportCategories = [];
foreach (Database::all('SELECT id, name FROM waste_categories') as $rc) $reportCategories[(int) $rc['id']] = $rc['name'];
$pickups = Database::all('SELECT pr.id, pr.pickup_code, pr.latitude, pr.longitude, pr.status FROM pickup_requests pr WHERE pr.latitude IS NOT NULL AND pr.status IN ("REQUESTED","ASSIGNED","ACCEPTED","ON_THE_WAY","ARRIVED")');
$waste = Database::all('SELECT id, waste_id, latitude, longitude, current_stage FROM waste_transactions WHERE latitude IS NOT NULL');
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="card">
  <div class="card-header d-flex align-items-center flex-wrap gap-3">
    <i class="text-pnv bi bi-map me-1"></i>Live operations map
    <span class="badge rounded-pill text-bg-light border ms-2" id="trucksInfo"><i class="bi bi-truck me-1"></i>Trucks: —</span>
    <span class="ms-auto d-flex gap-3 small flex-wrap">
      <label class="form-check m-0"><input class="form-check-input layer" type="checkbox" value="trucks" checked><span class="legend-dot" style="background:#0e7a4f"></span>🚛 Active Trucks</label>
      <label class="form-check m-0"><input class="form-check-input layer" type="checkbox" value="routes" checked><span class="legend-dot" style="background:#6f42c1"></span>Routes</label>
      <label class="form-check m-0"><input class="form-check-input layer" type="checkbox" value="facilities" checked><span class="legend-dot" style="background:#0b7285"></span>Facilities</label>
      <label class="form-check m-0"><input class="form-check-input layer" type="checkbox" value="reports" checked><span class="legend-dot" style="background:#c0392b"></span>Reports</label>
      <select id="reportFilter" class="form-select form-select-sm d-inline-block w-auto" aria-label="Filter reports by status">
        <option value="">All reports</option>
        <option value="SUBMITTED">Submitted (Pending)</option>
        <option value="VERIFIED">Verified</option>
        <option value="ASSIGNED">Assigned</option>
        <option value="IN_PROGRESS">In Progress</option>
        <option value="RESOLVED">Resolved</option>
        <option value="REJECTED">Rejected</option>
      </select>
      <label class="form-check m-0"><input class="form-check-input layer" type="checkbox" value="pickups" checked><span class="legend-dot" style="background:#1b6ca8"></span>Pickups</label>
      <label class="form-check m-0"><input class="form-check-input layer" type="checkbox" value="waste"><span class="legend-dot" style="background:#0e7a4f"></span>Waste origins</label>
    </span>
  </div>
  <div class="card-body">
    <div id="opsMap" class="map-box" style="height:520px"></div>
    <div class="small text-muted mt-2">All markers come live from database coordinates — nothing is hard-coded.</div>
  </div>
</div>
<?php $layerData = [
  'facilities' => array_map(fn($f) => ['lat' => $f['latitude'], 'lng' => $f['longitude'], 'title' => $f['name'], 'html' => e($f['facility_type'] . ' · ' . $f['city']), 'color' => 'teal', 'glyph' => 'bi-buildings'], $facilities),
  'reports' => array_map(function ($r) use ($reportCategories) {
        $thumb = $r['image_path'] ? upload_url($r['image_path']) : null;
        $html = '<div style="min-width:180px">'
              . ($thumb ? '<img src="' . e($thumb) . '" alt="Report photo" style="width:100%;height:90px;object-fit:cover;border-radius:6px;margin-bottom:6px">' : '')
              . '<strong>' . e($r['report_code']) . '</strong> · ' . e($r['status']) . '<br>'
              . '<small>' . e($reportCategories[(int) $r['category_id']] ?? '') . '</small><br>'
              . '<small>' . e(mb_strimwidth((string) $r['description'], 0, 70, '…')) . '</small><br>'
              . '<small class="text-muted">' . e($r['ward'] ? ('Ward ' . $r['ward'] . ' · ') : '') . fmt_dt($r['created_at'], 'd M, h:i A') . '</small></div>';
        return ['lat' => $r['latitude'], 'lng' => $r['longitude'], 'title' => $r['report_code'], 'html' => $html,
                'color' => $r['status'] === 'RESOLVED' ? 'green' : ($r['status'] === 'REJECTED' ? 'grey' : 'red'), 'glyph' => 'bi-exclamation-triangle-fill', 'status' => $r['status']];
    }, $reports),
  'pickups' => array_map(fn($p) => ['lat' => $p['latitude'], 'lng' => $p['longitude'], 'title' => $p['pickup_code'], 'html' => e(PICKUP_STATUS_LABELS[$p['status']]), 'color' => 'blue', 'glyph' => 'bi-truck'], $pickups),
  'waste' => array_map(fn($w) => ['lat' => $w['latitude'], 'lng' => $w['longitude'], 'title' => $w['waste_id'], 'html' => e(WASTE_STAGE_LABELS[$w['current_stage']]), 'color' => 'green', 'glyph' => 'bi-passport'], $waste),
];
$pageScripts = '<script>
const layers = ' . json_encode($layerData) . ';
let map = pnvMap("opsMap", { fitAll: true, zoom: 12 });
const group = L.layerGroup().addTo(map);        // static/demo layers
const truckGroup = L.layerGroup().addTo(map);   // animated live trucks
const routeGroup = L.layerGroup().addTo(map);   // shift route polylines
const truckMarkers = new Map();                 // vehicle_id -> {marker, pos, tgt, heading, anim}

const TRUCK_SVG = `<svg viewBox="0 0 40 24" width="34" height="20" xmlns="http://www.w3.org/2000/svg">
  <rect x="1" y="3" width="22" height="14" rx="2" fill="#0e7a4f" stroke="#fff" stroke-width="1.5"/>
  <rect x="24" y="7" width="9" height="10" rx="1.5" fill="#0b6b45" stroke="#fff" stroke-width="1.5"/>
  <rect x="26" y="9" width="5" height="4" rx="0.5" fill="#cfe9ff"/>
  <rect x="2" y="4.5" width="8" height="5" rx="1" fill="#a5d6a7" opacity="0.85"/>
  <circle cx="8" cy="19" r="3.4" fill="#333" stroke="#fff" stroke-width="1.4"/>
  <circle cx="29" cy="19" r="3.4" fill="#333" stroke="#fff" stroke-width="1.4"/>
</svg>`;
function truckIcon(state, heading) {
  const ring = state === "LIVE" ? "#2ecc71" : (state === "UPDATING" ? "#f1c40f" : "#e74c3c");
  return L.divIcon({
    className: "",
    html: `<div class="pnv-truck ${state.toLowerCase()}"><span class="pnv-truck-ring" style="border-color:${ring}"></span>
           <span class="pnv-truck-body" style="transform:rotate(${heading || 0}deg)">${TRUCK_SVG}</span></div>`,
    iconSize: [46, 46], iconAnchor: [23, 23], popupAnchor: [0, -20],
  });
}
function fmtAgo(iso) {
  if (!iso) return "—";
  const s = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 5) return "just now";
  if (s < 60) return s + " seconds ago";
  const m = Math.floor(s / 60); return m + " min " + (s % 60) + " s ago";
}
function popupHtml(t) {
  return `<div style="min-width:190px"><strong>🚛 ${t.vehicle}</strong><br>
    <small>Driver: <strong>${t.driver}</strong><br>
    Status: <span class="badge text-bg-${t.state === "LIVE" ? "success" : (t.state === "UPDATING" ? "warning text-dark" : "danger")}">${t.state}</span><br>
    Speed: ${t.speed != null ? (t.speed * 3.6).toFixed(0) + " km/h" : "—"}<br>
    GPS accuracy: ${t.accuracy != null ? Math.round(t.accuracy) + " m" : "—"}<br>
    Last updated: <span data-ago="${t.last_ping_at || ""}">${fmtAgo(t.last_ping_at)}</span><br>
    Shift start: ${new Date(String(t.started_at).replace(" ", "T")).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</small><br>
    <button class="btn btn-sm btn-outline-secondary mt-2 pnv-route-btn" data-shift="${t.shift_id}">View route</button></div>`;
}
function animateTruck(entry, lat, lng, heading) {
  entry.tgt = { lat, lng, heading };
  if (!entry.pos) { entry.pos = { lat, lng, heading }; entry.marker.setLatLng([lat, lng]); return; }
  if (entry.raf) return;
  const from = { ...entry.pos };
  const t0 = performance.now(), DUR = 2400; // smooth 2.4s glide — no jumping
  function step(now) {
    const k = Math.min(1, (now - t0) / DUR);
    const e = 1 - Math.pow(1 - k, 3); // ease-out cubic
    const p = { lat: from.lat + (entry.tgt.lat - from.lat) * e, lng: from.lng + (entry.tgt.lng - from.lng) * e };
    // heading: follow movement bearing when reliable; otherwise retain previous heading
    if (entry.tgt.heading != null) entry.pos.heading = entry.tgt.heading;
    else if (Math.abs(entry.tgt.lat - from.lat) + Math.abs(entry.tgt.lng - from.lng) > 1e-5) {
      const y = Math.sin((entry.tgt.lng - from.lng) * Math.PI / 180) * Math.cos(entry.tgt.lat * Math.PI / 180);
      const x = Math.cos(from.lat * Math.PI / 180) * Math.sin(entry.tgt.lat * Math.PI / 180) - Math.sin(from.lat * Math.PI / 180) * Math.cos(entry.tgt.lat * Math.PI / 180) * Math.cos((entry.tgt.lng - from.lng) * Math.PI / 180);
      entry.pos.heading = (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
    }
    entry.pos.lat = p.lat; entry.pos.lng = p.lng;
    entry.marker.setLatLng([p.lat, p.lng]);
    const body = entry.marker.getElement() && entry.marker.getElement().querySelector(".pnv-truck-body");
    if (body) body.style.transform = `rotate(${entry.pos.heading || 0}deg)`;
    if (k < 1) entry.raf = requestAnimationFrame(step);
    else { entry.raf = null; }
  }
  entry.raf = requestAnimationFrame(step);
}
async function refreshTrucks() {
  try {
    const out = await pnvApi("' . e(url('api/admin/tracking.php')) . '?action=active");
    if (!out.success) return;
    const trucks = (out.data && out.data.trucks) || [];
    document.getElementById("trucksInfo").innerHTML = `<i class="bi bi-truck me-1"></i>Trucks: ${trucks.filter(t => t.state === "LIVE").length} live / ${trucks.length} on duty`;
    const seen = new Set();
    trucks.forEach((t) => {
      seen.add(String(t.vehicle_id));
      if (t.lat == null || t.lng == null) return;
      let entry = truckMarkers.get(String(t.vehicle_id));
      if (!entry) {
        const marker = L.marker([t.lat, t.lng], { icon: truckIcon(t.state, t.heading) }).bindPopup(popupHtml(t));
        marker.addTo(truckGroup);
        entry = { marker, pos: null, tgt: null, heading: t.heading, raf: null };
        truckMarkers.set(String(t.vehicle_id), entry);
      }
      entry.marker.setIcon(truckIcon(t.state, t.heading));
      entry.marker.getPopup().setContent(popupHtml(t));
      animateTruck(entry, t.lat, t.lng, t.heading);
    });
    // remove ended trucks
    for (const [vid, entry] of truckMarkers) {
      if (!seen.has(vid)) { truckGroup.removeLayer(entry.marker); truckMarkers.delete(vid); }
    }
    if (routeShifts.size) { /* routes stay as drawn */ }
  } catch (e) { /* transient network issues must not break the page */ }
}
const routeShifts = new Set();
document.addEventListener("click", async (e) => {
  const btn = e.target.closest(".pnv-route-btn");
  if (!btn) return;
  const shiftId = btn.dataset.shift;
  if (routeShifts.has(shiftId)) return;
  try {
    const out = await pnvApi("' . e(url('api/admin/tracking.php')) . '?action=route&shift_id=" + encodeURIComponent(shiftId));
    if (!out.success) { alert(out.message || "Could not load route."); return; }
    const pts = (out.data.points || []).map(p => [p.lat, p.lng]);
    if (pts.length < 2) { alert("Not enough route points recorded yet for this shift."); return; }
    const line = L.polyline(pts, { color: "#6f42c1", weight: 4, opacity: 0.85 }).bindPopup(`<strong>Route — ${out.data.vehicle}</strong><br><small>${out.data.driver} · ${pts.length} GPS points</small>`);
    const startM = L.circleMarker(pts[0], { radius: 7, color: "#1b6ca8", fillOpacity: 1 }).bindPopup("Shift start");
    const endM = L.circleMarker(pts[pts.length - 1], { radius: 7, color: "#e67e22", fillOpacity: 1 }).bindPopup("Latest position");
    const lg = L.layerGroup([line, startM, endM]).addTo(routeGroup);
    routeShifts.set(shiftId, lg);
    if (!document.querySelector(".layer[value=\"routes\"]").checked) lg.remove();
    map.fitBounds(line.getBounds(), { padding: [30, 30] });
  } catch (err) { alert("Could not load route."); }
});

const staticRender = (function () {
  function render() {
    group.clearLayers();
    let bounds = [];
    const reportFilter = document.getElementById("reportFilter");
    const rf = reportFilter ? reportFilter.value : "";
    document.querySelectorAll(".layer:checked").forEach((cb) => {
      if (cb.value === "trucks" || cb.value === "routes") return; // live layers handled separately
      (layers[cb.value] || []).forEach((m) => {
        if (m.lat === null || m.lng === null || m.lat === "" || m.lng === "") return;
        if (cb.value === "reports" && rf && m.status !== rf) return;
        const mk = L.marker([Number(m.lat), Number(m.lng)], { icon: pnvIcon(PNV_MARKERS[m.color] || m.color, m.glyph) }).bindPopup(`<strong>${m.title}</strong><br>${m.html || ""}`);
        mk.addTo(group); bounds.push([Number(m.lat), Number(m.lng)]);
      });
    });
    if (bounds.length) map.fitBounds(bounds, { padding: [30, 30], maxZoom: 15 });
  }
  return render;
})();
document.querySelectorAll(".layer").forEach((cb) => cb.addEventListener("change", () => {
  if (cb.value === "trucks") truckGroup[cb.checked ? "addTo" : "removeFrom"](map);
  if (cb.value === "routes") routeGroup[cb.checked ? "addTo" : "removeFrom"](map);
  staticRender();
}));
const rfEl = document.getElementById("reportFilter");
if (rfEl) rfEl.addEventListener("change", staticRender);
staticRender();
if (!document.querySelector(".layer[value=\"trucks\"]").checked) map.removeLayer(truckGroup);
refreshTrucks();
setInterval(refreshTrucks, 10000); // lightweight JSON — no page reloads
setInterval(() => { document.querySelectorAll("[data-ago]").forEach((el) => { if (el.dataset.ago) el.textContent = fmtAgo(el.dataset.ago.replace(" ", "T")); }); }, 5000);
</script>';
require dirname(__DIR__) . '/views/layouts/dash_footer.php';
