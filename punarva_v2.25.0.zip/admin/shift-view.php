<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once __DIR__ . '/../includes/shift_filters.php';
$user = require_role(ROLE_ADMIN);

// v2.9.0 — SHIFT DETAILS (Admin): one real shift, lightweight GPS summary + Leaflet trail.
$id = (int) get_val('id', 0);
$shift = Database::one(
    'SELECT ds.*, u.name AS driver_name, u.phone AS driver_phone,
            v.vehicle_number, v.vehicle_type, v.capacity_kg
     FROM driver_shifts ds
     JOIN users u ON u.id = ds.driver_user_id
     JOIN vehicles v ON v.id = ds.vehicle_id
     WHERE ds.id = ?',
    [$id]
);
if (!$shift) {
    flash('warning', 'Shift record not found.');
    redirect('admin/shifts.php');
}

// GPS summary only (no bulk coordinates in PHP table; trail fetched by map JS below)
$gps = [
    'points' => (int) Database::val('SELECT COUNT(*) FROM driver_locations WHERE shift_id = ?', [$id]),
    'first'  => Database::val('SELECT MIN(recorded_at) FROM driver_locations WHERE shift_id = ?', [$id]),
    'last'   => Database::val('SELECT MAX(recorded_at) FROM driver_locations WHERE shift_id = ?', [$id]),
    'last_acc' => Database::val('SELECT accuracy_m FROM driver_locations WHERE shift_id = ? ORDER BY id DESC LIMIT 1', [$id]),
];
$gpsStatus = $shift['status'] === 'ACTIVE' ? TrackingService::statusFor($shift['last_ping_at']) : (($gps['points'] || $shift['last_ping_at']) ? 'RECORDED' : 'NONE');

$pageTitle = 'Shift Details'; $activeMenu = 'shifts';
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="d-flex flex-wrap gap-2 align-items-center mb-3">
  <h1 class="h4 fw-bold mb-0 me-auto"><i class="text-pnv bi bi-clock-history me-2"></i>Shift Details <span class="text-muted">#<?= (int) $shift['id'] ?></span></h1>
  <a class="btn btn-pnv" href="<?= e(url('admin/shift-pdf.php?id=' . (int) $shift['id'])) ?>"><i class="bi bi-file-earmark-pdf me-1"></i>Download Shift PDF</a>
  <button class="btn btn-outline-secondary no-print" onclick="window.print()"><i class="bi bi-printer me-1"></i>Print</button>
  <a class="btn btn-outline-secondary no-print" href="<?= e(url('admin/shifts.php')) ?>"><i class="bi bi-arrow-left me-1"></i>Back</a>
</div>

<div class="row g-4">
  <div class="col-lg-5">
    <div class="card mb-3">
      <div class="card-header fw-bold"><i class="bi bi-info-circle me-2"></i>Shift Information</div>
      <div class="card-body p-0">
        <table class="table table-sm mb-0">
          <tbody>
            <tr><th class="text-muted w-25">Driver</th><td class="fw-semibold"><?= e($shift['driver_name']) ?></td></tr>
            <tr><th class="text-muted">Truck</th><td><?= e($shift['vehicle_number']) ?><?= $shift['vehicle_type'] ? ' · ' . e($shift['vehicle_type']) : '' ?></td></tr>
            <tr><th class="text-muted">Date</th><td><?= e(date('d F Y', strtotime($shift['started_at']))) ?></td></tr>
            <tr><th class="text-muted">Punch In</th><td><?= e(shift_time($shift['started_at'])) ?></td></tr>
            <tr><th class="text-muted">Punch Out</th><td><?= e(shift_time($shift['ended_at'])) ?></td></tr>
            <tr><th class="text-muted">Duration</th><td><?= e(shift_duration($shift['started_at'], $shift['ended_at'])) ?></td></tr>
            <tr><th class="text-muted">Status</th><td><?= $shift['status'] === 'ACTIVE' ? '<span class="badge text-bg-success">ACTIVE</span>' : '<span class="badge text-bg-secondary">ENDED</span>' ?></td></tr>
            <tr><th class="text-muted">GPS Status</th>
              <td><?= match ($gpsStatus) { 'LIVE' => '<span class="badge text-bg-success">LIVE</span>', 'UPDATING' => '<span class="badge text-bg-warning text-dark">STALE</span>', 'RECORDED' => '<span class="badge text-bg-info">RECORDED</span>', default => '<span class="badge text-bg-light border text-muted">UNAVAILABLE</span>' } ?></td></tr>
            <tr><th class="text-muted">Last GPS Update</th><td><?= $shift['last_ping_at'] ? e(shift_date($shift['last_ping_at']) . ', ' . shift_time($shift['last_ping_at'])) : '—' ?></td></tr>
            <tr><th class="text-muted">Punch-In Location</th><td><?= $gps['points'] ? '<span class="badge text-bg-light border">Available</span>' : '<span class="badge text-bg-light border text-muted">Not Available</span>' ?></td></tr>
            <tr><th class="text-muted">GPS Points</th><td><?= fmt_num($gps['points']) ?><?= $gps['last_acc'] !== null ? ' · last accuracy ' . e(rtrim(rtrim((string) round((float) $gps['last_acc'], 1), '0'), '.')) . ' m' : '' ?></td></tr>
            <tr><th class="text-muted">Trail Window</th><td class="small text-muted"><?= $gps['first'] ? e(shift_date($gps['first']) . ' ' . shift_time($gps['first']) . ' → ' . shift_time($gps['last'])) : '—' ?></td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="col-lg-7">
    <div class="card">
      <div class="card-header d-flex align-items-center fw-bold"><i class="bi bi-route me-2"></i>Tracking
        <span class="ms-auto small text-muted fw-normal d-none d-xxl-inline no-print">detailed interactive trail — kept on the web, not in the PDF</span>
      </div>
      <div class="card-body p-0">
        <?php if ($gps['points']): ?>
          <div id="shiftMap" style="height:420px" aria-label="Shift GPS route map"></div>
        <?php else: ?>
          <div class="empty-state py-5"><i class="bi bi-geo-slash"></i><div class="mt-1">No GPS trail recorded for this shift.</div></div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php if ($gps['points']):
$pageScripts = '<link rel="stylesheet" href="' . url('assets/vendor/leaflet/leaflet.css') . '">
<script src="' . url('assets/vendor/leaflet/leaflet.js') . '"></script>
<script>
(async function () {
  const res = await fetch(' . json_encode(url('api/admin/tracking.php') . '?action=route&shift_id=' . (int) $shift['id']) . ', { headers: { "Accept": "application/json" } });
  const out = await res.json();
  const pts = (out && out.data && out.data.points) || [];
  if (!pts.length) return;
  const map = L.map("shiftMap");
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "© OpenStreetMap" }).addTo(map);
  const line = pts.map(p => [p.lat, p.lng]);
  L.polyline(line, { color: "#6f42c1", weight: 3 }).addTo(map);
  L.circleMarker(line[0], { radius: 7, color: "#16a34a", fillOpacity: 1 }).addTo(map).bindTooltip("Punch in");
  L.circleMarker(line[line.length - 1], { radius: 7, color: "#dc2626", fillOpacity: 1 }).addTo(map).bindTooltip("Last fix");
  map.fitBounds(line, { padding: [24, 24] });
})();
</script>';
endif;
require dirname(__DIR__) . '/views/layouts/dash_footer.php';
