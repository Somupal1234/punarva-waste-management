<?php
/**
 * Admin — Waste Scan Log (ALL users, read-only). v2.14.0: scanner is manual;
 * historical AI rows are displayed as-is (labelled HISTORICAL, no confidence column).
 */
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_ADMIN);
$pageTitle = 'Waste Scan Log'; $activeMenu = 'ai-scans';

$status = (string) get_val('status', '');
$allowed = ['completed', 'failed', 'corrected'];
$where = $status !== '' && in_array($status, $allowed, true) ? 'WHERE ws.status = ?' : '';
$params = $where ? [$status] : [];

$scans = Database::all(
    "SELECT ws.*, u.name AS user_name, u.email AS user_email,
            wc.name AS category_name, cc.name AS corrected_name
     FROM waste_scans ws
     JOIN users u ON u.id = ws.user_id
     LEFT JOIN waste_categories wc ON wc.id = ws.category_id
     LEFT JOIN waste_categories cc ON cc.id = ws.corrected_category_id
     $where
     ORDER BY ws.created_at DESC LIMIT 200", $params);
$stats = Database::one("SELECT COUNT(*) AS total,
    SUM(status = 'completed') AS completed, SUM(status = 'corrected') AS corrected,
    SUM(status = 'failed') AS failed, SUM(provider = 'manual') AS manual_rows
    FROM waste_scans");
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="card">
  <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
    <span><i class="text-pnv bi bi-journal-text me-2"></i>Waste Scan Log — all scans (last 200)</span>
    <form method="get" class="d-flex gap-2 align-items-center">
      <select name="status" class="form-select form-select-sm" onchange="this.form.submit()" aria-label="Filter by status">
        <option value="">All statuses</option>
        <option value="completed" <?= $status === 'completed' ? 'selected' : '' ?>>Completed</option>
        <option value="corrected" <?= $status === 'corrected' ? 'selected' : '' ?>>Corrected by user</option>
        <option value="failed" <?= $status === 'failed' ? 'selected' : '' ?>>Failed</option>
      </select>
      <noscript><button class="btn btn-sm btn-soft">Filter</button></noscript>
    </form>
  </div>
  <div class="card-body py-3">
    <div class="alert alert-light border small"><i class="bi bi-info-circle me-1"></i>Scanner mode: <strong>Manual</strong> — users select the category themselves. Older rows created by the retired automatic scanner are marked <span class="badge text-bg-secondary">HISTORICAL</span> and are kept for record integrity.</div>
    <div class="row g-2 text-center small mb-3">
      <div class="col"><div class="p-2 bg-light border rounded-3"><div class="fw-bold fs-5"><?= (int) ($stats['total'] ?? 0) ?></div>Total scans</div></div>
      <div class="col"><div class="p-2 bg-light border rounded-3"><div class="fw-bold fs-5 text-success"><?= (int) ($stats['completed'] ?? 0) ?></div>Completed</div></div>
      <div class="col"><div class="p-2 bg-light border rounded-3"><div class="fw-bold fs-5 text-info"><?= (int) ($stats['corrected'] ?? 0) ?></div>Corrected</div></div>
      <div class="col"><div class="p-2 bg-light border rounded-3"><div class="fw-bold fs-5 text-danger"><?= (int) ($stats['failed'] ?? 0) ?></div>Failed</div></div>
      <div class="col"><div class="p-2 bg-light border rounded-3"><div class="fw-bold fs-5"><?= (int) ($stats['manual_rows'] ?? 0) ?></div>Manual (new flow)</div></div>
    </div>
    <div class="table-responsive">
      <table class="table table-sm table-hover align-middle">
        <thead><tr><th>Image</th><th>User</th><th>Item</th><th>Category (final)</th><th>Recyclable</th><th>Mode</th><th>Status</th><th>When</th></tr></thead>
        <tbody>
        <?php if (!$scans): ?>
          <tr><td colspan="8" class="text-center text-muted py-4">No scans yet.</td></tr>
        <?php endif; ?>
        <?php foreach ($scans as $s): $isManual = ($s['provider'] ?? '') === 'manual'; ?>
          <tr>
            <td><?php if ($s['image_path']): ?><img src="<?= e(upload_url($s['image_path'])) ?>" alt="scan" style="width:44px;height:44px;object-fit:cover" class="rounded"><?php endif; ?></td>
            <td><div class="small fw-semibold"><?= e($s['user_name']) ?></div><div class="text-muted" style="font-size:.75rem"><?= e($s['user_email']) ?></div></td>
            <td><?= e($s['result_item']) ?><?php if ($s['error_note']): ?><div class="text-danger small"><?= e(mb_strimwidth($s['error_note'], 0, 70, '…')) ?></div><?php endif; ?></td>
            <td class="small"><?= e($s['corrected_name'] ?: $s['category_name'] ?: '—') ?><?= $s['corrected_name'] ? ' <span class="badge text-bg-info">corrected</span>' : '' ?></td>
            <td class="small"><?= e(ucfirst((string) ($s['recyclable'] ?? '—'))) ?></td>
            <td><?php if ($isManual): ?><span class="badge text-bg-success">MANUAL</span><?php else: ?><span class="badge text-bg-secondary">HISTORICAL</span><?php endif; ?><div class="text-muted" style="font-size:.7rem"><?= e($s['provider'] ?: '—') ?></div></td>
            <td><?php if ($s['status'] === 'failed'): ?><span class="badge text-bg-danger">FAILED</span><?php elseif ($s['status'] === 'corrected'): ?><span class="badge text-bg-info">CORRECTED</span><?php else: ?><span class="badge text-bg-success">DONE</span><?php endif; ?></td>
            <td class="small text-muted"><?= e($s['created_at']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
