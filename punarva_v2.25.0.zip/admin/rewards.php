<?php
// v2.8.0: REWARDS RETIRED — replaced by Badges & Achievements (points/coins/redeem removed).
require_once dirname(__DIR__) . '/includes/init.php';
require_role(ROLE_ADMIN);
redirect('admin/badges.php');
