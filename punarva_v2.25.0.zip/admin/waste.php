<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_ADMIN);
$pageTitle = 'Waste Transactions'; $activeMenu = 'waste';
$q = trim((string) get_val('q', '')); $stage = (string) get_val('stage', ''); $cat = (string) get_val('category_id', '');
$where = '1=1'; $params = [];
if ($q !== '') { $where .= ' AND (wt.waste_id LIKE ? OR u.name LIKE ?)'; $params = ["%$q%", "%$q%"]; }
if ($stage !== '' && in_array($stage, WASTE_STAGES, true)) { $where .= ' AND wt.current_stage = ?'; $params[] = $stage; }
if ($cat !== '') { $where .= ' AND wt.category_id = ?'; $params[] = $cat; }
$total = (int) Database::val("SELECT COUNT(*) FROM waste_transactions wt JOIN waste_categories wc ON wc.id = wt.category_id JOIN users u ON u.id = wt.source_user_id WHERE $where", $params);
$pg = paginate_request($total);
$rows = Database::all(
    "SELECT wt.*, wc.name AS category_name, wc.color, u.name AS source_name, f.name AS facility_name
     FROM waste_transactions wt
     JOIN waste_categories wc ON wc.id = wt.category_id
     JOIN users u ON u.id = wt.source_user_id
     LEFT JOIN facilities f ON f.id = wt.facility_id
     WHERE $where ORDER BY wt.created_at DESC LIMIT {$pg['limit']} OFFSET {$pg['offset']}", $params);
$categories = Database::all('SELECT id, name FROM waste_categories ORDER BY id');
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="card">
  <div class="card-header d-flex align-items-center">
    <i class="text-pnv bi bi-box-seam me-1"></i>Waste Transactions
    <span class="badge text-bg-light border"><?= $total ?></span>
    <span class="ms-auto small text-muted">Total collected: <strong><?= fmt_kg((float) Database::val('SELECT COALESCE(SUM(initial_weight),0) FROM waste_transactions')) ?></strong></span>
  </div>
  <div class="card-body">
    <form class="row g-2 mb-3">
      <div class="col-md-4"><input class="form-control form-control-sm text-uppercase" name="q" placeholder="Waste ID / source…" value="<?= e($q) ?>"></div>
      <div class="col-md-2"><select class="form-select form-select-sm" name="stage"><option value="">Stage</option>
        <?php foreach (WASTE_STAGES as $st): ?><option <?= $stage === $st ? 'selected' : '' ?>><?= $st ?></option><?php endforeach; ?></select></div>
      <div class="col-md-2"><select class="form-select form-select-sm" name="category_id"><option value="">Category</option>
        <?php foreach ($categories as $c): ?><option value="<?= (int) $c['id'] ?>" <?= $cat === (string) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
      <div class="col-md-3 d-flex gap-2"><button class="btn btn-sm btn-pnv px-3">Filter</button>
        <a class="btn btn-sm btn-outline-secondary" href="<?= url('admin/waste.php') ?>">Reset</a></div>
    </form>
    <?php if (!$rows): ?><div class="empty-state"><i class="bi bi-inbox"></i><div class="mt-2">No waste transactions.</div></div>
    <?php else: ?>
      <div class="table-responsive"><table class="table table-hover align-middle">
        <thead><tr><th>Waste ID</th><th>Source</th><th>Category</th><th>Weight</th><th>Facility</th><th>Stage</th><th>Outcome</th><th></th></tr></thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td class="font-mono fw-bold"><?= e($r['waste_id']) ?></td>
              <td class="small"><?= e($r['source_name']) ?><div class="text-muted"><?= e($r['source_type']) ?></div></td>
              <td class="small"><span class="dot" style="background:<?= e($r['color']) ?>"></span><?= e($r['category_name']) ?></td>
              <td class="small"><?= fmt_kg($r['initial_weight']) ?><div class="text-muted">now <?= fmt_kg($r['current_weight']) ?></div></td>
              <td class="small"><?= e($r['facility_name'] ?? '—') ?></td>
              <td><?= waste_badge($r['current_stage']) ?></td>
              <td><?= $r['final_outcome'] ? waste_badge($r['final_outcome']) : '—' ?></td>
              <td><a class="btn btn-sm btn-soft" target="_blank" href="<?= url('track.php?id=' . urlencode($r['waste_id'])) ?>">Passport</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody></table></div>
      <?= pagination_links($pg) ?>
    <?php endif; ?>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php';
