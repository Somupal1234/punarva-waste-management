<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_ADMIN);
$pageTitle = 'Hotspot Analytics'; $activeMenu = 'hotspots';
if (is_post() && post_val('action') === 'recompute') {
    $n = HotspotService::recompute();
    AuditService::log('HOTSPOT_RECOMPUTE', 'analytics', null, null, ['wards' => $n]);
    flash('success', $n . ' hotspot zone(s) recalculated (rule-based MVP).');
    redirect('admin/hotspots.php');
}
$hotspots = HotspotService::all();
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="alert alert-light border small">
  <i class="bi bi-info-circle me-1"></i><strong>Hotspot scoring is a rule-based MVP</strong> — NOT machine learning.
  Score = reports×10 + reports(last 30 days)×15 + unresolved×25, grouped by ward. ML-based prediction is a planned future upgrade.
</div>
<form method="post" class="mb-3"><?= csrf_field() ?><input type="hidden" name="action" value="recompute">
  <button class="btn btn-pnv"><i class="bi bi-arrow-repeat me-1"></i>Recompute hotspots now</button></form>
<div class="row g-4">
  <div class="col-lg-5">
    <div class="card"><div class="card-header"><i class="bi bi-fire me-1 text-danger"></i>Hotspot zones (<?= count($hotspots) ?>)</div>
      <div class="card-body p-0">
        <?php if (!$hotspots): ?><div class="empty-state py-4"><i class="bi bi-fire"></i><div>No hotspots — no reports yet.</div></div>
        <?php else: foreach ($hotspots as $h): ?>
          <div class="notif-item d-flex justify-content-between align-items-center">
            <div>
              <strong><i class="bi bi-geo-alt me-1"></i><?= e($h['ward']) ?></strong>
              <span class="badge text-bg-<?= ['CRITICAL' => 'danger', 'HIGH' => 'warning', 'MEDIUM' => 'info', 'LOW' => 'secondary'][$h['status']] ?? 'secondary' ?>"><?= e($h['status']) ?></span>
              <div class="small text-muted"><?= (int) $h['report_count'] ?> reports · <?= (int) $h['recent_reports'] ?> recent ·
                <?= (int) $h['unresolved_reports'] ?> unresolved · est. <?= fmt_kg($h['estimated_volume_kg']) ?></div>
            </div>
            <div class="text-center">
              <div class="fs-5 fw-bold <?= $h['hotspot_score'] >= 80 ? 'text-danger' : ($h['hotspot_score'] >= 50 ? 'text-warning' : '') ?>"><?= (int) $h['hotspot_score'] ?></div>
              <div class="small text-muted" style="font-size:.65rem">hotspot score</div>
            </div>
          </div>
        <?php endforeach; endif; ?>
      </div></div>
  </div>
  <div class="col-lg-7"><div class="card"><div class="card-header">Hotspot map</div><div class="card-body">
    <div id="hotspotMap" class="map-box" style="height:480px"></div>
    <div class="small text-muted mt-2">
      <span class="legend-dot" style="background:#c0392b"></span>Critical (≥80) &nbsp;
      <span class="legend-dot" style="background:#e09f1f"></span>High (50–79) &nbsp;
      <span class="legend-dot" style="background:#e8c33a"></span>Medium/Low
    </div>
  </div></div></div>
</div>
<?php $hs = [];
foreach ($hotspots as $h) $hs[] = ['lat' => $h['latitude'], 'lng' => $h['longitude'], 'title' => 'Ward: ' . $h['ward'], 'score' => (int) $h['hotspot_score'], 'status' => $h['status'], 'html' => e($h['report_count'] . ' reports · score ' . $h['hotspot_score'])];
$pageScripts = '<script>pnvMap("hotspotMap", { fitAll: true, zoom: 12, hotspots: ' . json_encode($hs) . ' });</script>';
require dirname(__DIR__) . '/views/layouts/dash_footer.php';
