<?php
/**
 * Generic admin CRUD module (users, categories, facilities, organizations, vehicles,
 * reward rules, impact factors, articles, quizzes, quiz questions).
 * Includes search, filters, pagination, add/edit/delete with audit logging.
 */
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_ADMIN);
require_once dirname(__DIR__) . '/includes/admin_entities.php';

$entities = admin_entities();
$entityKey = (string) get_val('entity', 'users');
if (!isset($entities[$entityKey])) { flash('danger', 'Unknown module.'); redirect('admin/dashboard.php'); }
$entity = $entities[$entityKey];
if ($entity === 'reward_rules') { redirect('badges.php'); } // v2.8.0: rewards retired
$pageTitle = $entity['label']; $activeMenu = $entityKey;
$from = $entity['from'] ?? $entity['table'];
$alias = isset($entity['from']) ? explode(' ', $from)[1] : $entity['table'];

// list columns resolve to SQL
$listCols = [];
foreach ($entity['list'] as $key => $spec) {
    if (is_int($key) && is_array($spec)) {
        $listCols[] = ['key' => $spec['alias'] ?? $spec['col'], 'sql' => $spec['col'], 'label' => $spec['label'], 'opts' => $spec];
    } else {
        $listCols[] = ['key' => $key, 'sql' => "$alias.$key", 'label' => is_array($spec) ? $spec['label'] : $spec, 'opts' => is_array($spec) ? $spec : []];
    }
}
$selectSql = implode(', ', array_map(fn($c) => $c['sql'] . ' AS `' . $c['key'] . '`', $listCols));

// ---- actions (add / edit / delete / toggle) ----
if (is_post()) {
    $action = (string) post_val('action', 'save');
    try {
        if ($action === 'delete') {
            $id = (int) post_val('id');
            if ($entityKey === 'users' && (int) $id === (int) $user['id']) throw new RuntimeException('You cannot delete your own account.');
            $old = Database::one("SELECT * FROM {$entity['table']} WHERE id = ?", [$id]);
            Database::run("DELETE FROM {$entity['table']} WHERE id = ?", [$id]);
            AuditService::log('DELETE', $entityKey, $id, $old, null);
            flash('success', 'Record deleted.');
        } elseif ($action === 'toggle') {
            $id = (int) post_val('id');
            $row = Database::one("SELECT * FROM {$entity['table']} WHERE id = ?", [$id]);
            if (!$row) throw new RuntimeException('Record not found.');
            if (isset($row['status'])) {
                $new = $row['status'] === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
                Database::update($entity['table'], ['status' => $new], 'id = ?', [$id]);
                if ($entityKey === 'users') SessionRegistry::revokeAll($id); // disable/enable kicks all sessions of that user
                AuditService::log('STATUS_CHANGE', $entityKey, $id, $row['status'], $new);
            }
            flash('success', 'Status updated.');
        } else { // save
            $id = (int) post_val('id', 0);
            $data = [];
            foreach ($entity['fields'] as $f) {
                [$name, $label, $type, $required] = $f;
                if ($name === 'password_plain') {
                    $pw = (string) post_val('password_plain');
                    if ($pw !== '') {
                        if (strlen($pw) < 8) throw new InvalidArgumentException('Password must be at least 8 characters.');
                        $data['password_hash'] = password_hash($pw, PASSWORD_DEFAULT);
                    }
                    continue;
                }
                if ($type === 'checkbox') { $data[$name] = isset($_POST[$name]) ? 1 : 0; continue; }
                $v = trim((string) post_val($name, ''));
                if ($v === '') {
                    if ($required) throw new InvalidArgumentException("$label is required.");
                    if ($type === 'number') continue;
                    $data[$name] = null; continue;
                }
                if ($type === 'number') {
                    if (!is_numeric($v)) throw new InvalidArgumentException("$label must be numeric.");
                    $data[$name] = $v + 0;
                } else {
                    if ($type === 'email' && !filter_var($v, FILTER_VALIDATE_EMAIL)) { // server-side, not just the HTML input type
                        throw new InvalidArgumentException("$label: " . t('val.email_invalid'));
                    }
                    if ($type === 'phone') {
                        $v = (string) val_phone($_POST, $name, true); // canonical 10-digit Indian mobile
                    }
                    $data[$name] = $v;
                }
            }
            if ($entityKey === 'quiz_questions' && isset($data['options'])) {
                $json = json_decode($data['options'], true);
                if (!is_array($json) || count($json) < 2) throw new InvalidArgumentException('Options must be a JSON array with at least 2 items.');
                $data['options'] = json_encode(array_values($json), JSON_UNESCAPED_UNICODE);
                if (!isset($data['correct_index']) || (int) $data['correct_index'] < 0 || (int) $data['correct_index'] >= count($json)) {
                    throw new InvalidArgumentException('Correct option index is out of range.');
                }
            }
            if ($entityKey === 'users') { // duplicate email/phone guard with privacy-safe friendly messages
                if (isset($data['email']) && Database::val('SELECT id FROM users WHERE email = ? AND id <> ?', [$data['email'], $id])) {
                    throw new InvalidArgumentException(t('val.email_duplicate'));
                }
                if (!empty($data['phone']) && Database::val('SELECT id FROM users WHERE phone = ? AND id <> ?', [$data['phone'], $id])) {
                    throw new InvalidArgumentException(t('val.phone_duplicate'));
                }
                if ($id && isset($data['status']) && $data['status'] !== 'ACTIVE') SessionRegistry::revokeAll($id); // edited to non-ACTIVE
            }
            if ($id) {
                $old = Database::one("SELECT * FROM {$entity['table']} WHERE id = ?", [$id]);
                try {
                    Database::update($entity['table'], $data, 'id = ?', [$id]);
                } catch (PDOException $e) {
                    $drv = (int) ($e->errorInfo[1] ?? 0);
                    if ($drv === 1062) throw new InvalidArgumentException(t('val.account_duplicate')); // UNIQUE
                    if (in_array($drv, [1048, 1452], true)) throw new InvalidArgumentException(t('val.integrity')); // NOT NULL / FK
                    throw $e;
                }
                AuditService::log('UPDATE', $entityKey, $id, $old, $data);
                flash('success', 'Record updated.');
            } else {
                if ($entityKey === 'users' && empty($data['password_hash'])) {
                    throw new InvalidArgumentException('Password is required for a new user (minimum 8 characters).');
                }
                if (!empty($entity['table']) && $entityKey === 'articles' && empty($data['slug'])) {
                    $data['slug'] = preg_replace('/[^a-z0-9]+/', '-', strtolower($data['title']));
                }
                if ($entityKey === 'articles') { $data['author_id'] = $user['id']; $data['views'] = 0; }
                try {
                    $newId = Database::insert($entity['table'], $data);
                } catch (PDOException $e) {
                    $drv = (int) ($e->errorInfo[1] ?? 0);
                    if ($drv === 1062) throw new InvalidArgumentException(t('val.account_duplicate')); // UNIQUE
                    if (in_array($drv, [1048, 1452], true)) throw new InvalidArgumentException(t('val.integrity')); // NOT NULL / FK
                    throw $e;
                }
                AuditService::log('CREATE', $entityKey, $newId, null, $data);
                flash('success', 'Record created.');
            }
        }
        redirect('admin/module.php?entity=' . $entityKey);
    } catch (Throwable $e) {
        flash('danger', $e->getMessage());
        redirect('admin/module.php?entity=' . $entityKey . (post_val('id') ? '&edit=' . (int) post_val('id') : '&add=1'));
    }
}

// ---- list query with search / filters / pagination ----
$where = ['1=1']; $params = [];
$q = trim((string) get_val('q', ''));
if ($q !== '' && !empty($entity['search'])) {
    $parts = [];
    foreach ($entity['search'] as $col) { $parts[] = "$alias.$col LIKE ?"; $params[] = "%$q%"; }
    $where[] = '(' . implode(' OR ', $parts) . ')';
}
foreach (($entity['filters'] ?? []) as $fkey => $f) {
    $fv = (string) get_val($fkey, '');
    if ($fv !== '') { $where[] = "$alias.$fkey = ?"; $params[] = $fv; }
}
$whereSql = implode(' AND ', $where);
$total = (int) Database::val("SELECT COUNT(*) FROM $from WHERE $whereSql", $params);
$pg = paginate_request($total);
$rows = Database::all("SELECT $alias.id AS `id`, $selectSql FROM $from WHERE $whereSql ORDER BY {$entity['order']} LIMIT {$pg['limit']} OFFSET {$pg['offset']}", $params);

// ---- edit form data ----
$editId = (int) (get_val('edit', post_val('edit', 0)) ?: 0);
$editing = $editId ? Database::one("SELECT * FROM {$entity['table']} WHERE id = ?", [$editId]) : null;
$showForm = $editing || get_val('add') === '1';

require dirname(__DIR__) . '/views/layouts/dash_header.php';
// "Add new" par dedicated form page khulta hai (list chhup jati hai) — form dhundhna nahi padta
$addMode = $showForm && !$editing;
?>
<?php if (!$addMode): ?>
<div class="card">
  <div class="card-header d-flex align-items-center flex-wrap gap-2">
    <i class="text-pnv bi <?= e($entity['icon']) ?> me-1"></i><?= e($entity['label']) ?>
    <span class="badge text-bg-light border"><?= $total ?></span>
    <a class="btn btn-pnv btn-sm ms-auto" href="<?= url('admin/module.php?entity=' . $entityKey . '&add=1') ?>"><i class="bi bi-plus-lg me-1"></i>Add new</a>
  </div>
  <div class="card-body">
    <form class="row g-2 mb-3">
      <input type="hidden" name="entity" value="<?= e($entityKey) ?>">
      <?php if (!empty($entity['search'])): ?>
        <div class="col-md-4"><input class="form-control form-control-sm" name="q" placeholder="Search…" value="<?= e($q) ?>"></div>
      <?php endif; ?>
      <?php foreach (($entity['filters'] ?? []) as $fkey => $f): ?>
        <div class="col-md-3">
          <select class="form-select form-select-sm" name="<?= e($fkey) ?>">
            <option value="">All <?= e(strtolower($f['label'])) ?>s</option>
            <?php foreach (($f['options'])() as $opt): ?>
              <option value="<?= e($opt['value']) ?>" <?= (string) get_val($fkey) === (string) $opt['value'] ? 'selected' : '' ?>><?= e($opt['label']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      <?php endforeach; ?>
      <div class="col-md-3 d-flex gap-2"><button class="btn btn-sm btn-pnv px-3">Filter</button>
        <a class="btn btn-sm btn-outline-secondary" href="<?= url('admin/module.php?entity=' . $entityKey) ?>">Reset</a></div>
    </form>

    <?php if (!$rows): ?>
      <div class="empty-state"><i class="bi <?= e($entity['icon']) ?>"></i><div class="mt-2">No records found.</div></div>
    <?php else: ?>
      <div class="table-responsive"><table class="table table-hover align-middle">
        <thead><tr><?php foreach ($listCols as $c): ?><th><?= e($c['label']) ?></th><?php endforeach; ?><th>Actions</th></tr></thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
            <tr>
              <?php foreach ($listCols as $c):
                $v = $r[$c['key']];
                if (isset($c['opts']['badge'])): ?>
                  <td><span class="badge text-bg-<?= e($c['opts']['badge'][$v] ?? 'secondary') ?>"><?= e($v) ?></span></td>
                <?php elseif (!empty($c['opts']['bool'])): ?>
                  <td><?= $v ? '<i class="bi bi-check-circle-fill text-success"></i>' : '<i class="bi bi-dash"></i>' ?></td>
                <?php elseif (!empty($c['opts']['icon'])): ?>
                  <td><i class="text-pnv bi <?= e((string) $v) ?>"></i></td>
                <?php elseif (!empty($c['opts']['color'])): ?>
                  <td><span class="dot" style="background:<?= e((string) $v) ?>"></span> <code><?= e((string) $v) ?></code></td>
                <?php elseif ($c['key'] === 'created_at'): ?>
                  <td class="small"><?= fmt_dt((string) $v, 'd M Y') ?></td>
                <?php else: ?>
                  <td class="small" style="max-width:260px"><?= e(mb_strimwidth((string) ($v ?? ''), 0, 60, '…')) ?></td>
                <?php endif;
              endforeach; ?>
              <td class="text-nowrap">
                <a class="btn btn-sm btn-soft" href="<?= url('admin/module.php?entity=' . $entityKey . '&edit=' . (int) $r['id']) ?>"><i class="bi bi-pencil"></i></a>
                <?php if (isset($r['status'])): ?>
                  <form class="d-inline" method="post" data-confirm="Toggle status of record #<?= (int) $r['id'] ?>?">
                    <?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                    <button class="btn btn-sm btn-outline-secondary"><i class="bi bi-toggle-<?= ($r['status'] ?? '') === 'ACTIVE' ? 'on text-success' : 'off' ?>"></i></button>
                  </form>
                <?php endif; ?>
                <form class="d-inline" method="post" data-confirm="Delete record #<?= (int) $r['id'] ?>? This cannot be undone.">
                  <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                  <button class="btn btn-sm btn-outline-danger" aria-label="Delete record #<?= (int) $r['id'] ?>"><i class="bi bi-trash" aria-hidden="true"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody></table></div>
      <?= pagination_links($pg) ?>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<?php if ($showForm): ?>
<div class="card" id="record-form">
  <div class="card-header d-flex justify-content-between align-items-center">
    <span><i class="text-pnv bi bi-plus-circle me-1"></i><?= $editing ? 'Edit record #' . (int) $editing['id'] : 'Add new record' ?> — <?= e($entity['label']) ?></span>
    <a class="btn btn-sm btn-outline-secondary" href="<?= url('admin/module.php?entity=' . $entityKey) ?>"><i class="bi bi-arrow-left me-1"></i>Back to list</a>
  </div>
  <div class="card-body p-4">
    <form method="post"><?= csrf_field() ?>
      <input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int) ($editing['id'] ?? 0) ?>">
      <div class="row g-3">
        <?php foreach ($entity['fields'] as $f): [$name, $label, $type, $required] = $f;
          // options pehle resolve (closure ho to call) — warna Closure-as-array crash
          $opts = isset($f[4]) ? (is_callable($f[4]) ? ($f[4])() : $f[4]) : [];
          $val  = $editing[$name] ?? ($name === 'status' && $type === 'select' ? 'ACTIVE' : ''); ?>
          <div class="col-md-<?= $type === 'textarea' ? 12 : 6 ?>">
            <label class="form-label fw-semibold small"><?= e($name === 'password_plain' && !$editing ? 'Password' : $label) ?><?= ($required || ($name === 'password_plain' && !$editing)) ? ' <span class="required-asterisk" aria-hidden="true">*</span>' : '' ?></label>
            <?php if ($type === 'textarea'): ?>
              <textarea class="form-control" name="<?= e($name) ?>" rows="<?= $name === 'content' ? 7 : 2 ?>"><?= e((string) $val) ?></textarea>
            <?php elseif ($type === 'select'): ?>
              <select class="form-select" name="<?= e($name) ?>" <?= $required ? 'required' : '' ?>>
                <option value="">Select…</option>
                <?php foreach ($opts as $opt): ?>
                  <option value="<?= e($opt['value']) ?>" <?= (string) $val === (string) $opt['value'] ? 'selected' : '' ?>><?= e($opt['label']) ?></option>
                <?php endforeach; ?>
              </select>
            <?php elseif ($type === 'checkbox'): ?>
              <div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="<?= e($name) ?>" <?= $val ? 'checked' : '' ?>>
                <label class="form-check-label small">Enabled</label></div>
            <?php else: ?>
              <input class="form-control" type="<?= $type === 'password' ? 'password' : ($type === 'color' ? 'color' : ($type === 'number' ? 'number' : ($type === 'date' ? 'date' : ($type === 'email' ? 'email' : 'text')))) ?>"
                     name="<?= e($name) ?>" value="<?= e((string) $val) ?>" <?= ($required || ($name === 'password_plain' && !$editing)) ? 'required' : '' ?>
                     <?= $type === 'number' ? 'step="any"' : '' ?><?= $name === 'password_plain' ? ' minlength="8" autocomplete="new-password"' : '' ?>>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
      <div class="mt-3 d-flex gap-2">
        <button class="btn btn-pnv px-4"><i class="bi bi-check2 me-1"></i><?= $editing ? 'Update' : 'Create' ?></button>
        <a class="btn btn-outline-secondary" href="<?= url('admin/module.php?entity=' . $entityKey) ?>">Cancel</a>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>
<?php $pageScripts = '<script src="' . asset_url('assets/js/password-toggle.js') . '" defer></script>'; // v2.1.9: same eye standard on user password field ?>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
