<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_ADMIN);

// v2.8.0 — BADGES & ACHIEVEMENTS admin: manage badge catalogue + inspect award audit.
// Ranking is NEVER manually editable (computed from verified activity only).

if (is_post()) {
    $action = (string) post_val('action', '');
    // v2.10.0 fix: validation errors must be a friendly flash on the form — never an uncaught
    // exception that aborts the page (root cause of the "Name is required." crash screen).
    try {
    if ($action === 'toggle') {
        $id = (int) post_val('id');
        Database::run('UPDATE badges SET is_active = 1 - is_active WHERE id = ?', [$id]);
        AuditService::log('BADGE_TOGGLE', 'badges', $id, null, ['by' => $user['id']]);
        flash('success', t('admin.badge.toggled'));
        redirect('admin/badges.php');
    }
    if ($action === 'save') {
        $id = (int) post_val('id');
        $iconKeys = ['first', 'reporter', 'truck', 'recycle', 'globe', 'sorter', 'trophy_truck', 'shield', 'hero', 'legend'];
        $cat = 'real_impact'; // v2.11.0: REAL IMPACT ONLY — no learning category anymore
        $icon = in_array(post_val('icon'), $iconKeys, true) ? (string) post_val('icon') : 'learner';
        $data = [
            'name' => val_str($_POST, 'name', 80, true, 'Name'),
            'description' => val_str($_POST, 'description', 190, true, 'Description'),
            'icon' => $icon,
            'category' => $cat,
            'criteria_type' => val_str($_POST, 'criteria_type', 40, true, 'Criteria'),
            'criteria_value' => max(1, (int) post_val('criteria_value', 1)),
        ];
        if ($id) {
            Database::update('badges', $data, 'id = ?', [$id]);
            flash('success', t('admin.badge.saved'));
        } else {
            $key = strtolower(preg_replace('/[^a-z0-9]+/i', '_', val_str($_POST, 'badge_key', 60, true, 'Badge key')) ?? '');
            $key = trim($key, '_');
            $dupe = (int) Database::val('SELECT COUNT(*) FROM badges WHERE badge_key = ?', [$key]);
            if (!$key || $dupe) {
                flash('danger', t('admin.badge.key_bad'));
            } else {
                $data['badge_key'] = $key;
                Database::insert('badges', $data);
                flash('success', t('admin.badge.created'));
            }
        }
        AuditService::log('BADGE_SAVE', 'badges', $id ?: null, null, ['key' => $data['name'] ?? null]);
        redirect('admin/badges.php');
    }
    } catch (InvalidArgumentException $e) {
        flash('danger', $e->getMessage());
        redirect('admin/badges.php' . ($id ? '?edit=' . $id : ''));
    }
}

$badges = Database::all('SELECT b.*,
    (SELECT COUNT(*) FROM user_badges ub WHERE ub.badge_id = b.id) AS earned_count
    FROM badges b ORDER BY b.category, b.criteria_value');
$audit = Database::all('SELECT ub.*, b.name AS badge_name, b.category, u.name AS user_name
    FROM user_badges ub JOIN badges b ON b.id = ub.badge_id JOIN users u ON u.id = ub.user_id
    ORDER BY ub.awarded_at DESC LIMIT 20');
$stats = [
    'participants' => (int) Database::val('SELECT COUNT(DISTINCT user_id) FROM user_badges'),
    'awarded' => (int) Database::val('SELECT COUNT(*) FROM user_badges'),
    'real' => (int) Database::val('SELECT COUNT(*) FROM user_badges ub JOIN badges b ON b.id = ub.badge_id WHERE b.category = "real_impact"'),
    'verified_activities' => (int) Database::val('SELECT (SELECT COUNT(*) FROM pickup_requests WHERE status="COMPLETED") + (SELECT COUNT(*) FROM waste_reports WHERE status IN ("VERIFIED","RESOLVED")) + (SELECT COUNT(*) FROM waste_transactions WHERE completed_at IS NOT NULL)'),
];
$edit = null;
if (($eid = (int) get_val('edit', 0))) $edit = Database::one('SELECT * FROM badges WHERE id = ?', [$eid]);

$iconOptions = ['first', 'reporter', 'truck', 'recycle', 'globe', 'sorter', 'trophy_truck', 'shield', 'hero', 'legend'];
$critOptions = ['pickups_completed', 'reports_verified', 'reports_resolved', 'recycling_completed', 'verified_activities', 'scan_count'];

$pageTitle = t('admin.badge.title'); $activeMenu = 'badges';
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="row g-3 mb-3">
  <?php foreach ([['verified_activities', t('admin.imp.verified')], ['participants', t('admin.imp.participants')], ['awarded', t('admin.imp.awarded')], ['real', t('badge.category.real_impact')]] as [$k, $label]): ?>
    <div class="col-6 col-md"><div class="kpi-card kpi-green p-3"><div class="kpi-value"><?= fmt_num($stats[$k]) ?></div><div class="kpi-label"><?= e($label) ?></div></div></div>
  <?php endforeach; ?>
</div>

<div class="row g-4">
  <div class="col-lg-8">
    <div class="card">
      <div class="card-header fw-bold"><i class="bi bi-patch-check me-2"></i><?= e(t('admin.badge.catalogue')) ?></div>
      <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
          <thead><tr><th><?= e(t('admin.badge.badge')) ?></th><th><?= e(t('admin.badge.category')) ?></th><th><?= e(t('admin.badge.criteria')) ?></th><th class="text-center"><?= e(t('admin.imp.earned_by')) ?></th><th></th></tr></thead>
          <tbody>
            <?php foreach ($badges as $b): ?>
              <tr class="<?= $b['is_active'] ? '' : 'table-light' ?>">
                <td><div class="d-flex align-items-center gap-2"><?= badge_icon_svg($b['icon'], ['size' => 34, 'title' => $b['name']]) ?>
                  <div><div class="fw-semibold"><?= e($b['name']) ?></div><div class="small text-muted"><?= e($b['badge_key']) ?></div></div></div></td>
                <td><span class="ach-cat ach-cat-impact"><?= e(t('badge.category.real_impact')) ?></span></td>
                <td class="small"><?= e($b['criteria_type']) ?> ≥ <?= (int) $b['criteria_value'] ?></td>
                <td class="text-center fw-bold"><?= fmt_num($b['earned_count']) ?></td>
                <td class="text-end text-nowrap">
                  <a class="btn btn-sm btn-soft" href="?edit=<?= (int) $b['id'] ?>"><i class="bi bi-pencil"></i></a>
                  <form method="post" class="d-inline" data-confirm="<?= e(t('admin.badge.toggle_confirm')) ?>"><?= csrf_field() ?>
                    <input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $b['id'] ?>">
                    <button class="btn btn-sm <?= $b['is_active'] ? 'btn-outline-danger' : 'btn-outline-success' ?>"><?= $b['is_active'] ? '<i class="bi bi-pause"></i>' : '<i class="bi bi-play"></i>' ?></button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card mb-3">
      <div class="card-header fw-bold"><i class="bi bi-<?= $edit ? 'pencil' : 'plus-circle' ?> me-2"></i><?= e($edit ? t('admin.badge.edit') : t('admin.badge.create')) ?></div>
      <div class="card-body">
        <form method="post" novalidate><?= csrf_field() ?>
          <input type="hidden" name="action" value="save">
          <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int) $edit['id'] ?>">
          <?php else: ?>
          <div class="mb-2"><label class="form-label small fw-semibold"><?= e(t('admin.badge.key')) ?> <span class="required-asterisk">*</span></label>
            <input class="form-control form-control-sm" name="badge_key" pattern="[a-z0-9_]+" required></div>
          <?php endif; ?>
          <div class="mb-2"><label class="form-label small fw-semibold"><?= e(t('admin.badge.name')) ?> <span class="required-asterisk">*</span></label>
            <input class="form-control form-control-sm" name="name" value="<?= e($edit['name'] ?? '') ?>" required></div>
          <div class="mb-2"><label class="form-label small fw-semibold"><?= e(t('admin.badge.desc')) ?> <span class="required-asterisk">*</span></label>
            <textarea class="form-control form-control-sm" name="description" rows="2" required><?= e($edit['description'] ?? '') ?></textarea></div>
          <div class="row g-2 mb-2">
            <div class="col-6"><label class="form-label small fw-semibold"><?= e(t('admin.badge.category')) ?></label>
              <select class="form-select form-select-sm" name="category">
                <option value="real_impact" selected><?= e(t('badge.category.real_impact')) ?></option>
              </select></div>
            <div class="col-6"><label class="form-label small fw-semibold"><?= e(t('admin.badge.icon')) ?></label>
              <select class="form-select form-select-sm" name="icon">
                <?php foreach ($iconOptions as $ic): ?><option value="<?= $ic ?>" <?= ($edit['icon'] ?? '') === $ic ? 'selected' : '' ?>><?= e($ic) ?></option><?php endforeach; ?>
              </select></div>
          </div>
          <div class="row g-2 mb-3">
            <div class="col-7"><label class="form-label small fw-semibold"><?= e(t('admin.badge.criteria')) ?></label>
              <select class="form-select form-select-sm" name="criteria_type">
                <?php foreach ($critOptions as $c): ?><option value="<?= $c ?>" <?= ($edit['criteria_type'] ?? '') === $c ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?>
              </select></div>
            <div class="col-5"><label class="form-label small fw-semibold"><?= e(t('admin.badge.threshold')) ?></label>
              <input type="number" min="1" max="100000" class="form-control form-control-sm" name="criteria_value" value="<?= (int) ($edit['criteria_value'] ?? 1) ?>"></div>
          </div>
          <div class="d-flex gap-2">
            <button class="btn btn-pnv btn-sm flex-grow-1"><?= e(t('admin.save')) ?></button>
            <?php if ($edit): ?><a class="btn btn-outline-secondary btn-sm" href="badges.php"><?= e(t('admin.cancel')) ?></a><?php endif; ?>
          </div>
        </form>
        <div class="small text-muted mt-2"><i class="bi bi-shield-check me-1"></i><?= e(t('admin.badge.icon_note')) ?></div>
      </div>
    </div>
  </div>

  <div class="col-12">
    <div class="card">
      <div class="card-header fw-bold"><i class="bi bi-clock-history me-2"></i><?= e(t('admin.badge.audit')) ?></div>
      <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
          <thead><tr><th><?= e(t('admin.audit.user')) ?></th><th><?= e(t('admin.audit.badge')) ?></th><th><?= e(t('admin.audit.category')) ?></th><th><?= e(t('admin.audit.source')) ?></th><th><?= e(t('admin.audit.when')) ?></th></tr></thead>
          <tbody>
            <?php foreach ($audit as $a): ?>
              <tr>
                <td class="fw-semibold"><?= e($a['user_name']) ?></td>
                <td><?= e($a['badge_name']) ?></td>
                <td><span class="ach-cat ach-cat-impact"><?= e(t('badge.category.real_impact')) ?></span></td>
                <td class="small"><?= e($a['source_type']) ?><?= $a['source_id'] ? ' #' . (int) $a['source_id'] : '' ?></td>
                <td class="small text-muted"><?= fmt_dt($a['awarded_at'], 'd M Y H:i') ?></td>
              </tr>
            <?php endforeach; if (!$audit): ?>
              <tr><td colspan="5" class="text-muted small p-3"><?= e(t('admin.audit.empty')) ?></td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
