<?php
/**
 * v2.4.4 — Admin profile shares the same account page (details + password + verification).
 * Requires ROLE_ADMIN to be authorised in citizen/profile.php (added in v2.4.4).
 */
require dirname(__DIR__) . '/citizen/profile.php';
