<?php
/**
 * SINGLE SHIFT REPORT PDF (admin) — any shift. Collector own-shift export lives at
 * collector/shift-pdf.php; both share services/ShiftPdfService.php (IDOR rules,
 * GPS-summary §13, branded letterhead, robust streaming live there).
 */
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/shift_filters.php';

// v2.19.0 — explicit auth guard: an unauthenticated hit now gets a clean 302 to the
// login page instead of a TypeError from passing null into the PDF service.
$user = current_user();
if (!$user) {
    flash('warning', 'Please sign in to download shift reports.');
    redirect('login.php');
}

ShiftPdfService::downloadFor($user, true, (int) get_val('id', 0));
