<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_ADMIN);
$pageTitle = 'Announcements'; $activeMenu = 'notifications';

if (is_post()) {
    try {
        $action = (string) post_val('action');
        $id = (int) post_val('id', 0);
        switch ($action) {
            case 'save':
                $sid = AnnouncementService::save(
                    $id,
                    val_str($_POST, 'title', 120, true, 'Title'),
                    val_str($_POST, 'message', 500, true, 'Message'),
                    trim((string) post_val('publish_at', '')) ?: null,
                    trim((string) post_val('expires_at', '')) ?: null,
                    AnnouncementService::normalizeRoles((array) ($_POST['roles'] ?? [])),
                    (int) $user['id']
                );
                flash('success', $id ? 'Announcement updated (still ' . AnnouncementService::effectiveStatus(AnnouncementService::find($sid)) . ').' : 'Draft saved. Use Publish to make it visible.');
                break;
            case 'publish':
                AnnouncementService::publish($id, (int) $user['id']);
                flash('success', 'Announcement published — targeted users have been notified.');
                break;
            case 'unpublish':
                AnnouncementService::unpublish($id, (int) $user['id']);
                flash('success', 'Announcement unpublished and moved back to drafts.');
                break;
            case 'delete':
                AnnouncementService::delete($id, (int) $user['id']);
                flash('success', 'Announcement deleted.');
                break;
            default:
                throw new InvalidArgumentException('Unknown action.');
        }
    } catch (InvalidArgumentException | RuntimeException $e) {
        flash('danger', $e->getMessage());
    } catch (Throwable $e) {
        error_log('PUNARVA announcement action failed: ' . $e->getMessage());
        flash('danger', 'This action could not be completed. Please try again — if it keeps failing, contact the administrator.');
    }
    redirect('admin/notifications.php');
}

$edit = null;
if (($eid = (int) get_val('edit', 0)) && ($edit = AnnouncementService::find($eid)) === null) {
    flash('warning', 'Announcement not found.');
    redirect('admin/notifications.php');
}
$rows = AnnouncementService::all();
$statusOf = fn(array $r) => AnnouncementService::effectiveStatus($r);
$filter = (string) get_val('status', 'all');
$visible = $filter === 'all' ? $rows : array_values(array_filter($rows, fn($r) => $statusOf($r) === $filter));
$activeCount = count(array_filter($rows, fn($r) => $statusOf($r) === 'active'));
$badge = ['active' => 'text-bg-success', 'scheduled' => 'text-bg-info', 'draft' => 'text-bg-secondary', 'expired' => 'text-bg-dark'];
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="d-flex flex-wrap align-items-center gap-2 mb-3">
  <h1 class="h4 fw-bold mb-0 me-auto"><i class="text-pnv bi bi-megaphone me-2"></i>Announcements</h1>
</div>

<div class="row g-4">
  <div class="col-lg-5">
    <div class="card">
      <div class="card-header fw-bold"><i class="bi <?= $edit ? 'bi-pencil' : 'bi-plus-circle' ?> me-2"></i><?= $edit ? 'Edit announcement' : 'New announcement' ?></div>
      <div class="card-body">
        <form method="post" novalidate><?= csrf_field() ?>
          <input type="hidden" name="action" value="save">
          <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int) $edit['id'] ?>"><?php endif; ?>
          <div class="mb-2"><label class="form-label small fw-semibold">Title <span class="required-asterisk">*</span></label>
            <input class="form-control form-control-sm" name="title" maxlength="120" required value="<?= e($edit['title'] ?? '') ?>"></div>
          <div class="mb-2"><label class="form-label small fw-semibold">Message <span class="required-asterisk">*</span></label>
            <textarea class="form-control form-control-sm" name="message" rows="4" maxlength="500" required><?= e($edit['message'] ?? '') ?></textarea>
            <div class="form-text">Max 500 characters. Announcements are for real operational information only.</div></div>
          <div class="row g-2 mb-2">
            <div class="col-6"><label class="form-label small fw-semibold">Publish at (optional)</label>
              <input type="datetime-local" class="form-control form-control-sm" name="publish_at" value="<?= e($edit ? substr((string) ($edit['publish_at'] ?? ''), 0, 16) : '') ?>">
              <div class="form-text">Empty = immediately on publish.</div></div>
            <div class="col-6"><label class="form-label small fw-semibold">Expires at (optional)</label>
              <input type="datetime-local" class="form-control form-control-sm" name="expires_at" value="<?= e($edit ? substr((string) ($edit['expires_at'] ?? ''), 0, 16) : '') ?>"></div>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Show to</label>
            <div class="d-flex flex-wrap gap-3 small">
              <?php $cur = $edit ? ($edit['target_roles'] === 'ALL' ? AnnouncementService::ROLES : array_filter(explode(',', (string) $edit['target_roles']))) : AnnouncementService::ROLES;
              foreach (AnnouncementService::ROLES as $r): ?>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="roles[]" value="<?= e($r) ?>" id="role_<?= e($r) ?>" <?= in_array($r, $cur, true) ? 'checked' : '' ?>>
                  <label class="form-check-label text-capitalize" for="role_<?= e($r) ?>"><?= e($r) ?></label>
                </div>
              <?php endforeach; ?>
            </div>
            <div class="form-text">Roles are enforced server-side — the banner only shows to these roles.</div>
          </div>
          <div class="d-flex gap-2">
            <button class="btn btn-pnv px-3"><i class="bi bi-check2 me-1"></i><?= $edit ? 'Update' : 'Save draft' ?></button>
            <?php if ($edit): ?><a class="btn btn-outline-secondary" href="<?= url('admin/notifications.php') ?>">Cancel</a><?php endif; ?>
          </div>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-7">
    <div class="card">
      <div class="card-header d-flex flex-wrap gap-2 align-items-center">
        <span class="fw-bold me-auto"><i class="bi bi-list-check me-2"></i>All announcements</span>
        <?php foreach (['all' => 'All', 'active' => 'Active', 'scheduled' => 'Scheduled', 'draft' => 'Draft', 'expired' => 'Expired'] as $k => $l): ?>
          <a class="btn btn-sm <?= $filter === $k ? 'btn-pnv' : 'btn-soft' ?>" href="?status=<?= $k ?>"><?= $l ?></a>
        <?php endforeach; ?>
      </div>
      <div class="card-body p-0">
        <?php if (!$visible): ?>
          <div class="empty-state py-5">
            <i class="bi bi-megaphone"></i>
            <div class="fw-semibold mt-2"><?= $activeCount === 0 ? 'No active announcements available.' : 'Nothing in this view.' ?></div>
            <div class="small text-muted">Create one on the left, then press Publish when it is ready.</div>
          </div>
        <?php else: ?>
          <div class="table-responsive"><table class="table table-hover align-middle mb-0">
            <thead><tr><th>Announcement</th><th>Audience</th><th>Window</th><th>Status</th><th class="text-end">Actions</th></tr></thead>
            <tbody>
            <?php foreach ($visible as $r): $st = $statusOf($r); ?>
              <tr>
                <td class="small"><span class="fw-bold"><?= e($r['title']) ?></span>
                  <div class="text-muted" style="max-width:340px"><?= e(mb_strimwidth($r['message'], 0, 90, '…')) ?></div></td>
                <td><span class="badge text-bg-light border"><?= e($r['target_roles'] === 'ALL' ? 'All roles' : str_replace(',', ', ', (string) $r['target_roles'])) ?></span></td>
                <td class="small text-muted">
                  <?= $r['publish_at'] ? 'From ' . fmt_dt($r['publish_at'], 'd M Y, h:i A') : 'No start' ?><br>
                  <?= $r['expires_at'] ? 'Until ' . fmt_dt($r['expires_at'], 'd M Y, h:i A') : 'No expiry' ?></td>
                <td><span class="badge <?= $badge[$st] ?>"><?= ucfirst($st) ?></span></td>
                <td class="text-end text-nowrap">
                  <a class="btn btn-sm btn-soft" href="?edit=<?= (int) $r['id'] ?>" aria-label="Edit"><i class="bi bi-pencil"></i></a>
                  <?php if ($r['status'] === 'published'): ?>
                    <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="unpublish"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                      <button class="btn btn-sm btn-outline-secondary" data-confirm="Unpublish this announcement? It will disappear from dashboards immediately."><i class="bi bi-pause-fill"></i></button></form>
                  <?php else: ?>
                    <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="publish"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                      <button class="btn btn-sm btn-outline-pnv" data-confirm="Publish this announcement to the selected roles now?"><i class="bi bi-send"></i></button></form>
                  <?php endif; ?>
                  <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                    <button class="btn btn-sm btn-outline-danger" data-confirm="Delete this announcement permanently? This cannot be undone."><i class="bi bi-trash"></i></button></form>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody></table></div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
