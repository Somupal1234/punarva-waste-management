<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_ADMIN);
$pageTitle = 'Waste Reports'; $activeMenu = 'reports';
if (is_post()) {
    try {
        $id = (int) post_val('report_id'); $action = (string) post_val('action');
        $r = Database::one('SELECT * FROM waste_reports WHERE id = ?', [$id]);
        if (!$r) throw new InvalidArgumentException('Report not found.');
        $allowed = ['SUBMITTED' => ['VERIFIED', 'REJECTED'], 'VERIFIED' => ['ASSIGNED'], 'ASSIGNED' => ['IN_PROGRESS'], 'IN_PROGRESS' => ['RESOLVED']];
        if ($action === 'status') {
            $new = (string) post_val('new_status');
            if (!in_array($new, $allowed[$r['status']] ?? [], true)) throw new InvalidArgumentException('Invalid transition: ' . $r['status'] . ' → ' . $new);
            $data = ['status' => $new, 'updated_at' => date('Y-m-d H:i:s')];
            if ($new === 'VERIFIED') $data['verified_at'] = date('Y-m-d H:i:s');
            if ($new === 'RESOLVED') $data['resolved_at'] = date('Y-m-d H:i:s');
            if (in_array($new, ['RESOLVED', 'REJECTED'], true)) $data['resolution_notes'] = val_str($_POST, 'resolution_notes', 300, false) ?: null;
            Database::update('waste_reports', $data, 'id = ?', [$id]);
            if ($new === 'ASSIGNED') {
                $cid = (int) post_val('assigned_to');
                if ($cid) Database::update('waste_reports', ['assigned_to' => $cid], 'id = ?', [$id]);
            }
            if ($r['user_id']) NotificationService::send((int) $r['user_id'], 'REPORT', 'Report ' . strtolower(REPORT_STATUS_LABELS[$new]),
                'Your report ' . $r['report_code'] . ' is now: ' . REPORT_STATUS_LABELS[$new] . '.', 'waste_report', $id);
            if (in_array($new, ['VERIFIED', 'RESOLVED'], true) && $r['user_id']) {
                    BadgeService::evaluateRealImpact((int) $r['user_id'], 'report', (int) $id); // v2.8.0: badges, not points
                }
            HotspotService::refreshAsync();
            AuditService::log('REPORT_' . $new, 'reports', $id, $r['status'], $new);
            flash('success', 'Report ' . $r['report_code'] . ' → ' . REPORT_STATUS_LABELS[$new]);
        }
        redirect('admin/reports.php');
    } catch (Throwable $e) { flash('danger', $e->getMessage()); redirect('admin/reports.php'); }
}
$q = trim((string) get_val('q', '')); $status = (string) get_val('status', '');
$where = '1=1'; $params = [];
if ($q !== '') { $where .= ' AND (wr.report_code LIKE ? OR wr.address_line LIKE ? OR wr.ward LIKE ?)'; $params = ["%$q%", "%$q%", "%$q%"]; }
if ($status !== '' && in_array($status, REPORT_STATUSES, true)) { $where .= ' AND wr.status = ?'; $params[] = $status; }
$total = (int) Database::val("SELECT COUNT(*) FROM waste_reports wr WHERE $where", $params);
$pg = paginate_request($total);
$rows = Database::all(
    "SELECT wr.*, wc.name AS category_name, cu.name AS reporter, col.name AS assigned_name
     FROM waste_reports wr
     LEFT JOIN waste_categories wc ON wc.id = wr.category_id
     LEFT JOIN users cu ON cu.id = wr.user_id
     LEFT JOIN users col ON col.id = wr.assigned_to
     WHERE $where ORDER BY wr.status = 'SUBMITTED' DESC, wr.created_at DESC LIMIT {$pg['limit']} OFFSET {$pg['offset']}", $params);
$collectors = Database::all('SELECT u.id, u.name FROM users u JOIN roles r ON r.id = u.role_id WHERE r.code = "collector" AND u.status = "ACTIVE" ORDER BY u.name');
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="card">
  <div class="card-header d-flex align-items-center"><i class="text-pnv bi bi-megaphone me-1"></i>Waste Reports
    <span class="badge text-bg-light border"><?= $total ?></span>
    <button class="btn btn-sm btn-soft ms-auto" id="btnCsvReports"><i class="bi bi-download me-1"></i>Download CSV</button></div>
  <div class="card-body">
    <form class="row g-2 mb-3">
      <div class="col-md-4"><input class="form-control form-control-sm" name="q" placeholder="Code / address / ward…" value="<?= e($q) ?>"></div>
      <div class="col-md-2"><select class="form-select form-select-sm" name="status"><option value="">Status</option>
        <?php foreach (REPORT_STATUSES as $st): ?><option <?= $status === $st ? 'selected' : '' ?>><?= $st ?></option><?php endforeach; ?></select></div>
      <div class="col-md-3 d-flex gap-2"><button class="btn btn-sm btn-pnv px-3">Filter</button>
        <a class="btn btn-sm btn-outline-secondary" href="<?= url('admin/reports.php') ?>">Reset</a></div>
    </form>
    <?php if (!$rows): ?><div class="empty-state"><i class="bi bi-inbox"></i><div class="mt-2">No reports found.</div></div>
    <?php else: foreach ($rows as $r): ?>
      <div class="border rounded-3 p-3 mb-2 <?= $r['status'] === 'SUBMITTED' ? 'border-warning-subtle bg-warning-subtle bg-opacity-10' : '' ?>">
        <div class="d-flex flex-wrap gap-2 align-items-start">
          <?php if ($r['image_path']): ?><a href="<?= e(upload_url($r['image_path'])) ?>" target="_blank">
            <img src="<?= e(upload_url($r['image_path'])) ?>" alt="Waste report photo <?= e($r['report_code'] ?? '') ?>" style="width:64px;height:64px;object-fit:cover" class="rounded border"></a><?php endif; ?>
          <div class="flex-grow-1">
            <div class="d-flex flex-wrap gap-2 align-items-center">
              <strong><?= e($r['report_code']) ?></strong> <?= report_badge($r['status']) ?>
              <?php if ($r['category_name']): ?><span class="badge text-bg-light border"><?= e($r['category_name']) ?></span><?php endif; ?>
              <span class="small text-muted">by <?= e($r['reporter'] ?? 'guest') ?> · <?= time_ago($r['created_at']) ?></span>
            </div>
            <div class="small mt-1"><?= e($r['description']) ?></div>
            <div class="small text-muted"><i class="bi bi-geo-alt me-1"></i><?= e($r['address_line']) ?><?= $r['ward'] ? ' · ' . e($r['ward']) : '' ?>
              <?= $r['latitude'] ? ' · <span style="font-family:monospace">' . e(round((float) $r['latitude'], 4) . ',' . e(round((float) $r['longitude'], 4))) . '</span>' : '' ?>
              <?php if ($r['assigned_name']): ?> · crew: <?= e($r['assigned_name']) ?><?php endif; ?></div>
          </div>
          <div class="text-nowrap">
            <?php if ($r['status'] === 'SUBMITTED'): ?>
              <form class="d-inline" method="post"><?= csrf_field() ?><input type="hidden" name="action" value="status">
                <input type="hidden" name="report_id" value="<?= (int) $r['id'] ?>"><input type="hidden" name="new_status" value="VERIFIED">
                <button class="btn btn-sm btn-pnv"><i class="bi bi-check2 me-1"></i>Verify</button></form>
              <form class="d-inline" method="post" data-confirm="Reject this report?"><?= csrf_field() ?>
                <input type="hidden" name="action" value="status"><input type="hidden" name="report_id" value="<?= (int) $r['id'] ?>">
                <input type="hidden" name="new_status" value="REJECTED"><input type="hidden" name="resolution_notes" value="Rejected after verification">
                <button class="btn btn-sm btn-outline-danger"><i class="bi bi-x"></i></button></form>
            <?php elseif ($r['status'] === 'VERIFIED'): ?>
              <form class="d-flex gap-1" method="post"><?= csrf_field() ?><input type="hidden" name="action" value="status">
                <input type="hidden" name="report_id" value="<?= (int) $r['id'] ?>"><input type="hidden" name="new_status" value="ASSIGNED">
                <select class="form-select form-select-sm" name="assigned_to" required aria-label="Assign crew (required)"><option value="">Crew…</option>
                  <?php foreach ($collectors as $c): ?><option value="<?= (int) $c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?></select><span class="required-asterisk" aria-hidden="true" title="Required">*</span>
                <button class="btn btn-sm btn-pnv">Assign</button></form>
            <?php elseif ($r['status'] === 'ASSIGNED'): ?>
              <form class="d-inline" method="post"><?= csrf_field() ?><input type="hidden" name="action" value="status">
                <input type="hidden" name="report_id" value="<?= (int) $r['id'] ?>"><input type="hidden" name="new_status" value="IN_PROGRESS">
                <button class="btn btn-sm btn-soft"><i class="bi bi-play"></i>Start cleanup</button></form>
            <?php elseif ($r['status'] === 'IN_PROGRESS'): ?>
              <form class="d-inline" method="post"><?= csrf_field() ?><input type="hidden" name="action" value="status">
                <input type="hidden" name="report_id" value="<?= (int) $r['id'] ?>"><input type="hidden" name="new_status" value="RESOLVED">
                <input class="form-control form-control-sm d-inline-block w-auto" name="resolution_notes" placeholder="Resolution note">
                <button class="btn btn-sm btn-success"><i class="bi bi-check2-circle me-1"></i>Resolve</button></form>
            <?php else: ?><span class="small text-muted">closed</span><?php endif; ?>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
    <?= pagination_links($pg) ?>
    <?php endif; ?>
  </div>
</div>
<?php $pageScripts = '<script>
// v2.4.1 — CSV export of the CURRENTLY FILTERED report list, generated locally in the browser (Blob API)
const reportRows = ' . json_encode(array_map(fn($r) => [$r['report_code'], $r['status'], $r['category_name'], ($r['reporter'] ?? 'guest'), $r['address_line'], $r['ward'], $r['latitude'], $r['longitude'], ($r['assigned_name'] ?? ''), $r['created_at']], $rows)) . ';
document.getElementById("btnCsvReports").addEventListener("click", () => pnvCsvDownload("punarva-waste-reports.csv", ["Report ID","Status","Category","Reported by","Address","Ward","Latitude","Longitude","Assigned crew","Date/time"], reportRows));
</script>';
require dirname(__DIR__) . '/views/layouts/dash_footer.php';
