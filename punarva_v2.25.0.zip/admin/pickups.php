<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_ADMIN);
$pageTitle = 'Pickup Requests'; $activeMenu = 'pickups';

if (is_post()) {
    try {
        $pickupId = (int) post_val('pickup_id');
        if (post_val('action') === 'assign') {
            $collectorId = (int) post_val('collector_id');
            if (!$collectorId) throw new InvalidArgumentException('Select a collector.');
            PickupService::assign($pickupId, $collectorId, $user);
            flash('success', 'Collector assigned to pickup.');
        } elseif (post_val('action') === 'auto') {
            PickupService::autoAssign($pickupId, $user);
            flash('success', 'Pickup auto-assigned to the least-loaded collector.');
        } elseif (post_val('action') === 'cancel') {
            PickupService::cancel($pickupId, $user);
            flash('success', 'Pickup cancelled.');
        }
        redirect('admin/pickups.php');
    } catch (Throwable $e) { flash('danger', $e->getMessage()); redirect('admin/pickups.php'); }
}

$q = trim((string) get_val('q', '')); $status = (string) get_val('status', ''); $cat = (string) get_val('category_id', '');
$where = '1=1'; $params = [];
if ($q !== '') { $where .= ' AND (pr.pickup_code LIKE ? OR u.name LIKE ? OR pr.address_line LIKE ?)'; $params = ["%$q%", "%$q%", "%$q%"]; }
if ($status !== '' && in_array($status, PICKUP_STATUSES, true)) { $where .= ' AND pr.status = ?'; $params[] = $status; }
if ($cat !== '') { $where .= ' AND pr.category_id = ?'; $params[] = $cat; }

$total = (int) Database::val("SELECT COUNT(*) FROM pickup_requests pr JOIN users u ON u.id = pr.user_id JOIN waste_categories wc ON wc.id = pr.category_id WHERE $where", $params);
$pg = paginate_request($total);
$rows = Database::all(
    "SELECT pr.*, u.name AS uname, u.phone AS uphone, wc.name AS category_name, wc.color, wc.icon,
            pa.collector_id, cu.name AS collector_name, pa.status AS assignment_status, org.name AS org_name
     FROM pickup_requests pr
     JOIN users u ON u.id = pr.user_id
     JOIN waste_categories wc ON wc.id = pr.category_id
     LEFT JOIN pickup_assignments pa ON pa.pickup_request_id = pr.id
     LEFT JOIN users cu ON cu.id = pa.collector_id
     LEFT JOIN organizations org ON org.id = pr.organization_id
     WHERE $where ORDER BY pr.status = 'REQUESTED' DESC, pr.created_at DESC LIMIT {$pg['limit']} OFFSET {$pg['offset']}", $params);
$collectors = Database::all(
    'SELECT u.id, u.name,
        (SELECT COUNT(*) FROM pickup_assignments pa WHERE pa.collector_id = u.id AND pa.status IN ("ASSIGNED","ACCEPTED","ON_THE_WAY","ARRIVED")) AS load_count
     FROM users u JOIN roles r ON r.id = u.role_id WHERE r.code = "collector" AND u.status = "ACTIVE" ORDER BY u.name');
$categories = Database::all('SELECT id, name FROM waste_categories ORDER BY id');
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="card">
  <div class="card-header d-flex align-items-center flex-wrap gap-2">
    <i class="text-pnv bi bi-truck me-1"></i>Pickup Requests <span class="badge text-bg-light border"><?= $total ?></span>
    <?php $reqCount = (int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE status = "REQUESTED"');
    if ($reqCount): ?><span class="badge text-bg-warning"><?= $reqCount ?> awaiting assignment</span><?php endif; ?>
  </div>
  <div class="card-body">
    <form class="row g-2 mb-3">
      <div class="col-md-4"><input class="form-control form-control-sm" name="q" placeholder="Code / citizen / address…" value="<?= e($q) ?>"></div>
      <div class="col-md-2"><select class="form-select form-select-sm" name="status"><option value="">Status</option>
        <?php foreach (PICKUP_STATUSES as $st): ?><option <?= $status === $st ? 'selected' : '' ?>><?= $st ?></option><?php endforeach; ?></select></div>
      <div class="col-md-2"><select class="form-select form-select-sm" name="category_id"><option value="">Category</option>
        <?php foreach ($categories as $c): ?><option value="<?= (int) $c['id'] ?>" <?= $cat === (string) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
      <div class="col-md-3 d-flex gap-2"><button class="btn btn-sm btn-pnv px-3">Filter</button>
        <a class="btn btn-sm btn-outline-secondary" href="<?= url('admin/pickups.php') ?>">Reset</a></div>
    </form>
    <?php if (!$rows): ?><div class="empty-state"><i class="bi bi-inbox"></i><div class="mt-2"><?= t('misc.no_pickups_found') ?></div></div>
    <?php else: ?>
      <div class="table-responsive"><table class="table table-hover align-middle">
        <thead><tr><th>Code</th><th>Source</th><th>Category / weight</th><th>Schedule</th><th>Collector</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
            <tr class="<?= $r['status'] === 'REQUESTED' ? 'table-warning' : '' ?>">
              <td><div class="fw-bold"><?= e($r['pickup_code']) ?></div><div class="small text-muted"><?= time_ago($r['created_at']) ?></div></td>
              <td class="small"><?= e($r['org_name'] ? $r['org_name'] . ' (org)' : $r['uname']) ?><div class="text-muted"><?= e($r['uphone']) ?></div></td>
              <td class="small"><span class="dot" style="background:<?= e($r['color']) ?>"></span><?= e($r['category_name']) ?><div class="text-muted"><?= fmt_kg($r['estimated_weight']) ?></div></td>
              <td class="small"><?= fmt_dt($r['preferred_date'], 'd M Y') ?><div class="text-muted"><?= e($r['time_slot']) ?></div></td>
              <td class="small"><?= e($r['collector_name'] ?? '—') ?></td>
              <td><?= pickup_badge($r['status']) ?></td>
              <td class="text-nowrap">
                <?php if (in_array($r['status'], ['REQUESTED','ASSIGNED'], true)): ?>
                  <form class="d-flex gap-1 align-items-center" method="post">
                    <?= csrf_field() ?><input type="hidden" name="action" value="assign"><input type="hidden" name="pickup_id" value="<?= (int) $r['id'] ?>">
                    <select class="form-select form-select-sm" name="collector_id" style="max-width:170px" required aria-label="Assign collector (required)">
                      <option value="">Assign collector…</option>
                      <?php foreach ($collectors as $c): ?>
                        <option value="<?= (int) $c['id'] ?>" <?= (int) $r['collector_id'] === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?> (<?= (int) $c['load_count'] ?> open)</option>
                      <?php endforeach; ?>
                    </select><span class="required-asterisk" aria-hidden="true" title="Required">*</span>
                    <button class="btn btn-sm btn-pnv"><?= e(t('btn.assign')) ?></button>
                  </form>
                  <?php if ($r['status'] === 'REQUESTED'): ?>
                    <form class="d-inline mt-1" method="post"><?= csrf_field() ?>
                      <input type="hidden" name="action" value="auto"><input type="hidden" name="pickup_id" value="<?= (int) $r['id'] ?>">
                      <button class="btn btn-sm btn-soft" title="Assign least-loaded collector"><i class="bi bi-magic me-1"></i>Auto-assign</button>
                    </form>
                  <?php endif; ?>
                <?php elseif (in_array($r['status'], ['REQUESTED','ASSIGNED','ACCEPTED'], true)): ?>
                  <form class="d-inline" method="post" data-confirm="Cancel pickup <?= e($r['pickup_code']) ?>?"><?= csrf_field() ?>
                    <input type="hidden" name="action" value="cancel"><input type="hidden" name="pickup_id" value="<?= (int) $r['id'] ?>">
                    <button class="btn btn-sm btn-outline-danger">Cancel</button></form>
                <?php else: echo '<span class="text-muted small">—</span>'; endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody></table></div>
      <?= pagination_links($pg) ?>
    <?php endif; ?>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
