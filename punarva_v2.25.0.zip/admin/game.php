<?php
// v2.10.0: game admin page retired — stale links land on badge management.
require_once dirname(__DIR__) . '/includes/init.php';
redirect('admin/badges.php');
