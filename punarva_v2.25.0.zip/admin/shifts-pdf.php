<?php
/**
 * SHIFT MANAGEMENT REPORT — filtered branded PDF (admin-only, v2.13.0).
 * All logic (no-data rule, filters, letterhead, streaming) lives in the shared service.
 */
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/shift_filters.php';
require_role(ROLE_ADMIN);

ShiftPdfService::managementReport(current_user());
