<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_ADMIN);
$pageTitle = 'System Settings'; $activeMenu = 'settings';
settings_ensure_columns();
$schema = settings_schema();

/** Persist one setting with group + author + audit trail (skips secrets; none exist here). */
function settings_save(string $key, string $value, string $group, int $userId): bool
{
    $old = setting($key, null);
    if ((string) $old === $value) return false; // unchanged → no write/no audit noise
    if (Database::one('SELECT setting_key FROM settings WHERE setting_key = ?', [$key])) {
        Database::update('settings',
            ['setting_value' => $value, 'setting_group' => $group, 'updated_by' => $userId, 'updated_at' => date('Y-m-d H:i:s')],
            'setting_key = ?', [$key]);
    } else {
        Database::insert('settings', [
            'setting_key' => $key, 'setting_value' => $value, 'setting_group' => $group,
            'description' => 'Updated via System Settings', 'updated_by' => $userId,
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
    }
    AuditService::log('SETTING_CHANGED', 'settings', null, $key . ' = ' . (string) $old, $key . ' = ' . $value);
    return true;
}

if (is_post()) {
    try {
        $action = (string) post_val('action', 'save_group');

        // ---- Force logout all users (bumps the global session epoch) ----
        // v2.12.0: requires admin RE-AUTHENTICATION (own password) in addition to confirmation.
        if ($action === 'force_logout') {
            $pw = (string) post_val('admin_password', '');
            // session array deliberately carries no password hash — re-auth reads it fresh from the DB
            $hash = (string) Database::val('SELECT password_hash FROM users WHERE id = ?', [(int) $user['id']]);
            if ($pw === '' || $hash === '' || !password_verify($pw, $hash)) {
                AuditService::log('FORCE_LOGOUT_DENIED', 'settings', null, null, ['by' => (int) $user['id']]);
                flash('danger', 'Re-authentication failed — enter your own admin password to force logout all users.');
                redirect('admin/settings.php#security');
            }
            settings_save('sessions_epoch', (string) time(), 'security', (int) $user['id']);
            AuditService::log('FORCE_LOGOUT_ALL', 'settings', null, null, ['by' => (int) $user['id']]);
            AuthService::logout();
            flash('success', 'All users — including you — have been signed out. Please log in again.');
            redirect('login.php');
        }

        // ---- Save one group ----
        $groupKey = (string) post_val('group', '');
        if (!isset($schema[$groupKey])) throw new InvalidArgumentException('Unknown settings group.');

        $saved = 0;
        // v2.15.0 — validate ALL fields first, then save: an invalid value anywhere in the
        // group rejects the whole submit (no partial applies).
        $pending = [];
        foreach ($schema[$groupKey]['fields'] as $f) {
            $key = $f[0]; $type = $f[1];
            if (in_array($type, ['sub', 'info', 'health', 'note', 'action', 'always'], true)) continue;
            if (str_starts_with($key, '_')) continue;

            // switches: posted value is authoritative ("1" checked, "0" explicitly unchecked);
            // absent from POST = unchecked (plain form submit without the field)
            $v = $type === 'switch' ? (string) post_val($key, '0') : trim((string) post_val($key, ''));
            // password-type (secrets): khaali submit = existing value KEEP (overwrite nahi)
            if ($type === 'password' && $v === '' && (string) setting($key, '') !== '') continue;
            if ($err = settings_validate_field($f, $v)) throw new InvalidArgumentException($err);
            $pending[$key] = [$v, $groupKey];
        }
        foreach ($pending as $key => [$v, $grp]) {
            if (settings_save($key, $v, $grp, (int) $user['id'])) $saved++;
        }
        flash('success', $groupKey === 'security'
            ? 'Security settings saved successfully.'
            : ($saved ? ucfirst($groupKey) . " settings saved ($saved changed)." : 'No changes to save.'));
        AuditService::log('SETTINGS_UPDATED', 'settings', null, $groupKey, "$saved keys");
        redirect('admin/settings.php#' . $groupKey);
    } catch (InvalidArgumentException | RuntimeException $e) {
        flash('danger', $e->getMessage());
        redirect('admin/settings.php#' . (string) post_val('group', ''));
    } catch (Throwable $e) {
        flash('danger', APP_DEBUG ? $e->getMessage() : 'Could not save settings.');
        redirect('admin/settings.php');
    }
}

// one settings() round-trip per request (static cache) – values for render
$cur = fn(string $k, string $d = '') => (string) setting($k, $d);
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<h1 class="h4 fw-bold mb-1"><i class="text-pnv bi bi-gear-fill me-2"></i>System Settings</h1>
<p class="text-muted small mb-4">Configure only what you need — critical protections stay permanently enforced. Operational modules (Badges, Hotspots, Pickups, Vehicles…) have their own dedicated pages.</p>

<div class="accordion" id="settingsAcc">
<?php foreach ($schema as $gKey => $g): ?>
  <div class="accordion-item" id="<?= e($gKey) ?>">
    <h2 class="accordion-header">
      <button class="accordion-button <?= $gKey === 'general' ? '' : 'collapsed' ?>" type="button"
              data-bs-toggle="collapse" data-bs-target="#acc-<?= e($gKey) ?>">
        <i class="text-pnv bi <?= e($g['icon']) ?> me-2"></i>
        <span class="fw-bold"><?= e($g['title']) ?></span>
        <span class="text-muted small ms-2 d-none d-sm-inline">— <?= e($g['desc']) ?></span>
      </button>
    </h2>
    <div id="acc-<?= e($gKey) ?>" class="accordion-collapse collapse <?= $gKey === 'general' ? 'show' : '' ?>"
         data-bs-parent="#settingsAcc">
      <div class="accordion-body">
        <?php $hasForm = (bool) array_filter($g['fields'], fn($f) => !in_array($f[1], ['sub', 'info', 'health', 'note', 'action', 'always'], true) && !str_starts_with((string) $f[0], '_')); ?>
        <?php if ($hasForm): ?><form method="post" action="<?= url('admin/settings.php') ?>"><?= csrf_field() ?>
          <input type="hidden" name="action" value="save_group">
          <input type="hidden" name="group" value="<?= e($gKey) ?>">
        <?php endif; ?>
          <?php $actionFields = []; ?>
          <div class="row g-3">
            <?php foreach ($g['fields'] as $f):
                [$key, $type, $label] = [$f[0], $f[1], $f[2]];
                // DB value wins; default only as fallback. info/action/sub/etc. have no stored value.
                $curV = in_array($type, ['switch', 'text', 'textarea', 'email', 'number', 'select'], true)
                    ? $cur($key, (string) ($f[3] ?? '')) : '';
                $extra = fn(string $tag) => (($i = array_search($tag, $f, true)) === false ? null : ($f[$i + 1] ?? null));
                if ($type === 'sub'): ?>
                  <div class="col-12"><hr class="my-1"><h6 class="fw-bold text-uppercase small text-muted mb-0"><?= e($label) ?></h6></div>
                <?php continue; endif;
                if ($type === 'note'): ?>
                  <div class="col-12"><div class="alert alert-light border small mb-0"><i class="text-pnv bi bi-shield-lock me-1"></i><?= e($label) ?></div></div>
                <?php continue; endif;
                if ($type === 'health'): ?>
                  <div class="col-md-6"><div class="border rounded p-3 small"><b><i class="text-pnv bi bi-database me-1"></i>Database</b><br><?= settings_info_value('db_status') ?></div></div>
                  <div class="col-md-6"><div class="border rounded p-3 small"><b><i class="text-pnv bi bi-folder2 me-1"></i>Storage</b><br><?= settings_info_value('storage_status') ?></div></div>
                  <div class="col-md-6"><div class="border rounded p-3 small"><b><i class="text-pnv bi bi-code-slash me-1"></i>PHP</b><br><?= e(PHP_VERSION) ?> · <?= e(PHP_OS_FAMILY) ?></div></div>
                  <div class="col-md-6"><div class="border rounded p-3 small"><b><i class="text-pnv bi bi-stars me-1"></i>Application</b><br><?= settings_info_value('app_status') ?> · v<?= e(APP_VERSION) ?> · From Waste to Worth</div></div>
                  <div class="col-md-6"><div class="border rounded p-3 small"><b><i class="text-pnv bi bi-upc-scan me-1"></i>Waste Scanner</b><br><?= settings_info_value('scanner_mode') ?></div></div>
                  <div class="col-md-6"><div class="border rounded p-3 small"><b><i class="text-pnv bi bi-map me-1"></i>Map Provider</b><br><?= settings_info_value('map_status') ?></div></div>
                  <div class="col-md-6"><div class="border rounded p-3 small"><b><i class="text-pnv bi bi-cloud-upload me-1"></i>Maximum Upload Size</b><br><?= round(UPLOAD_MAX_BYTES / 1048576) ?> MB per image</div></div>
                  <div class="col-12"><div class="form-text mb-0"><i class="bi bi-shield-check me-1"></i>Read-only for security. Connection details, credentials and API keys are never shown here, and PUNARVA provides no destructive server operations.</div></div>
                <?php continue; endif;
                if ($type === 'info'): ?>
                  <div class="col-md-6">
                    <label class="form-label fw-semibold small"><?= e($label) ?></label>
                    <div class="form-control bg-light small" style="border-style:dashed"><?= settings_info_value($extra('fn') ?? '') ?></div>
                  </div>
                <?php continue; endif;
                if ($type === 'always'): ?>
                  <div class="col-md-6">
                    <div class="border rounded p-2 ps-3 small h-100 d-flex align-items-center gap-2" style="background:var(--bs-tertiary-bg, #f8f9fa)">
                      <i class="text-success bi bi-shield-check fs-5"></i>
                      <div><span class="fw-semibold"><?= e($label) ?></span>
                        <span class="badge text-bg-success ms-1"><i class="bi bi-lock-fill"></i>Always Enforced</span>
                        <div class="text-muted"><?= e($f[3] ?? '') ?></div>
                      </div>
                    </div>
                  </div>
                <?php continue; endif;
                if ($type === 'action'):
                    $actionFields[] = $f; // v2.15.0: rendered as a SEPARATE high-risk form below the save form
                    continue; endif;

                $conf  = $extra('confirm');
                $help  = $extra('help');
                $locked = $extra('locked');
                $col   = $type === 'textarea' ? 12 : 6;
                if ($type === 'select') $opts = $extra('options') ?? [];
            ?>
            <div class="col-md-<?= $col ?>">
              <?php if ($type === 'switch'): ?>
                <div class="form-check form-switch pnv-switch">
                  <input class="form-check-input" type="checkbox" role="switch" id="f_<?= e($key) ?>"
                         name="<?= e($key) ?>" value="1" <?= $curV === '1' ? 'checked' : '' ?>
                         <?= $locked ? 'disabled' : '' ?> <?= $conf ? 'data-confirm="' . e($conf) . '"' : '' ?>>
                  <label class="form-check-label fw-semibold small" for="f_<?= e($key) ?>"><?= e($label) ?>
                    <?php if ($locked): ?><span class="badge text-bg-secondary ms-1"><i class="bi bi-lock-fill"></i> always enforced</span><?php endif; ?>
                  </label>
                  <?php if ($help): ?><div class="form-text"><?= e($help) ?></div><?php endif; ?>
                </div>
              <?php else: ?>
                <label class="form-label fw-semibold small" for="f_<?= e($key) ?>"><?= e($label) ?></label>
                <?php if ($type === 'select'): ?>
                  <select class="form-select" id="f_<?= e($key) ?>" name="<?= e($key) ?>">
                    <?php foreach ($opts as $o): ?>
                      <option value="<?= e($o['value']) ?>" <?= $curV === (string) $o['value'] ? 'selected' : '' ?>><?= e($o['label']) ?></option>
                    <?php endforeach; ?>
                  </select>
                <?php elseif ($type === 'textarea'): ?>
                  <textarea class="form-control" id="f_<?= e($key) ?>" name="<?= e($key) ?>" rows="2" maxlength="500"><?= e($curV) ?></textarea>
                <?php else: ?>
                  <input class="form-control" id="f_<?= e($key) ?>" name="<?= e($key) ?>" value="<?= $type === 'password' ? '' : e($curV) ?>"
                         type="<?= $type === 'number' ? 'number' : ($type === 'email' ? 'email' : ($type === 'password' ? 'password' : 'text')) ?>"
                         <?= $type === 'number' ? 'step="1"' : '' ?> <?= $type === 'password' ? 'autocomplete="new-password" placeholder="••••••••"' : '' ?>>
                <?php endif; ?>
                <?php if ($help): ?><div class="form-text"><?= e($help) ?></div><?php endif; ?>
                <?php if ($type === 'password' && (string) setting($key, '') !== ''): ?>
                  <div class="form-text text-success"><i class="bi bi-check-circle me-1"></i>Saved: ••••<?= e(substr((string) setting($key, ''), -4)) ?> — badalne ke liye nayi key type karen (khaali = keep).</div>
                <?php endif; ?>
              <?php endif; ?>
            </div>
            <?php endforeach; ?>
          </div>
          <?php if ($hasForm): ?>
          <div class="mt-3 d-flex gap-2">
            <button class="btn btn-pnv px-4"><i class="bi bi-check2 me-1"></i>Save <?= e($g['title']) ?></button>
            <a class="btn btn-outline-secondary" href="<?= url('admin/settings.php') ?>">Reset</a>
          </div>
          <?php endif; ?>
        <?php if ($hasForm): ?></form>
        <?php endif; ?>
        <?php foreach ($actionFields ?? [] as $af): [$aKey, $aType, $aLabel] = $af; $aExtra = fn(string $tag) => (($ai = array_search($tag, $af, true)) === false ? null : ($af[$ai + 1] ?? null)); ?>
          <div class="border border-danger-subtle rounded-3 p-3 mt-3" style="background:rgba(220,53,69,.04)">
            <h6 class="fw-bold small text-uppercase text-danger mb-1"><i class="bi bi-exclamation-octagon me-1"></i><?= e($aLabel) ?> — High-Risk Security Action</h6>
            <div class="small text-muted mb-2"><?= e($aExtra('help') ?? '') ?></div>
            <form method="post" action="<?= url('admin/settings.php') ?>" class="d-flex gap-2 flex-wrap align-items-center"><?= csrf_field() ?>
              <input type="hidden" name="action" value="force_logout">
              <input class="form-control form-control-sm" style="max-width:240px" type="password" id="f_force_pw"
                     name="admin_password" autocomplete="current-password" placeholder="Enter your current password to continue">
              <button class="btn btn-danger btn-sm" data-confirm="<?= e($aExtra('confirm') ?? 'Are you sure?') ?>">
                <i class="bi bi-box-arrow-right me-1"></i>Confirm Force Logout</button>
            </form>
            <div class="form-text mb-0">Invalidates all active user sessions — every user signs in again on their next request. Users, their data, passwords and roles are never modified.</div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
<?php endforeach; ?>

<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
