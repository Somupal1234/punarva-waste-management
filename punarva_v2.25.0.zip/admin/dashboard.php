<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_ADMIN);
$pageTitle = 'Municipality Dashboard'; $activeMenu = 'dash';

// ---- all stats live from the database ----
$kpi = [
    'users'     => (int) Database::val('SELECT COUNT(*) FROM users'),
    'citizens'  => (int) Database::val('SELECT COUNT(*) FROM users u JOIN roles r ON r.id = u.role_id WHERE r.code = "citizen"'),
    'collectors'=> (int) Database::val('SELECT COUNT(*) FROM users u JOIN roles r ON r.id = u.role_id WHERE r.code = "collector"'),
    'recyclers' => (int) Database::val('SELECT COUNT(*) FROM users u JOIN roles r ON r.id = u.role_id WHERE r.code = "recycler"'),
    'business'  => (int) Database::val('SELECT COUNT(*) FROM users u JOIN roles r ON r.id = u.role_id WHERE r.code = "business"'),
    'pickups'   => (int) Database::val('SELECT COUNT(*) FROM pickup_requests'),
    'open'      => (int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE status IN ("REQUESTED","ASSIGNED","ACCEPTED","ON_THE_WAY","ARRIVED","COLLECTED")'),
    'completed' => (int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE status = "COMPLETED"'),
    'wasteKg'   => (float) (Database::val('SELECT COALESCE(SUM(initial_weight),0) FROM waste_transactions')),
    'recycledKg'=> (float) (Database::val('SELECT COALESCE(SUM(current_weight),0) FROM waste_transactions WHERE final_outcome = "RECYCLED"')),
    'recoveredKg'=> (float) (Database::val('SELECT COALESCE(SUM(current_weight),0) FROM waste_transactions WHERE final_outcome IN ("RECOVERED","COMPOSTED","REUSED")')),
    'residualKg'=> (float) (Database::val('SELECT COALESCE(SUM(current_weight),0) FROM waste_transactions WHERE final_outcome = "RESIDUAL_DISPOSAL"')),
    'reportsOpen'  => (int) Database::val('SELECT COUNT(*) FROM waste_reports WHERE status IN ("SUBMITTED","VERIFIED","ASSIGNED","IN_PROGRESS")'),
    'reportsDone'  => (int) Database::val('SELECT COUNT(*) FROM waste_reports WHERE status = "RESOLVED"'),
    'badges'    => (int) Database::val('SELECT COUNT(*) FROM user_badges'),
    'passports' => (int) Database::val('SELECT COUNT(*) FROM waste_transactions'),
];
$impact = ImpactService::globalSummary();

// charts data
$byCategory = Database::all(
    'SELECT wc.name, wc.color, COALESCE(SUM(wt.initial_weight),0) AS total
     FROM waste_transactions wt JOIN waste_categories wc ON wc.id = wt.category_id
     GROUP BY wt.category_id ORDER BY total DESC LIMIT 8');
$byMonth = Database::all(
    'SELECT DATE_FORMAT(created_at, "%b %y") AS ym, COALESCE(SUM(initial_weight),0) AS total, COUNT(*) AS n
     FROM waste_transactions
     GROUP BY YEAR(created_at), MONTH(created_at) ORDER BY YEAR(created_at), MONTH(created_at)
     LIMIT 36');
$pickupTrend = Database::all(
    'SELECT DATE_FORMAT(preferred_date, "%d %b") AS ym, COUNT(*) AS n, SUM(status = "COMPLETED") AS done
     FROM pickup_requests WHERE preferred_date >= DATE_SUB(CURDATE(), INTERVAL 14 DAY)
     GROUP BY preferred_date ORDER BY preferred_date');
$outcomes = Database::all('SELECT final_outcome, COUNT(*) AS n, COALESCE(SUM(current_weight),0) AS w FROM waste_transactions WHERE final_outcome IS NOT NULL GROUP BY final_outcome');
$reportStatus = Database::all('SELECT status, COUNT(*) AS n FROM waste_reports GROUP BY status');

// recent activity (audit trail + newest pickups)
$recentPickups = Database::all(
    'SELECT pr.pickup_code, pr.status, pr.created_at, u.name AS uname, wc.name AS cat
     FROM pickup_requests pr JOIN users u ON u.id = pr.user_id JOIN waste_categories wc ON wc.id = pr.category_id
     ORDER BY pr.created_at DESC LIMIT 6');
$recentAudit = Database::all(
    'SELECT a.*, u.name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.created_at DESC LIMIT 6');
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="row g-3 mb-4">
  <?php $cards = [
    ['kpi-green','bi-people', fmt_num($kpi['users']),'TOTAL USERS', $kpi['citizens'].' citizens · '.$kpi['collectors'].' collectors · '.$kpi['recyclers'].' recyclers · '.$kpi['business'].' business'],
    ['kpi-blue','bi-truck', fmt_num($kpi['pickups']),'PICKUP REQUESTS', $kpi['open'].' open · '.$kpi['completed'].' completed'],
    ['kpi-teal','bi-passport', fmt_num($kpi['passports']),'WASTE PASSPORTS', fmt_kg($kpi['wasteKg']).' collected'],
    ['kpi-violet','bi-recycle', fmt_kg($kpi['recycledKg']+$kpi['recoveredKg']),'WASTE RECYCLED/RECOVERED', fmt_kg($kpi['residualKg']).' residual disposed'],
    ['kpi-amber','bi-megaphone', fmt_num($kpi['reportsOpen']+$kpi['reportsDone']),'WASTE REPORTS', $kpi['reportsOpen'].' active · '.$kpi['reportsDone'].' resolved'],
    ['kpi-red','bi-patch-check', fmt_num($kpi['badges']),'BADGES AWARDED', number_format((float) $impact['co2'],1).' kg est. CO₂e avoided'],
  ];
  foreach ($cards as [$c,$i,$v,$l,$s]): ?>
    <div class="col-6 col-lg-2"><div class="kpi-card <?= $c ?> p-3 h-100"><i class="bi <?= $i ?> kpi-icon"></i>
      <div class="kpi-value" style="font-size:1.35rem"><?= $v ?></div><div class="kpi-label"><?= e($l) ?></div>
      <div class="small opacity-75 mt-1"><?= e($s) ?></div></div></div>
  <?php endforeach; ?>
</div>

<?php if ($kpi['open'] > 0 && (int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE status = "REQUESTED"') > 0): ?>
  <div class="alert alert-warning d-flex align-items-center flex-wrap gap-2">
    <i class="bi bi-exclamation-triangle"></i>
    <strong><?= (int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE status = "REQUESTED"') ?> pickup request(s) awaiting assignment.</strong>
    <a class="btn btn-sm btn-pnv ms-auto" href="<?= url('admin/pickups.php') ?>">Assign collectors <i class="bi bi-arrow-right"></i></a>
  </div>
<?php endif; ?>

<div class="row g-3">
  <div class="col-lg-7"><div class="chart-card h-100">
    <div class="chart-head">
      <h2 class="chart-title"><i class="bi bi-graph-up-arrow"></i>Waste collected by month</h2>
      <div class="chart-range ms-auto" id="monthRange" role="group" aria-label="Chart period">
        <button type="button" data-months="7" aria-pressed="false">7M</button>
        <button type="button" data-months="6" aria-pressed="false">6M</button>
        <button type="button" data-months="12" aria-pressed="true">12M</button>
        <button type="button" data-months="0" aria-pressed="false">All</button>
      </div>
    </div>
    <div class="pnv-chart pnv-chart-primary">
      <?php if ($byMonth): ?><canvas id="monthChart" role="img" aria-label="Area chart: waste collected by month in kilograms"></canvas>
      <?php else: ?><div class="chart-empty"><i class="bi bi-graph-up"></i><div><?= t('misc.no_waste_data') ?></div></div><?php endif; ?>
    </div>
  </div></div>
  <div class="col-lg-5"><div class="chart-card h-100">
    <div class="chart-head"><h2 class="chart-title"><i class="bi bi-bar-chart-line"></i>Waste mix</h2><span class="chart-sub">kg · share</span></div>
    <?php if ($byCategory): ?><div id="mixChart" class="pnv-mix"></div>
    <?php else: ?><div class="chart-empty"><i class="bi bi-bar-chart"></i><div><?= t('misc.no_waste_data') ?></div></div><?php endif; ?>
  </div></div>
  <div class="col-lg-5"><div class="chart-card h-100">
    <div class="chart-head"><h2 class="chart-title"><i class="bi bi-diagram-3"></i>Recycling outcome</h2><span class="chart-sub">kg · share of collected</span></div>
    <?php if ($outcomes): ?><div id="flowChart" class="pnv-flow"></div>
    <?php else: ?><div class="chart-empty"><i class="bi bi-pie-chart"></i><div>No outcomes yet</div></div><?php endif; ?>
  </div></div>
  <div class="col-lg-7"><div class="chart-card h-100">
    <div class="chart-head"><h2 class="chart-title"><i class="bi bi-truck"></i>Pickup trend</h2><span class="chart-sub">last 14 days</span></div>
    <div class="pnv-chart pnv-chart-spark">
      <?php if ($pickupTrend): ?><canvas id="pickupChart" role="img" aria-label="Line chart: pickups per day over the last 14 days"></canvas>
      <?php else: ?><div class="chart-empty"><i class="bi bi-truck"></i><div><?= t('misc.no_pickups') ?></div></div><?php endif; ?>
    </div>
  </div></div>
</div>

<?php
// v2.25.0 — compact visualizations data (all derived from the queries above)
const REPORT_SEG_COLORS = ['SUBMITTED' => '#f2b32c', 'VERIFIED' => '#3d9be9', 'ASSIGNED' => '#1b6ca8', 'IN_PROGRESS' => '#8e5cd9', 'RESOLVED' => '#0e7a4f', 'REJECTED' => '#c0392b'];
$processedKg = array_sum(array_map(fn($o) => (float) $o['w'], $outcomes));
$recycleKgAll = (float) $kpi['recycledKg'] + (float) $kpi['recoveredKg'];
$flowSteps = $outcomes ? [
    ['name' => 'Collected', 'color' => '#1b6ca8', 'icon' => 'bi-truck',    'value' => round((float) $kpi['wasteKg'], 1)],
    ['name' => 'Processed', 'color' => '#0b7285', 'icon' => 'bi-box-seam', 'value' => round($processedKg, 1)],
    ['name' => 'Recycled',  'color' => '#0e7a4f', 'icon' => 'bi-recycle',  'value' => round($recycleKgAll, 1), 'meta' => 'incl. recovered'],
    ['name' => 'Rejected',  'color' => '#c0392b', 'icon' => 'bi-trash3',   'value' => round((float) $kpi['residualKg'], 1), 'meta' => 'residual disposal'],
] : [];
$segParts = array_map(fn($r) => ['label' => REPORT_STATUS_LABELS[$r['status']], 'n' => (int) $r['n'], 'color' => REPORT_SEG_COLORS[$r['status']] ?? '#66766c'], $reportStatus);
?>

<div class="row g-3 mt-1">
  <div class="col-lg-5"><div class="chart-card h-100">
    <div class="chart-head"><h2 class="chart-title"><i class="bi bi-megaphone"></i>Waste reports by status</h2></div>
    <?php if ($reportStatus): ?>
      <div class="pnv-seg" id="reportSeg" role="img" aria-label="Segmented bar: waste reports by status"></div>
      <div class="pnv-seg-list" id="reportSegList"></div>
    <?php else: ?><div class="chart-empty"><i class="bi bi-megaphone"></i><div><?= t('misc.no_reports') ?></div></div><?php endif; ?>
  </div></div>
  <div class="col-lg-7"><div class="card h-100"><div class="card-header">Latest pickups</div><div class="card-body p-0">
    <?php if (!$recentPickups): ?><div class="empty-state py-4"><?= t('misc.no_pickups') ?></div><?php endif; ?>
    <?php foreach ($recentPickups as $r): ?>
      <div class="notif-item d-flex justify-content-between align-items-center">
        <div><strong><?= e($r['pickup_code']) ?></strong> <span class="text-muted small">by <?= e($r['uname']) ?></span>
          <div class="small text-muted"><?= e($r['cat']) ?> · <?= time_ago($r['created_at']) ?></div></div>
        <?= pickup_badge($r['status']) ?>
      </div>
    <?php endforeach; ?>
  </div></div></div>
  <div class="col-lg-5"><div class="card h-100"><div class="card-header">Recent system activity (audit)</div><div class="card-body p-0">
    <?php foreach ($recentAudit as $a): ?>
      <div class="notif-item">
        <strong><?= e($a['action']) ?></strong> <span class="badge text-bg-light border"><?= e($a['module']) ?></span>
        <div class="small text-muted"><?= e($a['name'] ?? 'system') ?> · <?= time_ago($a['created_at']) ?>
          <?php if ($a['old_value'] || $a['new_value']): ?>· <?= e(mb_strimwidth(trim((string) $a['old_value'] . ' → ' . $a['new_value']), 0, 70, '…')) ?><?php endif; ?></div>
      </div>
    <?php endforeach; ?>
  </div></div></div>
</div>

<?php $pageScripts = '<script>
' . ($byMonth ? 'PNV_CHART.monthControl("#monthRange", "monthChart", { labels: ' . json_encode(array_column($byMonth, 'ym')) . ', values: ' . json_encode(array_map(fn($r) => round((float) $r['total'], 1), $byMonth)) . ' }, { label: "Collected", color: PNV_CHART.palette.green, suffix: "" });' : '') . '
' . ($byCategory ? 'PNV_CHART.renderMix("#mixChart", ' . json_encode(array_map(fn($r) => ['name' => $r['name'], 'color' => $r['color'], 'value' => round((float) $r['total'], 1)], $byCategory)) . ');' : '') . '
' . ($flowSteps ? 'PNV_CHART.renderFlow("#flowChart", ' . json_encode($flowSteps) . ');' : '') . '
' . ($pickupTrend ? 'PNV_CHART.area("pickupChart", { labels: ' . json_encode(array_column($pickupTrend, 'ym')) . ', count: true, suffix: " pickups", series: [
  { label: "Requested", data: ' . json_encode(array_map(fn($r) => (int) $r['n'], $pickupTrend)) . ', color: "#3d9be9", fill: false },
  { label: "Completed", data: ' . json_encode(array_map(fn($r) => (int) $r['done'], $pickupTrend)) . ', color: "#0e7a4f", fill: false }] });' : '') . '
' . ($reportStatus ? 'PNV_CHART.renderSeg("#reportSeg", "#reportSegList", ' . json_encode($segParts) . ');' : '') . '
</script>';
require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
