<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once __DIR__ . '/../includes/shift_filters.php';
$user = require_role(ROLE_ADMIN);

// v2.9.0 — SHIFT MANAGEMENT (Admin → Operations): real driver_shifts records, filters,
// server-side pagination, live summary. Read-only for admins — shifts are created by
// collectors via Punch In/Out (TrackingService); nothing is auto-ended by viewing.
$pageTitle = 'Shift Management'; $activeMenu = 'shifts';

$f = shift_filters_parse();
$perPage = 25;
$page = max(1, (int) get_val('page', 1));
$offset = ($page - 1) * $perPage;

$total = (int) Database::val(
    'SELECT COUNT(*) FROM driver_shifts ds WHERE ' . $f['where'],
    $f['params']
);
$rows = $total ? Database::all(
    'SELECT ds.id, ds.status, ds.started_at, ds.ended_at, ds.last_ping_at,
            u.name AS driver_name, u.id AS driver_id,
            v.vehicle_number, v.id AS vehicle_id
     FROM driver_shifts ds
     JOIN users u ON u.id = ds.driver_user_id
     JOIN vehicles v ON v.id = ds.vehicle_id
     WHERE ' . $f['where'] . '
     ORDER BY ds.started_at DESC, ds.id DESC
     LIMIT ' . $perPage . ' OFFSET ' . $offset,
    $f['params']
) : [];

// summary (real DB, app-wide — not filter-dependent)
$summary = [
    'today'  => (int) Database::val('SELECT COUNT(*) FROM driver_shifts WHERE DATE(started_at) = CURDATE()'),
    'active' => (int) Database::val('SELECT COUNT(*) FROM driver_shifts WHERE status = "ACTIVE"'),
    'ended'  => (int) Database::val('SELECT COUNT(*) FROM driver_shifts WHERE status = "ENDED" AND DATE(started_at) = CURDATE()'),
    'nogps'  => (int) Database::val('SELECT COUNT(*) FROM driver_shifts ds WHERE DATE(ds.started_at) = CURDATE() AND ds.last_ping_at IS NULL AND NOT EXISTS (SELECT 1 FROM driver_locations dl WHERE dl.shift_id = ds.id)'),
];

// filter dropdown data (real records only)
$drivers = Database::all('SELECT DISTINCT u.id, u.name FROM users u
    JOIN roles r ON r.id = u.role_id AND r.code = "COLLECTOR"
    JOIN driver_shifts ds ON ds.driver_user_id = u.id ORDER BY u.name');
$trucks = Database::all('SELECT DISTINCT v.id, v.vehicle_number FROM vehicles v
    JOIN driver_shifts ds ON ds.vehicle_id = v.id ORDER BY v.vehicle_number');

$qs = function (array $override = []) use ($f, $page): string {
    $base = array_filter([
        'range' => $f['range'] !== 'all' ? $f['range'] : '',
        'from' => $f['from'], 'to' => $f['to'],
        'driver' => $f['driver'] ?: '', 'truck' => $f['truck'] ?: '',
        'status' => $f['status'], 'gps' => $f['gps'],
    ]);
    $all = array_merge($base, array_filter($override, fn($v) => $v !== ''));
    return http_build_query($all);
};
$pdfUrl = url('admin/shifts-pdf.php') . '?' . $qs();
$lastPage = max(1, (int) ceil($total / $perPage));

require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="d-flex flex-wrap align-items-center gap-2 mb-3">
  <h1 class="h4 fw-bold mb-0 me-auto"><i class="text-pnv bi bi-clock-history me-2"></i>Shift Management</h1>
  <?php if ((int) $total === 0): // v2.13.0 no-data rule: no records → no PDF offer (server also enforces) ?>
    <span class="btn btn-pnv disabled" aria-disabled="true" title="No shift records found for the selected filters — PDF download is unavailable because there is no data."><i class="bi bi-file-earmark-pdf me-1"></i>Download PDF</span>
  <?php else: ?>
    <a class="btn btn-pnv" href="<?= e($pdfUrl) ?>"><i class="bi bi-file-earmark-pdf me-1"></i>Download PDF</a>
  <?php endif; ?>
  <button class="btn btn-outline-secondary no-print" onclick="window.print()"><i class="bi bi-printer me-1"></i>Print</button>
</div>

<div class="row g-3 mb-3">
  <?php
  $cards = [
    ['kpi-green', 'bi-calendar-day', fmt_num($summary['today']), "TODAY'S SHIFTS", 'Punch-ins today'],
    ['kpi-blue', 'bi-broadcast', fmt_num($summary['active']), 'ACTIVE', 'Currently on shift'],
    ['kpi-teal', 'bi-check2-circle', fmt_num($summary['ended']), 'COMPLETED TODAY', 'Ended today'],
    ['kpi-amber', 'bi-geo-slash', fmt_num($summary['nogps']), 'GPS UNAVAILABLE', 'No GPS today'],
  ];
  foreach ($cards as [$c, $i, $v, $l, $s]): ?>
    <div class="col-6 col-lg-3">
      <div class="kpi-card <?= $c ?> p-3 h-100"><i class="bi <?= $i ?> kpi-icon"></i>
        <div class="kpi-value"><?= $v ?></div><div class="kpi-label"><?= e($l) ?></div>
        <div class="small opacity-75 mt-1"><?= e($s) ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<?php if ($summary['active']): ?>
  <a class="alert alert-info d-flex align-items-center gap-2 py-2 text-decoration-none" href="<?= e(url('admin/shifts.php?status=ACTIVE')) ?>">
    <i class="bi bi-broadcast fs-5"></i>
    <strong><?= (int) $summary['active'] ?> Active Shift<?= $summary['active'] > 1 ? 's' : '' ?></strong>
    <span class="small">— click to filter the table</span>
  </a>
<?php endif; ?>

<div class="card mb-3 no-print">
  <div class="card-body py-3">
    <form method="get" class="row g-2 align-items-end">
      <div class="col-6 col-md-2">
        <label class="form-label small fw-semibold">Date</label>
        <select class="form-select form-select-sm" name="range">
          <?php foreach (['all' => 'All', 'today' => 'Today', 'yesterday' => 'Yesterday', 'week' => 'This week', 'month' => 'This month', 'custom' => 'Custom'] as $k => $l): ?>
            <option value="<?= $k ?>" <?= $f['range'] === $k ? 'selected' : '' ?>><?= $l ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-6 col-md-2">
        <label class="form-label small fw-semibold">From – To</label>
        <div class="d-flex gap-1">
          <input type="date" class="form-control form-control-sm flex-fill" style="min-width:0" name="from" value="<?= e($f['from']) ?>">
          <input type="date" class="form-control form-control-sm flex-fill" style="min-width:0" name="to" value="<?= e($f['to']) ?>">
        </div>
      </div>
      <div class="col-6 col-md-3">
        <label class="form-label small fw-semibold">Driver</label>
        <select class="form-select form-select-sm" name="driver">
          <option value="">All drivers</option>
          <?php foreach ($drivers as $d): ?><option value="<?= (int) $d['id'] ?>" <?= $f['driver'] === (int) $d['id'] ? 'selected' : '' ?>><?= e($d['name']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="col-6 col-md-2">
        <label class="form-label small fw-semibold">Truck</label>
        <select class="form-select form-select-sm" name="truck">
          <option value="">All trucks</option>
          <?php foreach ($trucks as $t): ?><option value="<?= (int) $t['id'] ?>" <?= $f['truck'] === (int) $t['id'] ? 'selected' : '' ?>><?= e($t['vehicle_number']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="col-4 col-md-1">
        <label class="form-label small fw-semibold">Status</label>
        <select class="form-select form-select-sm" name="status">
          <option value="">All</option>
          <option value="ACTIVE" <?= $f['status'] === 'ACTIVE' ? 'selected' : '' ?>>ACTIVE</option>
          <option value="ENDED" <?= $f['status'] === 'ENDED' ? 'selected' : '' ?>>ENDED</option>
        </select>
      </div>
      <div class="col-4 col-md-1">
        <label class="form-label small fw-semibold">GPS</label>
        <select class="form-select form-select-sm" name="gps">
          <option value="">All</option>
          <option value="live" <?= $f['gps'] === 'live' ? 'selected' : '' ?>>Live</option>
          <option value="stale" <?= $f['gps'] === 'stale' ? 'selected' : '' ?>>Stale</option>
          <option value="none" <?= $f['gps'] === 'none' ? 'selected' : '' ?>>No GPS</option>
        </select>
      </div>
      <div class="col-4 col-md-1 d-grid gap-1">
        <button class="btn btn-pnv btn-sm"><i class="bi bi-funnel me-1"></i>Apply</button>
        <a class="btn btn-outline-secondary btn-sm" href="<?= e(url('admin/shifts.php')) ?>">Clear</a>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <div class="small text-muted mb-2">Showing <?= $total ? ($offset + 1) : 0 ?>–<?= min($offset + $perPage, $total) ?> of <strong><?= fmt_num($total) ?></strong> records</div>
    <div class="table-responsive">
      <table class="table table-sm table-hover align-middle mb-0">
        <thead><tr><th>Date</th><th>Driver</th><th>Truck</th><th>Punch In</th><th>Punch Out</th><th>Duration</th><th>Status</th><th>GPS</th><th class="text-end no-print"></th></tr></thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td><?= e(shift_date($r['started_at'])) ?></td>
              <td class="fw-semibold"><?= e($r['driver_name']) ?></td>
              <td><?= e($r['vehicle_number']) ?></td>
              <td><?= e(shift_time($r['started_at'])) ?></td>
              <td><?= e(shift_time($r['ended_at'])) ?></td>
              <td><?= e(shift_duration($r['started_at'], $r['ended_at'])) ?></td>
              <td><?= $r['status'] === 'ACTIVE' ? '<span class="badge text-bg-success">ACTIVE</span>' : '<span class="badge text-bg-secondary">ENDED</span>' ?></td>
              <td><?= shift_gps_badge($r) ?></td>
              <td class="text-end text-nowrap no-print">
                <a class="btn btn-sm btn-soft" href="<?= e(url('admin/shift-view.php?id=' . (int) $r['id'])) ?>"><i class="bi bi-eye me-1"></i>Details</a>
              </td>
            </tr>
          <?php endforeach; if (!$rows): ?>
            <tr><td colspan="9" class="text-center text-muted py-4"><i class="bi bi-inbox me-1"></i>No shift records found for the selected filters.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php if ($lastPage > 1): ?>
      <nav class="mt-3 no-print"><ul class="pagination pagination-sm mb-0">
        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="?<?= e($qs(['page' => $page - 1])) ?>">Previous</a></li>
        <?php for ($p = 1; $p <= $lastPage; $p++): if ($p > 3 && $p < $lastPage && abs($p - $page) > 1): ?>
          <?php if (abs($p - $page) === 2): ?><li class="page-item disabled"><span class="page-link">…</span></li><?php endif; continue; endif; ?>
          <li class="page-item <?= $p === $page ? 'active' : '' ?>"><a class="page-link" href="?<?= e($qs(['page' => $p])) ?>"><?= $p ?></a></li>
        <?php endfor; ?>
        <li class="page-item <?= $page >= $lastPage ? 'disabled' : '' ?>"><a class="page-link" href="?<?= e($qs(['page' => $page + 1])) ?>">Next</a></li>
      </ul></nav>
    <?php endif; ?>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
