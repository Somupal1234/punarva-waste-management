<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_ADMIN);
$pageTitle = 'Analytics'; $activeMenu = 'analytics';

// ---- everything computed live ----
$summary = [
  'collected' => (float) (Database::val('SELECT COALESCE(SUM(initial_weight),0) FROM waste_transactions')),
  'recycled' => (float) (Database::val('SELECT COALESCE(SUM(current_weight),0) FROM waste_transactions WHERE final_outcome = "RECYCLED"')),
  'recovered' => (float) (Database::val('SELECT COALESCE(SUM(current_weight),0) FROM waste_transactions WHERE final_outcome IN ("RECOVERED","COMPOSTED","REUSED")')),
  'residual' => (float) (Database::val('SELECT COALESCE(SUM(current_weight),0) FROM waste_transactions WHERE final_outcome = "RESIDUAL_DISPOSAL"')),
  'pickups' => (int) Database::val('SELECT COUNT(*) FROM pickup_requests'),
  'completed' => (int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE status = "COMPLETED"'),
  'cancelled' => (int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE status = "CANCELLED"'),
  'badges' => (int) Database::val('SELECT COUNT(*) FROM user_badges'),
];
$completionRate = $summary['pickups'] ? round($summary['completed'] / max(1, $summary['pickups'] - $summary['cancelled']) * 100) : 0;
$recycleRate = ($summary['recycled'] + $summary['recovered'] + $summary['residual']) > 0
  ? round(($summary['recycled'] + $summary['recovered']) / ($summary['recycled'] + $summary['recovered'] + $summary['residual']) * 100) : 0;
$impact = ImpactService::globalSummary();
$byCategory = Database::all('SELECT wc.name, wc.color, SUM(wt.initial_weight) AS total, SUM(wt.final_outcome IS NOT NULL) AS done FROM waste_transactions wt JOIN waste_categories wc ON wc.id = wt.category_id GROUP BY wt.category_id ORDER BY total DESC');
$monthly = Database::all('SELECT DATE_FORMAT(created_at, "%b %y") AS ym, SUM(initial_weight) AS w, COUNT(*) AS n FROM waste_transactions GROUP BY YEAR(created_at), MONTH(created_at) ORDER BY YEAR(created_at), MONTH(created_at)');
$facilityPerf = Database::all(
  'SELECT f.name, f.facility_type, COUNT(wt.id) AS loads, COALESCE(SUM(wt.current_weight),0) AS w,
          SUM(wt.final_outcome IS NOT NULL) AS done, ROUND(AVG(CASE WHEN wt.final_outcome IN ("RECYCLED","RECOVERED","COMPOSTED","REUSED") THEN 100 ELSE 0 END),0) AS success_pct
   FROM facilities f LEFT JOIN waste_transactions wt ON wt.facility_id = f.id
   GROUP BY f.id ORDER BY loads DESC');
$collectorPerf = Database::all(
  'SELECT u.name, COUNT(pa.id) AS done, COALESCE(SUM(pa.actual_weight),0) AS w, ROUND(AVG(TIMESTAMPDIFF(HOUR, pr.created_at, pa.completed_at)),1) AS avg_hours
   FROM users u JOIN roles r ON r.id = u.role_id
   LEFT JOIN pickup_assignments pa ON pa.collector_id = u.id AND pa.status = "COMPLETED"
   LEFT JOIN pickup_requests pr ON pr.id = pa.pickup_request_id
   WHERE r.code = "collector" GROUP BY u.id HAVING done > 0 ORDER BY done DESC LIMIT 10');
$outcomes = Database::all('SELECT final_outcome, COUNT(*) AS n, SUM(current_weight) AS w FROM waste_transactions WHERE final_outcome IS NOT NULL GROUP BY final_outcome');
$reportByWard = Database::all('SELECT COALESCE(NULLIF(ward,""),"Unwarded") AS ward, COUNT(*) AS n, SUM(status = "RESOLVED") AS resolved FROM waste_reports GROUP BY ward ORDER BY n DESC LIMIT 10');
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>

<div class="d-flex flex-wrap align-items-center gap-2 mb-3">
  <h1 class="h4 fw-bold mb-0"><i class="text-pnv bi bi-graph-up-arrow me-2"></i>Analytics</h1>
  <span class="badge rounded-pill text-bg-light border"><i class="bi bi-database-check me-1"></i>Computed live from the database</span>
  <span class="badge rounded-pill text-bg-light border"><i class="bi bi-calculator me-1"></i>Impact figures are estimates</span>
</div>
<div class="row g-3 mb-4">
  <?php $cards = [['kpi-green','bi-box-seam', fmt_kg($summary['collected']),'Total collected'],
    ['kpi-teal','bi-recycle', fmt_kg($summary['recycled']),'Recycled'],
    ['kpi-blue','bi-lightning', fmt_kg($summary['recovered']),'Recovered / composted / reused'],
    ['kpi-red','bi-trash3', fmt_kg($summary['residual']),'Residual disposed'],
    ['kpi-violet','bi-check2-square', $completionRate.'%','Pickup completion rate'],
    ['kpi-amber','bi-arrow-repeat', $recycleRate.'%','RESOURCE RECOVERY RATE']];
  foreach ($cards as [$c,$i,$v,$l]): ?>
    <div class="col-6 col-lg-2"><div class="kpi-card <?= $c ?> p-3 h-100"><i class="bi <?= $i ?> kpi-icon"></i>
      <div class="kpi-value" style="font-size:1.3rem"><?= $v ?></div><div class="kpi-label"><?= e($l) ?></div></div></div>
  <?php endforeach; ?>
</div>
<div class="alert alert-light border small"><i class="bi bi-info-circle me-1"></i>Impact to date (estimated): <strong><?= number_format((float) $impact['co2'],1) ?> kg CO₂e</strong> avoided ·
  <strong><?= fmt_num($impact['water']) ?> L</strong> water saved · <strong><?= number_format((float) $impact['energy'],1) ?> kWh</strong> energy saved ·
  <strong><?= fmt_num($summary['badges']) ?></strong> badges awarded to citizens. All impact values are estimates (<?= e(METHODOLOGY_VERSION) ?>).</div>

<div class="row g-3">
  <div class="col-lg-6"><div class="chart-card h-100">
    <div class="chart-head"><h2 class="chart-title"><i class="bi bi-graph-up"></i>Monthly waste collected</h2><span class="chart-sub">kg / month</span></div>
    <div class="pnv-chart pnv-chart-md">
    <?php if ($monthly): ?><canvas id="mChart" role="img" aria-label="Area chart: waste collected per month in kilograms"></canvas><?php else: ?><div class="chart-empty"><i class="bi bi-graph-up"></i><div>No data.</div></div><?php endif; ?>
    </div></div></div>
  <div class="col-lg-6"><div class="chart-card h-100">
    <div class="chart-head"><h2 class="chart-title"><i class="bi bi-bar-chart-line"></i>Category distribution</h2><span class="chart-sub">kg collected</span></div>
    <div class="pnv-chart pnv-chart-md">
    <?php if ($byCategory): ?><canvas id="cChart" role="img" aria-label="Bar chart: collected weight by waste category"></canvas><?php else: ?><div class="chart-empty"><i class="bi bi-bar-chart"></i><div>No data.</div></div><?php endif; ?>
    </div></div></div>
  <div class="col-lg-6"><div class="chart-card h-100">
    <div class="chart-head"><h2 class="chart-title"><i class="bi bi-diagram-3"></i>Final outcomes</h2><span class="chart-sub">kg · share of processed</span></div>
    <?php if ($outcomes): ?><div id="oFlow" class="pnv-flow"></div><?php else: ?><div class="chart-empty"><i class="bi bi-pie-chart"></i><div>No outcomes.</div></div><?php endif; ?>
  </div></div></div>
  <div class="col-lg-6"><div class="chart-card h-100">
    <div class="chart-head"><h2 class="chart-title"><i class="bi bi-geo"></i>Reports by ward</h2><span class="chart-sub">total · resolved</span></div>
    <div class="pnv-chart pnv-chart-md">
    <?php if ($reportByWard): ?><canvas id="wChart" role="img" aria-label="Horizontal bar chart: reports and resolved reports by ward"></canvas><?php else: ?><div class="chart-empty"><i class="bi bi-geo"></i><div>No reports.</div></div><?php endif; ?>
    </div></div></div>
</div>

<div class="row g-3 mt-1">
  <div class="col-lg-6"><div class="card h-100">
    <div class="card-header d-flex align-items-center"><i class="bi bi-buildings me-1"></i>Facility performance
      <button class="btn btn-sm btn-soft ms-auto" id="btnCsvFacility"><i class="bi bi-download me-1"></i>Download CSV</button></div>
    <div class="card-body p-0">
      <?php if (!$facilityPerf): ?><div class="empty-state py-4">No facilities.</div>
      <?php else: ?>
      <div class="table-responsive"><table class="table mb-0">
        <thead><tr><th>Facility</th><th>Loads</th><th>Weight</th><th>Completed</th><th>Success %</th></tr></thead>
        <tbody><?php foreach ($facilityPerf as $f): ?>
          <tr><td class="small"><strong><?= e($f['name']) ?></strong><div class="text-muted"><?= e($f['facility_type']) ?></div></td>
            <td><?= (int) $f['loads'] ?></td><td class="small"><?= fmt_kg($f['w']) ?></td><td><?= (int) $f['done'] ?></td>
            <td><div class="progress" style="height:7px;min-width:70px"><div class="progress-bar bg-success" style="width:<?= (int) $f['success_pct'] ?>%"></div></div></td></tr>
        <?php endforeach; ?></tbody></table></div>
      <?php endif; ?>
    </div></div></div>
  <div class="col-lg-6"><div class="card h-100">
    <div class="card-header d-flex align-items-center"><i class="bi bi-person-badge me-1"></i>Collector performance
      <button class="btn btn-sm btn-soft ms-auto" id="btnCsvCollector"><i class="bi bi-download me-1"></i>Download CSV</button></div>
    <div class="card-body p-0">
      <?php if (!$collectorPerf): ?><div class="empty-state py-4">No completed collections yet.</div>
      <?php else: ?>
      <div class="table-responsive"><table class="table mb-0">
        <thead><tr><th>Collector</th><th>Collections</th><th>Weight</th><th>Avg turnaround</th></tr></thead>
        <tbody><?php foreach ($collectorPerf as $c): ?>
          <tr><td><?= e($c['name']) ?></td><td><?= (int) $c['done'] ?></td><td class="small"><?= fmt_kg($c['w']) ?></td>
            <td class="small"><?= $c['avg_hours'] !== null ? e((string) $c['avg_hours']) . ' h' : '—' ?></td></tr>
        <?php endforeach; ?></tbody></table></div>
      <?php endif; ?>
    </div></div></div>
</div>
<?php $pageScripts = '<script>
const facilityRows = ' . json_encode(array_map(fn($f) => [$f['name'], $f['facility_type'], (int) $f['loads'], round((float) $f['w'], 1), (int) $f['done'], (int) $f['success_pct']], $facilityPerf)) . ';
const collectorRows = ' . json_encode(array_map(fn($c) => [$c['name'], (int) $c['done'], round((float) $c['w'], 1), $c['avg_hours']], $collectorPerf)) . ';
document.getElementById("btnCsvFacility").addEventListener("click", () => pnvCsvDownload("punarva-facility-performance.csv", ["Facility","Type","Loads","Weight (kg)","Completed","Success %"], facilityRows));
document.getElementById("btnCsvCollector").addEventListener("click", () => pnvCsvDownload("punarva-collector-performance.csv", ["Collector","Collections","Weight (kg)","Avg turnaround (h)"], collectorRows));
' . ($monthly ? 'PNV_CHART.area("mChart", { labels: ' . json_encode(array_column($monthly, 'ym')) . ', suffix: "",
  series: [{ label: "Collected", data: ' . json_encode(array_map(fn($r) => round((float) $r['w'], 1), $monthly)) . ', color: "#0e7a4f" }] });' : '') . '
' . ($byCategory ? 'PNV_CHART.bars("cChart", { labels: ' . json_encode(array_column($byCategory, 'name')) . ', suffix: "",
  series: [{ label: "Collected", data: ' . json_encode(array_map(fn($r) => round((float) $r['total'], 1), $byCategory)) . ', colors: ' . json_encode(array_column($byCategory, 'color')) . ' }] });' : '') . '
' . ($outcomes ? 'PNV_CHART.renderFlow("#oFlow", ' . json_encode(array_map(fn($o) => [
        'name' => WASTE_STAGE_LABELS[$o['final_outcome']],
        'color' => match ($o['final_outcome']) { 'RECYCLED' => '#0e7a4f', 'RECOVERED', 'COMPOSTED', 'REUSED' => '#12b886', 'RESIDUAL_DISPOSAL' => '#c0392b', default => '#0b7285' },
        'icon' => match ($o['final_outcome']) { 'RECYCLED' => 'bi-recycle', 'RECOVERED' => 'bi-lightning-charge', 'COMPOSTED' => 'bi-flower1', 'REUSED' => 'bi-arrow-repeat', 'RESIDUAL_DISPOSAL' => 'bi-trash3', default => 'bi-box-seam' },
        'value' => round((float) $o['w'], 1)], $outcomes)) . ', ' . json_encode(max(1, array_sum(array_map(fn($o) => (float) $o['w'], $outcomes)))) . ');' : '') . '
' . ($reportByWard ? 'PNV_CHART.bars("wChart", { labels: ' . json_encode(array_column($reportByWard, 'ward')) . ', horizontal: true, count: true, suffix: " reports",
  series: [{ label: "Reports", data: ' . json_encode(array_map(fn($r) => (int) $r['n'], $reportByWard)) . ', color: "#e35d6a" },
           { label: "Resolved", data: ' . json_encode(array_map(fn($r) => (int) $r['resolved'], $reportByWard)) . ', color: "#0e7a4f" }] });' : '') . '
</script>';
require dirname(__DIR__) . '/views/layouts/dash_footer.php';
