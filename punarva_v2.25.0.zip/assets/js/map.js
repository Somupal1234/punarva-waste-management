/* PUNARVA – Leaflet map helpers (OpenStreetMap tiles) */
'use strict';

const PNV_MARKERS = {
  green:  '#0e7a4f', blue: '#1b6ca8', amber: '#e09f1f', red: '#c0392b',
  violet: '#6f42c1', teal: '#0b7285', grey: '#6c757d',
};

function pnvIcon(color, glyph) {
  return L.divIcon({
    className: '',
    html: `<div style="background:${color};width:30px;height:30px;border-radius:50% 50% 50% 4px;transform:rotate(-45deg);
           display:flex;align-items:center;justify-content:center;box-shadow:0 3px 8px rgba(0,0,0,.35);border:2px solid #fff">
           <i class="bi ${glyph}" style="transform:rotate(45deg);color:#fff;font-size:.85rem"></i></div>`,
    iconSize: [30, 30], iconAnchor: [15, 30], popupAnchor: [0, -28],
  });
}

/**
 * pnvMap(elId, {center:[lat,lng], zoom, markers:[{lat,lng,title,html,color,glyph}],
 *          clickTarget: {latInput, lngInput}, fitAll:bool, heatmap:[{lat,lng,score}]})
 */
console.log('PUNARVA map.js v2.4.3 loaded');

function pnvMap(elId, opts = {}) {
  const el = document.getElementById(elId);
  if (!el || typeof L === 'undefined') return null;
  if (el.dataset.pnvMapInit) return null; // prevent double initialization
  el.dataset.pnvMapInit = '1';
  const center = opts.center || window.PNV_MAP_CENTER || [24.2785, 87.2494]; // Dumka default
  const map = L.map(elId, { scrollWheelZoom: false }).setView(center, opts.zoom || 12);
  L.tileLayer(window.PNV_TILE_URL || 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19, attribution: window.PNV_ATTR || '&copy; OpenStreetMap contributors',
  }).addTo(map);

  const bounds = [];
  (opts.markers || []).forEach((m) => {
    if (m.lat === null || m.lng === null || m.lat === '' || m.lng === '') return;
    const color = PNV_MARKERS[m.color] || m.color || PNV_MARKERS.green;
    const marker = L.marker([Number(m.lat), Number(m.lng)], { icon: pnvIcon(color, m.glyph || 'bi-geo-alt-fill') }).addTo(map);
    const html = `<strong>${m.title || ''}</strong>` + (m.html ? `<br><small>${m.html}</small>` : '');
    marker.bindPopup(html);
    bounds.push([Number(m.lat), Number(m.lng)]);
  });

  // hotspot circles
  (opts.hotspots || []).forEach((h) => {
    if (h.lat === null || h.lng === null) return;
    const color = h.score >= 80 ? '#c0392b' : h.score >= 50 ? '#e09f1f' : '#e8c33a';
    L.circle([Number(h.lat), Number(h.lng)], {
      radius: 140 + Math.min(h.score, 120) * 3, color, fillColor: color, fillOpacity: 0.22, weight: 1.5,
    }).addTo(map).bindPopup(`<strong>Hotspot: ${h.title}</strong><br>Score ${h.score} (${h.status})<br><small>${h.html || ''}</small>`);
    bounds.push([Number(h.lat), Number(h.lng)]);
  });

  if (opts.fitAll && bounds.length) map.fitBounds(bounds, { padding: [34, 34], maxZoom: 15 });

  // click-to-pick location
  if (opts.clickTarget) {
    let picked = L.circleMarker(center, { radius: 9, color: '#0e7a4f', fillOpacity: 0.9 }).addTo(map);
    const sync = (lat, lng) => {
      picked.setLatLng([lat, lng]);
      // callers pass {latInput, lngInput}; {lat, lng} accepted as aliases.
      // Any missing/absent optional field is skipped — a null element must
      // never break the location workflow (no "Cannot set properties of null").
      const latKey = opts.clickTarget?.latInput || opts.clickTarget?.lat;
      const lngKey = opts.clickTarget?.lngInput || opts.clickTarget?.lng;
      const latEl = latKey ? document.getElementById(latKey) : null;
      const lngEl = lngKey ? document.getElementById(lngKey) : null;
      if (latEl) latEl.value = lat.toFixed(6);
      if (lngEl) lngEl.value = lng.toFixed(6);
    };
    // v2.4.0 — expose pin control so page scripts can move the pin programmatically
    window.PNV_PINS = window.PNV_PINS || {};
    window.PNV_PINS[elId] = { setPin: sync, map: map };
    map.on('click', (e) => sync(e.latlng.lat, e.latlng.lng));
    const gl = document.getElementById('btnGeolocate');
    const glReset = () => { gl.innerHTML = '<i class="bi bi-geo-alt me-1"></i>Use my location'; };
    const tell = (msg, type) => { try { if (typeof pnvToast === 'function') pnvToast(msg, type); else console.warn('[PUNARVA] ' + msg); } catch (_) { console.warn('[PUNARVA] ' + msg); } };
    if (gl && !gl.dataset.pnvGeoRich) gl.addEventListener('click', () => { // v2.4.0: pages with a rich handler opt out via data-pnv-geo-rich
      if (!navigator.geolocation) return tell('Geolocation is not supported by this browser. Please type coordinates manually.', 'error');
      // pre-check permission: if denied, fail fast instead of spinning
      const start = () => {
        if (gl.disabled) return; // concurrent double-click guard: ek waqt me ek hi request
        gl.disabled = true;
        gl.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
        let settled = false;
        // watchdog: no browser callback within 12s → recover with a clear message
        const watchdog = setTimeout(() => {
          if (settled) return;
          settled = true;
          gl.disabled = false;
          glReset();
          tell('Location request is not responding. Your device/browser location service may be switched off. Please pin the spot by clicking the map instead.', 'error');
        }, 12000);
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            if (settled) return;
            settled = true; clearTimeout(watchdog);
            try {
              sync(pos.coords.latitude, pos.coords.longitude);
              map.setView([pos.coords.latitude, pos.coords.longitude], 15);
              tell('Location captured from your device.', 'success');
            } finally { gl.disabled = false; glReset(); }
          },
          (err) => {
            if (settled) return;
            settled = true; clearTimeout(watchdog);
            gl.disabled = false;
            glReset();
            let m = 'Could not get your location. Please pin the spot by clicking the map.';
            if (err && err.code === 1) m = 'Location permission denied. Allow location for this site in the address bar, then press again.';
            else if (err && err.code === 2) m = 'Your position is unavailable right now. Check that device location (Windows/macOS location service) is on, or pin the spot on the map.';
            else if (err && err.code === 3) m = 'Location request timed out. Please try again or pin the spot on the map.';
            if (window.isSecureContext === false) m += ' Location works on localhost or HTTPS only.';
            tell(m, 'error');
          },
          { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 });
      };
      if (navigator.permissions && navigator.permissions.query) {
        navigator.permissions.query({ name: 'geolocation' })
          .then((st) => {
            if (st.state === 'denied') {
              tell('Location permission is blocked for this site. Click the lock/target icon near the address bar → Location → Allow, then press again.', 'error');
            } else start();
          })
          .catch(start);
      } else start();
    });
  }
  return map;
}

// draw a suggested route polyline
function pnvDrawRoute(map, stops) {
  if (!map || !stops || stops.length === 0) return;
  const pts = stops.filter((s) => s.latitude && s.longitude).map((s) => [Number(s.latitude), Number(s.longitude)]);
  if (pts.length) L.polyline(pts, { color: '#0e7a4f', weight: 3.5, dashArray: '7 8', opacity: 0.85 }).addTo(map);
}
