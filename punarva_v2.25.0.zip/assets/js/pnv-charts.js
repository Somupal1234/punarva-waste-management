/* ============================================================================
   PUNARVA v2.25.0 — premium chart system (admin / citizen / business)
   One themed Chart.js language: Inter type, hairline grids, refined tooltips,
   compact legends, 180–450ms animations, destroy-before-create (no leaks).
   Loaded ONLY on chart pages via pnv_needs_charts() / pnv_chart_assets().
   ========================================================================== */
(function () {
  'use strict';
  if (typeof Chart === 'undefined') { window.PNV_CHART = { ok: false }; return; }

  var css = getComputedStyle(document.documentElement);
  var tok = function (n, f) { var v = (css.getPropertyValue(n) || '').trim(); return v || f; };

  var MUTED = tok('--pnv-muted', '#66766c');

  Chart.defaults.font.family = tok('--bs-body-font-family', 'Inter, sans-serif');
  Chart.defaults.font.size = 11.5;
  Chart.defaults.font.weight = 600;
  Chart.defaults.color = MUTED;
  Chart.defaults.borderColor = 'rgba(32,40,31,.07)';
  Chart.defaults.maintainAspectRatio = false;
  Chart.defaults.animation = { duration: 420, easing: 'easeOutQuart' };
  Chart.defaults.plugins.legend.display = false;
  Chart.defaults.plugins.tooltip = {
    enabled: true,
    backgroundColor: 'rgba(16,32,24,.94)',
    titleColor: '#fff',
    bodyColor: 'rgba(255,255,255,.92)',
    titleFont: { size: 11, weight: 700 },
    bodyFont: { size: 11, weight: 600 },
    padding: 10, cornerRadius: 10, displayColors: false, borderWidth: 0,
    caretSize: 5, boxPadding: 4
  };

  var PAL = {
    green: '#0e7a4f', greenDark: tok('--pnv-green-dark', '#085135'), lime: '#7ccb5f',
    blue: '#1b6ca8', sky: '#3d9be9', amber: '#e09f1f', gold: '#f2b32c',
    red: '#c0392b', rose: '#e35d6a', violet: '#6f42c1', plum: '#8e5cd9',
    teal: '#0b7285', ink: tok('--pnv-ink', '#20281f'), muted: MUTED
  };

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function fmtKg(n) {
    n = Number(n) || 0;
    if (Math.abs(n) >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + ' t';
    var r = Math.round(n * 10) / 10;
    return (r % 1 === 0 ? r.toFixed(0) : r.toFixed(1)) + ' kg';
  }
  function fmtInt(n) { return (Number(n) || 0).toLocaleString('en-IN'); }
  function fmtVal(n, count) { return count ? fmtInt(n) : fmtKg(n); }
  function hexAt(hex, a) {
    var m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex || '');
    if (!m) return hex;
    return 'rgba(' + parseInt(m[1], 16) + ',' + parseInt(m[2], 16) + ',' + parseInt(m[3], 16) + ',' + a + ')';
  }
  function grad(canvas, hex, top) {
    top = top === undefined ? 0.2 : top;
    try {
      var h = canvas.clientHeight || (canvas.parentElement ? canvas.parentElement.clientHeight : 0) || 240;
      var g = canvas.getContext('2d').createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, hexAt(hex, top));
      g.addColorStop(1, hexAt(hex, 0.01));
      return g;
    } catch (e) { return hex; }
  }
  function legendCfg() {
    return { display: true, position: 'bottom', align: 'end',
      labels: { boxWidth: 7, boxHeight: 7, usePointStyle: true, pointStyle: 'circle',
        font: { size: 10.5, weight: 700 }, color: MUTED, padding: 10 } };
  }

  /** create-or-replace: destroys any previous instance on the canvas first */
  function make(canvas, config) {
    var el = typeof canvas === 'string' ? document.getElementById(canvas) : canvas;
    if (!el || !el.getContext) return null;
    var old = Chart.getChart(el);
    if (old) old.destroy();
    var c = new Chart(el, config);
    (window.PNV_CHART._all = window.PNV_CHART._all || []).push(c);
    return c;
  }

  /** compact area/line chart — cfg: {labels, series:[{label,data,color,fill,dash}], suffix, count} */
  function area(canvas, cfg) {
    var el = typeof canvas === 'string' ? document.getElementById(canvas) : canvas;
    if (!el || !cfg || !cfg.labels || !cfg.labels.length) return null;
    var series = cfg.series.map(function (s) {
      var color = s.color || PAL.green;
      return {
        label: s.label || '', data: s.data,
        borderColor: color, borderWidth: 2.4,
        backgroundColor: s.fill === false ? 'transparent' : grad(el, color),
        fill: s.fill !== false, tension: 0.38, borderDash: s.dash || undefined,
        pointRadius: cfg.labels.length > 16 ? 0 : 2.5, pointHoverRadius: 4.5,
        pointBackgroundColor: '#fff', pointBorderColor: color, pointBorderWidth: 2
      };
    });
    return make(el, {
      type: 'line',
      data: { labels: cfg.labels, datasets: series },
      options: {
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: series.length > 1 ? legendCfg() : { display: false },
          tooltip: { callbacks: {
            title: function (its) { return its.length ? String(its[0].label) : ''; },
            label: function (it) { return it.dataset.label + ' ' + fmtVal(it.parsed.y, cfg.count) + (cfg.suffix || ''); }
          } }
        },
        scales: {
          y: { beginAtZero: true, border: { display: false }, grid: { color: 'rgba(32,40,31,.06)' },
               ticks: { maxTicksLimit: 5, callback: function (v) { return fmtVal(v, cfg.count); } } },
          x: { border: { display: false }, grid: { display: false },
               ticks: { maxTicksLimit: 8, maxRotation: 0, autoSkip: true, font: { size: 10.5 } } }
        }
      }
    });
  }

  /** compact bar chart — cfg: {labels, series:[{label,data,color|colors}], horizontal, suffix, count} */
  function bars(canvas, cfg) {
    var el = typeof canvas === 'string' ? document.getElementById(canvas) : canvas;
    if (!el || !cfg || !cfg.labels || !cfg.labels.length) return null;
    var axis = cfg.horizontal ? 'y' : 'x';
    var valKey = cfg.horizontal ? 'x' : 'y';
    var series = cfg.series.map(function (s) {
      return { label: s.label || '', data: s.data,
        backgroundColor: s.colors || s.color, borderRadius: 6, borderSkipped: false,
        maxBarThickness: cfg.horizontal ? 15 : 32, minBarLength: 2 };
    });
    return make(el, {
      type: 'bar',
      data: { labels: cfg.labels, datasets: series },
      options: {
        indexAxis: axis,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: series.length > 1 ? legendCfg() : { display: false },
          tooltip: { callbacks: {
            label: function (it) { return it.dataset.label + ' ' + fmtVal(it.parsed[valKey], cfg.count) + (cfg.suffix || ''); }
          } }
        },
        scales: cfg.horizontal ? {
          x: { beginAtZero: true, border: { display: false }, grid: { color: 'rgba(32,40,31,.06)' },
               ticks: { maxTicksLimit: 5, precision: 0, callback: function (v) { return fmtVal(v, cfg.count); } } },
          y: { border: { display: false }, grid: { display: false }, ticks: { font: { size: 10.5 } } }
        } : {
          y: { beginAtZero: true, border: { display: false }, grid: { color: 'rgba(32,40,31,.06)' },
               ticks: { maxTicksLimit: 5, precision: 0, callback: function (v) { return fmtVal(v, cfg.count); } } },
          x: { border: { display: false }, grid: { display: false },
               ticks: { maxRotation: 0, autoSkip: true, font: { size: 10.5 } } }
        }
      }
    });
  }

  function animBars(scope) {
    requestAnimationFrame(function () { requestAnimationFrame(function () {
      (scope || document).querySelectorAll('.mix-fill, .flow-bar i').forEach(function (f) {
        f.style.width = f.dataset.w + '%';
      });
    }); });
  }

  /** horizontal distribution bars — rows: [{name,color,value}] */
  function renderMix(el, rows) {
    var E = typeof el === 'string' ? document.querySelector(el) : el;
    if (!E || !rows || !rows.length) return;
    var max = Math.max.apply(null, rows.map(function (r) { return Number(r.value) || 0; }).concat([0.0001]));
    var total = rows.reduce(function (s, r) { return s + (Number(r.value) || 0); }, 0) || 1;
    E.innerHTML = rows.map(function (r) {
      var v = Number(r.value) || 0;
      return '<div class="mix-row">' +
        '<div class="mix-top"><span class="mix-name"><span class="dot" style="background:' + r.color + '" aria-hidden="true"></span>' + esc(r.name) + '</span>' +
        '<span class="mix-val">' + fmtKg(v) + '<small>' + Math.round(v / total * 100) + '%</small></span></div>' +
        '<div class="mix-track" aria-hidden="true"><i class="mix-fill" data-w="' + (v / max * 100).toFixed(1) + '" style="background:' + r.color + '"></i></div>' +
        '</div>';
    }).join('');
    animBars(E);
  }

  /** operational progression — steps: [{name,color,icon,value,meta}], base = 100% reference */
  function renderFlow(el, steps, base) {
    var E = typeof el === 'string' ? document.querySelector(el) : el;
    if (!E || !steps || !steps.length) return;
    var b = Math.max(Number(base) || (steps.length ? Number(steps[0].value) : 1), 0.0001);
    E.innerHTML = steps.map(function (s) {
      var v = Number(s.value) || 0;
      var pct = Math.max(0, Math.min(100, Math.round(v / b * 100)));
      return '<div class="flow-step">' +
        '<span class="flow-dot" style="background:' + s.color + '"><i class="bi ' + (s.icon || 'bi-circle') + '" aria-hidden="true"></i></span>' +
        '<span class="flow-info"><span class="flow-name">' + esc(s.name) + '</span>' +
        '<span class="flow-bar" aria-hidden="true"><i data-w="' + pct + '" style="background:' + s.color + '"></i></span></span>' +
        '<span class="flow-val">' + fmtVal(v, s.count) + '<small>' + (s.meta || (pct + '%')) + '</small></span>' +
        '</div>';
    }).join('');
    animBars(E);
  }

  /** segmented bar + readable list — parts: [{label,color,n}] */
  function renderSeg(barSel, listSel, parts) {
    var bar = typeof barSel === 'string' ? document.querySelector(barSel) : barSel;
    var list = typeof listSel === 'string' ? document.querySelector(listSel) : listSel;
    if (!bar || !parts || !parts.length) return;
    var total = parts.reduce(function (s, p) { return s + (Number(p.n) || 0); }, 0) || 1;
    bar.innerHTML = parts.filter(function (p) { return Number(p.n) > 0; }).map(function (p) {
      return '<i data-w="' + (p.n / total * 100).toFixed(2) + '" style="background:' + p.color + '" title="' + esc(p.label) + '"></i>';
    }).join('');
    bar.querySelectorAll('i').forEach(function (f) { f.style.width = f.dataset.w + '%'; });
    if (list) list.innerHTML = parts.map(function (p) {
      return '<div class="seg-item"><span class="dot" style="background:' + p.color + '" aria-hidden="true"></span>' +
        '<span class="seg-name">' + esc(p.label) + '</span>' +
        '<span class="seg-val">' + fmtInt(p.n) + '<small>' + Math.round(p.n / total * 100) + '%</small></span></div>';
    }).join('');
  }

  /** 7M / 6M / 12M / All range chips wired to a real dataset (client-side slice) */
  function monthControl(rangeSel, canvasId, data, opts) {
    var box = typeof rangeSel === 'string' ? document.querySelector(rangeSel) : rangeSel;
    if (!box || !data || !data.labels || !data.labels.length) return;
    opts = opts || {};
    var draw = function (n) {
      var L = data.labels, V = data.values;
      if (n > 0) { L = L.slice(-n); V = V.slice(-n); }
      area(canvasId, { labels: L, suffix: opts.suffix, count: opts.count,
        series: [{ label: opts.label || '', data: V, color: opts.color || PAL.green }] });
    };
    var init = box.querySelector('button[aria-pressed="true"]');
    draw(init ? (parseInt(init.dataset.months, 10) || 0) : 12);
    box.addEventListener('click', function (e) {
      var b = e.target.closest('button[data-months]');
      if (!b) return;
      box.querySelectorAll('button').forEach(function (x) {
        x.setAttribute('aria-pressed', x === b ? 'true' : 'false');
      });
      draw(parseInt(b.dataset.months, 10) || 0);
    });
  }

  window.PNV_CHART = {
    ok: true, make: make, area: area, bars: bars,
    renderMix: renderMix, renderFlow: renderFlow, renderSeg: renderSeg,
    monthControl: monthControl, palette: PAL, fmtKg: fmtKg, fmtInt: fmtInt, esc: esc
  };
})();
