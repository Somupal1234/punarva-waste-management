/* PUNARVA – shared frontend behaviours (ES6) */
'use strict';

// escape user/server-sourced strings before HTML interpolation (XSS defense-in-depth)
const pnvEsc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pnvHex = (c) => (/^#[0-9a-fA-F]{3,8}$/.test(String(c)) ? c : '#198754'); // style-attr safe color

// ---------- v2.4.1 CSV export (free browser Blob/File API — file is generated locally in the browser,
// no server round-trip). Always .csv — never labelled .xlsx (no XLSX generator is used). ----------
window.pnvCsvDownload = function (filename, headers, rows) {
  try {
    const esc = (v) => { const s = String(v === null || v === undefined ? '' : v); return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
    const lines = [headers.map(esc).join(',')].concat((rows || []).map((r) => r.map(esc).join(',')));
    const blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' }); // BOM → Excel opens Unicode safely
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000); // generous revoke — some browsers keep the download pipeline open
    if (window.pnvToast) pnvToast('CSV downloaded (' + (rows ? rows.length : 0) + ' rows).', 'success');
  } catch (e) { if (window.pnvToast) pnvToast('Could not generate the CSV in this browser.', 'error'); }
};

// ---------- toasts ----------
// (single implementation: accessible .pnv-toast system defined at the bottom of this file)

// ---------- confirm dialogs ----------
document.addEventListener('submit', (e) => {
  const f = e.target;
  if (f.dataset && f.dataset.confirm) {
    if (!window.confirm(f.dataset.confirm)) { e.preventDefault(); }
  }
});

// ---------- v2.4.3 double-submit guard ----------
// A second click on a submitting button must never post twice (the collector "Complete Pickup"
// double-click produced a duplicate-key SQL error). AJAX forms that preventDefault() are skipped;
// buttons are re-enabled after 8 s as a safety net (e.g. user presses Stop and retries).
document.addEventListener('submit', (e) => {
  const f = e.target;
  if (e.defaultPrevented || f.dataset.pnvSubmitted === '1' || f.hasAttribute('data-allow-double')) return;
  const btns = [...f.querySelectorAll('button[type="submit"], button:not([type])')].filter((b) => !b.disabled);
  if (!btns.length) return;
  f.dataset.pnvSubmitted = '1';
  btns.forEach((b) => { b.disabled = true; });
  setTimeout(() => { delete f.dataset.pnvSubmitted; btns.forEach((b) => { b.disabled = false; }); }, 8000);
});

// ---------- auto-hide alerts ----------
document.querySelectorAll('.alert-auto').forEach((a) => setTimeout(() => bootstrap.Alert.getOrCreateInstance(a).close(), 6000));

// ---------- language selector auto-submit ----------
document.querySelectorAll('form[data-autosubmit] select').forEach((s) =>
  s.addEventListener('change', () => s.form.submit()));

// ---------- API helper ----------
async function pnvApi(url, options = {}) {
  const opts = Object.assign({ headers: { 'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]')?.content || '' } }, options);
  if (opts.body && !(opts.body instanceof FormData) && typeof opts.body === 'object') {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(opts.body);
  }
  const res = await fetch(url, opts);
  let data;
  try { data = await res.json(); } catch { data = { success: false, message: 'Invalid server response' }; }
  return data;
}

// ---------- notification bell ----------
(function initNotifications() {
  const listEl = document.getElementById('notifList');
  if (!listEl) return;
  const countEl = document.getElementById('notifCount');
  const apiBase = listEl.dataset.api;
  let firstLoad = true;

  async function refresh() {
    if (firstLoad && !listEl.children.length) {
      listEl.innerHTML = Array(3).fill('<div class="notif-skel"><div class="sk-line w-75"></div><div class="sk-line w-100"></div></div>').join('');
    }
    try {
      const data = await pnvApi(apiBase + '/list.php?limit=12');
      firstLoad = false;
      if (!data.success) return;
      countEl.textContent = data.data.unread || '';
      countEl.classList.toggle('d-none', !data.data.unread);
      listEl.innerHTML = data.data.items.length === 0
        ? '<div class="empty-state py-4"><i class="bi bi-bell-slash"></i><div class="mt-2">No notifications yet</div></div>'
        : data.data.items.map((n) => `
          <div class="notif-item ${n.is_read ? '' : 'unread'}">
            <div class="d-flex justify-content-between">
              <span class="n-title">${pnvEsc(n.title)}</span>
              ${n.is_read ? '' : `<button class="btn btn-sm btn-link p-0 mark-read" data-id="${Number(n.id)}">mark read</button>`}
            </div>
            <div class="text-muted small">${pnvEsc(n.message)}</div>
            <div class="text-muted" style="font-size:.72rem">${pnvEsc(n.ago)}</div>
          </div>`).join('');
    } catch (e) { /* silent */ }
  }
  listEl.addEventListener('click', async (e) => {
    const btn = e.target.closest('.mark-read');
    if (!btn) return;
    await pnvApi(apiBase + '/read.php', { method: 'POST', body: { id: Number(btn.dataset.id) } });
    refresh();
  });
  const markAll = document.getElementById('markAllRead');
  if (markAll) markAll.addEventListener('click', async () => { await pnvApi(apiBase + '/read.php', { method: 'POST', body: {} }); refresh(); });
  refresh();
  setInterval(refresh, 60000);
})();

// ---------- sidebar toggle (mobile) ----------
const sidebarToggle = document.getElementById('sidebarToggle');
if (sidebarToggle) {
  sidebarToggle.addEventListener('click', () => {
    const open = document.querySelector('.dash-sidebar').classList.toggle('show');
    sidebarToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    document.querySelector('.sidebar-backdrop').classList.toggle('show');
  });
  // v2.7.0: bfcache restore par stuck mobile nav state clear (sidebar + backdrop + public collapse)
  window.addEventListener('pageshow', (e) => {
    if (!e.persisted) return;
    document.querySelector('.dash-sidebar')?.classList.remove('show');
    document.querySelector('.sidebar-backdrop')?.classList.remove('show');
    document.querySelectorAll('.navbar-collapse.show').forEach((el) => el.classList.remove('show'));
    document.querySelectorAll('.navbar-toggler, #sidebarToggle').forEach((el) => el.setAttribute('aria-expanded', 'false'));
  });
  document.querySelector('.sidebar-backdrop')?.addEventListener('click', () => {
    document.querySelector('.dash-sidebar').classList.remove('show');
    document.querySelector('.sidebar-backdrop').classList.remove('show');
    sidebarToggle.setAttribute('aria-expanded', 'false');
  });
}

// ---------- QR code ----------
document.querySelectorAll('[data-qr]').forEach((el) => {
  new QRCode(el, { text: el.dataset.qr, width: el.dataset.size ? Number(el.dataset.size) : 132, height: el.dataset.size ? Number(el.dataset.size) : 132, correctLevel: QRCode.CorrectLevel.M });
});

// ---------- copy button ----------
document.querySelectorAll('[data-copy]').forEach((btn) => btn.addEventListener('click', () => {
  navigator.clipboard?.writeText(btn.dataset.copy);
  pnvToast('Copied: ' + btn.dataset.copy, 'info');
}));

// ---------- Manual Waste Scanner page (v2.14.0 — no AI, user classifies) ----------
(function initScanner() {
  const boot = () => {
  const form = document.getElementById('scanForm');
  if (!form) return;
  const input = document.getElementById('scanImage');
  const drop = document.getElementById('scanDrop');
  const preview = document.getElementById('scanPreview');
  const previewWrap = document.getElementById('previewWrap');
  const classifyWrap = document.getElementById('classifyWrap');
  const select = document.getElementById('scanCategory');
  const guideWrap = document.getElementById('guideWrap');
  const submitBtn = document.getElementById('scanSubmit');
  const resultBox = document.getElementById('scanResult');
  const cats = window.PNV_CATEGORIES || [];

  // populate the category selector (grouped by recommended bin)
  const bins = [...new Set(cats.map((c) => c.bin || 'Other'))];
  bins.forEach((bin) => {
    const og = document.createElement('optgroup');
    og.label = bin;
    cats.filter((c) => (c.bin || 'Other') === bin).forEach((c) => {
      const o = document.createElement('option');
      o.value = c.id;
      o.textContent = c.name;
      og.appendChild(o);
    });
    select.appendChild(og);
  });

  const showPreview = (file) => {
    if (!file || !file.type.startsWith('image/')) { pnvToast('Please choose an image file (JPG, PNG or WebP).', 'error'); return; }
    if (file.size > 6 * 1024 * 1024) { pnvToast('Image is too large — maximum ' + Math.round(6) + ' MB.', 'error'); return; }
    // CSP-safe preview: FileReader data-URL (blob: is not in CSP img-src)
    const fr = new FileReader();
    fr.onload = () => { preview.src = String(fr.result || ''); };
    fr.readAsDataURL(file);
    previewWrap.classList.remove('d-none');
    classifyWrap.classList.remove('d-none');
    guideWrap.classList.add('d-none');
    select.value = '';
  };
  const clearImage = () => {
    input.value = '';
    previewWrap.classList.add('d-none');
    classifyWrap.classList.add('d-none');
    resultBox.innerHTML = '';
    document.getElementById('scanResultWrap').classList.add('d-none');
  };
  input.addEventListener('change', () => (input.files.length ? showPreview(input.files[0]) : clearImage()));
  document.getElementById('scanRemove').addEventListener('click', clearImage);
  drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('dragover'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('dragover'));
  drop.addEventListener('drop', (e) => {
    e.preventDefault(); drop.classList.remove('dragover');
    if (e.dataTransfer.files.length) { input.files = e.dataTransfer.files; showPreview(input.files[0]); }
  });

  // static rule-based guidance for the selected category (not AI — plain lookup)
  select.addEventListener('change', () => {
    const c = cats.find((x) => String(x.id) === String(select.value));
    if (!c) { guideWrap.classList.add('d-none'); return; }
    document.getElementById('guideCat').innerHTML =
      '<div class="small text-muted fw-bold text-uppercase">Category</div><div class="fw-bold" style="color:' + pnvHex(c.color) + '">' + pnvEsc(c.name) + '</div>';
    document.getElementById('guideBin').innerHTML = '<i class="bi bi-trash3 me-1"></i>' + pnvEsc(c.bin || '');
    document.getElementById('guideRec').innerHTML = c.rec === 'yes'
      ? '<span class="badge text-bg-success"><i class="bi bi-recycle me-1"></i>Recyclable</span>'
      : '<span class="badge text-bg-secondary"><i class="bi bi-x-circle me-1"></i>Not recyclable</span>';
    document.getElementById('guideAdvice').innerHTML = '<i class="bi bi-lightbulb text-warning me-1"></i>' + pnvEsc(c.advice || '');
    guideWrap.classList.remove('d-none');
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!input.files.length) { pnvToast('Please choose or capture a waste photo first.', 'error'); return; }
    if (!select.value) { pnvToast('Please select a waste category.', 'error'); return; }
    const fd = new FormData();
    fd.append('image', input.files[0]);
    fd.append('category_id', select.value);
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Saving…';
    document.getElementById('scanLoading').classList.remove('d-none');
    try {
      const data = await pnvApi(form.dataset.api, { method: 'POST', body: fd });
      if (!data.success) { pnvToast(data.message || 'Could not save the scan', 'error'); return; }
      renderResult(data.data);
      pnvToast('Scan saved with your selected category');
    } catch (err) {
      pnvToast('Network error — please retry.', 'error');
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = '<i class="bi bi-check2-circle me-1"></i> Confirm & Save Scan';
      document.getElementById('scanLoading').classList.add('d-none');
    }
  });

  function renderResult(r) {
    document.getElementById('scanResultWrap').classList.remove('d-none');
    resultBox.innerHTML = `
      <div><span class="badge text-bg-success"><i class="bi bi-hand-index-thumb me-1"></i>User Selected Classification</span></div>
      <h3 class="mt-2 mb-0 fw-bold">${pnvEsc(r.category_name)}</h3>
      <div class="row g-2 mt-1">
        <div class="col-6"><div class="p-2 rounded-3 bg-light border h-100"><div class="small text-muted fw-bold text-uppercase">Recommended bin</div><div class="fw-bold small"><i class="bi bi-trash3 me-1"></i>${pnvEsc(r.bin_type || '')}</div></div></div>
        <div class="col-6"><div class="p-2 rounded-3 bg-light border h-100"><div class="small text-muted fw-bold text-uppercase">Recyclable</div><div class="small">${r.recyclable === 'yes' ? '<span class="badge text-bg-success"><i class="bi bi-recycle me-1"></i>Yes</span>' : '<span class="badge text-bg-secondary"><i class="bi bi-x-circle me-1"></i>No</span>'}</div></div></div>
      </div>
      <div class="alert alert-light border mt-2 mb-3 small"><i class="bi bi-lightbulb text-warning me-1"></i>${pnvEsc(r.advice || '')}</div>
      <div class="d-flex gap-2 flex-wrap">
        <a class="btn btn-pnv" href="${r.report_url}"><i class="bi bi-megaphone me-1"></i>Report Waste</a>
        <a class="btn btn-outline-pnv" href="${r.pickup_url}"><i class="bi bi-truck me-1"></i>Request Pickup</a>
        <button class="btn btn-outline-secondary" onclick="document.getElementById('scanImage').value='';document.getElementById('previewWrap').classList.add('d-none');document.getElementById('classifyWrap').classList.add('d-none');document.getElementById('scanResultWrap').classList.add('d-none');">Scan another</button>
      </div>`;
  }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();

// ---------- global image upload size guard (5 MB, client-side) ----------
(function () {
  const LIMIT = 5 * 1024 * 1024; // 5 MB (binary)
  const MSG = 'Image size must be 5 MB or less.';
  function clearError(inp) { const box = inp.parentElement && inp.parentElement.querySelector('.js-size-error'); if (box) box.remove(); }
  function showError(inp) {
    clearError(inp);
    const d = document.createElement('div');
    d.className = 'text-danger small mt-1 js-size-error';
    d.textContent = MSG;
    (inp.closest('.col-6, .col-md-6, .col, .mb-3, .scan-drop') || inp.parentElement).appendChild(d);
  }
  document.addEventListener('change', function (e) {
    const inp = e.target;
    if (!(inp instanceof HTMLInputElement) || inp.type !== 'file' || !/image/i.test(inp.accept || '')) return;
    const f = inp.files && inp.files[0];
    if (!f) { clearError(inp); return; }
    if (f.size > LIMIT) {
      inp.value = '';
      showError(inp);
      if (window.pnvToast) pnvToast(MSG, 'error');
    } else {
      clearError(inp);
    }
  });
  // safety net: block submit if an oversized image somehow still selected
  document.addEventListener('submit', function (e) {
    const f = e.target;
    if (!(f instanceof HTMLFormElement)) return;
    for (const inp of f.querySelectorAll('input[type="file"][accept]')) {
      if (!/image/i.test(inp.accept || '')) continue;
      const file = inp.files && inp.files[0];
      if (file && file.size > LIMIT) { e.preventDefault(); showError(inp); if (window.pnvToast) pnvToast(MSG, 'error'); return; }
    }
  }, true);
})();
// ---------- data-confirm dialogs (delete/confirm buttons & critical switches) ----------
document.addEventListener('submit', function (e) {
  const f = e.target.closest('[data-confirm]');
  if (f && !window.confirm(f.getAttribute('data-confirm'))) { e.preventDefault(); e.stopPropagation(); }
}, true);
document.addEventListener('click', function (e) {
  const b = e.target.closest('button[data-confirm],input[type="checkbox"][data-confirm]');
  if (!b) return;
  if (!window.confirm(b.getAttribute('data-confirm'))) {
    e.preventDefault(); e.stopPropagation();
    if (b.type === 'checkbox') b.checked = !b.checked; // revert toggle
  }
}, true);

// ---------- section reveal on scroll (progressive enhancement) ----------
(function () {
  const els = document.querySelectorAll('.reveal');
  if (!els.length || !('IntersectionObserver' in window)) { els.forEach(e => e.classList.add('in')); return; }
  const io = new IntersectionObserver(entries => {
    entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
  }, { threshold: .12 });
  els.forEach(e => io.observe(e));
})();

// ---------- KPI count-up (progressive enhancement; static values remain in markup) ----------
(function () {
  const nums = document.querySelectorAll('.kpi-card strong, .kpi-card .h3, .kpi-card .display-6, .kpi-card .kpi-value');
  if (!nums.length || !('IntersectionObserver' in window)) return;
  const fmt = n => n.toLocaleString('en-IN');
  const io = new IntersectionObserver(entries => {
    entries.forEach(en => {
      if (!en.isIntersecting) return;
      const el = en.target; io.unobserve(el);
      const raw = (el.textContent || '').trim();
      const m = raw.match(/^([\d,]+(\.\d+)?)(.*)$/);
      if (!m) return;
      const end = parseFloat(m[1].replace(/,/g, ''));
      if (!isFinite(end) || end === 0) return;
      const suffix = m[3] || '';
      const dur = 900, t0 = performance.now();
      const decimals = (m[1].split('.')[1] || '').length;
      (function tick(t) {
        const p = Math.min(1, (t - t0) / dur);
        const eased = 1 - Math.pow(1 - p, 3);
        el.textContent = fmt(+(end * eased).toFixed(decimals)) + suffix;
        if (p < 1) requestAnimationFrame(tick);
      })(t0);
    });
  }, { threshold: .4 });
  nums.forEach(el => io.observe(el));
})();

// ---------- animate .progress bars when visible ----------
(function () {
  const bars = document.querySelectorAll('.progress-bar');
  if (!bars.length || !('IntersectionObserver' in window)) return;
  const io = new IntersectionObserver(entries => {
    entries.forEach(en => {
      if (!en.isIntersecting) return;
      const el = en.target; io.unobserve(el);
      const w = el.getAttribute('data-width') || el.style.width;
      el.style.transition = 'none'; el.style.width = '0%';
      requestAnimationFrame(() => { el.style.transition = 'width 1s ease'; el.style.width = w; });
    });
  }, { threshold: .4 });
  bars.forEach(el => io.observe(el));
})();

// ---------- accessible toast notifications (success flashes -> toasts; errors stay inline) ----------
(function () {
  const container = document.createElement('div');
  container.className = 'pnv-toasts';
  container.setAttribute('aria-live', 'polite');
  container.setAttribute('aria-atomic', 'false');
  document.body.appendChild(container);

  window.pnvToast = function (message, type = 'success') {
    const t = document.createElement('div');
    t.className = 'pnv-toast pnv-toast-' + type;
    t.setAttribute('role', 'status');
    t.innerHTML = `<i class="bi ${type === 'success' ? 'bi-check-circle-fill' : 'bi-info-circle-fill'}" aria-hidden="true"></i>
      <div class="pnv-toast-msg"></div>
      <button class="pnv-toast-close" type="button" aria-label="Close notification">&times;</button>`;
    t.querySelector('.pnv-toast-msg').textContent = message; // XSS-safe
    container.appendChild(t);
    requestAnimationFrame(() => t.classList.add('show'));
    const close = () => { t.classList.remove('show'); setTimeout(() => t.remove(), 350); };
    t.querySelector('.pnv-toast-close').addEventListener('click', close);
    t.addEventListener('mouseenter', () => clearTimeout(t._tm));
    t.addEventListener('mouseleave', () => { t._tm = setTimeout(close, 2500); });
    t._tm = setTimeout(close, 5000);
    return t;
  };

  // success flashes become toasts; danger/warning alerts remain inline (persistent)
  document.querySelectorAll('.alert-success.alert-auto').forEach((alertEl) => {
    const msg = alertEl.textContent.trim();
    if (msg) window.pnvToast(msg, 'success');
    alertEl.classList.add('d-none');
  });
})();

// ---------- form busy state (real waits: uploads, POSTs) ----------
(function () {
  document.addEventListener('submit', (e) => {
    const form = e.target;
    if (!(form instanceof HTMLFormElement)) return;
    if (form.dataset.busyBound) return; // this submit already handled
    if (e.defaultPrevented) return;     // data-confirm cancelled
    if (form.hasAttribute('data-no-busy')) return;
    const btn = (e.submitter && e.submitter.type === 'submit') ? e.submitter
              : form.querySelector('button[type="submit"], button:not([type])');
    if (!btn || btn.classList.contains('pnv-busy')) return;
    form.dataset.busyBound = '1';
    btn.classList.add('pnv-busy');
    btn.setAttribute('aria-busy', 'true');
    btn.disabled = true;
    // safety: re-enable if navigation is blocked (validation or slow scripts)
    setTimeout(() => {
      btn.disabled = false;
      btn.classList.remove('pnv-busy');
      btn.removeAttribute('aria-busy');
      delete form.dataset.busyBound;
    }, 8000);
  }, true);
})();

/* =========================================================================
   v2.2.0 — GLOBAL required-field marker (ek standard, poori website)
   Har `required` input/select/textarea ke label ke aage red asterisk lagata hai.
   - Single source of truth: HTML `required` attribute (optional fields kabhi mark nahi hote)
   - Idempotent: jis label me pehle se .required-asterisk hai wahan dobara nahi lagata
   - AJAX/modals/dynamic forms: MutationObserver naye nodes par bhi chalta hai
   - a11y: asterisk aria-hidden (asli indication = required attribute)
   ========================================================================= */
(function () {
  'use strict';
  function findLabel(el) {
    if (el.id) {
      var byFor = document.querySelector('label[for="' + (window.CSS && CSS.escape ? CSS.escape(el.id) : el.id) + '"]');
      if (byFor) return byFor;
    }
    var wrap = el.closest ? el.closest('label') : null;
    if (wrap) return wrap;
    // ancestor-walk: har poorvaj ke direct bachon me label dhoondo (input-group/mb-1 jaise compact layouts cover)
    var n = el.parentElement, hops = 0;
    while (n && n !== document.body && hops < 4) {
      for (var i = 0; i < n.children.length; i++) {
        if (n.children[i].tagName === 'LABEL') return n.children[i];
      }
      n = n.parentElement; hops++;
    }
    return null;
  }
  function decorateEl(el) {
    if (!el || el.type === 'hidden' || el.disabled) return;
    var label = findLabel(el);
    if (!label || label.querySelector('.required-asterisk')) return;
    // purane plain-text asterisk (label ka text '*' par khatam) — dobara mat lagao
    if (/\*\s*$/.test((label.textContent || '').trim())) return;
    var span = document.createElement('span');
    span.className = 'required-asterisk';
    span.setAttribute('aria-hidden', 'true');
    span.textContent = '*';
    label.appendChild(span);
  }
  function scan(root) {
    if (!root) return; // document (nodeType 9) bhi allow — initial pass isi par chalta hai
    if (root.nodeType === 1 && root.matches && root.matches('input[required], select[required], textarea[required]')) decorateEl(root);
    if (root.querySelectorAll) root.querySelectorAll('input[required], select[required], textarea[required]').forEach(decorateEl);
  }
  scan(document);
  try {
    new MutationObserver(function (muts) {
      muts.forEach(function (m) {
        Array.prototype.forEach.call(m.addedNodes, function (n) { if (n.nodeType === 1) scan(n); });
      });
    }).observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) { /* purane browsers me static scan hi kaafi hai */ }
})();

// ---------- v2.8.0: live community impact ranking (Option B — lightweight polling) ----------
// Polls every 12 s ONLY while the tab is visible; refreshes on bfcache restore; stops otherwise.
(function () {
  const list = document.getElementById('rankList');
  if (!list) return;
  const api = list.dataset.api;
  let timer = null;

  const mvIcon = (m) => m === 'up' ? '<i class="mv-up bi bi-arrow-up-short"></i>'
    : m === 'down' ? '<i class="mv-down bi bi-arrow-down-short"></i>' : '<i class="mv-flat">—</i>';

  function render(d) {
    // v2.22.0 fix: API wraps payload in a `data` envelope (json_ok) and the previous
    // code referenced an `esc` helper that does not exist in this scope — the widget
    // therefore never re-rendered (silent ReferenceError inside refresh's try/catch).
    const payload = d && d.data ? d.data : d;
    if (!payload || !Array.isArray(payload.users)) return;
    const me = payload.me || {};
    const rows = payload.users.map((u) => '<li data-uid="' + Number(u.id) + '" class="' + (me && me.rank === u.rank ? 'me' : '') + '">' +
      '<span class="rank-no">#' + Number(u.rank) + '</span><span class="flex-grow-1 fw-semibold">' + pnvEsc(u.display_name) + '</span>' +
      '<span class="small text-muted">' + Number(u.impact_count) + ' ✓</span>' + mvIcon(u.movement) + '</li>');
    if (me && !me.in_top) rows.push('<li class="me" data-uid="' + Number(me.id) + '"><span class="rank-no">#' + Number(me.rank) + '</span>' +
      '<span class="flex-grow-1 fw-bold">' + pnvEsc(document.body.dataset.rankYou || 'You') + '</span>' +
      '<span class="small text-muted">' + Number(me.impact_count) + ' ✓</span>' + mvIcon(me.movement) + '</li>');
    list.innerHTML = rows.join('') || '<li><span class="small text-muted">—</span></li>';
    const upd = document.getElementById('rankUpdated');
    if (upd) { upd.innerHTML = '<i class="bi bi-arrow-repeat"></i> ' + new Date(payload.updated_at).toLocaleTimeString(); }
  }

  async function refresh() {
    try {
      const r = await fetch(api, { headers: { 'Accept': 'application/json' } });
      if (r.ok) render(await r.json());
    } catch (e) { /* offline: keep last ranking on screen */ }
  }

  function start() { if (!timer) { refresh(); timer = setInterval(refresh, 12000); } }
  function stop() { if (timer) { clearInterval(timer); timer = null; } }
  document.addEventListener('visibilitychange', () => document.hidden ? stop() : start());
  window.addEventListener('pageshow', (e) => { if (e.persisted) refresh(); });
  window.pnvRefreshRanking = refresh; // callable after citizen's own verified activity
  start();
})();
