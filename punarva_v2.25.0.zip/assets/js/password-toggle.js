/* PUNARVA – accessible password show/hide toggle (no dependencies)
   - Default: password HIDDEN
   - Only flips input type in the browser; value never leaves the DOM
   - ARIA: aria-label + aria-pressed, keyboard focusable (button element) */
'use strict';

(function () {
  function decorate(inp) {
    if (inp.dataset.pnvEye) return;
    inp.dataset.pnvEye = '1';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'btn btn-outline-secondary pnv-eye-btn';
    btn.setAttribute('aria-label', 'Show password');
    btn.setAttribute('aria-pressed', 'false');
    btn.title = 'Show password';
    btn.innerHTML = '<i class="bi bi-eye" aria-hidden="true"></i>';

    btn.addEventListener('click', function () {
      const show = inp.type === 'password';
      inp.type = show ? 'text' : 'password';
      btn.innerHTML = '<i class="bi bi-eye' + (show ? '-slash' : '') + '" aria-hidden="true"></i>';
      btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
      btn.setAttribute('aria-pressed', show ? 'true' : 'false');
      btn.title = show ? 'Hide password' : 'Show password';
      inp.focus({ preventScroll: true });
    });

    const ig = inp.closest('.input-group');
    if (ig) {
      ig.appendChild(btn);
      return;
    }
    // input-group ke bahar wale password fields ke liye floating toggle
    const wrap = document.createElement('div');
    wrap.className = 'pnv-eye-wrap';
    inp.parentNode.insertBefore(wrap, inp);
    wrap.appendChild(inp);
    wrap.appendChild(btn);
  }

  function init() { document.querySelectorAll('input[type="password"]').forEach(decorate); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
