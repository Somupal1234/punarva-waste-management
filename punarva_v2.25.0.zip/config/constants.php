<?php
/**
 * Application constants: roles, status machines, labels.
 */

// ---- Roles ----
const ROLE_ADMIN     = 'admin';
const ROLE_CITIZEN   = 'citizen';
const ROLE_COLLECTOR = 'collector';
const ROLE_RECYCLER  = 'recycler';
const ROLE_BUSINESS  = 'business';
const ROLE_LABELS = [
    ROLE_ADMIN     => 'Administrator',
    ROLE_CITIZEN   => 'Citizen',
    ROLE_COLLECTOR => 'Waste Collector',
    ROLE_RECYCLER  => 'Recycler / Facility',
    ROLE_BUSINESS  => 'Business / Institution',
];
const ROLE_HOME = [
    ROLE_ADMIN     => 'admin/dashboard.php',
    ROLE_CITIZEN   => 'citizen/dashboard.php',
    ROLE_COLLECTOR => 'collector/dashboard.php',
    ROLE_RECYCLER  => 'recycler/dashboard.php',
    ROLE_BUSINESS  => 'business/dashboard.php',
];

// ---- Pickup status machine ----
const PICKUP_STATUSES = ['REQUESTED','ASSIGNED','ACCEPTED','ON_THE_WAY','ARRIVED','COLLECTED','COMPLETED','CANCELLED','REJECTED'];
// allowed: current => [next...]
const PICKUP_TRANSITIONS = [
    'REQUESTED' => ['ASSIGNED', 'CANCELLED'],
    'ASSIGNED'  => ['ACCEPTED', 'REQUESTED', 'CANCELLED'],
    'ACCEPTED'  => ['ON_THE_WAY', 'CANCELLED'],
    'ON_THE_WAY'=> ['ARRIVED'],
    'ARRIVED'   => ['COLLECTED'],
    'COLLECTED' => ['COMPLETED'],
    'COMPLETED' => [],
    'CANCELLED' => [],
    'REJECTED'  => [],
];
const PICKUP_STATUS_LABELS = [
    'REQUESTED' => 'Requested', 'ASSIGNED' => 'Assigned', 'ACCEPTED' => 'Accepted',
    'ON_THE_WAY'=> 'On the way', 'ARRIVED' => 'Arrived', 'COLLECTED' => 'Collected',
    'COMPLETED' => 'Completed', 'CANCELLED' => 'Cancelled', 'REJECTED' => 'Rejected',
];
const PICKUP_STATUS_COLORS = [
    'REQUESTED' => 'warning', 'ASSIGNED' => 'info', 'ACCEPTED' => 'primary',
    'ON_THE_WAY'=> 'secondary', 'ARRIVED' => 'dark', 'COLLECTED' => 'purple',
    'COMPLETED' => 'success', 'CANCELLED' => 'danger', 'REJECTED' => 'danger',
];

// ---- Waste stage machine (Waste Passport) ----
const WASTE_STAGES = ['CREATED','PICKUP_REQUESTED','COLLECTED','SORTED','PROCESSING','PROCESSED',
                      'RECYCLED','RECOVERED','COMPOSTED','REUSED','RESIDUAL_DISPOSAL'];
const WASTE_TRANSITIONS = [
    'CREATED'           => ['PICKUP_REQUESTED'],
    'PICKUP_REQUESTED'  => ['COLLECTED'],
    'COLLECTED'         => ['SORTED'],
    'SORTED'            => ['PROCESSING'],
    'PROCESSING'        => ['PROCESSED'],
    'PROCESSED'         => ['RECYCLED', 'RECOVERED', 'COMPOSTED', 'REUSED', 'RESIDUAL_DISPOSAL'],
    'RECYCLED'          => [], 'RECOVERED' => [], 'COMPOSTED' => [], 'REUSED' => [], 'RESIDUAL_DISPOSAL' => [],
];
const FINAL_OUTCOMES = ['RECYCLED','RECOVERED','COMPOSTED','REUSED','RESIDUAL_DISPOSAL'];
const WASTE_STAGE_LABELS = [
    'CREATED' => 'Created', 'PICKUP_REQUESTED' => 'Pickup Requested', 'COLLECTED' => 'Collected',
    'SORTED' => 'Sorted', 'PROCESSING' => 'Processing', 'PROCESSED' => 'Processed',
    'RECYCLED' => 'Recycled', 'RECOVERED' => 'Recovered (energy)', 'COMPOSTED' => 'Composted',
    'REUSED' => 'Reused', 'RESIDUAL_DISPOSAL' => 'Residual Disposal',
];
const WASTE_STAGE_COLORS = [
    'CREATED' => 'secondary', 'PICKUP_REQUESTED' => 'warning', 'COLLECTED' => 'info',
    'SORTED' => 'primary', 'PROCESSING' => 'purple', 'PROCESSED' => 'dark',
    'RECYCLED' => 'success', 'RECOVERED' => 'success', 'COMPOSTED' => 'success',
    'REUSED' => 'success', 'RESIDUAL_DISPOSAL' => 'danger',
];

// ---- Report status machine ----
const REPORT_STATUSES = ['SUBMITTED','VERIFIED','ASSIGNED','IN_PROGRESS','RESOLVED','REJECTED'];
const REPORT_STATUS_LABELS = [
    'SUBMITTED' => 'Submitted', 'VERIFIED' => 'Verified', 'ASSIGNED' => 'Assigned',
    'IN_PROGRESS' => 'In progress', 'RESOLVED' => 'Resolved', 'REJECTED' => 'Rejected',
];
const REPORT_STATUS_COLORS = [
    'SUBMITTED' => 'warning', 'VERIFIED' => 'info', 'ASSIGNED' => 'primary',
    'IN_PROGRESS' => 'purple', 'RESOLVED' => 'success', 'REJECTED' => 'danger',
];

// ---- Journey event types ----
const JOURNEY_EVENTS = [
    'WASTE_IDENTIFIED','PICKUP_REQUESTED','COLLECTOR_ASSIGNED','COLLECTED','PICKUP_COMPLETED',
    'SORTED','PROCESSING_STARTED','PROCESSED','FINAL_OUTCOME','IMPACT_CALCULATED','REWARD_GENERATED','IMPACT_BADGES_EVALUATED',
];

// ---- Reward / impact rule actions ----
const REWARD_ACTIONS = [
    'pickup_completed'      => 'Pickup completed',
    'segregation_good'      => 'Proper segregation (recyclable stream)',
    'recycling_completed'   => 'Waste fully recycled / recovered',
    'quiz_completed'        => 'Learning quiz passed',
    'report_verified'       => 'Verified waste report',
];
