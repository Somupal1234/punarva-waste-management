<?php
/**
 * PUNARVA – Central Configuration
 * --------------------------------
 * This is the ONLY file you normally need to edit.
 * XAMPP default: MySQL user "root" with empty password.
 */

// ---- Environment (v2.5.0: .env-driven, safe XAMPP fallback) ----
// Values come from the project-root .env file (or real environment variables).
// WITHOUT a .env file the app keeps running with the XAMPP dev defaults below, so
// an existing install never breaks; on a server, set APP_ENV=production + APP_DEBUG=false.
require_once dirname(__DIR__) . '/includes/env.php';
pnv_load_env(dirname(__DIR__) . '/.env');
$__env = static function (string $k, string $d) { $v = getenv($k); return ($v === false || $v === '') ? $d : $v; };

define('APP_NAME', 'PUNARVA');
define('APP_VERSION', '2.25.0');
define('SESSION_IDLE_TIMEOUT', 1800); // seconds of inactivity before auto-logout (0 = off)
define('APP_TAGLINE', 'From Waste to Worth');
define('APP_MESSAGE', 'Know your waste. Track its journey. Create impact.');
define('APP_ENV', $__env('APP_ENV', 'local')); // local | production
define('APP_DEBUG', $__env('APP_DEBUG', 'true') === 'true'); // .env should set APP_DEBUG=false in production

// ---- Database (XAMPP defaults) ----
// v2.5.0 — standard names (DB_*) with legacy PUNARVA_DB_* fallback, then XAMPP defaults
$__g = static function (string $std, string $legacy, string $dflt) { $v = getenv($std); if ($v === false || $v === '') $v = getenv($legacy); return ($v === false || $v === '') ? $dflt : $v; };
define('DB_HOST', $__g('DB_HOST', 'PUNARVA_DB_HOST', '127.0.0.1'));
define('DB_PORT', $__g('DB_PORT', 'PUNARVA_DB_PORT', '3306'));
define('DB_NAME', $__g('DB_NAME', 'PUNARVA_DB_NAME', 'punarva_db'));
define('DB_USER', $__g('DB_USER', 'PUNARVA_DB_USER', 'root'));
define('DB_PASS', $__g('DB_PASS', 'PUNARVA_DB_PASS', ''));

// ---- Base URL (auto-detected; works at http://localhost/punarva/) ----
$__root = str_replace('\\', '/', dirname(__DIR__));
$__doc  = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']), '/') : '';
if ($__doc !== '' && str_starts_with(strtolower($__root), strtolower($__doc))) {
    define('BASE_PATH', substr($__root, strlen($__doc)));
} else {
    define('BASE_PATH', '');
}
define('BASE_URL', BASE_PATH); // host-relative base (works on localhost, LAN IPs and https proxies alike)

// ---- Uploads ----
define('UPLOAD_MAX_BYTES', 5 * 1024 * 1024); // 5 MB
define('UPLOAD_DIR', __DIR__ . '/../uploads');
define('UPLOAD_URL', 'uploads');

// AI provider configuration REMOVED in v2.3.0 — scanner runs in local demo mode (zero external API calls).

// ---- Map (Leaflet + OpenStreetMap) ----
define('MAP_CENTER_LAT', 24.2785);   // Dumka, Jharkhand default centre
define('MAP_CENTER_LNG', 87.2494);
define('MAP_DEFAULT_ZOOM', 12);
define('MAP_TILE_URL', 'https://tile.openstreetmap.org/{z}/{x}/{y}.png');
define('MAP_ATTRIBUTION', '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors');

// ---- QR / tracking ----
define('QR_TRACK_PATH', 'track.php'); // public tracking endpoint: track.php?id=PNV-...

// ---- misc ----
define('PER_PAGE', 10);
define('SESSION_NAME', 'PUNARVA_SESSID');
define('LOG_DIR', __DIR__ . '/../storage/logs');
define('METHODOLOGY_VERSION', 'v1.0-estimate');

date_default_timezone_set('Asia/Kolkata');
mb_internal_encoding('UTF-8');

// Optional local overrides (config/config.local.php) – useful for testing setups.
if (is_file(__DIR__ . '/config.local.php')) require __DIR__ . '/config.local.php';
