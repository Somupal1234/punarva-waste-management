<?php
/**
 * PDO connection (singleton). All queries across PUNARVA use prepared statements.
 */
class Database
{
    private static ?PDO $pdo = null;
    private static int $txDepth = 0;

    /** Nested-transaction-safe BEGIN (uses savepoints for inner levels). */
    public static function begin(): void
    {
        $pdo = self::pdo();
        if (!$pdo->inTransaction()) {
            $pdo->beginTransaction();
            self::$txDepth = 0;
        } else {
            self::$txDepth++;
            $pdo->exec('SAVEPOINT pnv_sp' . self::$txDepth);
        }
    }

    public static function commit(): void
    {
        $pdo = self::pdo();
        if (!$pdo->inTransaction()) return;
        if (self::$txDepth > 0) {
            $pdo->exec('RELEASE SAVEPOINT pnv_sp' . self::$txDepth);
            self::$txDepth--;
        } else {
            $pdo->commit();
        }
    }

    public static function rollBack(): void
    {
        $pdo = self::pdo();
        if (!$pdo->inTransaction()) return;
        if (self::$txDepth > 0) {
            $pdo->exec('ROLLBACK TO SAVEPOINT pnv_sp' . self::$txDepth);
            self::$txDepth--;
        } else {
            $pdo->rollBack();
        }
    }

    public static function pdo(): PDO
    {
        if (self::$pdo === null) {
            $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
            try {
                self::$pdo = new PDO($dsn, DB_USER, DB_PASS, [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]);
            } catch (PDOException $e) {
                error_log('PUNARVA DB error: ' . $e->getMessage());
                if (APP_DEBUG) {
                    die('<div style="font-family:sans-serif;padding:2rem"><h2>Database connection failed</h2><p>' .
                        htmlspecialchars($e->getMessage()) . '</p><p>Start MySQL in XAMPP and import <code>database/schema.sql</code> + <code>database/seed.sql</code>. See README.md.</p></div>');
                }
                http_response_code(500);
                die('Service temporarily unavailable.');
            }
        }
        return self::$pdo;
    }

    public static function run(string $sql, array $params = []): PDOStatement
    {
        $stmt = self::pdo()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public static function one(string $sql, array $params = []): ?array
    {
        $row = self::run($sql, $params)->fetch();
        return $row === false ? null : $row;
    }

    public static function all(string $sql, array $params = []): array
    {
        return self::run($sql, $params)->fetchAll();
    }

    public static function val(string $sql, array $params = [])
    {
        $v = self::run($sql, $params)->fetchColumn();
        return $v === false ? null : $v;
    }

    public static function insert(string $table, array $data): int
    {
        $cols = array_keys($data);
        $sql  = 'INSERT INTO `' . $table . '` (`' . implode('`,`', $cols) . '`) VALUES (' .
                implode(',', array_fill(0, count($cols), '?')) . ')';
        self::run($sql, array_values($data));
        return (int) self::pdo()->lastInsertId();
    }

    public static function update(string $table, array $data, string $where, array $whereParams = []): int
    {
        $set = implode(',', array_map(fn($c) => "`$c` = ?", array_keys($data)));
        $stmt = self::run("UPDATE `$table` SET $set WHERE $where", array_merge(array_values($data), $whereParams));
        return $stmt->rowCount();
    }

    public static function delete(string $table, string $where, array $whereParams = []): int
    {
        // v2.13.0 — parameterised delete, consistent with insert/update (prepared statement)
        return self::run("DELETE FROM `$table` WHERE $where", $whereParams)->rowCount();
    }
}
