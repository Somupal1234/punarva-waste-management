<?php
/**
 * AuthMiddleware / RoleMiddleware / OwnershipMiddleware
 * Thin middleware classes – page controllers and APIs call these (helpers delegate here).
 */
class AuthMiddleware
{
    public static function handle(): array { return require_login(); }
}

class RoleMiddleware
{
    public static function handle(string ...$roles): array { return require_role(...$roles); }
}

class CSRFMiddleware
{
    public static function token(): string { return csrf_token(); }

    /** Enforce CSRF token on every state-changing request (v2.12.0: ALWAYS ON — not a setting). */
    public static function enforce(): void
    {
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        if (in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
            $token = $_POST['_csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
            if (!hash_equals(csrf_token(), (string) $token)) {
                if (is_api_request()) json_err('Invalid or missing CSRF token.', [], 419);
                http_response_code(419);
                flash('danger', 'Your session expired. Please try again.');
                redirect('index.php');
            }
        }
    }
}

class OwnershipMiddleware
{
    /** Citizen may only read/modify their own pickup. */
    public static function pickupOwner(array $pickup, array $user): void
    {
        if ((int) $pickup['user_id'] !== (int) $user['id'] && $user['role_code'] !== ROLE_ADMIN) {
            if (is_api_request()) json_err('You are not allowed to access this record.', [], 403);
            flash('danger', 'You are not allowed to access that record.');
            redirect(ROLE_HOME[$user['role_code']] ?? 'index.php');
        }
    }

    /** Collector may only access pickups assigned to them. */
    public static function assignmentOwner(array $assignment, array $user): void
    {
        if ((int) $assignment['collector_id'] !== (int) $user['id'] && $user['role_code'] !== ROLE_ADMIN) {
            if (is_api_request()) json_err('This assignment does not belong to you.', [], 403);
            flash('danger', 'That assignment does not belong to you.');
            redirect(ROLE_HOME[$user['role_code']] ?? 'index.php');
        }
    }

    /** Recycler may only process waste routed to their facility. */
    public static function facilityWaste(array $tx, array $user): void
    {
        $facilityId = (int) ($user['facility_id'] ?? 0);
        if ($user['role_code'] === ROLE_ADMIN) return;
        if ((int) ($tx['facility_id'] ?? 0) !== $facilityId && (int) ($tx['assigned_facility_id'] ?? 0) !== $facilityId) {
            if (is_api_request()) json_err('This waste record is not assigned to your facility.', [], 403);
            flash('danger', 'That waste record is not assigned to your facility.');
            redirect(ROLE_HOME[$user['role_code']] ?? 'index.php');
        }
    }
}
