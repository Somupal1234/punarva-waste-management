<?php
/**
 * PUNARVA premium badge emblem library (v2.10.0).
 * Hand-drawn inline SVGs — NO emoji artwork, NO external icon font, NO uploads, no mixing.
 * Each emblem: 64x64 viewBox, consistent ring frame, shared PUNARVA gradients, subtle depth.
 * Usage: badge_icon_svg('truck', ['size' => 44, 'class' => 'badge-icon'])
 * Accessibility: pass 'title' for meaningful icons; decorative => aria-hidden.
 */

function badge_icon_svg(string $icon, array $opt = []): string
{
    static $defs = null;
    if ($defs === null) {
        $defs = '<defs>'
            . '<linearGradient id="pnvG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#22a06b"/><stop offset="1" stop-color="#0e7a4f"/></linearGradient>'
            . '<linearGradient id="pnvA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f2c14e"/><stop offset="1" stop-color="#c98a12"/></linearGradient>'
            . '<linearGradient id="pnvB" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3b82f6"/><stop offset="1" stop-color="#1d4ed8"/></linearGradient>'
            . '<linearGradient id="pnvR" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f87171"/><stop offset="1" stop-color="#b91c1c"/></linearGradient>'
            . '<linearGradient id="pnvY" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#facc15"/><stop offset="1" stop-color="#a16207"/></linearGradient>'
            . '</defs>';
    }
    $size  = (int) ($opt['size'] ?? 44);
    $cls   = 'badge-svg' . (isset($opt['class']) ? ' ' . $opt['class'] : '');
    $title = $opt['title'] ?? null;
    $meta  = 'width="' . $size . '" height="' . $size . '" class="' . e($cls) . '"'
        . ($title ? ' role="img" aria-label="' . e($title) . '"' : ' aria-hidden="true" focusable="false"');

    $ring = '<circle cx="32" cy="32" r="29.5" fill="none" stroke="url(#pnvG)" stroke-width="2.6" opacity=".9"/>'
          . '<circle cx="32" cy="32" r="25" fill="#f4faf6"/>';

    $inner = match ($icon) {
        // First Contribution — leaf + check (first verified real action)
        'first' => '<path d="M32 20c9 2.5 13 8 12 15.5-7.5 2-13-.8-15-7-1.5-5 .5-8.5 3-8.5z" fill="url(#pnvG)"/>'
            . '<path d="M23 40c5-8 12-12 19-11" stroke="#0b3d27" stroke-width="1.8" fill="none" stroke-linecap="round"/>'
            . '<circle cx="41" cy="40" r="9.5" fill="url(#pnvA)"/>'
            . '<path d="M37 40l2.7 2.8 5-5.4" stroke="#fff" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>',
                // Pickup Contributor — recycling truck
        'truck' => '<rect x="15" y="27" width="20" height="13" rx="2" fill="url(#pnvG)"/>'
            . '<path d="M35 30h8l6 6v4H35z" fill="#22a06b" opacity=".85"/>'
            . '<circle cx="23" cy="42" r="3.4" fill="#0b3d27"/><circle cx="43" cy="42" r="3.4" fill="#0b3d27"/>'
            . '<rect x="13" y="24" width="26" height="3.4" rx="1.7" fill="#0b3d27"/>'
            . '<path d="M40 33l2.5 2.5 3.5-3.5" stroke="#fff" stroke-width="2" fill="none" stroke-linecap="round"/>',
        // Waste Sorter — twin bins with check
        'sorter' => '<rect x="17" y="24" width="13" height="19" rx="2.4" fill="url(#pnvG)"/>'
            . '<rect x="34" y="24" width="13" height="19" rx="2.4" fill="url(#pnvB)"/>'
            . '<rect x="15.5" y="20" width="16" height="4" rx="2" fill="#0b3d27"/>'
            . '<rect x="32.5" y="20" width="16" height="4" rx="2" fill="#0b3d27"/>'
            . '<path d="M25 33l4 4 8-8" stroke="#fff" stroke-width="3.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'
            . '<circle cx="41" cy="19" r="6" fill="url(#pnvA)"/><path d="M38.4 19l1.9 2 3.2-3.4" stroke="#fff" stroke-width="1.9" fill="none" stroke-linecap="round"/>',
        // Waste Reporter — document + verified check
        'reporter' => '<rect x="19" y="17" width="19" height="26" rx="2.6" fill="#fff" stroke="url(#pnvG)" stroke-width="2.2"/>'
            . '<path d="M23 24h11M23 29h11M23 34h7" stroke="#22a06b" stroke-width="2" stroke-linecap="round"/>'
            . '<circle cx="41" cy="36" r="9" fill="url(#pnvG)"/>'
            . '<path d="M37.4 36l2.5 2.6 4.7-5" stroke="#fff" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>',
        // Recycling Champion — bold recycle loop + laurel star
        'recycle' => '<path d="M32 19l5 8h-4v6h-2v-6h-4z" fill="url(#pnvG)" opacity="0"/>'
            . '<path d="M25.8 27.5a9.5 9.5 0 0114.9 2.2M40.4 36.6a9.5 9.5 0 01-15 2.3" stroke="url(#pnvG)" stroke-width="3.4" fill="none" stroke-linecap="round"/>'
            . '<path d="M40 23.5l.9 6.6-6.3-2z" fill="#22a06b"/>'
            . '<path d="M24 40.5l-.9-6.6 6.3 2z" fill="#0e7a4f"/>'
            . '<path d="M32 25.5l3.1 5.4h-6.2z" fill="url(#pnvA)" transform="rotate(180 32 28.2)"/>',
        // Impact Maker — earth with growth mark
        'globe' => '<circle cx="32" cy="32" r="14" fill="url(#pnvB)" opacity=".16"/>'
            . '<circle cx="32" cy="32" r="14" fill="none" stroke="url(#pnvG)" stroke-width="2.6"/>'
            . '<path d="M20 28c4-2 8-2 10 1s6 3 9 1 6-1 8 2M22 38c3 2 6 2 8 0s7-2 10 1" stroke="#22a06b" stroke-width="2.2" fill="none" stroke-linecap="round"/>'
            . '<path d="M32 44c4-5 8-7 12-6-1.6 5-5.4 7.6-12 6z" fill="#22a06b" opacity=".9"/>',
        // Collection Champion — collection truck + trophy
        'trophy_truck' => '<rect x="14" y="29" width="18" height="11" rx="2" fill="url(#pnvG)"/>'
            . '<path d="M32 31.5h7l5 5v3.5H32z" fill="#22a06b" opacity=".85"/>'
            . '<circle cx="21" cy="42" r="3" fill="#0b3d27"/><circle cx="39" cy="42" r="3" fill="#0b3d27"/>'
            . '<path d="M15 26h18" stroke="#0b3d27" stroke-width="3" stroke-linecap="round"/>'
            . '<path d="M41 15h8v5a4.5 4.5 0 01-9 0z" fill="url(#pnvA)"/>'
            . '<path d="M41 16h-3.4a3.4 3.4 0 003.4 4.4M49 16h3.4a3.4 3.4 0 01-3.4 4.4" stroke="#c98a12" stroke-width="1.8" fill="none"/>'
            . '<rect x="43.6" y="24" width="2.8" height="3.4" fill="#c98a12"/><rect x="41" y="27.4" width="8" height="2.6" rx="1.3" fill="#c98a12"/>',
        // Community Protector — people + shield
        'shield' => '<path d="M32 16l11 4v9c0 7.5-4.6 12.6-11 15-6.4-2.4-11-7.5-11-15v-9z" fill="url(#pnvG)"/>'
            . '<path d="M32 19.5l8 2.9v6.8c0 5.6-3.4 9.4-8 11.3-4.6-1.9-8-5.7-8-11.3v-6.8z" fill="#e9f7ee" opacity=".35"/>'
            . '<circle cx="27.5" cy="30" r="2.6" fill="#fff"/><circle cx="36.5" cy="30" r="2.6" fill="#fff"/><circle cx="32" cy="27" r="3" fill="#f2c14e"/>'
            . '<path d="M23 39c1.8-3.6 5-5.4 9-5.4s7.2 1.8 9 5.4" stroke="#fff" stroke-width="2.2" fill="none" stroke-linecap="round"/>',
        // Recycling Hero — recycle loop + star
        'hero' => '<path d="M25.4 26.5a9.5 9.5 0 0114.9 2.2M40.6 36.4a9.5 9.5 0 01-15 2.3" stroke="url(#pnvG)" stroke-width="3.2" fill="none" stroke-linecap="round"/>'
            . '<path d="M39.8 22.5l.9 6.4-6.1-1.9z" fill="#22a06b"/>'
            . '<path d="M24.2 41.5l-.9-6.4 6.1 1.9z" fill="#0e7a4f"/>'
            . '<path d="M32 26.5l1.9 3.9 4.3.6-3.1 3 .7 4.3-3.8-2-3.8 2 .7-4.3-3.1-3 4.3-.6z" fill="url(#pnvA)"/>',
        // PUNARVA Impact Legend — earth + premium medal
        'legend' => '<circle cx="30" cy="27" r="10.5" fill="url(#pnvB)" opacity=".18"/>'
            . '<circle cx="30" cy="27" r="10.5" fill="none" stroke="url(#pnvG)" stroke-width="2.3"/>'
            . '<path d="M21.5 24c3-1.5 6-1.5 7.5.8s4.5 2.2 6.8.7 4.4-.8 5.9 1.5" stroke="#22a06b" stroke-width="1.9" fill="none" stroke-linecap="round"/>'
            . '<path d="M24 33.5c2.3 1.5 4.5 1.5 6 0s5.2-1.5 7.4.7" stroke="#22a06b" stroke-width="1.9" fill="none" stroke-linecap="round"/>'
            . '<path d="M28 39.5l4 3.5-1.2 5.5-5.3-3.2-5.3 3.2L21 43z" fill="none" stroke="url(#pnvA)" stroke-width="2.4" stroke-linejoin="round" transform="translate(7 0)"/>'
            . '<circle cx="39" cy="45" r="4.6" fill="url(#pnvA)"/><path d="M39 42.2l.9 1.9 2.1.3-1.5 1.5.3 2.1-1.8-1-1.8 1 .3-2.1-1.5-1.5 2.1-.3z" fill="#8a5f07"/>',
        default => '<circle cx="32" cy="32" r="14" fill="url(#pnvG)"/>',
    };

    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" ' . $meta . '>' . $defs . $ring . $inner . '</svg>';
}
