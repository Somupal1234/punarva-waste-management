<?php
/**
 * Reusable journey timeline component.
 * Expects: $events (journey rows), $tx (waste transaction row), $public (bool – masks PII when true).
 */
function mask_name(?string $name): string {
    if (!$name) return '—';
    $parts = preg_split('/\s+/', trim($name));
    return e($parts[0]) . (isset($parts[1]) ? ' ' . mb_substr($parts[1], 0, 1) . '.' : '');
}
$icons = [
    'WASTE_IDENTIFIED' => 'bi-search', 'PICKUP_REQUESTED' => 'bi-calendar-check', 'COLLECTOR_ASSIGNED' => 'bi-person-badge',
    'COLLECTED' => 'bi-truck', 'PICKUP_COMPLETED' => 'bi-check2-circle', 'SORTED' => 'bi-funnel',
    'RECEIVED_AT_FACILITY' => 'bi-box-arrow-in-down', 'PROCESSING_STARTED' => 'bi-gear', 'PROCESSED' => 'bi-box-seam',
    'FINAL_OUTCOME' => 'bi-recycle', 'IMPACT_CALCULATED' => 'bi-globe-americas', 'REWARD_GENERATED' => 'bi-trophy', 'IMPACT_BADGES_EVALUATED' => 'bi-patch-check',
];
$finalStage = $tx['current_stage'];
$doneTypes = array_column($events, 'event_type');
$stageOrder = ['WASTE_IDENTIFIED','PICKUP_REQUESTED','COLLECTOR_ASSIGNED','COLLECTED','PICKUP_COMPLETED','SORTED','PROCESSING_STARTED','PROCESSED','FINAL_OUTCOME','IMPACT_CALCULATED','REWARD_GENERATED','IMPACT_BADGES_EVALUATED'];
$futureStages = [];
foreach (WASTE_TRANSITIONS[$finalStage] ?? [] as $fs) $futureStages[] = $fs;
?>
<div class="journey mt-3">
  <?php foreach ($events as $ev): ?>
    <div class="journey-item done">
      <span class="j-icon"><i class="bi <?= $icons[$ev['event_type']] ?? 'bi-dot' ?>"></i></span>
      <div class="d-flex justify-content-between flex-wrap gap-1">
        <span class="j-title"><?= e(ucfirst(strtolower(str_replace('_', ' ', $ev['event_type'])))) ?></span>
        <span class="j-time"><i class="bi bi-clock"></i> <?= fmt_dt($ev['event_time']) ?></span>
      </div>
      <div class="j-note">
        <?php if ($ev['location']): ?><i class="bi bi-geo-alt me-1"></i><?= $public ? e($tx['ward'] ? 'Ward ' . $tx['ward'] . ', ' . ($tx['city'] ?? (string) setting('default_city', 'Dumka')) : (string) setting('default_city', 'Dumka')) : e($ev['location']) ?> ·<?php endif; ?>
        <?php if ($ev['actor_name'] || $ev['actor_role']): ?>
          <i class="bi bi-person me-1"></i><?= $ev['actor_name'] ? mask_name($ev['actor_name']) : 'System' ?>
          (<?= e($ev['actor_role']) ?>) ·
        <?php endif; ?>
        <?php if ($ev['facility_name']): ?><i class="bi bi-buildings me-1"></i><?= e($ev['facility_name']) ?> ·<?php endif; ?>
        <?php if ($ev['quantity'] !== null): ?><i class="bi bi-scale me-1"></i><?= fmt_kg($ev['quantity']) ?><?php endif; ?>
        <?php if (!empty($ev['notes']) && empty($hideInternalNotes)): ?><div class="mt-1"><?= e($ev['notes']) ?></div><?php endif; ?>
        <?php if (!empty($ev['proof_image']) && !$public): ?>
          <a href="<?= e(upload_url($ev['proof_image'])) ?>" target="_blank" class="d-inline-block mt-1">
            <img src="<?= e(upload_url($ev['proof_image'])) ?>" alt="proof" style="height:56px" class="rounded border"></a>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>

  <!-- remaining expected stages -->
  <?php
  $expected = [
      'SORTED' => ['Sorted at facility', 'bi-funnel'],
      'PROCESSING' => ['Processing', 'bi-gear'],
      'PROCESSED' => ['Processing complete', 'bi-box-seam'],
      'RECYCLED' => ['Recycled', 'bi-recycle'], 'RECOVERED' => ['Energy recovery', 'bi-lightning'],
      'COMPOSTED' => ['Composted', 'bi-tree'], 'REUSED' => ['Reused', 'bi-arrow-repeat'],
  ];
  $pending = [];
  switch ($finalStage) {
      case 'PICKUP_REQUESTED': case 'CREATED': $pending[] = ['Collected by collector', 'bi-truck']; // fallthrough intent
      case 'COLLECTED': $pending[] = $expected['SORTED'];
      case 'SORTED': $pending[] = $expected['PROCESSING'];
      case 'PROCESSING': $pending[] = $expected['PROCESSED'];
      case 'PROCESSED': $pending[] = ['Final outcome (recycled / recovered / composted)', 'bi-recycle'];
      case 'RECYCLED': case 'RECOVERED': case 'COMPOSTED': case 'REUSED':
          if (!in_array($finalStage, ['IMPACT_CALCULATED'], true) && in_array($finalStage, FINAL_OUTCOMES, true) === false) $pending[] = ['Impact & rewards', 'bi-globe-americas'];
          break;
  }
  if (empty($pending) && !in_array($finalStage, FINAL_OUTCOMES, true) && $finalStage === 'COLLECTED') {}
  foreach (array_slice($pending, 0, 5) as $p): ?>
    <div class="journey-item">
      <span class="j-icon"><i class="bi <?= $p[1] ?>"></i></span>
      <span class="j-title text-muted"><?= e($p[0]) ?></span>
      <div class="j-time">Pending</div>
    </div>
  <?php endforeach; ?>
  <?php if (in_array($finalStage, FINAL_OUTCOMES, true) && !in_array('IMPACT_CALCULATED', $doneTypes, true)): ?>
    <div class="journey-item">
      <span class="j-icon"><i class="bi bi-globe-americas"></i></span>
      <span class="j-title text-muted">Estimated impact calculation</span><div class="j-time">Pending</div>
    </div>
  <?php endif; ?>
</div>
