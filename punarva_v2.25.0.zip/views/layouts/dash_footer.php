    </div><!-- /.dash-content -->
  </div><!-- /.dash-main -->

  <!-- notifications modal -->
  <div class="modal fade" id="notifModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-scrollable">
      <div class="modal-content" style="border-radius:16px">
        <div class="modal-header">
          <h5 class="modal-title"><i class="bi bi-bell me-2"></i>Notifications</h5>
          <div class="ms-auto d-flex gap-2">
            <button class="btn btn-sm btn-soft" id="markAllRead">Mark all read</button>
            <button class="btn-close" data-bs-dismiss="modal" aria-label="<?= t('a11y.close') ?>"></button>
          </div>
        </div>
        <div class="modal-body p-0" id="notifList" data-api="<?= url('api/notifications') ?>"></div>
      </div>
    </div>
  </div>
</div>
<script src="<?= url('assets/vendor/bootstrap/bootstrap.bundle.min.js') ?>"></script>
<?php if (pnv_needs_map()): ?>
<script src="<?= url('assets/vendor/leaflet/leaflet.js') ?>"></script>
<script>window.PNV_ATTR = <?= json_encode(MAP_ATTRIBUTION) ?>; window.PNV_TILE_URL = <?= json_encode(MAP_TILE_URL) ?>; window.PNV_MAP_CENTER = [<?= json_encode((float) MAP_CENTER_LAT) ?>, <?= json_encode((float) MAP_CENTER_LNG) ?>];</script>
<script src="<?= asset_url('assets/js/map.js') ?>"></script>
<?php endif; ?>
<?php if (pnv_needs_charts()): ?><?= pnv_chart_assets() ?>
<?php endif; ?>
<script src="<?= url('assets/vendor/qrcode/qrcode.min.js') ?>"></script>
<script src="<?= asset_url('assets/js/app.js') ?>"></script>
<?= $pageScripts ?? '' ?>
<?php require __DIR__ . '/mobile_nav.php'; // v2.24.0 role-aware mobile bottom nav ?>
<div class="text-center small text-muted py-2 opacity-75 dash-footer-version">PUNARVA v<?= APP_VERSION ?> · From Waste to Worth</div>
</body>
</html>
