<?php
/**
 * v2.24.0 — Fixed mobile bottom navigation (dashboards only, < lg).
 * Role-aware 5 items max; uses existing $activeMenu to mark the active item.
 * Server-side authorization is untouched — this is navigation only (a hidden
 * item never grants access; every target page keeps its own require_role).
 */
if (!($__user ?? null)) return;
$role = $__user['role_code'] ?? '';
$nav = match ($role) {
    ROLE_COLLECTOR => [
        ['dashboard.php', 'bi-house-door', 'nav.home'],
        ['route.php',     'bi-map',        'nav.route'],
        ['pickups.php',   'bi-truck',      'nav.pickups'],
        ['shifts.php',    'bi-clock-history', 'nav.shifts'],
        ['profile.php',   'bi-person',     'nav.profile'],
    ],
    ROLE_RECYCLER => [
        ['dashboard.php', 'bi-box-seam',   'nav.incoming'],
        ['passports.php', 'bi-passport',   'nav.passport'],
        ['impact.php',    'bi-recycle',    'nav.impact'],
        ['notifications.php', 'bi-bell',   'nav.notifications'],
        ['profile.php',   'bi-person',     'nav.profile'],
    ],
    ROLE_BUSINESS => [
        ['dashboard.php', 'bi-house-door', 'nav.home'],
        ['bulk-pickup.php', 'bi-boxes',    'nav.bulk'],
        ['pickups.php',   'bi-truck',      'nav.pickups'],
        ['impact.php',    'bi-graph-up',   'nav.impact'],
        ['profile.php',   'bi-person',     'nav.profile'],
    ],
    ROLE_ADMIN => [
        ['dashboard.php', 'bi-speedometer2', 'nav.dashboard'],
        ['map.php',       'bi-map',        'nav.map'],
        ['pickups.php',   'bi-truck',      'nav.pickups'],
        ['announcements.php', 'bi-megaphone', 'nav.announcements'],
        ['settings.php',  'bi-gear',       'nav.settings'],
    ],
    default => [ // citizen
        ['dashboard.php', 'bi-house-door', 'nav.home'],
        ['pickups.php',   'bi-truck',      'nav.pickups'],
        ['scanner.php',   'bi-upc-scan',   'nav.scan'],
        ['passports.php', 'bi-passport',   'nav.passport'],
        ['profile.php',   'bi-person',     'nav.profile'],
    ],
};
/** असली target file से active match ($activeMenu page slug = basename बिना .php) */
$current = basename(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '');
?>
<nav class="pnv-bottom-nav d-lg-none" aria-label="Primary">
  <?php foreach ($nav as [$file, $icon, $labelKey]): ?>
    <a href="<?= url(($__user['role_code'] ?? 'citizen') . '/' . $file) ?>"
       class="<?= ($current === $file) ? 'active' : '' ?>"
       <?= ($current === $file) ? 'aria-current="page"' : '' ?>>
      <i class="bi <?= $icon ?>" aria-hidden="true"></i>
      <span><?= e(t($labelKey)) ?></span>
    </a>
  <?php endforeach; ?>
</nav>
