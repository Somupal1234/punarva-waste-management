</main>
<footer class="pnv-footer pt-5 pb-4 mt-5">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-4">
        <a class="brand-logo mb-2" href="<?= url('index.php') ?>" style="color:#fff">
          <img src="<?= url('assets/images/logo-icon.png') ?>" alt="PUNARVA logo" style="background:#fff;border-radius:10px;padding:2px">
          <span class="text-white"><?= e(setting('platform_name', 'PUNARVA')) ?><small><?= e(setting('platform_tagline', t('foot.tagline'))) ?></small></span>
        </a>
        <p class="small mt-2 mb-0"><?= e(t('foot.message')) ?></p>
        <p class="small text-secondary-emphasis">Smart digital waste-management ecosystem for citizens, collectors, recyclers, businesses and municipalities.</p>
      </div>
      <div class="col-6 col-lg-2">
        <h6 class="mb-3">PLATFORM</h6>
        <ul class="list-unstyled small d-grid gap-2">
          <li><a href="<?= url('how-it-works.php') ?>">How it works</a></li>
          <li><a href="<?= url('waste-guide.php') ?>">Waste guide</a></li>
          <li><a href="<?= url('track.php') ?>">Track waste</a></li>
          <li><a href="<?= url('learn.php') ?>">Learning center</a></li>
        </ul>
      </div>
      <div class="col-6 col-lg-2">
        <h6 class="mb-3">GET INVOLVED</h6>
        <ul class="list-unstyled small d-grid gap-2">
          <li><a href="<?= url('register.php') ?>">Create account</a></li>
          <li><a href="<?= url('citizen/scanner.php') ?>">Scan waste</a></li>
          <li><a href="<?= url('citizen/pickup-create.php') ?>">Request pickup</a></li>
          <li><a href="<?= url('report.php') ?>">Report dumping</a></li>
        </ul>
      </div>
      <div class="col-lg-4">
        <h6 class="mb-3">WASTE PASSPORT</h6>
        <p class="small">Every collected load receives a unique Waste ID and a traceable journey — from your doorstep to recycling.</p>
        <form class="d-flex gap-2" method="get" action="<?= url('track.php') ?>">
          <input class="form-control form-control-sm" name="id" aria-label="Waste ID" placeholder="e.g. PNV-2026-000001">
          <button class="btn btn-pnv btn-sm px-3">Track</button>
        </form>
      </div>
    </div>
    <hr class="border-secondary opacity-25">
    <div class="d-flex flex-wrap justify-content-between small">
      <span>© <?= date('Y') ?> <?= e(t('foot.rights')) ?> · PUNARVA v<?= APP_VERSION ?></span>
      <span><i class="bi bi-shield-check me-1"></i>Secure · PHP <?= e(PHP_VERSION) ?> · MySQL</span>
    </div>
  </div>
</footer>
<script src="<?= url('assets/vendor/bootstrap/bootstrap.bundle.min.js') ?>"></script>
<?php if (pnv_needs_map()): ?>
<script src="<?= url('assets/vendor/leaflet/leaflet.js') ?>"></script>
<script>window.PNV_ATTR = <?= json_encode(MAP_ATTRIBUTION) ?>; window.PNV_TILE_URL = <?= json_encode(MAP_TILE_URL) ?>; window.PNV_MAP_CENTER = [<?= json_encode((float) MAP_CENTER_LAT) ?>, <?= json_encode((float) MAP_CENTER_LNG) ?>];</script>
<script src="<?= asset_url('assets/js/map.js') ?>"></script>
<?php endif; ?>
<script src="<?= url('assets/vendor/qrcode/qrcode.min.js') ?>"></script>
<script src="<?= asset_url('assets/js/app.js') ?>"></script>
<?= $pageScripts ?? '' ?>
</body>
</html>
