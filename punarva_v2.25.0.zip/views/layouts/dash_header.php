<?php
/**
 * Dashboard shell header. Expects: $pageTitle, $activeMenu.
 * Populates $user via require_login (called by the page before including).
 */
$user = $user ?? require_login();
$role = $user['role_code'];

$menus = [
    ROLE_CITIZEN => [
        'Main' => [
            ['dashboard.php', 'bi-speedometer2', 'Dashboard', 'dash'],
            ['scanner.php', 'bi-upc-scan', 'Waste Scanner', 'scanner'],
            ['pickup-create.php', 'bi-plus-circle', 'Request Pickup', 'pickup-create'],
            ['pickups.php', 'bi-truck', 'My Pickups', 'pickups'],
        ],
        'Waste Passport' => [
            ['passports.php', 'bi-passport', 'My Waste Passports', 'passports'],
            ['track.php', 'bi-qr-code', 'Public Tracking', 'trackx'],
        ],
        'Community' => [
            ['reports.php', 'bi-megaphone', 'Waste Reports', 'reports'],
            ['badges.php', 'bi-patch-check', 'My Badges', 'badges'],
            ['impact.php', 'bi-globe-americas', 'Environmental Impact', 'impact'],
            ['notifications.php', 'bi-bell', 'Notifications', 'notifications'],
            ['learn.php', 'bi-journal-bookmark', 'Learning & Quiz', 'learnx'],
        ],
        'Account' => [
            ['profile.php', 'bi-person-gear', 'Profile & Settings', 'profile'],
        ],
    ],
    ROLE_COLLECTOR => [
        'Main' => [
            ['dashboard.php', 'bi-speedometer2', 'Dashboard', 'dash'],
            ['assignments.php', 'bi-list-check', 'Assigned Pickups', 'assignments'],
            ['route.php', 'bi-signpost-split', 'Suggested Route', 'route'],
            ['history.php', 'bi-clock-history', 'Collection History', 'history'],
            ['shifts.php', 'bi-stopwatch', 'My Shifts', 'myshifts'],
        ],
        'Account' => [
            ['profile.php', 'bi-person-gear', 'Profile', 'profile'],
        ],
    ],
    ROLE_RECYCLER => [
        'Main' => [
            ['dashboard.php', 'bi-speedometer2', 'Dashboard', 'dash'],
            ['incoming.php', 'bi-box-seam', 'Incoming Waste', 'incoming'],
            ['processed.php', 'bi-arrow-repeat', 'Processed History', 'processed'],
            ['facility.php', 'bi-buildings', 'My Facility', 'facility'],
        ],
        'Account' => [
            ['profile.php', 'bi-person-gear', 'Profile', 'profile'],
        ],
    ],
    ROLE_BUSINESS => [
        'Main' => [
            ['dashboard.php', 'bi-speedometer2', 'Dashboard', 'dash'],
            ['bulk-pickup.php', 'bi-stack', 'Bulk Pickup Request', 'bulk'],
            ['pickups.php', 'bi-truck', 'Pickup Records', 'pickups'],
            ['passports.php', 'bi-passport', 'Waste Passports', 'passports'],
        ],
        'Compliance' => [
            ['impact.php', 'bi-globe-americas', 'Environmental Impact', 'impact'],
            ['summary.php', 'bi-file-earmark-bar-graph', 'Periodic Summary', 'summary'],
            ['notifications.php', 'bi-bell', 'Notifications', 'notifications'],
        ],
        'Account' => [
            ['profile.php', 'bi-person-gear', 'Profile & Locations', 'profile'],
        ],
    ],
    ROLE_ADMIN => [
        'Overview' => [
            ['dashboard.php', 'bi-speedometer2', 'Dashboard', 'dash'],
            ['analytics.php', 'bi-graph-up-arrow', 'Analytics', 'analytics'],
            ['map.php', 'bi-map', 'Live Map', 'map'],
            ['hotspots.php', 'bi-fire', 'Hotspots', 'hotspots'],
        ],
        'Operations' => [
            ['shifts.php', 'bi-clock-history', 'Shift Management', 'shifts'],
            ['pickups.php', 'bi-truck', 'Pickup Requests', 'pickups'],
            ['waste.php', 'bi-box-seam', 'Waste Transactions', 'waste'],
            ['reports.php', 'bi-megaphone', 'Waste Reports', 'reports'],
            ['routes.php', 'bi-signpost-split', 'Routes', 'routes'],
        ],
        'Management' => [
            ['module.php?entity=users', 'bi-people', 'Users & Roles', 'users'],
            ['module.php?entity=facilities', 'bi-buildings', 'Facilities', 'facilities'],
            ['module.php?entity=organizations', 'bi-bank', 'Organizations', 'organizations'],
            ['module.php?entity=waste_categories', 'bi-recycle', 'Waste Categories', 'categories'],
            ['module.php?entity=vehicles', 'bi-bus-front', 'Vehicles', 'vehicles'],
        ],
        'Programs' => [
            ['badges.php', 'bi-patch-check', 'Badges & Achievements', 'badges'],
            ['module.php?entity=impact_factors', 'bi-globe-americas', 'Impact Factors', 'impact_factors'],
            ['module.php?entity=articles', 'bi-journal-bookmark', 'Learning Articles', 'articles'],
            ['module.php?entity=quizzes', 'bi-patch-question', 'Quizzes', 'quizzes'],
            ['notifications.php', 'bi-megaphone-fill', 'Announcements', 'notifications'],
        ],
        'System' => [
            ['ai-scans.php', 'bi-journal-text', 'Waste Scan Log', 'ai-scans'],
            ['audit.php', 'bi-clipboard-data', 'Audit Logs', 'audit'],
            ['settings.php', 'bi-gear', 'Settings', 'settings'],
        ],
        'Account' => [ // v2.4.4: same Profile entry as every other role (page exists now)
            ['profile.php', 'bi-person-gear', 'Profile', 'profile'],
        ],
    ],
];

$__menu = $menus[$role] ?? [];
$__base = $role . '/';
?>
<!DOCTYPE html>
<html lang="<?= e(current_lang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<title><?= e(($pageTitle ?? 'Dashboard') . ' · ' . APP_NAME) ?></title>
<meta property="og:title" content="<?= e(($pageTitle ?? 'Dashboard') . ' · PUNARVA') ?>">
<meta property="og:description" content="Every kilogram of waste gets a digital passport — trace its journey from doorstep to recycling with estimated impact.">
<meta property="og:image" content="<?= url('assets/images/logo-full.png') ?>">
<meta name="theme-color" content="#0e7a4f">
<link rel="icon" type="image/png" href="<?= url('assets/images/favicon.png') ?>">
<link rel="stylesheet" href="<?= url('assets/vendor/bootstrap/bootstrap.min.css') ?>">
<link rel="stylesheet" href="<?= url('assets/vendor/bootstrap-icons/bootstrap-icons.min.css') ?>">
<?php if (pnv_needs_map()): ?><link rel="stylesheet" href="<?= url('assets/vendor/leaflet/leaflet.css') ?>"><?php endif; ?>
<link rel="stylesheet" href="<?= asset_url('assets/css/style.css') ?>">
<link rel="stylesheet" href="<?= asset_url('assets/css/charts.css') ?>">
</head>
<body data-rank-you="<?= e(t('rank.you')) ?>">
<a class="skip-link" href="#main-content"><?= t('a11y.skip') ?></a>
<div class="dash-wrapper">
  <div class="sidebar-backdrop"></div>
  <aside class="dash-sidebar">
    <div class="brand">
      <a class="brand-logo" href="<?= url('index.php') ?>">
        <img src="<?= url('assets/images/logo-icon.png') ?>" alt="PUNARVA logo">
        <span><?= e(setting('platform_name', 'PUNARVA')) ?><small><?= e(setting('platform_tagline', t('foot.tagline'))) ?></small></span>
      </a>
    </div>
    <nav class="dash-nav">
      <?php foreach ($__menu as $caption => $links): ?>
        <div class="nav-caption"><?= e($caption) ?></div>
        <?php foreach ($links as [$href, $icon, $label, $key]): ?>
          <a href="<?= url($__base . $href) ?>" class="<?= ($activeMenu ?? '') === $key ? 'active' : '' ?>">
            <i class="bi <?= e($icon) ?>"></i> <?= e($label) ?>
          </a>
        <?php endforeach; ?>
      <?php endforeach; ?>
      <div class="nav-caption">Session</div>
      <a href="<?= logout_url() ?>" class="text-danger-emphasis" style="color:#f3b6b6!important"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </nav>
  </aside>

  <div class="dash-main">
<?php
// v2.12.0 — announcement CONTENT lives in the Announcements module (Admin → Announcements);
// System Settings only controls whether the latest announcement shows as a dashboard banner
// (7-day freshness window keeps the banner relevant and the query bounded).
$__banner = null;
if ((string) setting('announcement_display', '1') === '1') {
    try {
        // v2.13.0 — content comes from the Announcements module (published, within its
        // publish/expiry window, targeted to this user's role). Empty system = no banner.
        $__banner = AnnouncementService::activeForRole((string) ($_SESSION['user']['role_code'] ?? ''));
    } catch (Throwable $e) { $__banner = null; }
}
?>
<?php if ($__banner): ?>
    <div class="alert alert-warning small d-flex align-items-center gap-2 mx-3 mt-3 mb-0">
      <i class="bi bi-megaphone-fill"></i><div><strong><?= e($__banner['title']) ?></strong> — <?= e($__banner['message']) ?></div>
    </div>
<?php endif; ?>
    <header class="dash-topbar">
      <button class="btn btn-soft d-lg-none" id="sidebarToggle" aria-label="<?= t('a11y.toggle_sidebar') ?>" aria-expanded="false"><i class="bi bi-list" aria-hidden="true"></i></button>
      <div class="d-none d-md-block">
        <div class="small text-muted"><?= e($role === 'admin' ? 'Municipality Console' : ROLE_LABELS[$role] . ' Workspace') ?></div>
        <h1 class="dash-page-title"><?= e($pageTitle ?? '') ?></h1>
      </div>
      <div class="ms-auto d-flex align-items-center gap-2">
        <?= lang_selector() ?>
        <a href="<?= url($__base . 'notifications.php') ?>" class="btn btn-soft position-relative" data-bs-toggle="modal" data-bs-target="#notifModal" title="Notifications" aria-label="<?= t('a11y.notifications') ?>">
          <i class="bi bi-bell"></i>
          <span id="notifCount" class="badge rounded-pill bg-danger d-none">0</span>
        </a>
        <div class="dropdown">
          <button class="btn btn-soft d-flex align-items-center gap-2" data-bs-toggle="dropdown">
            <span class="avatar" style="width:30px;height:30px;font-size:.72rem"><?= e(initials($user['name'])) ?></span>
            <span class="d-none d-sm-inline small fw-semibold"><?= e($user['name']) ?></span>
            <i class="bi bi-chevron-down small"></i>
          </button>
          <ul class="dropdown-menu dropdown-menu-end shadow">
            <li><h6 class="dropdown-header"><?= e($user['email']) ?><br><span class="badge text-bg-success mt-1"><?= e(ROLE_LABELS[$role]) ?></span></h6></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="<?= url($__base . 'profile.php') ?>"><i class="bi bi-person-gear me-2"></i>Profile</a></li>
            <li><a class="dropdown-item" href="<?= url('index.php') ?>"><i class="bi bi-house me-2"></i>Public site</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="<?= logout_url() ?>"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
          </ul>
        </div>
      </div>
    </header>

    <div class="dash-content" id="main-content">
      <?php foreach (get_global_banners() as $__b): ?>
      <div class="container mt-3"><div class="alert alert-<?= e($__b['type']) ?>"><i class="bi bi-info-circle me-1"></i><?= e($__b['message']) ?></div></div>
    <?php endforeach; ?>
    <?php foreach (get_flashes() as $__fl): // $__ prefix: never clobber page variables ?>
        <div class="alert alert-<?= e($__fl['type']) ?> alert-dismissible fade show alert-auto">
          <?= e($__fl['message']) ?><button class="btn-close" data-bs-dismiss="alert" aria-label="<?= t('a11y.close') ?>"></button>
        </div>
      <?php endforeach; ?>
      <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb small">
          <li class="breadcrumb-item"><a href="<?= url($__base . 'dashboard.php') ?>"><?= e(ROLE_LABELS[$role]) ?></a></li>
          <li class="breadcrumb-item active"><?= e($pageTitle ?? '') ?></li>
        </ol>
      </nav>
