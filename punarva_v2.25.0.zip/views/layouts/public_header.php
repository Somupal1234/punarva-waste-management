<?php
/** Public site header. Expects optional $pageTitle, $bodyClass. */
$__pageTitle = ($pageTitle ?? 'Welcome') . ' · ' . APP_NAME;
$__user = current_user();
?>
<!DOCTYPE html>
<html lang="<?= e(current_lang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<title><?= e($__pageTitle) ?></title>
<meta property="og:title" content="<?= e($__pageTitle ?? 'PUNARVA') ?> · PUNARVA — From Waste to Worth">
<meta property="og:description" content="Every kilogram of waste gets a digital passport — trace its journey from doorstep to recycling with estimated impact.">
<meta property="og:image" content="<?= url('assets/images/logo-full.png') ?>">
<link rel="canonical" href="<?= e(url(basename(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: 'index.php'))) // v2.21.0: canonical per public page ?>">
<meta name="theme-color" content="#0e7a4f">
<meta name="description" content="PUNARVA — From Waste to Worth. A transparent digital waste-management ecosystem with traceable Waste Passports, QR tracking and estimated environmental impact.">
<link rel="icon" type="image/png" href="<?= url('assets/images/favicon.png') ?>">
<link rel="stylesheet" href="<?= url('assets/vendor/bootstrap/bootstrap.min.css') ?>">
<link rel="stylesheet" href="<?= url('assets/vendor/bootstrap-icons/bootstrap-icons.min.css') ?>">
<?php if (pnv_needs_map()): ?><link rel="stylesheet" href="<?= url('assets/vendor/leaflet/leaflet.css') ?>"><?php endif; ?>
<link rel="stylesheet" href="<?= asset_url('assets/css/style.css') ?>">
</head>
<body class="<?= e($bodyClass ?? '') ?>">
<a class="skip-link" href="#main-content"><?= t('a11y.skip') ?></a>
<nav class="navbar navbar-expand-lg navbar-pnv sticky-top py-2">
  <div class="container">
    <a class="brand-logo" href="<?= url('index.php') ?>">
      <img src="<?= url('assets/images/logo-icon.png') ?>" alt="PUNARVA logo">
      <span><?= e(setting('platform_name', 'PUNARVA')) ?><small><?= e(setting('platform_tagline', t('foot.tagline'))) ?></small></span>
    </a>
    <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="<?= t('a11y.toggle_nav') ?>"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav mx-auto">
        <li class="nav-item"><a class="nav-link <?= ($activeNav ?? '') === 'home' ? 'active' : '' ?>" href="<?= url('index.php') ?>"><?= t('nav.home') ?></a></li>
        <li class="nav-item"><a class="nav-link <?= ($activeNav ?? '') === 'how' ? 'active' : '' ?>" href="<?= url('how-it-works.php') ?>"><?= t('nav.how') ?></a></li>
        <li class="nav-item"><a class="nav-link <?= ($activeNav ?? '') === 'guide' ? 'active' : '' ?>" href="<?= url('waste-guide.php') ?>"><?= t('nav.guide') ?></a></li>
        <li class="nav-item"><a class="nav-link <?= ($activeNav ?? '') === 'learn' ? 'active' : '' ?>" href="<?= url('learn.php') ?>"><?= t('nav.learn') ?></a></li>
        <li class="nav-item"><a class="nav-link <?= ($activeNav ?? '') === 'track' ? 'active' : '' ?>" href="<?= url('track.php') ?>"><?= t('nav.track') ?></a></li>
        <li class="nav-item"><a class="nav-link <?= ($activeNav ?? '') === 'report' ? 'active' : '' ?>" href="<?= url('report.php') ?>"><?= t('nav.report') ?></a></li>
      </ul>
      <div class="d-flex align-items-center gap-2 flex-wrap">
        <?= lang_selector() ?>
        <?php if ($__user): ?>
          <a class="btn btn-pnv btn-sm px-3" href="<?= url(ROLE_HOME[$__user['role_code']] ?? 'index.php') ?>"><i class="bi bi-speedometer2 me-1"></i><?= t('nav.dashboard') ?></a>
        <?php else: ?>
          <a class="btn btn-outline-pnv btn-sm px-3" href="<?= url('login.php') ?>"><?= t('nav.login') ?></a>
          <a class="btn btn-pnv btn-sm px-3" href="<?= url('register.php') ?>"><?= t('nav.register') ?></a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>
<?php foreach (get_global_banners() as $__b): ?>
    <div class="container mt-3"><div class="alert alert-<?= e($__b['type']) ?>"><i class="bi bi-info-circle me-1"></i><?= e($__b['message']) ?></div></div>
  <?php endforeach; ?>
  <?php foreach (get_flashes() as $f): ?>
  <div class="container mt-3"><div class="alert alert-<?= e($f['type']) ?> alert-dismissible fade show alert-auto">
    <?= e($f['message']) ?><button class="btn-close" data-bs-dismiss="alert" aria-label="<?= t('a11y.close') ?>"></button></div></div>
<?php endforeach; ?>
<main id="main-content">
