<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_login();
if ($user['role_code'] === ROLE_ADMIN) $s = ImpactService::globalSummary();
else $s = ImpactService::summaryForUser((int) $user['id']);
$s['equivalents'] = ImpactService::equivalents($s);
$s['methodology'] = METHODOLOGY_VERSION;
$s['disclaimer'] = 'All impact values are ESTIMATES: quantity × configured factor.';
json_ok('Impact summary', $s);
