<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_role(ROLE_RECYCLER);
$fid = (int) $user['facility_id'];
$rows = Database::all(
    'SELECT wt.id, wt.waste_id, wt.current_stage, wt.current_weight, wc.name AS category
     FROM waste_transactions wt JOIN waste_categories wc ON wc.id = wt.category_id
     WHERE wt.facility_id = ? OR (wt.facility_id IS NULL AND wt.current_stage = "COLLECTED")
     ORDER BY wt.created_at DESC LIMIT 100', [$fid]);
json_ok('Intake queue', ['items' => $rows, 'count' => count($rows)]);
