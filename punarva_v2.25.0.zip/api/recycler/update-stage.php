<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_role(ROLE_RECYCLER);
if (!is_post()) json_err('Method not allowed', [], 405);
try {
    $id = (int) post_val('waste_transaction_id');
    $tx = Database::one('SELECT * FROM waste_transactions WHERE id = ?', [$id]);
    if (!$tx) json_err('Waste transaction not found', [], 404);
    OwnershipMiddleware::facilityWaste($tx, $user);
    $facility = Database::one('SELECT * FROM facilities WHERE id = ?', [$user['facility_id']]);
    $stage = strtoupper((string) post_val('new_stage'));
    if ($tx['facility_id'] === null) {
        Database::update('waste_transactions', ['facility_id' => $user['facility_id']], 'id = ?', [$id]);
        WasteJourneyService::addEvent($id, 'RECEIVED_AT_FACILITY', ['facility_id' => $user['facility_id'], 'actor_role' => 'RECYCLER',
            'passport_label' => 'Waste received at facility', 'notes' => 'Received at ' . $facility['name'], 'location' => $facility['city']]);
        if ($stage === 'COLLECTED') json_ok('Waste received at facility');
    }
    $res = WasteJourneyService::setStage($id, $stage, [
        'facility_id' => $user['facility_id'], 'facility_name' => $facility['name'],
        'quantity' => post_val('quantity') !== null ? (float) post_val('quantity') : null,
        'notes' => post_val('notes') ?: null,
    ]);
    json_ok('Stage updated to ' . WASTE_STAGE_LABELS[$stage], ['transaction' => $res]);
} catch (InvalidArgumentException $e) { json_err($e->getMessage(), [], 422); }
catch (Throwable $e) { json_err(APP_DEBUG ? $e->getMessage() : 'Stage update failed', [], 400); }
