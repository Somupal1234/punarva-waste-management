<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
require_role(ROLE_ADMIN);
json_ok('Admin dashboard', [
    'users' => (int) Database::val('SELECT COUNT(*) FROM users'),
    'pickups' => (int) Database::val('SELECT COUNT(*) FROM pickup_requests'),
    'open_pickups' => (int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE status IN ("REQUESTED","ASSIGNED","ACCEPTED","ON_THE_WAY","ARRIVED","COLLECTED")'),
    'completed_pickups' => (int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE status = "COMPLETED"'),
    'waste_transactions' => (int) Database::val('SELECT COUNT(*) FROM waste_transactions'),
    'waste_kg' => (float) (Database::val('SELECT COALESCE(SUM(initial_weight),0) FROM waste_transactions')),
    'recycled_kg' => (float) (Database::val('SELECT COALESCE(SUM(current_weight),0) FROM waste_transactions WHERE final_outcome IN ("RECYCLED","RECOVERED","COMPOSTED","REUSED")')),
    'reports_open' => (int) Database::val('SELECT COUNT(*) FROM waste_reports WHERE status IN ("SUBMITTED","VERIFIED","ASSIGNED","IN_PROGRESS")'),
    'badges_awarded' => (int) Database::val('SELECT COUNT(*) FROM user_badges'),
    'impact' => ImpactService::globalSummary(),
]);
