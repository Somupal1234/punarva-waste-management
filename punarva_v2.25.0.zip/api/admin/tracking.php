<?php
/**
 * GET /api/admin/tracking.php — live-tracking reads for the admin ops map (v2.4.0).
 *
 *   ?action=active          → all trucks with ACTIVE shifts + computed state
 *   ?action=route&shift_id= → full breadcrumb route of one shift
 *
 * Security: ADMIN session required (server-side RBAC — citizens/collectors can never
 * read live driver locations). Read-only GET; prepared statements throughout.
 */
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
require_role(ROLE_ADMIN);
if (is_post()) json_err('Method not allowed', [], 405);

$action = (string) ($_GET['action'] ?? 'active');
try {
    if ($action === 'active') {
        json_ok('Active trucks.', ['trucks' => TrackingService::activeTrucks(), 'server_time' => date('c')]);
    }
    if ($action === 'route') {
        $shiftId = (int) ($_GET['shift_id'] ?? 0);
        if ($shiftId <= 0) throw new InvalidArgumentException('Shift ID is required.');
        json_ok('Shift route.', TrackingService::shiftRoute($shiftId));
    }
    throw new InvalidArgumentException('Unknown action.');
} catch (InvalidArgumentException $e) {
    json_err($e->getMessage(), [], 422);
}
