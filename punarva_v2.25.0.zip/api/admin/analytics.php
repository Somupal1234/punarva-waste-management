<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
require_role(ROLE_ADMIN);
json_ok('Analytics', [
    'by_category' => Database::all('SELECT wc.name, wc.color, ROUND(COALESCE(SUM(wt.initial_weight),0),2) AS total_kg FROM waste_transactions wt JOIN waste_categories wc ON wc.id = wt.category_id GROUP BY wt.category_id ORDER BY total_kg DESC'),
    'by_month' => Database::all('SELECT DATE_FORMAT(created_at, "%Y-%m") AS month, ROUND(COALESCE(SUM(initial_weight),0),2) AS kg, COUNT(*) AS loads FROM waste_transactions GROUP BY month ORDER BY month'),
    'outcomes' => Database::all('SELECT final_outcome, COUNT(*) AS loads, ROUND(COALESCE(SUM(current_weight),0),2) AS kg FROM waste_transactions WHERE final_outcome IS NOT NULL GROUP BY final_outcome'),
    'pickup_trend' => Database::all('SELECT preferred_date AS date, COUNT(*) AS requested, SUM(status = "COMPLETED") AS completed FROM pickup_requests GROUP BY preferred_date ORDER BY preferred_date DESC LIMIT 30'),
    'completion_rate_pct' => round(((int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE status = "COMPLETED"')) / max(1, (int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE status <> "CANCELLED"')) * 100),
    'impact' => ImpactService::globalSummary(),
    'badges_awarded' => (int) Database::val('SELECT COUNT(*) FROM user_badges'),
]);
