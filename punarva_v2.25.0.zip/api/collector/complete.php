<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_role(ROLE_COLLECTOR);
if (!is_post()) json_err('Method not allowed', [], 405);
try {
    // record collection then complete in the required order (weight + proof first)
    $a = Database::one('SELECT status FROM pickup_assignments WHERE id = ?', [(int) post_val('assignment_id')]);
    if (!$a) json_err('Assignment not found', [], 404);
    if ($a['status'] === 'ARRIVED') PickupService::transition((int) post_val('assignment_id'), 'COLLECTED', $user, $_POST);
    $res = PickupService::transition((int) post_val('assignment_id'), 'COMPLETED', $user, $_POST);
    // v2.20.0 fix: waste transaction is keyed by PICKUP id, not assignment id —
    // use the pickup_request_id from the completed assignment (waste_id was always null before).
    $tx = Database::one('SELECT waste_id FROM waste_transactions WHERE pickup_request_id = ?', [(int) ($res['pickup_request_id'] ?? 0)]);
    json_ok('Pickup completed', ['waste_id' => $tx['waste_id'] ?? null]);
} catch (InvalidArgumentException $e) { json_err($e->getMessage(), [], 422); }
catch (Throwable $e) { json_err(APP_DEBUG ? $e->getMessage() : 'Completion failed', [], 400); }
