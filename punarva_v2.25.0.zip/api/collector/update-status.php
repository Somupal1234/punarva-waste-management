<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_role(ROLE_COLLECTOR);
if (!is_post()) json_err('Method not allowed', [], 405);
$status = strtoupper((string) post_val('status', ''));
if (!in_array($status, PICKUP_STATUSES, true)) json_err('Unknown status', [], 422);
try {
    $res = PickupService::transition((int) post_val('assignment_id'), $status, $user, $_POST);
    json_ok('Status updated to ' . PICKUP_STATUS_LABELS[$status], ['assignment' => $res]);
} catch (InvalidArgumentException $e) { json_err($e->getMessage(), [], 422); }
catch (Throwable $e) { json_err(APP_DEBUG ? $e->getMessage() : 'Update failed', [], 400); }
