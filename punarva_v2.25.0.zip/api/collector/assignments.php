<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_role(ROLE_COLLECTOR);
$status = (string) get_val('status', '');
$where = 'pa.collector_id = ?'; $params = [$user['id']];
if ($status !== '' && in_array($status, PICKUP_STATUSES, true)) { $where .= ' AND pa.status = ?'; $params[] = $status; }
$rows = Database::all(
    "SELECT pa.id, pa.status, pr.pickup_code, pr.address_line, pr.ward, pr.estimated_weight, pr.preferred_date, pr.time_slot,
            wc.name AS category, u.name AS citizen
     FROM pickup_assignments pa JOIN pickup_requests pr ON pr.id = pa.pickup_request_id
     JOIN waste_categories wc ON wc.id = pr.category_id JOIN users u ON u.id = pr.user_id
     WHERE $where ORDER BY pr.preferred_date LIMIT 100", $params);
json_ok('Assignments', ['items' => $rows, 'count' => count($rows)]);
