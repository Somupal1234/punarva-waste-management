<?php
/**
 * POST /api/driver/track.php — driver live-tracking endpoint (v2.4.0).
 *
 * Actions (JSON body via pnvApi, CSRF-checked by middleware):
 *   punch_in            → start shift (requires an assigned ACTIVE vehicle)
 *   punch_out           → end shift
 *   ping                → GPS update (lat,lng,accuracy,speed,heading) — validated + throttled
 *   status              → driver's own tracking status
 *
 * Security: collector session + ownership (a driver can only touch their OWN shifts);
 * server-side numeric validation for every GPS field; no raw errors, no key exposure.
 */
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_role(ROLE_COLLECTOR);
if (!is_post()) json_err('Method not allowed', [], 405);

$in = $_POST;
if (empty($in) && str_contains((string) ($_SERVER['CONTENT_TYPE'] ?? ''), 'application/json')) {
    $in = (array) json_decode((string) file_get_contents('php://input'), true);
}
$action = (string) ($in['action'] ?? '');

try {
    switch ($action) {
        case 'punch_in':
            json_ok('Punched in — tracking started.', TrackingService::punchIn((int) $user['id']));
        case 'punch_out':
            $out = TrackingService::punchOut((int) $user['id']);
            json_ok('Punched out — tracking stopped.', $out);
        case 'ping':
            // v2.20.0 — strict numeric validation: "abc" must be rejected, not silently
            // cast to 0.0 (PHP (float)"abc" === 0.0 would insert a fake 0°N 87°E ping).
            $num = function (string $k) use ($in): ?float {
                $v = $in[$k] ?? null;
                if ($v === null || $v === '') return null;
                if (!is_numeric($v)) throw new InvalidArgumentException('Invalid value for ' . $k . '.');
                return (float) $v;
            };
            if (!isset($in['lat'], $in['lng']) || $in['lat'] === '' || $in['lng'] === '') throw new InvalidArgumentException('Coordinates are required.');
            $lat = $num('lat'); $lng = $num('lng');
            if (!is_finite($lat) || !is_finite($lng)) throw new InvalidArgumentException('Coordinates are required.');
            $acc = $num('accuracy'); $spd = $num('speed'); $hdg = $num('heading');
            json_ok('Location updated.', TrackingService::ping((int) $user['id'], $lat, $lng, $acc, $spd, $hdg));
        case 'status':
            json_ok('Status.', TrackingService::driverStatus((int) $user['id']));
        default:
            throw new InvalidArgumentException('Unknown action.');
    }
} catch (InvalidArgumentException $e) {
    json_err($e->getMessage(), [], 422);
} catch (RuntimeException $e) {
    json_err($e->getMessage(), [], 409);
}
