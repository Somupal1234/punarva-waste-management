<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
if (!is_post()) json_err('Method not allowed', [], 405);
try {
    AuthService::attempt(val_email($_POST), (string) post_val('password', ''));
    json_ok('Login successful', ['user' => ['id' => current_user()['id'], 'name' => current_user()['name'], 'role' => current_user()['role_code']]]);
} catch (InvalidArgumentException | RuntimeException $e) {
    json_err($e->getMessage(), [], 401);
}
