<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_role(ROLE_ADMIN);
if (!is_post()) json_err('Method not allowed', [], 405);
$id = (int) post_val('report_id'); $new = strtoupper((string) post_val('status', ''));
$r = Database::one('SELECT * FROM waste_reports WHERE id = ?', [$id]);
if (!$r) json_err('Report not found', [], 404);
if (!in_array($new, REPORT_STATUSES, true)) json_err('Invalid status', [], 422);
Database::update('waste_reports', ['status' => $new, 'updated_at' => date('Y-m-d H:i:s')], 'id = ?', [$id]);
AuditService::log('REPORT_' . $new, 'reports', $id, $r['status'], $new);
HotspotService::refreshAsync();
json_ok('Report updated', ['report' => Database::one('SELECT * FROM waste_reports WHERE id = ?', [$id])]);
