<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = current_user(); // guests may report too
if (!is_post()) json_err('Method not allowed', [], 405);
try {
    $image = reencode_upload(handle_upload($_FILES['photo'] ?? null, 'reports'), 'reports'); // v2.4.0 server-side re-process
    [$lat, $lng] = val_latlng($_POST);
    // v2.4.0 — GPS capture metadata (sanitised; never trust the client blindly)
    $accRaw = $_POST['accuracy_m'] ?? null;
    $accuracy = ($accRaw !== null && $accRaw !== '' && is_numeric($accRaw)) ? round((float) $accRaw, 2) : null;
    if ($accuracy !== null && ($accuracy < 0 || $accuracy > 10000)) $accuracy = null;
    $capRaw = trim((string) ($_POST['location_captured_at'] ?? ''));
    $capAt = preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $capRaw) ? $capRaw : null;
    $id = Database::insert('waste_reports', [
        'report_code' => rand_code('PNVR'), 'user_id' => $user['id'] ?? null,
        'category_id' => (int) post_val('category_id', 0) ?: null,
        'description' => val_str($_POST, 'description', 1000, true, 'Description'),
        'image_path' => $image, 'address_line' => val_str($_POST, 'address_line', 255, true, 'Address'),
        'ward' => val_str($_POST, 'ward', 40, false) ?: null, 'city' => val_str($_POST, 'city', 80, false) ?: (string) setting('default_city', 'Dumka'),
        'latitude' => $lat, 'longitude' => $lng, 'status' => 'SUBMITTED',
        'accuracy_m' => $accuracy, 'location_captured_at' => $capAt,
    ]);
    HotspotService::refreshAsync();
    if ($user) NotificationService::send((int) $user['id'], 'REPORT', 'Report submitted', 'Your report was received.', 'waste_report', $id);
    NotificationService::sendToRoles([ROLE_ADMIN], 'REPORT', 'New waste report', 'A new report was submitted.', 'waste_report', $id);
    json_ok('Report submitted', ['report_id' => $id], 201);
} catch (InvalidArgumentException | RuntimeException $e) { json_err($e->getMessage(), [], 422); }
