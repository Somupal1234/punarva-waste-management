<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_login();
$where = '1=1'; $params = [];
if ($user['role_code'] === ROLE_CITIZEN || $user['role_code'] === ROLE_BUSINESS) { $where = 'wr.user_id = ?'; $params = [$user['id']]; }
elseif ($user['role_code'] === ROLE_ADMIN) {}
else json_err('Not authorized', [], 403);
$status = (string) get_val('status', '');
if ($status !== '' && in_array($status, REPORT_STATUSES, true)) { $where .= ' AND wr.status = ?'; $params[] = $status; }
$rows = Database::all("SELECT wr.id, wr.report_code, wr.status, wr.description, wr.address_line, wr.ward, wr.created_at
     FROM waste_reports wr WHERE $where ORDER BY wr.created_at DESC LIMIT 100", $params);
json_ok('Reports', ['items' => $rows, 'count' => count($rows)]);
