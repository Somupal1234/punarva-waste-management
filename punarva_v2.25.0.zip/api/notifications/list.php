<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_login();
$limit = min(50, max(1, (int) get_val('limit', 20)));
$items = array_map(fn($n) => [
    'id' => (int) $n['id'], 'title' => $n['title'], 'message' => $n['message'],
    'type' => $n['type'], 'is_read' => (bool) $n['is_read'], 'ago' => time_ago($n['created_at']),
], NotificationService::listFor((int) $user['id'], $limit));
json_ok('Notifications', ['items' => $items, 'unread' => NotificationService::unreadCount((int) $user['id'])]);
