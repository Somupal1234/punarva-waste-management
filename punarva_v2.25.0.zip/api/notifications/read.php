<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_login();
if (!is_post()) json_err('Method not allowed', [], 405);
$body = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$id = isset($body['id']) ? (int) $body['id'] : null;
$n = NotificationService::markRead((int) $user['id'], $id);
json_ok($id ? 'Notification marked as read' : 'All notifications marked as read', ['updated' => $n, 'unread' => NotificationService::unreadCount((int) $user['id'])]);
