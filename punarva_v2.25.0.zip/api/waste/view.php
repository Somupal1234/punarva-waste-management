<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
require_login();
$tx = WasteJourneyService::trackByWasteId((string) get_val('waste_id', get_val('id', '')));
if (!$tx) json_err('Waste transaction not found', [], 404);
json_ok('Waste transaction', [
    'waste_id' => $tx['waste_id'], 'category' => $tx['category_name'], 'weight_kg' => (float) $tx['current_weight'],
    'status' => $tx['current_stage'], 'final_outcome' => $tx['final_outcome'],
    'facility' => $tx['facility_name'], 'created_at' => $tx['created_at'],
]);
