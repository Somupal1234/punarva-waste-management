<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
require_login();
$tx = WasteJourneyService::trackByWasteId((string) get_val('waste_id', get_val('id', '')));
if (!$tx) json_err('Waste Passport not found', [], 404);
$events = WasteJourneyService::timeline((int) $tx['id']);
$impact = ImpactService::forTransaction((int) $tx['id']);
json_ok('Waste Passport', [
    'waste_id' => $tx['waste_id'], 'category' => $tx['category_name'], 'status' => $tx['current_stage'],
    'final_outcome' => $tx['final_outcome'], 'approx_weight_kg' => round((float) $tx['current_weight'], 1),
    'origin' => $tx['ward'] ? 'Ward ' . $tx['ward'] . ', ' . ($tx['city'] ?? (string) setting('default_city', 'Dumka')) : (string) setting('default_city', 'Dumka'),
    'journey' => array_map(fn($e) => [
        'event' => $e['event_type'], 'time' => $e['event_time'], 'actor_role' => $e['actor_role'],
        'facility' => $e['facility_name'], // internal notes intentionally excluded from public/passport API
    ], $events),
    'impact' => $impact, 'methodology' => METHODOLOGY_VERSION,
]);
