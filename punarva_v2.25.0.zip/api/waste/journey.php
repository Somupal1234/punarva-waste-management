<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
require_login();
$tx = WasteJourneyService::trackByWasteId((string) get_val('waste_id', get_val('id', '')));
if (!$tx) json_err('Waste transaction not found', [], 404);
$events = WasteJourneyService::timeline((int) $tx['id']);
json_ok('Journey events', ['waste_id' => $tx['waste_id'], 'events' => $events]);
