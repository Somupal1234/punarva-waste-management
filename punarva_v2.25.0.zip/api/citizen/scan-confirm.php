<?php
/**
 * GONE (v2.14.0) — the AI scan confirm/correct flow was removed together with the
 * AI scanner. The manual scanner stores the user-selected category directly
 * (api/citizen/scan.php). Historical scan rows remain untouched and viewable.
 */
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
json_err('The scan confirmation flow has been retired — scans are now saved with the category you select.', [], 410);
