<?php
/**
 * Community Impact Ranking (v2.8.0) — GET, citizen-only.
 * Ranks by VERIFIED real-world activity only (completed pickups + verified/resolved
 * reports + facility-processed recycling). Learning activity is excluded by design.
 * Privacy: first name + last initial only — never email/phone/address/location.
 * Cached ~20 s server-side; client polls ≤ every 12 s and pauses on hidden tabs.
 */
require_once dirname(__DIR__, 2) . '/includes/init.php';

$user = require_role(ROLE_CITIZEN);

$rank = BadgeService::ranking((int) $user['id'], 8);
$counts = BadgeService::counts((int) $user['id']);

json_ok('Community impact ranking', [
    'updated_at' => $rank['updated_at'],
    'users' => $rank['users'],
    'me' => $rank['me'],
    'my_counts' => [
        'verified_activities' => BadgeService::verifiedActivities((int) $user['id']),
        'real_badges' => $counts['real_impact'],
    ],
]);
