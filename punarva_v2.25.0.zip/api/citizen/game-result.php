<?php
// v2.10.0: the SORT IT game was removed — endpoint permanently retired (mirrors api/rewards pattern).
http_response_code(410);
header('Content-Type: application/json; charset=UTF-8');
echo json_encode(['success' => false, 'message' => 'This feature has been retired.', 'errors' => [], 'data' => null]);
exit;
