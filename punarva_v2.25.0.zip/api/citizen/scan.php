<?php
/**
 * POST /api/citizen/scan.php — MANUAL waste scan save (v2.14.0).
 * No AI, no external API, no automatic classification: the user picks the category;
 * this endpoint validates the image + category SERVER-SIDE and stores the scan with
 * provider='manual' / mode='manual'. Ownership is implicit (scan belongs to the
 * authenticated citizen); CSRF comes from init.php middleware.
 */
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN);
if (!is_post()) json_err('Method not allowed', [], 405);

try {
    $categoryId = (int) post_val('category_id', 0);
    if ($categoryId <= 0) throw new InvalidArgumentException('Please select a waste category.');

    $cat = Database::one('SELECT id, name, bin_type, is_recyclable, recycling_guidance, description, color FROM waste_categories WHERE id = ? AND status = "ACTIVE"', [$categoryId]);
    if (!$cat) throw new InvalidArgumentException('Please select a valid waste category.');

    // server-side upload validation (MIME sniff, extension, size, dimensions, safe name)
    $rel = handle_upload($_FILES['image'] ?? null, 'waste');
    if (!$rel) throw new InvalidArgumentException('Please choose or capture a waste image first.');

    $ok = Database::insert('waste_scans', [
        'user_id'      => (int) $user['id'],
        'image_path'   => $rel,
        'result_item'  => $cat['name'],
        'category_id'  => (int) $cat['id'],
        'material'     => null,
        'confidence'   => 0.00, // never a fake percentage — the user classified this
        'bin_type'     => $cat['bin_type'],
        'advice'       => mb_substr((string) ($cat['recycling_guidance'] ?: $cat['description']), 0, 500),
        'recyclable'   => $cat['is_recyclable'] === '1' ? 'yes' : 'no',
        'uncertain'    => 0,
        'status'       => 'completed',
        'mode'         => 'manual', // enum extended by migration 010
        'provider'     => 'manual',
        'ai_model'     => null,
    ]);

    AuditService::log('SCAN_SAVED', 'waste_scans', $ok, null, ['by' => (int) $user['id'], 'category' => $cat['name'], 'source' => 'manual']);

    json_ok('Scan saved with your selected category.', [
        'scan_id'        => $ok,
        'category_id'    => (int) $cat['id'],
        'category_name'  => $cat['name'],
        'category_color' => $cat['color'],
        'bin_type'       => $cat['bin_type'],
        'recyclable'     => $cat['is_recyclable'] === '1' ? 'yes' : 'no',
        'advice'         => (string) ($cat['recycling_guidance'] ?: $cat['description']),
        'report_url'     => url('citizen/reports.php?scan_id=' . $ok),
        'pickup_url'     => url('citizen/pickup-create.php?category=' . (int) $cat['id'] . '&from_scan=' . $ok),
        'source'         => 'manual',
    ]);
} catch (InvalidArgumentException | RuntimeException $e) {
    json_err($e->getMessage(), [], 422);
} catch (Throwable $e) {
    // never leak SQL/internal errors to the UI (v2.4.x standing rule)
    error_log('scan.php save failed: ' . $e->getMessage());
    json_err('Could not save the scan. Please try again.', [], 500);
}
