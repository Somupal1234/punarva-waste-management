<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN);
json_ok('Citizen dashboard', [
    'totals' => [
        'waste_submitted_kg' => (float) (Database::val('SELECT COALESCE(SUM(estimated_weight),0) FROM pickup_requests WHERE user_id = ? AND status <> "CANCELLED"', [$user['id']])),
        'completed_pickups'  => (int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE user_id = ? AND status = "COMPLETED"', [$user['id']]),
        'recycled_kg'        => (float) (Database::val('SELECT COALESCE(SUM(current_weight),0) FROM waste_transactions WHERE source_user_id = ? AND final_outcome IN ("RECYCLED","RECOVERED","COMPOSTED","REUSED")', [$user['id']])),
        'badges'             => BadgeService::counts((int) $user['id']),
        'verified_activities' => BadgeService::verifiedActivities((int) $user['id']),
    ],
    'impact' => ImpactService::summaryForUser((int) $user['id']),
    'unread_notifications' => NotificationService::unreadCount((int) $user['id']),
]);
