<?php
// v2.8.0: REWARDS RETIRED — the points system is replaced by Badges + Real Impact.
require_once dirname(__DIR__, 2) . '/includes/init.php';
require_role(ROLE_CITIZEN);
http_response_code(410);
header('Content-Type: application/json');
echo json_encode(['success' => false, 'message' => t('rewards.retired'), 'data' => null, 'errors' => []]);
