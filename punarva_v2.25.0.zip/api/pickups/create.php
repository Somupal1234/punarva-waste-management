<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN, ROLE_BUSINESS);
if (!is_post()) json_err('Method not allowed', [], 405);
try {
    $_POST['image'] = $_FILES['image'] ?? null;
    $pickup = PickupService::create($user, $_POST);
    json_ok('Pickup request created', ['pickup' => $pickup], 201);
} catch (InvalidArgumentException | RuntimeException $e) { json_err($e->getMessage(), [], 422); }
