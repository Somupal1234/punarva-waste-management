<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_login();
// v2.14.0 IDOR fix: explicit role allow-list — recyclers work on waste transactions,
// never on citizens' pickup details (address/ward/geo are PII). Deny before anything else.
if (!in_array($user['role_code'], [ROLE_CITIZEN, ROLE_BUSINESS, ROLE_COLLECTOR, ROLE_ADMIN], true)) {
    json_err('Not authorized', [], 403);
}
$id = (int) get_val('id', 0);
$pickup = Database::one('SELECT * FROM pickup_requests WHERE id = ?', [$id]);
if (!$pickup) json_err('Pickup not found', [], 404);
if ($user['role_code'] === ROLE_CITIZEN || $user['role_code'] === ROLE_BUSINESS) OwnershipMiddleware::pickupOwner($pickup, $user);
elseif ($user['role_code'] === ROLE_COLLECTOR) {
    $ok = Database::val('SELECT COUNT(*) FROM pickup_assignments WHERE pickup_request_id = ? AND collector_id = ?', [$id, $user['id']]);
    if (!$ok && $user['role_code'] !== ROLE_ADMIN) json_err('Not authorized', [], 403);
}
$assignment = Database::one('SELECT pa.*, u.name AS collector_name FROM pickup_assignments pa LEFT JOIN users u ON u.id = pa.collector_id WHERE pa.pickup_request_id = ?', [$id]);
$tx = Database::one('SELECT waste_id FROM waste_transactions WHERE pickup_request_id = ?', [$id]);
json_ok('Pickup detail', ['pickup' => $pickup, 'assignment' => $assignment, 'waste_id' => $tx['waste_id'] ?? null]);
