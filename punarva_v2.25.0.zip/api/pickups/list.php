<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN, ROLE_BUSINESS);
$where = 'pr.user_id = ?'; $params = [$user['id']];
$status = (string) get_val('status', '');
if ($status !== '' && in_array($status, PICKUP_STATUSES, true)) { $where .= ' AND pr.status = ?'; $params[] = $status; }
$rows = Database::all(
    "SELECT pr.id, pr.pickup_code, pr.status, pr.estimated_weight, pr.preferred_date, pr.time_slot,
            wc.name AS category, u.name AS collector
     FROM pickup_requests pr JOIN waste_categories wc ON wc.id = pr.category_id
     LEFT JOIN pickup_assignments pa ON pa.pickup_request_id = pr.id
     LEFT JOIN users u ON u.id = pa.collector_id
     WHERE $where ORDER BY pr.created_at DESC LIMIT 100", $params);
json_ok('Pickups', ['items' => $rows, 'count' => count($rows)]);
