<?php
require_once dirname(dirname(__DIR__)) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN, ROLE_BUSINESS, ROLE_ADMIN);
if (!is_post()) json_err('Method not allowed', [], 405);
try {
    PickupService::cancel((int) post_val('pickup_id'), $user, (string) post_val('reason', ''));
    json_ok('Pickup cancelled');
} catch (InvalidArgumentException $e) { json_err($e->getMessage(), [], 422); }
catch (Throwable $e) { json_err($e->getMessage(), [], 400); }
