<?php
// v2.10.0: SORT IT game retired — stale links land on the achievements page.
require_once dirname(__DIR__) . '/includes/init.php';
if (session_status() === PHP_SESSION_ACTIVE && isset($_SESSION['user_id'])) {
    redirect(ROLE_HOME[$_SESSION['role_code']] ?? 'index.php');
}
redirect('index.php');
