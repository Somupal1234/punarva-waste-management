<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN, ROLE_BUSINESS);
$pageTitle = 'Request Pickup'; $activeMenu = 'pickup-create';

$categories = Database::all('SELECT * FROM waste_categories WHERE status = "ACTIVE" ORDER BY id');
$addresses  = Database::all('SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC', [$user['id']]);
$slots = ['06:00-09:00','09:00-12:00','12:00-15:00','15:00-18:00','18:00-20:00'];

$fieldErrors = [];
if (is_post()) {
    try {
        $_POST['image'] = $_FILES['image'] ?? null;
        $pickup = PickupService::create($user, $_POST + ['image' => $_FILES['image'] ?? null]); // v2.11.1 fix: $_FILES was dropped — request photo never saved
        flash('success', 'Pickup request ' . $pickup['pickup_code'] . ' created! The municipality will assign a collector soon.');
        redirect('citizen/pickup-view.php?id=' . $pickup['id']);
    } catch (InvalidArgumentException | RuntimeException $e) {
        $msg = $e->getMessage();
        flash('danger', $msg);
        $f = pnv_field_error($msg, ['address' => 'address_line', 'date' => 'preferred_date',
            'slot' => 'time_slot', 'weight' => 'estimated_weight', 'category' => 'category_id',
            'notes' => 'notes', 'image' => 'image', 'photo' => 'image']);
        if ($f) $fieldErrors[$f] = $msg;
    } catch (Throwable $e) {
        flash('danger', APP_DEBUG ? $e->getMessage() : 'Could not create the pickup request.');
    }
}
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="row g-4">
  <div class="col-lg-8">
    <div class="card">
      <div class="card-body p-4">
        <h5 class="fw-bold mb-1"><i class="text-pnv bi bi-plus-circle me-2"></i>New pickup request</h5>
        <p class="text-muted small mb-4">Segregated waste only — mixed loads may be rejected at collection.</p>
        <form method="post" enctype="multipart/form-data" novalidate>
          <?= csrf_field() ?>
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label fw-semibold small">Waste category <span class="required-asterisk" aria-hidden="true">*</span></label>
              <select class="form-select" name="category_id" required>
                <option value="">Select category…</option>
                <?php foreach ($categories as $c): ?>
                  <option value="<?= (int) $c['id'] ?>" data-bin="<?= e($c['bin_type']) ?>"
                    <?= (post_val('category_id') ?: get_val('category')) == $c['id'] ? 'selected' : '' ?>>
                    <?= e($c['name']) ?> → <?= e($c['bin_type']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold small">Estimated weight (kg) <span class="required-asterisk" aria-hidden="true">*</span></label>
              <input name="estimated_weight" type="number" step="0.1" min="0.1" max="5000" class="form-control<?= isset($fieldErrors['estimated_weight']) ? ' is-invalid' : '' ?>" aria-invalid="<?= isset($fieldErrors['estimated_weight']) ? 'true' : 'false' ?>"<?= isset($fieldErrors['estimated_weight']) ? ' aria-describedby="err-estimated_weight"' : '' ?> name="estimated_weight"<?php if (isset($fieldErrors['estimated_weight'])): ?><div class="invalid-feedback" id="err-estimated_weight"><?= e($fieldErrors['estimated_weight']) ?></div><?php endif; ?>
                     value="<?= e(post_val('estimated_weight', '')) ?>" required>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold small">Pickup date <span class="required-asterisk" aria-hidden="true">*</span></label>
              <input name="preferred_date" type="date" class="form-control<?= isset($fieldErrors['preferred_date']) ? ' is-invalid' : '' ?>" aria-invalid="<?= isset($fieldErrors['preferred_date']) ? 'true' : 'false' ?>"<?= isset($fieldErrors['preferred_date']) ? ' aria-describedby="err-preferred_date"' : '' ?> name="preferred_date" min="<?= date('Y-m-d') ?>"
                     value="<?= e(post_val('preferred_date', date('Y-m-d', strtotime('+1 day')))) ?>" required><?php if (isset($fieldErrors['preferred_date'])): ?><div class="invalid-feedback" id="err-preferred_date"><?= e($fieldErrors['preferred_date']) ?></div><?php endif; ?>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold small">Time slot <span class="required-asterisk" aria-hidden="true">*</span></label>
              <select class="form-select" name="time_slot" required>
                <?php foreach ($slots as $s): ?>
                  <option <?= post_val('time_slot') === $s ? 'selected' : '' ?>><?= $s ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-12">
              <label class="form-label fw-semibold small">Pickup address <span class="required-asterisk" aria-hidden="true">*</span></label>
              <?php if ($addresses): ?>
                <select class="form-select mb-2" id="addrPick">
                  <option value="">— Use a saved address —</option>
                  <?php foreach ($addresses as $i => $a): ?>
                    <option value="<?= $i ?>"><?= e($a['label'] . ' · ' . $a['address_line']) ?></option>
                  <?php endforeach; ?>
                </select>
              <?php endif; ?>
              <input name="address_line" class="form-control<?= isset($fieldErrors['address_line']) ? ' is-invalid' : '' ?>" aria-invalid="<?= isset($fieldErrors['address_line']) ? 'true' : 'false' ?>"<?= isset($fieldErrors['address_line']) ? ' aria-describedby="err-address_line"' : '' ?> name="address_line" id="addrInput" required value="<?= e(post_val('address_line', '')) ?>" placeholder="House / street / area, landmark"><?php if (isset($fieldErrors['address_line'])): ?><div class="invalid-feedback" id="err-address_line"><?= e($fieldErrors['address_line']) ?></div><?php endif; ?>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold small">Ward</label>
              <input class="form-control" name="ward" value="<?= e(post_val('ward', '')) ?>" placeholder="e.g. Ward 12">
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold small">Photo (optional)</label>
              <input type="file" class="form-control" name="image" accept="image/*">
              <div class="form-text">Maximum file size: 5 MB · Supported formats: JPG, PNG, WebP</div>
            </div>
            <div class="col-12">
              <label class="form-label fw-semibold small">Notes for the collector</label>
              <textarea name="notes" class="form-control ? ' is-invalid' : '' ?>" aria-invalid="<?= isset($fieldErrors['notes']) ? 'true' : 'false' ?>"<?= isset($fieldErrors['notes']) ? ' aria-describedby="err-notes"' : '' ?> name="notes" rows="2" maxlength="500"><?= e(post_val('notes', '')) ?></textarea><?php if (isset($fieldErrors['notes'])): ?><div class="invalid-feedback" id="err-notes"><?= e($fieldErrors['notes']) ?></div><?php endif; ?>
            </div>
            <div class="col-12">
              <label class="form-label fw-semibold small">Pin the pickup location <span class="text-muted fw-normal">(click the map — helps routing)</span></label>
              <div id="pickupMap" class="map-box" style="height:280px"></div>
              <div class="row g-2 mt-2">
                <div class="col-4 col-md-3"><input class="form-control form-control-sm" name="latitude" id="latInput" placeholder="Latitude" value="<?= e(post_val('latitude', '')) ?>"></div>
                <div class="col-4 col-md-3"><input class="form-control form-control-sm" name="longitude" id="lngInput" placeholder="Longitude" value="<?= e(post_val('longitude', '')) ?>"></div>
                <div class="col-4 col-md-3"><button type="button" class="btn btn-sm btn-soft w-100" id="btnGeolocate" title="Use my location" aria-label="Use my location to fill coordinates"><i class="bi bi-geo-alt me-1"></i>Use my location</button></div>
              </div>
            </div>
            <div class="col-12 d-flex gap-2">
              <button class="btn btn-pnv px-4"><i class="bi bi-send me-1"></i>Submit Pickup Request</button>
              <a class="btn btn-outline-secondary" href="<?= url('citizen/pickups.php') ?>">My pickups</a>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card mb-3">
      <div class="card-header"><i class="bi bi-lightbulb me-2" style="color:var(--pnv-amber)"></i>Segregation checklist</div>
      <div class="card-body small">
        <div class="form-check mb-2"><input class="form-check-input" type="checkbox" checked disabled><label class="form-check-label">Waste is dry and drained</label></div>
        <div class="form-check mb-2"><input class="form-check-input" type="checkbox" checked disabled><label class="form-check-label">Sharps wrapped; liquids sealed</label></div>
        <div class="form-check mb-2"><input class="form-check-input" type="checkbox" checked disabled><label class="form-check-label">No mixed sanitary waste in dry bags</label></div>
        <div class="form-check"><input class="form-check-input" type="checkbox" checked disabled><label class="form-check-label">Category matches the bin colour</label></div>
        <hr>
        <div class="text-muted">Proper segregation earns <strong>♻️ Real Impact badges</strong> when the pickup is completed and verified.</div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">Time slots</div>
      <div class="card-body small text-muted">
        Pickups are grouped into 3-hour windows. Collectors follow the <strong>Suggested Route</strong> order within their slots.
        You'll get notifications at every status change.
      </div>
    </div>
  </div>
</div>
<?php $pageScripts = '<script>
pnvMap("pickupMap", { clickTarget: { latInput: "latInput", lngInput: "lngInput" }, zoom: 12 });
const addrData = ' . json_encode(array_map(fn($a) => ["lat" => $a["latitude"], "lng" => $a["longitude"], "line" => $a["address_line"], "ward" => $a["ward"]], $addresses)) . ';
document.getElementById("addrPick")?.addEventListener("change", function () {
  const a = addrData[this.value]; if (!a) return;
  document.getElementById("addrInput").value = a.line || "";
  if (a.lat && a.lng) { document.getElementById("latInput").value = a.lat; document.getElementById("lngInput").value = a.lng; }
});
</script>';
require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
