<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN);
$pageTitle = 'My Pickups'; $activeMenu = 'pickups';

// filters
$q      = trim((string) get_val('q', ''));
$status = (string) get_val('status', '');
$where  = 'pr.user_id = ?';
$params = [$user['id']];
if ($q !== '') { $where .= ' AND (pr.pickup_code LIKE ? OR wc.name LIKE ?)'; $params[] = "%$q%"; $params[] = "%$q%"; }
if ($status !== '' && in_array($status, PICKUP_STATUSES, true)) { $where .= ' AND pr.status = ?'; $params[] = $status; }

$total = (int) Database::val("SELECT COUNT(*) FROM pickup_requests pr JOIN waste_categories wc ON wc.id = pr.category_id WHERE $where", $params);
$pg = paginate_request($total);
$rows = Database::all(
    "SELECT pr.*, wc.name AS category_name, wc.color AS category_color, wc.icon AS category_icon,
            u.name AS collector_name, u.phone AS collector_phone
     FROM pickup_requests pr
     JOIN waste_categories wc ON wc.id = pr.category_id
     LEFT JOIN pickup_assignments pa ON pa.pickup_request_id = pr.id
     LEFT JOIN users u ON u.id = pa.collector_id
     WHERE $where ORDER BY pr.created_at DESC LIMIT {$pg['limit']} OFFSET {$pg['offset']}", $params);
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="card">
  <div class="card-header d-flex flex-wrap gap-2 align-items-center">
    <i class="text-pnv bi bi-truck me-1"></i>Pickup Requests
    <span class="badge text-bg-light border"><?= $total ?></span>
    <a class="btn btn-pnv btn-sm ms-auto" href="<?= url('citizen/pickup-create.php') ?>"><i class="bi bi-plus-lg me-1"></i>New request</a>
  </div>
  <div class="card-body">
    <form class="row g-2 mb-3">
      <div class="col-md-5"><input class="form-control form-control-sm" name="q" placeholder="Search code / category…" value="<?= e($q) ?>"></div>
      <div class="col-md-4">
        <select class="form-select form-select-sm" name="status">
          <option value="">All statuses</option>
          <?php foreach (PICKUP_STATUSES as $st): ?>
            <option <?= $status === $st ? 'selected' : '' ?>><?= $st ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3 d-flex gap-2">
        <button class="btn btn-sm btn-pnv px-3">Filter</button>
        <a class="btn btn-sm btn-outline-secondary" href="<?= url('citizen/pickups.php') ?>">Reset</a>
      </div>
    </form>

    <?php if (!$rows): ?>
      <div class="empty-state"><i class="bi bi-inbox"></i><div class="mt-2"><?= t('misc.no_pickups_found') ?></div>
        <a class="btn btn-pnv btn-sm mt-3" href="<?= url('citizen/pickup-create.php') ?>">Create your first pickup request</a></div>
    <?php else: ?>
    <div class="table-responsive">
      <table class="table table-hover align-middle">
        <thead><tr><th>Code</th><th>Category</th><th>Weight</th><th>Scheduled</th><th>Collector</th><th>Status</th><th></th></tr></thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td class="fw-bold"><?= e($r['pickup_code']) ?></td>
              <td><span class="dot" style="background:<?= e($r['category_color']) ?>"></span><?= e($r['category_name']) ?></td>
              <td><?= fmt_kg($r['estimated_weight']) ?></td>
              <td class="small"><?= fmt_dt($r['preferred_date'], 'd M Y') ?><div class="text-muted"><?= e($r['time_slot']) ?></div></td>
              <td class="small"><?= e($r['collector_name'] ?? '—') ?></td>
              <td><?= pickup_badge($r['status']) ?></td>
              <td><a class="btn btn-sm btn-soft" href="<?= url('citizen/pickup-view.php?id=' . (int) $r['id']) ?>">Track</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?= pagination_links($pg) ?>
    <?php endif; ?>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
