<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN);
$pageTitle = 'Waste Scanner'; $activeMenu = 'scanner';

// v2.14.0 — MANUAL scanner (no AI, no external API): upload → preview → user picks the
// category → server validates + saves (source=manual) → Report Waste / Pickup.
$recentScans = Database::all('SELECT * FROM waste_scans WHERE user_id = ? ORDER BY created_at DESC LIMIT 6', [$user['id']]);
$cats = Database::all('SELECT id, name, bin_type, color, is_recyclable, description, recycling_guidance FROM waste_categories WHERE status = "ACTIVE" ORDER BY bin_type, name');
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="row g-4">
  <div class="col-lg-7">
    <div class="card">
      <div class="card-body p-4">
        <div class="d-flex align-items-center gap-2 mb-1">
          <i class="text-pnv bi bi-upc-scan fs-4"></i>
          <h5 class="fw-bold mb-0">Sort your waste correctly</h5>
        </div>
        <p class="text-muted small">Add a photo for your records, then choose the waste category yourself. You know your waste best — PUNARVA never guesses.</p>

        <form id="scanForm" data-api="<?= url('api/citizen/scan.php') ?>">
          <div class="scan-drop" id="scanDrop">
            <i class="text-pnv bi bi-cloud-arrow-up fs-1"></i>
            <div class="fw-bold mt-2">Drag & drop an image here, or click to browse</div>
            <div class="text-muted small">Maximum file size: <?= round(UPLOAD_MAX_BYTES / 1048576) ?> MB · Supported formats: JPG, PNG, WebP</div>
            <input type="file" id="scanImage" accept="image/*" capture="environment" hidden>
            <button type="button" class="btn btn-outline-pnv btn-sm mt-3" onclick="document.getElementById('scanImage').click()">
              <i class="bi bi-camera me-1"></i>Take Photo / Choose from Gallery</button>
          </div>
          <div class="text-center d-none mt-3" id="previewWrap">
            <img id="scanPreview" alt="Selected waste photo preview" style="max-height:260px" class="rounded border">
            <div><button type="button" class="btn btn-sm btn-outline-secondary mt-2" id="scanRemove"><i class="bi bi-x-circle me-1"></i>Remove image</button></div>
          </div>

          <div class="d-none mt-3" id="classifyWrap">
            <div class="border rounded-3 p-3" style="background:var(--bs-tertiary-bg,#f8f9fa)">
              <h6 class="fw-bold mb-1"><i class="text-pnv bi bi-hand-index-thumb me-2"></i>Manual Classification</h6>
              <div class="text-muted small mb-2">You select the category — no automatic guessing.</div>
              <label class="form-label small fw-semibold" for="scanCategory">Waste category <span class="required-asterisk">*</span></label>
              <select class="form-select" id="scanCategory" required>
                <option value="">— Select the waste category —</option>
              </select>
              <div class="d-none mt-3" id="guideWrap">
                <div class="row g-2">
                  <div class="col-sm-4"><div class="p-2 rounded-3 h-100" id="guideCat" style="border:1px solid rgba(0,0,0,.08)"></div></div>
                  <div class="col-sm-4"><div class="p-2 rounded-3 bg-light border h-100"><div class="small text-muted fw-bold text-uppercase">Recommended bin</div><div class="fw-bold small" id="guideBin"></div></div></div>
                  <div class="col-sm-4"><div class="p-2 rounded-3 bg-light border h-100"><div class="small text-muted fw-bold text-uppercase">Recyclable</div><div class="small" id="guideRec"></div></div></div>
                </div>
                <div class="alert alert-light border small mt-2 mb-0" id="guideAdvice"><i class="bi bi-lightbulb text-warning me-1"></i></div>
              </div>
            </div>
            <div class="d-grid mt-3">
              <button class="btn btn-pnv py-2" id="scanSubmit"><i class="bi bi-check2-circle me-1"></i> Confirm & Save Scan</button>
            </div>
            <div class="text-center mt-3 d-none" id="scanLoading">
              <div class="spinner-border text-success spinner-border-sm"></div>
              <span class="small text-muted ms-2">Saving scan…</span>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="card d-none" id="scanResultWrap">
      <div class="card-header">Scan saved</div>
      <div class="card-body scan-result" id="scanResult"></div>
    </div>

    <div class="card mt-3">
      <div class="card-header"><i class="bi bi-clock-history me-2"></i>My recent scans</div>
      <div class="card-body p-0">
        <?php if (!$recentScans): ?>
          <div class="empty-state py-4"><i class="bi bi-camera"></i><div>Your scans will appear here.</div></div>
        <?php else: foreach ($recentScans as $s): ?>
          <div class="notif-item d-flex flex-wrap gap-3 align-items-center">
            <?php if ($s['image_path']): ?>
              <img src="<?= e(upload_url($s['image_path'])) ?>" style="width:52px;height:52px;object-fit:cover" class="rounded" alt="scan">
            <?php endif; ?>
            <div class="flex-grow-1">
              <strong><?= e($s['result_item']) ?></strong>
              <div class="text-muted small"><?= e($s['bin_type']) ?> · recyclable <?= e(ucfirst((string) ($s['recyclable'] ?? 'uncertain'))) ?><?= $s['corrected_category_id'] ? ' · category corrected by you' : '' ?></div>
              <div class="text-muted small"><?= time_ago($s['created_at']) ?></div>
            </div>
            <?php if ($s['status'] === 'failed'): ?><span class="badge text-bg-danger">FAILED</span>
            <?php elseif ($s['status'] === 'corrected'): ?><span class="badge text-bg-info">CORRECTED</span><?php endif; ?>
            <span class="badge text-bg-secondary"><?= e(strtoupper((string) ($s['provider'] ?? 'manual'))) ?></span>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
  </div>
</div>
<?php
$pageScripts = '<script>window.PNV_CATEGORIES = ' . json_encode(array_map(fn($c) => [
    'id' => (int) $c['id'], 'name' => $c['name'], 'bin' => $c['bin_type'], 'color' => $c['color'],
    'rec' => $c['is_recyclable'] === '1' ? 'yes' : 'no', 'advice' => (string) ($c['recycling_guidance'] ?: $c['description']),
], $cats), JSON_UNESCAPED_UNICODE) . ';</script>';
require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
