<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN);
$pageTitle = 'My Waste Passports'; $activeMenu = 'passports';

$q = trim((string) get_val('q', ''));
$stage = (string) get_val('stage', '');
$where = 'wt.source_user_id = ?';
$params = [$user['id']];
if ($q !== '') { $where .= ' AND wt.waste_id LIKE ?'; $params[] = "%$q%"; }
if ($stage !== '' && in_array($stage, WASTE_STAGES, true)) { $where .= ' AND wt.current_stage = ?'; $params[] = $stage; }

$total = (int) Database::val("SELECT COUNT(*) FROM waste_transactions wt WHERE $where", $params);
$pg = paginate_request($total);
$rows = Database::all(
    "SELECT wt.*, wc.name AS category_name, wc.color AS category_color, f.name AS facility_name
     FROM waste_transactions wt
     JOIN waste_categories wc ON wc.id = wt.category_id
     LEFT JOIN facilities f ON f.id = wt.facility_id
     WHERE $where ORDER BY wt.created_at DESC LIMIT {$pg['limit']} OFFSET {$pg['offset']}", $params);
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="card">
  <div class="card-header d-flex align-items-center">
    <i class="text-pnv bi bi-passport me-2"></i>Waste Passports <span class="badge text-bg-light border"><?= $total ?></span>
  </div>
  <div class="card-body">
    <form class="row g-2 mb-3">
      <div class="col-md-5"><input class="form-control form-control-sm" name="q" placeholder="Search Waste ID…" value="<?= e($q) ?>"></div>
      <div class="col-md-4">
        <select class="form-select form-select-sm" name="stage">
          <option value="">All stages</option>
          <?php foreach (WASTE_STAGES as $st): ?><option <?= $stage === $st ? 'selected' : '' ?>><?= $st ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3 d-flex gap-2">
        <button class="btn btn-sm btn-pnv px-3">Filter</button>
        <a class="btn btn-sm btn-outline-secondary" href="<?= url('citizen/passports.php') ?>">Reset</a>
      </div>
    </form>

    <?php if (!$rows): ?>
      <div class="empty-state"><i class="bi bi-passport"></i><div class="mt-2">No Waste Passports yet — complete your first pickup to get one.</div></div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead><tr><th>Waste ID</th><th>Category</th><th>Weight</th><th>Created</th><th>Facility</th><th>Status</th><th></th></tr></thead>
          <tbody>
            <?php foreach ($rows as $r): ?>
              <tr>
                <td class="font-mono fw-bold"><?= e($r['waste_id']) ?></td>
                <td><span class="dot" style="background:<?= e($r['category_color']) ?>"></span><?= e($r['category_name']) ?></td>
                <td><?= fmt_kg($r['current_weight']) ?></td>
                <td class="small"><?= fmt_dt($r['created_at'], 'd M Y') ?></td>
                <td class="small"><?= e($r['facility_name'] ?? '—') ?></td>
                <td><?= waste_badge($r['current_stage']) ?></td>
                <td>
                  <a class="btn btn-sm btn-soft" href="<?= url('citizen/passport-view.php?id=' . (int) $r['id']) ?>">Passport</a>
                  <a class="btn btn-sm btn-outline-secondary" href="<?= url('track.php?id=' . urlencode($r['waste_id'])) ?>" title="Public view"><i class="bi bi-box-arrow-up-right"></i></a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?= pagination_links($pg) ?>
    <?php endif; ?>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
