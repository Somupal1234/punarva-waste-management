<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN);
$pageTitle = 'Waste Reports'; $activeMenu = 'reports';
$categories = Database::all('SELECT * FROM waste_categories WHERE status = "ACTIVE" ORDER BY name');
if (is_post()) {
    try {
        $image = reencode_upload(handle_upload($_FILES['photo'] ?? null, 'reports'), 'reports'); // v2.4.0 server-side re-process
        $code = rand_code('PNVR');
        [$lat, $lng] = val_latlng($_POST);
        // v2.4.0 — GPS capture metadata (sanitised; never trust the client blindly)
        $accRaw = $_POST['accuracy_m'] ?? null;
        $accuracy = ($accRaw !== null && $accRaw !== '' && is_numeric($accRaw)) ? round((float) $accRaw, 2) : null;
        if ($accuracy !== null && ($accuracy < 0 || $accuracy > 10000)) $accuracy = null;
        $capRaw = trim((string) ($_POST['location_captured_at'] ?? ''));
        $capAt = preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $capRaw) ? $capRaw : null;
        $id = Database::insert('waste_reports', [
            'report_code' => $code, 'user_id' => $user['id'],
            'category_id' => (int) post_val('category_id', 0) ?: null,
            'description' => val_str($_POST, 'description', 1000, true, 'Description'),
            'image_path' => $image, 'address_line' => val_str($_POST, 'address_line', 255, true, 'Address'),
            'ward' => val_str($_POST, 'ward', 40, false) ?: null, 'city' => val_str($_POST, 'city', 80, false) ?: (string) setting('default_city', 'Dumka'),
            'latitude' => $lat, 'longitude' => $lng, 'status' => 'SUBMITTED',
            'accuracy_m' => $accuracy, 'location_captured_at' => $capAt,
        ]);
        HotspotService::refreshAsync();
        NotificationService::send((int) $user['id'], 'REPORT', 'Report submitted', 'Your waste report ' . $code . ' was received.', 'waste_report', $id);
        NotificationService::sendToRoles([ROLE_ADMIN], 'REPORT', 'New waste report', $user['name'] . ' reported unmanaged waste (' . $code . ').', 'waste_report', $id);
        flash('success', 'Report ' . $code . ' submitted. You will be notified as it progresses.');
        redirect('citizen/reports.php');
    } catch (Throwable $e) { flash('danger', $e->getMessage()); }
}
$myReports = Database::all(
    'SELECT wr.*, wc.name AS category_name FROM waste_reports wr LEFT JOIN waste_categories wc ON wc.id = wr.category_id
     WHERE wr.user_id = ? ORDER BY wr.created_at DESC LIMIT 50', [$user['id']]);
// ---- v2.2.1: AI-scan prefill (?scan_id=X — sirf APNA completed/corrected scan) ----
$scanPrefill = null;
$scanId = (int) get_val('scan_id', 0);
if ($scanId > 0) {
    $scanPrefill = Database::one(
        'SELECT ws.*, COALESCE(ws.corrected_category_id, ws.category_id) AS final_category_id, wc.name AS category_name
         FROM waste_scans ws LEFT JOIN waste_categories wc ON wc.id = COALESCE(ws.corrected_category_id, ws.category_id)
         WHERE ws.id = ? AND ws.user_id = ? AND ws.status IN ("completed","corrected")', [$scanId, $user['id']]);
    if (!$scanPrefill) $scanPrefill = null; // doosre ka scan / failed scan -> prefill nahi (koi error nahi)
}
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="row g-4">
  <div class="col-lg-5">
    <div class="card">
      <div class="card-body p-4">
        <h5 class="fw-bold mb-1"><i class="text-pnv bi bi-megaphone me-2"></i>Report a garbage hotspot</h5>
        <p class="text-muted small">Verified reports count towards your Real Impact badges and feed hotspot analytics.</p>
        <?php if ($scanPrefill): ?>
        <div class="alert alert-success small py-2"><i class="bi bi-stars me-1"></i>
          Scan #<?= (int) $scanPrefill['id'] ?> loaded — category <strong><?= e($scanPrefill['category_name'] ?? 'Other') ?></strong> and description prefilled.
          Please review and add the photo &amp; location. <a href="<?= url('citizen/scanner.php') ?>">Scan another item</a></div>
        <?php endif; ?>
        <form method="post" enctype="multipart/form-data" novalidate>
          <?= csrf_field() ?>
          <div class="mb-3">
            <label class="form-label fw-semibold small">Waste type</label>
            <select class="form-select" name="category_id"><option value="">General dumping</option>
              <?php foreach ($categories as $c): ?><option value="<?= (int) $c['id'] ?>" <?= ($scanPrefill && (int) $scanPrefill['final_category_id'] === (int) $c['id']) || post_val('category_id') == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3"><label class="form-label fw-semibold small">Description <span class="required-asterisk" aria-hidden="true">*</span></label>
            <textarea class="form-control" name="description" rows="3" required placeholder="What do you see? Since when?"><?=
              $scanPrefill ? e('Scan identified: ' . $scanPrefill['result_item'] . ($scanPrefill['material'] ? ' (' . $scanPrefill['material'] . ')' : '') . '. ') : e(post_val('description', '')) ?></textarea></div>
          <div class="mb-3"><label class="form-label fw-semibold small">Address <span class="required-asterisk" aria-hidden="true">*</span></label>
            <input class="form-control" name="address_line" required placeholder="Street / landmark / area"></div>
          <div class="row g-2 mb-3">
            <div class="col-6"><label class="form-label fw-semibold small">Ward</label><input class="form-control" name="ward" placeholder="Ward 21"></div>
            <div class="col-6"><label class="form-label fw-semibold small">Photo</label>
              <div id="camWrap" class="pnv-camera-wrap d-none mb-2"><video id="camVideo" autoplay playsinline muted></video></div>
              <img id="shotPreview" class="img-fluid rounded border d-none mb-2" style="max-height:200px" alt="Captured waste photo preview">
              <div class="d-flex flex-wrap gap-2 mb-1">
                <button type="button" class="btn btn-sm btn-pnv flex-grow-1" id="btnCamera"><i class="bi bi-camera me-1"></i>TAKE PHOTO</button>
                <button type="button" class="btn btn-sm btn-outline-danger d-none" id="btnRetake"><i class="bi bi-arrow-counterclockwise me-1"></i>Retake</button>
              </div>
              <input type="file" class="form-control" name="photo" id="photoInput" accept="image/*">
              <div class="form-text">Maximum file size: 5 MB · Supported formats: JPG, PNG, WebP. No camera? Choose a photo from your gallery below.</div>
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold small">Location <span class="required-asterisk" aria-hidden="true">*</span> <span class="text-muted small">(pin on map or use your location)</span></label>
            <div id="reportMap" class="map-box" style="height:220px"></div>
            <div class="row g-2 mt-2 align-items-center">
              <div class="col-4"><input class="form-control form-control-sm" name="latitude" id="latInput" placeholder="Latitude" required></div>
              <div class="col-4"><input class="form-control form-control-sm" name="longitude" id="lngInput" placeholder="Longitude" required></div>
              <div class="col-4"><button type="button" class="btn btn-sm btn-soft w-100" id="btnGeolocate" title="Use my location" data-pnv-geo-rich="1"><i class="bi bi-geo-alt me-1"></i>USE MY LOCATION</button></div>
            </div>
            <div id="geoStatus" class="form-text" role="status">Pin the spot on the map, or press USE MY LOCATION.</div>
            <input type="hidden" name="accuracy_m" id="accInput" value="">
            <input type="hidden" name="location_captured_at" id="capInput" value="">
            <input type="hidden" name="city" value="Patna">
          </div>
          <button class="btn btn-pnv w-100"><i class="bi bi-send me-1"></i>Submit Report</button>
        </form>
      </div>
    </div>
  </div>
  <div class="col-lg-7">
    <div class="card">
      <div class="card-header"><i class="text-pnv bi bi-list-check me-2"></i>My Reports (<?= count($myReports) ?>)</div>
      <div class="card-body p-0">
        <?php if (!$myReports): ?>
          <div class="empty-state py-4"><i class="bi bi-megaphone"></i><div><?= t('misc.no_reports') ?></div></div>
        <?php else: foreach ($myReports as $r): ?>
          <div class="notif-item d-flex gap-3 align-items-start">
            <?php if ($r['image_path']): ?><img src="<?= e(upload_url($r['image_path'])) ?>" class="rounded" style="width:56px;height:56px;object-fit:cover" alt=""><?php endif; ?>
            <div class="flex-grow-1">
              <div class="d-flex justify-content-between flex-wrap">
                <strong><?= e($r['report_code']) ?></strong><?= report_badge($r['status']) ?>
              </div>
              <div class="small text-muted"><?= e(mb_strimwidth($r['description'], 0, 90, '…')) ?></div>
              <div class="small text-muted"><i class="bi bi-geo-alt me-1"></i><?= e($r['address_line']) ?><?= $r['ward'] ? ' · ' . e($r['ward']) : '' ?> · <?= time_ago($r['created_at']) ?></div>
              <?php if ($r['resolution_notes']): ?><div class="small mt-1 text-success"><i class="bi bi-check2 me-1"></i><?= e($r['resolution_notes']) ?></div><?php endif; ?>
            </div>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
  </div>
</div>
<?php $pageScripts = '<script>
pnvMap("reportMap", { clickTarget: { latInput: "latInput", lngInput: "lngInput" }, zoom: 12 });
/* ---- v2.4.0 citizen camera: getUserMedia + gallery fallback ---- */
(function () {
  const video = document.getElementById("camVideo"), wrap = document.getElementById("camWrap");
  const btnCam = document.getElementById("btnCamera"), btnRetake = document.getElementById("btnRetake");
  const input = document.getElementById("photoInput"), preview = document.getElementById("shotPreview");
  let stream = null;
  function stopCam() { if (stream) { stream.getTracks().forEach(t => t.stop()); stream = null; } wrap.classList.add("d-none"); }
  function showShot(blob) {
    try { input.files = new DataTransfer().files; } catch (e) {}
    const dt = new DataTransfer(); dt.items.add(new File([blob], "waste-photo.jpg", { type: "image/jpeg" }));
    input.files = dt.files;
    preview.src = URL.createObjectURL(blob);
    preview.classList.remove("d-none"); btnRetake.classList.remove("d-none");
    btnCam.innerHTML = \'<i class="bi bi-camera me-1"></i>TAKE PHOTO\';
  }
  btnCam.addEventListener("click", async function () {
    if (stream) { // second tap = capture
      const c = document.createElement("canvas");
      c.width = video.videoWidth || 640; c.height = video.videoHeight || 480;
      c.getContext("2d").drawImage(video, 0, 0);
      c.toBlob((b) => { if (b) { stopCam(); showShot(b); if (window.pnvToast) pnvToast("Photo captured.", "success"); } }, "image/jpeg", 0.9);
      return;
    }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      if (window.pnvToast) pnvToast("Camera is not supported on this browser. Please upload a photo from your gallery.", "error");
      input.click(); return;
    }
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" }, width: { ideal: 1600 } }, audio: false });
      wrap.classList.remove("d-none"); preview.classList.add("d-none");
      video.srcObject = stream;
      this.innerHTML = \'<i class="bi bi-aperture me-1"></i>CAPTURE\';
    } catch (e) {
      const denied = e && (e.name === "NotAllowedError" || e.name === "SecurityError");
      if (window.pnvToast) pnvToast(denied
        ? "Camera permission is required to take a waste photo. You can also upload a photo from your gallery."
        : "Camera could not be started. Please upload a photo from your gallery.", "error");
      input.click();
    }
  });
  btnRetake.addEventListener("click", () => { input.value = ""; preview.classList.add("d-none"); btnRetake.classList.add("d-none"); });
  input.addEventListener("change", () => {
    if (input.files && input.files[0]) {
      preview.src = URL.createObjectURL(input.files[0]);
      preview.classList.remove("d-none"); btnRetake.classList.remove("d-none");
    }
  });
  window.addEventListener("pagehide", stopCam);
})();
/* ---- v2.4.0 USE MY LOCATION: full state machine, no endless spinner ---- */
(function () {
  const btn = document.getElementById("btnGeolocate");
  const lat = document.getElementById("latInput"), lng = document.getElementById("lngInput");
  const statusEl = document.getElementById("geoStatus"), acc = document.getElementById("accInput"), cap = document.getElementById("capInput");
  const base = statusEl.textContent;
  function done(pos) {
    const la = pos.coords.latitude, lo = pos.coords.longitude;
    if (window.PNV_PINS && window.PNV_PINS.reportMap) window.PNV_PINS.reportMap.setPin(la, lo); // moves marker + fills inputs
    lat.value = la.toFixed(7); lng.value = lo.toFixed(7);
    acc.value = pos.coords.accuracy || ""; cap.value = new Date().toISOString().slice(0, 19).replace("T", " ");
    statusEl.innerHTML = \'<span class="text-success">✔ Location captured</span> (±\' + Math.round(pos.coords.accuracy) + " m). Marker pinned on the map.";
    if (window.pnvMapApi && window.pnvMapApi.pinReport) window.pnvMapApi.pinReport(parseFloat(lat.value), parseFloat(lng.value));
    btn.disabled = false; btn.innerHTML = \'<i class="bi bi-geo-alt me-1"></i>USE MY LOCATION\';
  }
  function fail(e) {
    const M = { 1: "Location permission was denied. Allow it in your browser, or pin the spot on the map manually.",
                2: "Location is currently unavailable. Try again outdoors or pin the spot on the map.",
                3: "Getting your location timed out. Please retry." };
    statusEl.innerHTML = \'<span class="text-danger">\' + (M[e && e.code] || "Location could not be determined. Please pin the spot on the map.") + "</span>";
    btn.disabled = false; btn.innerHTML = \'<i class="bi bi-geo-alt me-1"></i>USE MY LOCATION\';
  }
  btn.addEventListener("click", () => {
    if (!("geolocation" in navigator)) { statusEl.innerHTML = \'<span class="text-danger">Your browser does not support location services. Please use a modern Android/iPhone browser, or pin the spot on the map.</span>\'; return; }
    btn.disabled = true;
    statusEl.innerHTML = \'<span class="spinner-border spinner-border-sm me-1"></span>Getting your location…\';
    navigator.geolocation.getCurrentPosition(done, fail, { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 });
  });
})();
</script>';
require dirname(__DIR__) . '/views/layouts/dash_footer.php';
