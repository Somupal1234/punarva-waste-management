<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN);
$pageTitle = 'Pickup Tracking'; $activeMenu = 'pickups';

$id = (int) get_val('id', 0);
$pickup = Database::one(
    'SELECT pr.*, wc.name AS category_name, wc.color AS category_color, wc.icon AS category_icon, wc.bin_type,
            pa.id AS assignment_id, pa.status AS assignment_status, pa.collector_id,
            cu.name AS collector_name, cu.phone AS collector_phone,
            pa.actual_weight, pa.proof_image, pa.completed_at, pa.remarks, wt.waste_id, wt.id AS tx_id
     FROM pickup_requests pr
     JOIN waste_categories wc ON wc.id = pr.category_id
     LEFT JOIN pickup_assignments pa ON pa.pickup_request_id = pr.id
     LEFT JOIN users cu ON cu.id = pa.collector_id
     LEFT JOIN waste_transactions wt ON wt.pickup_request_id = pr.id
     WHERE pr.id = ?', [$id]);
if (!$pickup) { flash('warning', 'Pickup not found.'); redirect('citizen/pickups.php'); }
OwnershipMiddleware::pickupOwner($pickup, $user);

// journey-like status history from assignment timestamps
$history = [];
if ($pickup['assignment_id']) {
    $a = Database::one('SELECT * FROM pickup_assignments WHERE id = ?', [$pickup['assignment_id']]);
    foreach ([['requested_at', 'REQUESTED'], ['assigned_at', 'ASSIGNED'], ['accepted_at', 'ACCEPTED'],
              ['started_at', 'ON_THE_WAY'], ['arrived_at', 'ARRIVED'], ['collected_at', 'COLLECTED'],
              ['completed_at', 'COMPLETED']] as [$col, $label]) {
        if (!empty($a[$col])) $history[] = ['time' => $a[$col], 'label' => $label];
    }
}
if ($pickup['status'] === 'CANCELLED' && $pickup['cancelled_at']) $history[] = ['time' => $pickup['cancelled_at'], 'label' => 'CANCELLED'];

if (is_post() && post_val('action') === 'cancel') {
    try {
        PickupService::cancel($id, $user, (string) post_val('reason', ''));
        flash('success', 'Pickup cancelled.');
        redirect('citizen/pickups.php');
    } catch (Throwable $e) { flash('danger', $e->getMessage()); redirect('citizen/pickup-view.php?id=' . $id); }
}
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="row g-4">
  <div class="col-lg-7">
    <div class="card mb-3">
      <div class="card-body p-4">
        <div class="d-flex align-items-center gap-3 flex-wrap">
          <?= pnv_cat_badge($pickup['category_icon'], $pickup['category_color'], 48) ?>
          <div>
            <div class="fw-bold fs-5"><?= e($pickup['pickup_code']) ?></div>
            <div class="small text-muted"><?= e($pickup['category_name']) ?> · bin: <?= e($pickup['bin_type']) ?></div>
          </div>
          <div class="ms-auto text-end">
            <?= pickup_badge($pickup['status']) ?>
            <div class="small text-muted mt-1">Requested <?= time_ago($pickup['created_at']) ?></div>
          </div>
        </div>
        <div class="row g-3 mt-3">
          <div class="col-md-4"><div class="small text-muted fw-bold">SCHEDULED</div><div><?= fmt_dt($pickup['preferred_date'], 'D, d M Y') ?><div class="text-muted small"><?= e($pickup['time_slot']) ?></div></div></div>
          <div class="col-md-4"><div class="small text-muted fw-bold">ESTIMATED WEIGHT</div><div><?= fmt_kg($pickup['estimated_weight']) ?></div></div>
          <div class="col-md-4"><div class="small text-muted fw-bold">COLLECTOR</div>
            <div><?= e($pickup['collector_name'] ?? 'Not assigned yet') ?>
              <?php if ($pickup['collector_phone'] && in_array($pickup['status'], ['ACCEPTED','ON_THE_WAY','ARRIVED'], true)): ?>
                <div class="small"><i class="bi bi-telephone me-1"></i><?= e($pickup['collector_phone']) ?></div><?php endif; ?></div></div>
          <div class="col-md-8"><div class="small text-muted fw-bold">ADDRESS</div><div class="small"><?= e($pickup['address_line']) ?><?= $pickup['ward'] ? ' · ' . e($pickup['ward']) : '' ?></div></div>
          <?php if ($pickup['actual_weight']): ?>
            <div class="col-md-4"><div class="small text-muted fw-bold">ACTUAL WEIGHT</div><div><?= fmt_kg($pickup['actual_weight']) ?></div></div>
          <?php endif; ?>
          <?php if ($pickup['notes']): ?>
            <div class="col-12"><div class="small text-muted fw-bold">NOTES</div><div class="small"><?= e($pickup['notes']) ?></div></div>
          <?php endif; ?>
        </div>

        <?php if ($pickup['status'] === 'COMPLETED' && $pickup['waste_id']): ?>
          <div class="alert alert-success mt-3 mb-0 d-flex align-items-center gap-2 flex-wrap">
            <i class="bi bi-passport fs-5"></i>
            <div><strong>Waste Passport issued:</strong> <code><?= e($pickup['waste_id']) ?></code></div>
            <a class="btn btn-sm btn-pnv ms-auto" href="<?= url('citizen/passport-view.php?id=' . (int) $pickup['tx_id']) ?>">Open passport <i class="bi bi-arrow-right"></i></a>
          </div>
        <?php endif; ?>

        <?php if ($pickup['proof_image']): ?>
          <div class="mt-3"><div class="small text-muted fw-bold mb-1">COLLECTION PROOF</div>
            <a href="<?= e(upload_url($pickup['proof_image'])) ?>" target="_blank">
              <img src="<?= e(upload_url($pickup['proof_image'])) ?>" style="height:90px" class="rounded border" alt="proof"></a></div>
        <?php endif; ?>

        <?php if (in_array($pickup['status'], ['REQUESTED','ASSIGNED','ACCEPTED'], true)): ?>
          <form method="post" class="mt-3" data-confirm="Cancel this pickup request?">
            <?= csrf_field() ?><input type="hidden" name="action" value="cancel">
            <button class="btn btn-outline-danger btn-sm"><i class="bi bi-x-circle me-1"></i>Cancel pickup</button>
          </form>
        <?php endif; ?>
      </div>
    </div>

    <?php if ($pickup['latitude'] && $pickup['longitude']): ?>
      <div class="card">
        <div class="card-header">Pickup location</div>
        <div class="card-body">
          <div id="pickupMap" class="map-box" style="height:260px"></div>
        </div>
      </div>
    <?php endif; ?>
  </div>

  <div class="col-lg-5">
    <div class="card">
      <div class="card-header"><i class="text-pnv bi bi-signpost-2 me-2"></i>Status timeline</div>
      <div class="card-body">
        <div class="journey">
          <?php foreach ($history as $h): ?>
            <div class="journey-item done">
              <span class="j-icon"><i class="bi bi-check-lg"></i></span>
              <span class="j-title"><?= e(PICKUP_STATUS_LABELS[$h['label']] ?? $h['label']) ?></span>
              <div class="j-time"><?= fmt_dt($h['time']) ?></div>
            </div>
          <?php endforeach; ?>
          <?php if (!$history): ?>
            <div class="empty-state py-3"><i class="bi bi-hourglass-split"></i><div>Waiting for assignment…</div></div>
          <?php else:
            $last = $history[count($history) - 1]['label'];
            $upcoming = array_slice(array_values(array_diff(['REQUESTED','ASSIGNED','ACCEPTED','ON_THE_WAY','ARRIVED','COLLECTED','COMPLETED'], array_column($history, 'label'))), 0, 3);
            foreach ($upcoming as $u): ?>
              <div class="journey-item">
                <span class="j-icon"><i class="bi bi-circle"></i></span>
                <span class="j-title text-muted"><?= e(PICKUP_STATUS_LABELS[$u]) ?></span><div class="j-time">Pending</div>
              </div>
            <?php endforeach;
          endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $pageScripts = $pickup['latitude'] ? '<script>pnvMap("pickupMap", { center: [' . json_encode((float) $pickup['latitude']) . ',' . json_encode((float) $pickup['longitude']) . '], zoom: 15, markers: [{ lat: ' . json_encode((float) $pickup['latitude']) . ', lng: ' . json_encode((float) $pickup['longitude']) . ', title: ' . json_encode($pickup['pickup_code']) . ', color: "green", glyph: "bi-truck" }] });</script>' : '';
require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
