<?php // quick redirect to public tracking
require_once dirname(__DIR__) . '/includes/init.php';
require_login();
redirect('track.php' . (!empty($_GET['id']) ? '?id=' . urlencode((string) $_GET['id']) : ''));
