<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN, ROLE_BUSINESS, ROLE_COLLECTOR, ROLE_RECYCLER, ROLE_ADMIN); // v2.4.4: shared account page also serves the admin wrapper
$pageTitle = 'Profile & Settings'; $activeMenu = 'profile';
$roleBase = $user['role_code'] . '/';

if (is_post()) {
    try {
        $action = post_val('action');
        if ($action === 'profile') {
            $name = val_str($_POST, 'name', 120, true, null, 2);
            $phone = val_phone($_POST, 'phone', true);
            $avatar = handle_upload($_FILES['avatar'] ?? null, 'profiles');
            $data = ['name' => $name, 'phone' => $phone, 'language' => in_array(post_val('language'), ['en','hi','bn'], true) ? post_val('language') : 'en'];
            // changing the mobile number invalidates any previous verification (format-valid ≠ verified)
            $cur = Database::one('SELECT phone, phone_verified FROM users WHERE id = ?', [$user['id']]);
            if ($phone !== (string) ($cur['phone'] ?? '')) { $data['phone_verified'] = 0; $data['phone_verified_at'] = null; }
            if ($avatar) $data['avatar_path'] = $avatar;
            Database::update('users', $data, 'id = ?', [$user['id']]);
            $_SESSION['user']['name'] = $name;
            AuditService::log('PROFILE_UPDATED', 'account', (int) $user['id']);
            flash('success', 'Profile updated.');
        } elseif ($action === 'password') {
            $cur = (string) post_val('current_password', '');
            $new = (string) post_val('new_password', '');
            $conf = (string) post_val('confirm_password', '');
            $row = Database::one('SELECT password_hash FROM users WHERE id = ?', [$user['id']]);
            if (!password_verify($cur, $row['password_hash'])) throw new InvalidArgumentException('Current password is incorrect.');
            if ($err = AuthService::policyError($new)) throw new InvalidArgumentException($err);
            if ($new !== $conf) throw new InvalidArgumentException('Password confirmation does not match.');
            Database::update('users', ['password_hash' => password_hash($new, PASSWORD_DEFAULT)], 'id = ?', [$user['id']]);
            SessionRegistry::revokeOthers((int) $user['id'], session_id()); // other devices must log in again
            AuditService::log('PASSWORD_CHANGED', 'account', (int) $user['id']);
            flash('success', 'Password changed successfully.');
        } elseif ($action === 'request_otp') {
            $out = VerificationService::requestMobileOtp($user);
            if ($out === 'NOT_CONFIGURED') flash('warning', t('verify.mobile_not_configured'));
            elseif (setting('sms_provider') === 'log') flash('info', t('verify.otp_generated_dev'));
            else flash('success', t('verify.otp_sent'));
        } elseif ($action === 'verify_otp') {
            VerificationService::verifyMobileOtp($user, (string) post_val('otp_code', ''));
            flash('success', t('verify.mobile_verified_ok'));
        } elseif ($action === 'request_email_verify') {
            $out = VerificationService::requestEmailVerification($user);
            if ($out === 'NOT_CONFIGURED') flash('warning', t('verify.email_not_configured'));
            elseif (setting('email_verification_provider') === 'log') flash('info', t('verify.email_link_dev'));
            else flash('success', t('verify.email_link_sent'));
        } elseif ($action === 'add_address') {
            [$lat, $lng] = val_latlng($_POST);
            Database::insert('addresses', [
                'user_id' => $user['id'], 'label' => val_str($_POST, 'label', 40, false) ?: 'Address',
                'address_line' => val_str($_POST, 'address_line', 255, true, 'Address'),
                'city' => val_str($_POST, 'city', 80, false) ?: (string) setting('default_city', 'Dumka'), 'state' => 'Bihar',
                'ward' => val_str($_POST, 'ward', 40, false) ?: null,
                'latitude' => $lat, 'longitude' => $lng,
                'is_default' => (int) Database::val('SELECT COUNT(*) FROM addresses WHERE user_id = ?', [$user['id']]) === 0 ? 1 : 0,
            ]);
            flash('success', 'Address saved.');
        } elseif ($action === 'delete_address') {
            Database::run('DELETE FROM addresses WHERE id = ? AND user_id = ?', [(int) post_val('address_id'), $user['id']]);
            flash('success', 'Address removed.');
        }
        redirect($roleBase . 'profile.php');
    } catch (Throwable $e) { flash('danger', $e->getMessage()); redirect($roleBase . 'profile.php'); }
}

$profile = Database::one('SELECT * FROM users WHERE id = ?', [$user['id']]);
$addresses = Database::all('SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC, id DESC', [$user['id']]);
$org = $user['organization_id'] ? Database::one('SELECT * FROM organizations WHERE id = ?', [$user['organization_id']]) : null;
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="row g-4">
  <div class="col-lg-5">
    <div class="card mb-3">
      <div class="card-body p-4 text-center">
        <?php if ($profile['avatar_path']): ?>
          <img src="<?= e(upload_url($profile['avatar_path'])) ?>" class="rounded-circle mb-2" style="width:84px;height:84px;object-fit:cover" alt="">
        <?php else: ?><span class="avatar mb-2" style="width:84px;height:84px;font-size:1.6rem"><?= e(initials($profile['name'])) ?></span><?php endif; ?>
        <h5 class="fw-bold mb-0"><?= e($profile['name']) ?></h5>
        <div class="text-muted small"><?= e($profile['email']) ?></div>
        <span class="badge text-bg-success mt-2"><?= e(ROLE_LABELS[$user['role_code']]) ?></span>
        <div class="small text-muted mt-2">Member since <?= fmt_dt($profile['created_at'], 'M Y') ?> · last login <?= time_ago($profile['last_login_at']) ?></div>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><i class="bi bi-shield-lock me-2"></i>Change password</div>
      <div class="card-body p-4">
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="password">
          <label class="form-label small fw-semibold" for="curPass">Current password <span class="required-asterisk" aria-hidden="true">*</span></label>
          <input type="password" id="curPass" class="form-control mb-2" name="current_password" placeholder="Current password" required autocomplete="current-password">
          <label class="form-label small fw-semibold" for="newPass">New password <span class="required-asterisk" aria-hidden="true">*</span></label>
          <input type="password" id="newPass" class="form-control mb-2" name="new_password" placeholder="New password (min 8 chars)" minlength="8" required autocomplete="new-password">
          <label class="form-label small fw-semibold" for="confPass">Confirm new password <span class="required-asterisk" aria-hidden="true">*</span></label>
          <input type="password" id="confPass" class="form-control mb-3" name="confirm_password" placeholder="Confirm new password" required autocomplete="new-password">
          <button class="btn btn-pnv w-100">Update password</button>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-7">
    <div class="card mb-3">
      <div class="card-header"><i class="bi bi-person-gear me-2"></i>Profile details</div>
      <div class="card-body p-4">
        <form method="post" enctype="multipart/form-data"><?= csrf_field() ?><input type="hidden" name="action" value="profile">
          <div class="row g-3">
            <div class="col-md-7"><label class="form-label fw-semibold small"><?= t('verify.full_name_label') ?> <span class="required-asterisk" aria-hidden="true">*</span></label><input class="form-control" name="name" value="<?= e($profile['name']) ?>" required minlength="2" maxlength="120"></div>
            <div class="col-md-5"><label class="form-label fw-semibold small"><?= t('common.phone') ?> <span class="required-asterisk" aria-hidden="true">*</span></label><input class="form-control" name="phone" value="<?= e($profile['phone']) ?>" required inputmode="tel" pattern="(\+91[\s-]?|0)?[6-9][0-9]{9}" maxlength="13" aria-required="true">
              <div class="form-text small"><?= t('val.phone_hint') ?></div></div>
            <div class="col-md-6"><label class="form-label fw-semibold small">Preferred language</label>
              <select class="form-select" name="language">
                <option value="en" <?= $profile['language'] === 'en' ? 'selected' : '' ?>>English</option>
                <option value="hi" <?= $profile['language'] === 'hi' ? 'selected' : '' ?>>हिन्दी</option>
                <option value="bn" <?= $profile['language'] === 'bn' ? 'selected' : '' ?>>বাংলা</option>
              </select></div>
            <div class="col-md-6"><label class="form-label fw-semibold small">Profile photo</label><input type="file" class="form-control" name="avatar" accept="image/*">
              <div class="form-text">Maximum file size: 5 MB · Supported formats: JPG, PNG, WebP</div></div>
            <?php if ($org): ?>
              <div class="col-12"><div class="alert alert-light border small mb-0"><i class="bi bi-bank me-1"></i>
                Organization: <strong><?= e($org['name']) ?></strong> (<?= e($org['org_type']) ?>) · status: <?= e($org['status']) ?></div></div>
            <?php endif; ?>
            <div class="col-12"><button class="btn btn-pnv"><i class="bi bi-check2 me-1"></i>Save changes</button></div>
          </div>
        </form>
      </div>
    </div>

    <?php $smsOn = VerificationService::smsConfigured(); $emailOn = VerificationService::emailConfigured(); ?>
    <div class="card mb-3">
      <div class="card-header"><i class="bi bi-patch-check me-2"></i><?= t('verify.title') ?></div>
      <div class="card-body p-4">
        <div class="row g-3">
          <div class="col-md-6">
            <div class="border rounded-3 p-3 h-100 d-flex flex-column">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="fw-semibold small"><i class="bi bi-phone me-1"></i><?= t('common.phone') ?></span>
                <?php if ((int) $profile['phone_verified'] === 1): ?>
                  <span class="badge text-bg-success"><?= t('verify.badge_verified') ?></span>
                <?php else: ?>
                  <span class="badge text-bg-secondary"><?= t('verify.badge_unverified') ?></span>
                <?php endif; ?>
              </div>
              <div class="small text-muted mb-2"><?= e($profile['phone'] ?: '—') ?> · <?= (int) $profile['phone_verified'] === 1 ? t('verify.mobile_verified_ok') : t('verify.mobile_unverified_note') ?></div>
              <?php if ($smsOn): ?>
                <form method="post" class="mb-2"><?= csrf_field() ?><input type="hidden" name="action" value="request_otp">
                  <button class="btn btn-sm btn-soft"><?= t('verify.send_otp') ?></button></form>
                <form method="post" class="d-flex gap-2 mt-auto"><?= csrf_field() ?><input type="hidden" name="action" value="verify_otp">
                  <input class="form-control form-control-sm" name="otp_code" inputmode="numeric" pattern="\d{6}" maxlength="6" autocomplete="one-time-code" placeholder="<?= t('verify.otp_placeholder') ?>" aria-label="<?= t('verify.otp_placeholder') ?>" required>
                  <button class="btn btn-sm btn-pnv"><?= t('verify.btn_verify') ?></button></form>
              <?php else: ?>
                <div class="alert alert-light border small mb-0 mt-auto"><?= t('verify.mobile_not_configured') ?></div>
              <?php endif; ?>
            </div>
          </div>
          <div class="col-md-6">
            <div class="border rounded-3 p-3 h-100 d-flex flex-column">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="fw-semibold small"><i class="bi bi-envelope me-1"></i><?= t('verify.email_label') ?></span>
                <?php if ((int) $profile['email_verified'] === 1): ?>
                  <span class="badge text-bg-success"><?= t('verify.badge_verified') ?></span>
                <?php else: ?>
                  <span class="badge text-bg-secondary"><?= t('verify.badge_unverified') ?></span>
                <?php endif; ?>
              </div>
              <div class="small text-muted mb-2"><?= e($profile['email']) ?> · <?= (int) $profile['email_verified'] === 1 ? t('verify.email_verified_ok') : t('verify.email_unverified_note') ?></div>
              <?php if ($emailOn): ?>
                <form method="post" class="mt-auto"><?= csrf_field() ?><input type="hidden" name="action" value="request_email_verify">
                  <button class="btn btn-sm btn-soft"><?= t('verify.send_email_link') ?></button></form>
              <?php else: ?>
                <div class="alert alert-light border small mb-0 mt-auto"><?= t('verify.email_not_configured') ?></div>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <div class="small text-muted mt-3"><i class="bi bi-info-circle me-1"></i><?= t('verify.format_note') ?></div>
      </div>
    </div>

    <?php if ($user['role_code'] !== 'recycler'): ?>
    <div class="card">
      <div class="card-header"><i class="bi bi-geo me-2"></i>Saved addresses</div>
      <div class="card-body p-4">
        <?php if ($addresses): ?>
          <div class="row g-3 mb-3">
            <?php foreach ($addresses as $a): ?>
              <div class="col-md-6">
                <div class="card h-100 border"><div class="card-body p-3">
                  <div class="d-flex justify-content-between">
                    <span class="badge text-bg-light border mb-1"><?= e($a['label']) ?><?= $a['is_default'] ? ' · default' : '' ?></span>
                    <form method="post" data-confirm="Delete this address?"><?= csrf_field() ?>
                      <input type="hidden" name="action" value="delete_address"><input type="hidden" name="address_id" value="<?= (int) $a['id'] ?>">
                      <button class="btn btn-sm btn-link text-danger p-0"><i class="bi bi-trash"></i></button></form>
                  </div>
                  <div class="small"><?= e($a['address_line']) ?></div>
                  <div class="small text-muted"><?= e($a['city']) ?><?= $a['ward'] ? ' · ' . e($a['ward']) : '' ?></div>
                </div></div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        <form method="post" class="row g-2"><?= csrf_field() ?><input type="hidden" name="action" value="add_address">
          <div class="col-md-4"><input class="form-control form-control-sm" name="label" placeholder="Label (Home/Office)" aria-label="Address label"></div>
          <div class="col-md-8"><label class="form-label small fw-semibold mb-1" for="addrLine">Address line <span class="required-asterisk" aria-hidden="true">*</span></label><input class="form-control form-control-sm" id="addrLine" name="address_line" placeholder="Street / landmark / area" required></div>
          <div class="col-4 col-md-3"><input class="form-control form-control-sm" name="ward" placeholder="Ward"></div>
          <div class="col-4 col-md-3"><input class="form-control form-control-sm" name="city" placeholder="City" value="Patna"></div>
          <div class="col-2 col-md-2"><input class="form-control form-control-sm" name="latitude" id="latInput" placeholder="Lat"></div>
          <div class="col-2 col-md-2"><input class="form-control form-control-sm" name="longitude" id="lngInput" placeholder="Lng"></div>
          <div class="col-12"><button class="btn btn-soft btn-sm"><i class="bi bi-plus-lg me-1"></i>Add address</button></div>
        </form>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php $pageScripts = '<script src="' . asset_url('assets/js/password-toggle.js') . '" defer></script>'; // v2.1.9: same eye standard as login/register on change-password fields ?>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
