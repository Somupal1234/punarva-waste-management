<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN);
$pageTitle = 'Waste Passport'; $activeMenu = 'passports';

$id = (int) get_val('id', 0);
$tx = Database::one(
    'SELECT wt.*, wc.name AS category_name, wc.code AS category_code, wc.color AS category_color, wc.bin_type, wc.recycling_guidance,
            f.name AS facility_name, f.city AS facility_city, f.facility_type, f.latitude AS facility_lat, f.longitude AS facility_lng
     FROM waste_transactions wt
     JOIN waste_categories wc ON wc.id = wt.category_id
     LEFT JOIN facilities f ON f.id = wt.facility_id
     WHERE wt.id = ?', [$id]);
if (!$tx || (int) $tx['source_user_id'] !== (int) $user['id']) {
    flash('warning', 'Passport not found or not owned by you.');
    redirect('citizen/passports.php');
}
$events = WasteJourneyService::timeline((int) $tx['id']);
$impact = ImpactService::forTransaction((int) $tx['id']);
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="row g-4">
  <div class="col-lg-5">
    <div class="passport">
      <div class="passport-head">
        <div class="passport-stamp">
          <i class="bi <?= in_array($tx['final_outcome'], ['RECYCLED','RECOVERED','COMPOSTED','REUSED'], true) ? 'bi-patch-check-fill' : 'bi-hourglass-split' ?>"></i>
          <span><?= e(in_array($tx['final_outcome'], ['RECYCLED','RECOVERED','COMPOSTED','REUSED'], true) ? 'Verified' : 'In progress') ?></span>
        </div>
        <div class="passport-title">Waste Passport</div>
        <div class="passport-waste-id mt-2"><?= e($tx['waste_id']) ?></div>
        <div class="small mt-2 opacity-75">Issued <?= fmt_dt($tx['created_at'], 'd M Y') ?></div>
      </div>
      <div class="passport-body">
        <div class="passport-meta">
          <div><div class="meta-label">Category</div><div class="meta-value"><span class="dot" style="background:<?= e($tx['category_color']) ?>"></span><?= e($tx['category_name']) ?></div></div>
          <div><div class="meta-label">Weight</div><div class="meta-value"><?= fmt_kg($tx['current_weight']) ?></div></div>
          <div><div class="meta-label">Current Status</div><div class="meta-value"><?= waste_badge($tx['current_stage']) ?></div></div>
          <div><div class="meta-label">Origin</div><div class="meta-value">Citizen<?= $tx['ward'] ? ' · ' . e($tx['ward']) : '' ?></div></div>
          <div><div class="meta-label">Facility</div><div class="meta-value"><?= e($tx['facility_name'] ?? 'Pending') ?></div></div>
          <div><div class="meta-label">Final Outcome</div><div class="meta-value"><?= $tx['final_outcome'] ? waste_badge($tx['final_outcome']) : '—' ?></div></div>
        </div>
        <?php if ($impact): ?>
          <div class="alert alert-success small mt-3 mb-0">
            <strong><i class="bi bi-globe-americas me-1"></i>Estimated environmental impact</strong>
            <div class="row text-center mt-2 g-2">
              <div class="col-4"><div class="fw-bold"><?= number_format((float) $impact['co2_saved_kg'], 2) ?> kg</div><div class="fs-tiny text-muted">CO₂e avoided</div></div>
              <div class="col-4"><div class="fw-bold"><?= number_format((float) $impact['water_saved_l'], 0) ?> L</div><div class="fs-tiny text-muted">water saved</div></div>
              <div class="col-4"><div class="fw-bold"><?= number_format((float) $impact['energy_saved_kwh'], 2) ?></div><div class="fs-tiny text-muted">kWh saved</div></div>
            </div>
          </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center mt-3">
          <div class="small text-muted">Public QR tracking<br><span class="badge text-bg-light border mt-1"><i class="bi bi-shield-lock me-1"></i>Private data never exposed</span></div>
          <div class="text-center">
            <?php if ((string) setting('qr_enabled', '1') === '1'): ?>
            <div class="qr-box" data-qr="<?= e(absolute_url('track.php?id=' . urlencode($tx['waste_id']))) ?>" data-size="116"></div>
<?php else: ?>
            <div class="text-muted small"><i class="bi bi-qr-code me-1"></i>QR generation is currently disabled by the administrator.</div>
<?php endif; ?>
            <a class="btn btn-sm btn-soft mt-2" href="<?= url('track.php?id=' . urlencode($tx['waste_id'])) ?>"><i class="bi bi-box-arrow-up-right me-1"></i>Public page</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-7">
    <div class="card mb-3">
      <div class="card-header"><i class="text-pnv bi bi-signpost-2 me-2"></i>Journey Timeline</div>
      <div class="card-body">
        <?php view('components/passport_timeline', ['events' => $events, 'tx' => $tx, 'public' => false]); ?>
      </div>
    </div>
    <?php if ($tx['latitude']): ?>
      <div class="card">
        <div class="card-header">Origin & facility</div>
        <div class="card-body">
          <div id="passportMap" class="map-box" style="height:260px"></div>
        </div>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php $pageScripts = $tx['latitude'] ? '<script>
pnvMap("passportMap", { fitAll: true, zoom: 12, markers: [
  { lat: ' . json_encode((float) $tx['latitude']) . ', lng: ' . json_encode((float) $tx['longitude']) . ', title: "Origin", color: "amber", glyph: "bi-house" }
  ' . ($tx['facility_lat'] ? ', { lat: ' . json_encode((float) $tx['facility_lat']) . ', lng: ' . json_encode((float) $tx['facility_lng']) . ', title: ' . json_encode($tx['facility_name']) . ', color: "teal", glyph: "bi-buildings" }' : '') . '
]});
</script>' : '';
require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
