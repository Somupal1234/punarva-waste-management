<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN);
$pageTitle = 'Environmental Impact'; $activeMenu = 'impact';
$summary = ImpactService::summaryForUser((int) $user['id']);
$eq = ImpactService::equivalents($summary);
$byCategory = Database::all(
  'SELECT wc.name, wc.color, SUM(ei.co2_saved_kg) AS co2, SUM(ei.quantity) AS qty
   FROM environmental_impacts ei
   JOIN waste_transactions wt ON wt.id = ei.waste_transaction_id
   JOIN waste_categories wc ON wc.id = wt.category_id
   WHERE wt.source_user_id = ? GROUP BY wt.category_id ORDER BY co2 DESC', [$user['id']]);
$monthly = Database::all(
  'SELECT DATE_FORMAT(wt.created_at, "%b %y") AS ym, SUM(ei.co2_saved_kg) AS co2
   FROM environmental_impacts ei JOIN waste_transactions wt ON wt.id = ei.waste_transaction_id
   WHERE wt.source_user_id = ? GROUP BY ym ORDER BY MIN(wt.created_at) LIMIT 12', [$user['id']]);
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="row g-3 mb-4">
  <?php $cards = [
    ['kpi-violet','bi-cloud-arrow-down', number_format((float) $summary['co2'],1).' kg','EST. CO₂e AVOIDED'],
    ['kpi-blue','bi-droplet', fmt_num($summary['water']).' L','EST. WATER SAVED'],
    ['kpi-teal','bi-lightning-charge', number_format((float) $summary['energy'],1).' kWh','EST. ENERGY SAVED'],
    ['kpi-green','bi-recycle', fmt_kg($summary['diverted'] ?: $summary['qty']),'EST. DIVERTED FROM DUMP'],
  ];
  foreach ($cards as [$c,$i,$v,$l]): ?>
    <div class="col-6 col-lg-3"><div class="kpi-card <?= $c ?> p-3">
      <i class="bi <?= $i ?> kpi-icon"></i><div class="kpi-value"><?= $v ?></div><div class="kpi-label"><?= e($l) ?></div>
      <div class="small opacity-75 mt-1">Estimated impact — <?= e(METHODOLOGY_VERSION) ?></div></div></div>
  <?php endforeach; ?>
</div>
<div class="alert alert-light border small">
  <i class="bi bi-info-circle me-1"></i><strong>About these numbers:</strong> Estimated Impact = waste quantity × configured impact factor
  (methodology <?= e(METHODOLOGY_VERSION) ?>). They are indicative estimates for awareness, not measured outcomes.
</div>
<div class="row g-4">
  <div class="col-lg-6"><div class="chart-card h-100">
    <div class="chart-head"><h2 class="chart-title"><i class="bi bi-bar-chart-line"></i>By waste category</h2><span class="chart-sub">kg CO₂e avoided</span></div>
    <div class="pnv-chart pnv-chart-md">
    <?php if ($byCategory): ?><canvas id="catChart" role="img" aria-label="Bar chart: estimated CO2e avoided by waste category"></canvas>
    <?php else: ?><div class="chart-empty"><i class="bi bi-bar-chart"></i><div>Impact appears after your waste completes recycling.</div></div><?php endif; ?>
    </div>
  </div></div>
  <div class="col-lg-6"><div class="chart-card h-100">
    <div class="chart-head"><h2 class="chart-title"><i class="bi bi-graph-up"></i>Monthly trend</h2><span class="chart-sub">kg CO₂e avoided</span></div>
    <div class="pnv-chart pnv-chart-md">
    <?php if ($monthly): ?><canvas id="monthChart" role="img" aria-label="Area chart: estimated CO2e avoided per month"></canvas>
    <?php else: ?><div class="chart-empty"><i class="bi bi-graph-up"></i><div><?= t('misc.no_trend') ?></div></div><?php endif; ?>
    </div>
  </div></div>
</div>
<div class="row g-3 mt-1">
  <div class="col-md-4"><div class="card"><div class="card-body text-center">
    <div style="font-size:2rem">🌳</div><div class="fs-4 fw-bold"><?= e($eq['trees']) ?></div>
    <div class="small text-muted">tree-years of carbon absorbed (equivalent)</div></div></div></div>
  <div class="col-md-4"><div class="card"><div class="card-body text-center">
    <div style="font-size:2rem">🚗</div><div class="fs-4 fw-bold"><?= fmt_num($eq['car_km']) ?> km</div>
    <div class="small text-muted">of average car emissions offset (equivalent)</div></div></div></div>
  <div class="col-md-4"><div class="card"><div class="card-body text-center">
    <div style="font-size:2rem">📱</div><div class="fs-4 fw-bold"><?= fmt_num($eq['phone']) ?></div>
    <div class="small text-muted">smartphone charges of energy saved (equivalent)</div></div></div></div>
</div>
<?php $pageScripts = '<script>
if (document.getElementById("catChart")) PNV_CHART.bars("catChart", { labels: ' . json_encode(array_column($byCategory, 'name')) . ', suffix: "",
  series: [{ label: "CO₂e avoided", data: ' . json_encode(array_map(fn($r) => round((float) $r['co2'], 2), $byCategory)) . ', colors: ' . json_encode(array_column($byCategory, 'color')) . ' }] });
if (document.getElementById("monthChart")) PNV_CHART.area("monthChart", { labels: ' . json_encode(array_column($monthly, 'ym')) . ', suffix: "",
  series: [{ label: "CO₂e avoided", data: ' . json_encode(array_map(fn($r) => round((float) $r['co2'], 2), $monthly)) . ', color: "#0e7a4f" }] });
</script>';
require dirname(__DIR__) . '/views/layouts/dash_footer.php';
