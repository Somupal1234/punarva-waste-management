<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN);
$pageTitle = 'My Dashboard'; $activeMenu = 'dash';

// ---- KPIs (all live from DB) ----
$kpi = [
    'submitted' => (float) (Database::val('SELECT COALESCE(SUM(estimated_weight),0) FROM pickup_requests WHERE user_id = ? AND status <> "CANCELLED"', [$user['id']])),
    'completed' => (int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE user_id = ? AND status = "COMPLETED"', [$user['id']]),
    'recycled'  => (float) (Database::val('SELECT COALESCE(SUM(wt.current_weight),0) FROM waste_transactions wt WHERE wt.source_user_id = ? AND wt.final_outcome IN ("RECYCLED","RECOVERED","COMPOSTED","REUSED")', [$user['id']])),
    'verified'  => BadgeService::verifiedActivities((int) $user['id']),
];
$impact = ImpactService::summaryForUser((int) $user['id']);
$eq = ImpactService::equivalents($impact);
$badgeCounts = BadgeService::counts((int) $user['id']);
$totalBadges = (int) Database::val('SELECT COUNT(*) FROM badges WHERE is_active = 1');
$recentBadges = array_slice(BadgeService::forUser((int) $user['id']), 0, 3);
$rankData = BadgeService::ranking((int) $user['id'], 5);

// active pickup (in-flight)
$activePickup = Database::one(
    'SELECT pr.*, wc.name AS category_name, wc.icon AS category_icon, wc.color AS category_color,
            u.name AS collector_name, u.phone AS collector_phone, pa.status AS assignment_status
     FROM pickup_requests pr
     JOIN waste_categories wc ON wc.id = pr.category_id
     LEFT JOIN pickup_assignments pa ON pa.pickup_request_id = pr.id
     LEFT JOIN users u ON u.id = pa.collector_id
     WHERE pr.user_id = ? AND pr.status IN ("REQUESTED","ASSIGNED","ACCEPTED","ON_THE_WAY","ARRIVED","COLLECTED")
     ORDER BY pr.created_at DESC LIMIT 1', [$user['id']]);

$latestPassport = Database::one(
    'SELECT wt.*, wc.name AS category_name, wc.color AS category_color
     FROM waste_transactions wt JOIN waste_categories wc ON wc.id = wt.category_id
     WHERE wt.source_user_id = ? ORDER BY wt.created_at DESC LIMIT 1', [$user['id']]);

$recentNotifications = NotificationService::listFor((int) $user['id'], 6);
$unread = NotificationService::unreadCount((int) $user['id']);

// category mix chart (own waste)
$mix = Database::all(
    'SELECT wc.name, wc.color, COALESCE(SUM(pr.estimated_weight),0) AS total
     FROM pickup_requests pr JOIN waste_categories wc ON wc.id = pr.category_id
     WHERE pr.user_id = ? AND pr.status <> "CANCELLED"
     GROUP BY pr.category_id ORDER BY total DESC LIMIT 6', [$user['id']]);

require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="row g-3 mb-4">
  <?php
  $cards = [
      ['kpi-green', 'bi-trash3', fmt_kg($kpi['submitted']), 'TOTAL WASTE SUBMITTED', 'Across ' . (int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE user_id = ? AND status <> "CANCELLED"', [$user['id']]) . ' pickups'],
      ['kpi-blue', 'bi-check2-circle', fmt_num($kpi['completed']), 'COMPLETED PICKUPS', 'Collected & verified'],
      ['kpi-teal', 'bi-recycle', fmt_kg($kpi['recycled']), 'WASTE RECYCLED', 'Final outcome recorded'],
      ['kpi-amber', 'bi-patch-check', fmt_num($kpi['verified']), 'VERIFIED ACTIVITIES', 'Completed pickups + verified reports'],
      ['kpi-violet', 'bi-cloud-arrow-down', number_format((float) $impact['co2'], 1) . ' kg', 'EST. CO₂e AVOIDED', 'Estimated impact'],
  ];
  foreach ($cards as [$color, $icon, $value, $label, $sub]): ?>
    <div class="col-6 col-md-4 col-xl">
      <div class="kpi-card <?= $color ?> p-3 h-100">
        <i class="bi <?= $icon ?> kpi-icon"></i>
        <div class="kpi-value"><?= $value ?></div>
        <div class="kpi-label"><?= e($label) ?></div>
        <div class="small opacity-75 mt-1"><?= e($sub) ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="row g-3 mb-1">
  <!-- MY BADGES -->
  <div class="col-md-6 col-xl-7">
    <div class="card h-100">
      <div class="card-header d-flex align-items-center"><i class="text-pnv bi bi-patch-check me-2"></i><?= e(t('badge.my_badges')) ?>
        <a class="btn btn-sm btn-soft ms-auto" href="<?= url('citizen/badges.php') ?>"><?= e(t('badge.view_all')) ?></a>
      </div>
      <div class="card-body">
        <div class="small text-muted mb-2"><?= e(t('badge.ach_sub')) ?></div>
        <div class="d-flex align-items-center gap-2 mb-1">
          <span class="ach-earned-count"><i class="bi bi-patch-check-fill text-pnv me-1"></i><?= e(t('badge.earned')) ?> <strong><?= (int) $badgeCounts['total'] ?></strong> / <?= (int) $totalBadges ?></span>
        </div>
        <div class="progress ach-progress mb-3" role="progressbar" aria-label="<?= e(t('badge.earned')) ?> <?= (int) $badgeCounts['total'] ?> / <?= (int) $totalBadges ?>" aria-valuemin="0" aria-valuemax="<?= (int) $totalBadges ?>" aria-valuenow="<?= (int) $badgeCounts['total'] ?>">
          <div class="progress-bar bg-success" style="width: <?= $totalBadges ? round($badgeCounts['total'] / $totalBadges * 100) : 0 ?>%"></div>
        </div>
        <?php if ($recentBadges): foreach ($recentBadges as $rb): ?>
          <div class="d-flex align-items-center gap-2 py-1">
            <?= badge_icon_svg($rb['icon'], ['size' => 34, 'title' => $rb['name']]) ?>
            <div class="small"><span class="fw-bold"><?= e($rb['name']) ?></span>
              <span class="ach-cat ach-cat-impact ms-1"><?= e(t('badge.category.real_impact')) ?></span>
              <div class="text-muted" style="font-size:.7rem"><?= e(time_ago($rb['awarded_at'])) ?></div>
            </div>
          </div>
        <?php endforeach; else: ?>
          <div class="empty-state py-2"><i class="bi bi-patch-check"></i><div class="small fw-semibold"><?= e(t('badge.empty_title')) ?></div><div class="small text-muted"><?= e(t('badge.empty_sub')) ?></div></div>
        <?php endif; ?>
      </div>
    </div>
  </div>


  <!-- COMMUNITY IMPACT RANKING -->
  <div class="col-xl-5">
    <div class="card h-100">
      <div class="card-header d-flex align-items-center"><i class="text-pnv bi bi-trophy me-2"></i><?= e(t('rank.title')) ?>
        <span class="ms-auto small text-muted" id="rankUpdated" title="<?= e(t('rank.auto_refresh')) ?>"><i class="bi bi-arrow-repeat"></i></span>
      </div>
      <div class="card-body py-2" id="rankWrap">
        <ol class="rank-list" id="rankList" data-api="<?= e(url('api/citizen/impact-ranking.php')) ?>">
          <?php foreach ($rankData['users'] as $ru): ?>
            <li data-uid="<?= (int) $ru['id'] ?>">
              <span class="rank-no">#<?= (int) $ru['rank'] ?></span>
              <span class="flex-grow-1 fw-semibold"><?= e($ru['display_name']) ?></span>
              <span class="small text-muted"><?= (int) $ru['impact_count'] ?> ✓</span>
              <span class="mv-flat">—</span>
            </li>
          <?php endforeach; ?>
          <?php if ($rankData['me'] && !$rankData['me']['in_top']): ?>
            <li class="me" data-uid="<?= (int) $rankData['me']['id'] ?>">
              <span class="rank-no">#<?= (int) $rankData['me']['rank'] ?></span>
              <span class="flex-grow-1 fw-bold"><?= e(t('rank.you')) ?></span>
              <span class="small text-muted"><?= (int) $rankData['me']['impact_count'] ?> ✓</span>
              <span class="mv-flat">—</span>
            </li>
          <?php endif; ?>
          <?php if (!$rankData['users'] && !$rankData['me']): ?>
            <li><span class="small text-muted"><?= e(t('rank.empty')) ?></span></li>
          <?php endif; ?>
        </ol>
        <div class="small text-muted mt-2">
          <i class="bi bi-shield-check me-1"></i><?= e(t('rank.verified_note')) ?>
          <?php if ($rankData['me']): ?>· <?= e(t('rank.you_have')) ?> <strong><?= (int) $rankData['me']['impact_count'] ?></strong> ✓ · <?= (int) $rankData['me']['real_badges'] ?> ♻️<?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-7">
    <!-- active pickup -->
    <div class="card mb-3">
      <div class="card-header d-flex align-items-center"><i class="text-pnv bi bi-truck me-2"></i>Active Pickup</div>
      <div class="card-body">
        <?php if ($activePickup): ?>
          <div class="d-flex align-items-center gap-3 flex-wrap">
            <?= pnv_cat_badge($activePickup['category_icon'], $activePickup['category_color'], 46) ?>
            <div>
              <div class="fw-bold"><?= e($activePickup['pickup_code']) ?> · <?= e($activePickup['category_name']) ?> · <?= fmt_kg($activePickup['estimated_weight']) ?></div>
              <div class="small text-muted"><i class="bi bi-calendar3 me-1"></i><?= fmt_dt($activePickup['preferred_date'], 'D, d M Y') ?> · <?= e($activePickup['time_slot']) ?>
                <?php if ($activePickup['collector_name']): ?> · <i class="bi bi-person me-1"></i><?= e($activePickup['collector_name']) ?><?php endif; ?></div>
            </div>
            <div class="ms-auto"><?= pickup_badge($activePickup['status']) ?></div>
          </div>
          <div class="stepper mt-3">
            <?php $flow = ['REQUESTED','ASSIGNED','ACCEPTED','ON_THE_WAY','ARRIVED','COLLECTED','COMPLETED'];
            $idx = array_search($activePickup['status'], $flow, true);
            foreach ($flow as $i => $st): ?>
              <div class="step <?= $i < $idx ? 'done' : ($i == $idx ? 'current' : '') ?>"><?= e(PICKUP_STATUS_LABELS[$st]) ?></div>
            <?php endforeach; ?>
          </div>
          <a class="btn btn-soft btn-sm mt-3" href="<?= url('citizen/pickup-view.php?id=' . (int) $activePickup['id']) ?>">Track this pickup <i class="bi bi-arrow-right"></i></a>
        <?php else: ?>
          <div class="d-flex align-items-center gap-3 flex-wrap">
            <div class="empty-state py-3 flex-grow-1">
              <i class="bi bi-truck"></i>
              <div class="mt-1">No active pickup right now.</div>
            </div>
          </div>
          <a class="btn btn-pnv btn-sm" href="<?= url('citizen/pickup-create.php') ?>"><i class="bi bi-plus-circle me-1"></i>Request a pickup</a>
        <?php endif; ?>
      </div>
    </div>

    <!-- latest passport -->
    <div class="card">
      <div class="card-header d-flex align-items-center">
        <i class="text-pnv bi bi-passport me-2"></i>Latest Waste Passport
        <a class="btn btn-sm btn-soft ms-auto" href="<?= url('citizen/passports.php') ?>">View all</a>
      </div>
      <div class="card-body">
        <?php if ($latestPassport): ?>
          <div class="d-flex align-items-center gap-3 flex-wrap">
            <div>
              <span class="passport-waste-id" style="font-size:1.05rem;padding:.3rem .7rem"><?= e($latestPassport['waste_id']) ?></span>
              <div class="small text-muted mt-2"><span class="dot" style="background:<?= e($latestPassport['category_color']) ?>"></span><?= e($latestPassport['category_name']) ?> · <?= fmt_kg($latestPassport['current_weight']) ?></div>
            </div>
            <div class="ms-auto text-center">
              <?= waste_badge($latestPassport['current_stage']) ?>
              <div class="mt-2">
                <a class="btn btn-sm btn-outline-pnv" href="<?= url('citizen/passport-view.php?id=' . (int) $latestPassport['id']) ?>">Open passport</a>
              </div>
            </div>
          </div>
        <?php else: ?>
          <div class="empty-state py-3"><i class="bi bi-passport"></i>
            <div class="mt-1">Your first Waste Passport appears here after your first completed pickup.</div></div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="col-lg-5">
    <!-- impact -->
    <div class="panel-dark card mb-3">
      <div class="card-body p-4">
        <div class="d-flex justify-content-between align-items-center">
          <h6 class="fw-bold mb-0"><i class="bi bi-globe-americas me-2"></i>Estimated Impact</h6>
          <span class="badge text-bg-light">Estimated</span>
        </div>
        <div class="row text-center mt-3 g-2">
          <div class="col-4"><div class="fs-5 fw-bold"><?= number_format((float) $impact['co2'], 1) ?></div><div class="small opacity-75">kg CO₂e avoided</div></div>
          <div class="col-4"><div class="fs-5 fw-bold"><?= number_format((float) $impact['water']) ?></div><div class="small opacity-75">L water saved</div></div>
          <div class="col-4"><div class="fs-5 fw-bold"><?= number_format((float) $impact['energy'], 1) ?></div><div class="small opacity-75">kWh saved</div></div>
        </div>
        <div class="small opacity-75 mt-3">
          🌳 ≈ <?= $eq['trees'] ?> trees-year of carbon · 🚗 ≈ <?= fmt_num($eq['car_km']) ?> car-km of emissions · method <?= e(METHODOLOGY_VERSION) ?>
        </div>
        <a class="btn btn-light btn-sm fw-bold mt-3" href="<?= url('citizen/impact.php') ?>">Full impact report</a>
      </div>
    </div>

    <!-- category mix -->
    <div class="chart-card mb-3">
      <div class="chart-head"><h2 class="chart-title"><i class="bi bi-bar-chart-line"></i>My waste mix</h2><span class="chart-sub">kg · share</span></div>
        <?php if ($mix): ?><div id="mixChart" class="pnv-mix"></div>
        <?php else: ?><div class="chart-empty"><i class="bi bi-pie-chart"></i><div>Chart appears after your first pickup request.</div></div><?php endif; ?>
    </div>

    <!-- notifications -->
    <div class="card">
      <div class="card-header d-flex align-items-center">
        <i class="text-pnv bi bi-bell me-2"></i>Recent Notifications
        <?php if ($unread): ?><span class="badge text-bg-danger ms-2"><?= $unread ?> new</span><?php endif; ?>
        <a class="btn btn-sm btn-soft ms-auto" href="<?= url('citizen/notifications.php') ?>">All</a>
      </div>
      <div class="card-body p-0">
        <?php if (!$recentNotifications): ?>
          <div class="empty-state py-4"><i class="bi bi-bell-slash"></i><div>No notifications yet.</div></div>
        <?php else: foreach ($recentNotifications as $n): ?>
          <div class="notif-item <?= $n['is_read'] ? '' : 'unread' ?>">
            <div class="n-title"><?= e($n['title']) ?></div>
            <div class="text-muted"><?= e($n['message']) ?></div>
            <div class="text-muted" style="font-size:.72rem"><?= time_ago($n['created_at']) ?></div>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
  </div>
</div>

<?php if ($mix): $pageScripts = '<script>
PNV_CHART.renderMix("#mixChart", ' . json_encode(array_map(fn($m) => ['name' => $m['name'], 'color' => $m['color'], 'value' => round((float) $m['total'], 1)], $mix)) . ');
</script>'; endif;
require dirname(__DIR__) . '/views/layouts/dash_footer.php';
