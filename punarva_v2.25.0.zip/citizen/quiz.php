<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN);
$pageTitle = 'Knowledge Quiz'; $activeMenu = 'learnx';

$quizId = (int) get_val('id', 0);
$quiz = Database::one('SELECT * FROM quizzes WHERE id = ? AND status = "ACTIVE"', [$quizId]);
if (!$quiz) { flash('warning', 'Quiz not found.'); redirect('learn.php'); }

$questions = Database::all('SELECT * FROM quiz_questions WHERE quiz_id = ? ORDER BY id', [$quizId]);
if (!$questions) { flash('warning', 'This quiz has no questions yet.'); redirect('learn.php'); }

if (is_post()) {
    try {
        $score = 0;
        foreach ($questions as $q) {
            if ((int) post_val('q' . $q['id'], -1) === (int) $q['correct_index']) $score++;
        }
        $pct = (int) round($score / count($questions) * 100);
        $passed = $pct >= (int) $quiz['pass_score_pct'];
        $alreadyPassed = (bool) Database::val('SELECT COUNT(*) FROM quiz_attempts WHERE quiz_id = ? AND user_id = ? AND passed = 1', [$quizId, $user['id']]);
        $attemptId = Database::insert('quiz_attempts', [
            'quiz_id' => $quizId, 'user_id' => $user['id'], 'score_pct' => $pct, 'passed' => $passed ? 1 : 0,
        ]);
        AuditService::log('QUIZ_ATTEMPT', 'learning', $attemptId, null, ['quiz' => $quizId, 'score' => $pct]);
        // v2.11.0: quizzes no longer award badges (REAL IMPACT ONLY badge system)
        flash($passed ? 'success' : 'warning',
            $passed ? '🎉 Passed with ' . $pct . '%!' : 'Scored ' . $pct . '% — try again (pass mark ' . $quiz['pass_score_pct'] . '%).');
        redirect('learn.php');
    } catch (Throwable $e) { flash('danger', $e->getMessage()); redirect('citizen/quiz.php?id=' . $quizId); }
}
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="row justify-content-center">
  <div class="col-lg-8">
    <div class="card">
      <div class="card-header d-flex align-items-center">
        <i class="text-pnv bi bi-patch-question me-2"></i><?= e($quiz['title']) ?>
        <span class="small text-muted ms-auto"> <?= e(t('badge.quiz_none')) ?></span>
      </div>
      <div class="card-body p-4">
        <p class="text-muted small"><?= e($quiz['description']) ?> · Pass mark: <?= (int) $quiz['pass_score_pct'] ?>% · <?= count($questions) ?> questions</p>
        <form method="post"><?= csrf_field() ?>
          <?php foreach ($questions as $i => $q): $opts = json_decode($q['options'], true); ?>
            <div class="mb-4">
              <div class="fw-semibold mb-2"><?= $i + 1 ?>. <?= e($q['question']) ?></div>
              <?php foreach ($opts as $oi => $opt): ?>
                <div class="form-check mb-1">
                  <input class="form-check-input" type="radio" name="q<?= (int) $q['id'] ?>" value="<?= $oi ?>" id="q<?= (int) $q['id'] ?>_<?= $oi ?>" required>
                  <label class="form-check-label small" for="q<?= (int) $q['id'] ?>_<?= $oi ?>"><?= e($opt) ?></label>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endforeach; ?>
          <button class="btn btn-pnv px-4"><i class="bi bi-send me-1"></i>Submit answers</button>
          <a class="btn btn-outline-secondary ms-2" href="<?= url('learn.php') ?>">Back to learning</a>
        </form>
      </div>
    </div>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
