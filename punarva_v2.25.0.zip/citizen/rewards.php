<?php
// v2.8.0: REWARDS RETIRED — replaced by Badges + Real Impact (no points/coins/redeem).
require_once dirname(__DIR__) . '/includes/init.php';
require_role(ROLE_CITIZEN);
redirect('citizen/badges.php');
