<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN, ROLE_COLLECTOR, ROLE_RECYCLER, ROLE_BUSINESS);
$pageTitle = 'Notifications'; $activeMenu = 'notifications';
if (is_post() && post_val('action') === 'read_all') {
    NotificationService::markRead((int) $user['id']);
    flash('success', 'All notifications marked as read.');
    redirect($user['role_code'] . '/notifications.php');
}
$items = NotificationService::listFor((int) $user['id'], 100);
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="card">
  <div class="card-header d-flex align-items-center">
    <i class="text-pnv bi bi-bell me-2"></i>Notifications
    <form method="post" class="ms-auto"><input type="hidden" name="action" value="read_all">
      <?= csrf_field() ?><button class="btn btn-sm btn-soft">Mark all read</button></form>
  </div>
  <div class="card-body p-0">
    <?php if (!$items): ?>
      <div class="empty-state py-5"><i class="bi bi-bell-slash"></i><div class="mt-2">You have no notifications yet.</div></div>
    <?php else: foreach ($items as $n): ?>
      <div class="notif-item <?= $n['is_read'] ? '' : 'unread' ?> d-flex gap-3">
        <span class="logo-mark" style="width:34px;height:34px;font-size:.95rem;flex:none;<?= $n['is_read'] ? 'background:#b9c9bf' : '' ?>">
          <i class="bi bi-bell"></i></span>
        <div class="flex-grow-1">
          <div class="n-title"><?= e($n['title']) ?></div>
          <div class="text-muted"><?= e($n['message']) ?></div>
          <div class="text-muted" style="font-size:.72rem"><?= fmt_dt($n['created_at']) ?></div>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php';
