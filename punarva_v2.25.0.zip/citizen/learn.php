<?php // Learning center reuses the public page
require_once dirname(__DIR__) . '/includes/init.php';
require_role(ROLE_CITIZEN);
require dirname(__DIR__) . '/learn.php';
