<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_CITIZEN);

// v2.10.0 — YOUR ACHIEVEMENTS: premium achievement-card system (never a Bootstrap-tag look).
// Real progress only: every number comes from BadgeService::realCounts (verified DB records).
$earned = BadgeService::forUser((int) $user['id']);
$counts = BadgeService::counts((int) $user['id']);
$earnedAt = [];
foreach ($earned as $e) $earnedAt[(int) $e['id']] = $e['awarded_at'];
$all = Database::all('SELECT * FROM badges WHERE is_active = 1 ORDER BY category DESC, criteria_value');
$total = count($all);
$rc = BadgeService::realCounts((int) $user['id']);
$rc['verified_activities'] = BadgeService::verifiedActivities((int) $user['id']);

/** Real progress [current, target] for a criterion — never faked; unmeasurable => null. */
$progressFor = function (string $type, int $value) use ($rc): ?array {
    $cur = match ($type) {
        'pickups_completed', 'reports_verified', 'recycling_completed', 'verified_activities', 'scan_count', 'quiz_count' => (int) ($rc[$type] ?? 0),
        'quiz_passed' => (int) ($rc['quiz_best'] ?? 0),
        default => null,
    };
    return $cur === null ? null : [min($cur, $value), $value];
};
$criteriaText = fn(string $type, int $n): string => str_replace('{n}', (string) $n, t('badge.crit.' . $type));

$pageTitle = t('badge.achievements'); $activeMenu = 'badges';
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>

<div class="card ach-hero mb-4">
  <div class="card-body p-4">
    <div class="d-flex flex-wrap align-items-center gap-3">
      <div class="pnv-badge-total rounded-4 d-flex align-items-center justify-content-center">
        <span class="fs-2 fw-bold"><?= (int) $counts['total'] ?></span>
      </div>
      <div class="flex-grow-1 min-w-0">
        <h1 class="h5 fw-bold mb-1"><?= e(t('badge.achievements')) ?></h1>
        <div class="text-muted small mb-2"><?= e(t('badge.ach_sub')) ?></div>
        <div class="ach-earned-count mb-1"><?= e(t('badge.earned')) ?> <strong><?= (int) $counts['total'] ?></strong> / <?= (int) $total ?></div>
        <div class="progress ach-progress" role="progressbar" aria-label="<?= e(t('badge.earned')) ?> <?= (int) $counts['total'] ?> / <?= (int) $total ?>" aria-valuemin="0" aria-valuemax="<?= (int) $total ?>" aria-valuenow="<?= (int) $counts['total'] ?>">
          <div class="progress-bar bg-success" style="width: <?= $total ? round($counts['total'] / $total * 100) : 0 ?>%"></div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php if (!$total): ?>
  <div class="card"><div class="card-body text-center py-5 empty-state">
    <i class="bi bi-patch-check"></i>
    <div class="fw-bold mt-2"><?= e(t('badge.empty_title')) ?></div>
    <div class="text-muted small"><?= e(t('badge.empty_sub')) ?></div>
  </div></div>
<?php else: ?>

<?php // v2.11.0: REAL IMPACT ONLY — single achievement grid, no learning category ?>
<div class="card mb-4">
  <div class="card-header d-flex align-items-center gap-2 bg-transparent">
    <span class="ach-cat ach-cat-impact"><?= e(t('badge.category.real_impact')) ?></span>
    <span class="small text-muted ms-auto"><?= e(t('badge.cat_impact_hint')) ?></span>
  </div>
  <div class="card-body">
    <div class="row g-3">
      <?php
      $shown = 0;
      foreach ($all as $b):
        if ($b['category'] !== 'real_impact') continue;
        $shown = 1;
        $has = isset($earnedAt[(int) $b['id']]);
        $prog = $has ? null : $progressFor($b['criteria_type'], (int) $b['criteria_value']);
        $pct = $prog ? (int) round($prog[0] / max(1, $prog[1]) * 100) : 0;
        $when = $has ? date('d M Y', strtotime($earnedAt[(int) $b['id']])) : null;
      ?>
      <div class="col-6 col-md-4 col-xl-3">
        <button type="button" class="ach-card h-100 w-100 text-start <?= $has ? 'ach-earned' : 'ach-locked' ?>"
          data-bs-toggle="modal" data-bs-target="#badgeModal"
          data-name="<?= e($b['name']) ?>" data-cat="real_impact"
          data-desc="<?= e($b['description']) ?>"
          data-req="<?= e($criteriaText($b['criteria_type'], (int) $b['criteria_value'])) ?>"
          data-icon="<?= e($b['icon']) ?>" data-has="<?= $has ? 1 : 0 ?>"
          data-when="<?= e($when ?? '') ?>"
          data-cur="<?= $prog ? (int) $prog[0] : ($has ? (int) $b['criteria_value'] : 0) ?>"
          data-max="<?= (int) $b['criteria_value'] ?>"
          aria-label="<?= e($b['name'] . ' — ' . ($has ? t('badge.unlocked') : t('badge.how_to_earn'))) ?>">
          <div class="ach-emblem-wrap mx-auto">
            <?= badge_icon_svg($b['icon'], ['size' => 62, 'title' => $b['name']]) ?>
            <?php if ($has): ?>
              <span class="ach-check" aria-hidden="true"><i class="bi bi-check-lg"></i></span>
            <?php else: ?>
              <span class="ach-lock" aria-hidden="true"><i class="bi bi-lock-fill"></i></span>
            <?php endif; ?>
          </div>
          <div class="ach-name"><?= e($b['name']) ?></div>
          <div class="ach-cat ach-cat-impact mx-auto"><?= e(t('badge.category.real_impact')) ?></div>
          <div class="ach-desc"><?= e($b['description']) ?></div>
          <?php if ($has): ?>
            <div class="ach-state ach-state-earned"><i class="bi bi-check2-circle me-1" aria-hidden="true"></i><?= e(t('badge.earned_on')) ?> <?= e($when) ?></div>
          <?php else: ?>
            <?php if ($prog): ?>
              <div class="ach-progress-track" role="progressbar" aria-label="<?= e(t('badge.progress')) ?>: <?= (int) $prog[0] ?> / <?= (int) $prog[1] ?>" aria-valuemin="0" aria-valuemax="<?= (int) $prog[1] ?>" aria-valuenow="<?= (int) $prog[0] ?>">
                <div class="ach-progress-fill" style="width: <?= $pct ?>%"></div>
              </div>
              <div class="ach-req"><i class="bi bi-lock me-1" aria-hidden="true"></i><?= e($criteriaText($b['criteria_type'], (int) $b['criteria_value'])) ?></div>
              <div class="ach-progress-num"><?= (int) $prog[0] ?> / <?= (int) $prog[1] ?></div>
            <?php else: ?>
              <div class="ach-req"><i class="bi bi-lock me-1" aria-hidden="true"></i><?= e($criteriaText($b['criteria_type'], (int) $b['criteria_value'])) ?></div>
            <?php endif; ?>
          <?php endif; ?>
        </button>
      </div>
      <?php endforeach; ?>
      <?php if (!$shown): ?>
        <div class="col-12 text-muted small">—</div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<div class="alert alert-light border small text-muted d-flex align-items-center gap-2">
  <i class="bi bi-shield-check text-pnv"></i>
  <?= e(t('badge.split_note')) ?>
</div>

<div class="modal fade" id="badgeModal" tabindex="-1" aria-labelledby="badgeModalTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content ach-modal">
      <div class="modal-body text-center p-4">
        <button type="button" class="btn-close position-absolute top-0 end-0 m-3" data-bs-dismiss="modal" aria-label="<?= e(t('badge.close')) ?>"></button>
        <div class="ach-emblem-wrap ach-emblem-lg mx-auto" id="bmIcon"></div>
        <div class="ach-cat mx-auto mt-2" id="bmCat"></div>
        <h2 class="h5 fw-bold mt-2 mb-1" id="badgeModalTitle"></h2>
        <p class="text-muted small mb-2" id="bmDesc"></p>
        <div id="bmState" class="ach-modal-state mb-2"></div>
        <div id="bmProgWrap">
          <div class="ach-progress-track ach-progress-track-lg" role="progressbar" aria-label="<?= e(t('badge.progress')) ?>" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" id="bmBar">
            <div class="ach-progress-fill" id="bmBarFill" style="width:0%"></div>
          </div>
          <div class="ach-progress-num mt-1" id="bmProgNum"></div>
        </div>
        <div class="small text-muted mt-2" id="bmReq"></div>
      </div>
    </div>
  </div>
</div>

<?php // modal emblems rendered server-side (consistent SVG system, no runtime fetching)
$emblems = [];
foreach (array_unique(array_column($all, 'icon')) as $ic) $emblems[$ic] = badge_icon_svg((string) $ic, ['size' => 88]);
$emblems['_default'] = badge_icon_svg('globe', ['size' => 88]);
?>
<script>window.PNV_BADGE_EMBLEMS = <?= json_encode($emblems) ?>;</script>
<script>
document.addEventListener("DOMContentLoaded", function () {
  var modal = document.getElementById("badgeModal");
  modal.addEventListener("show.bs.modal", function (ev) {
    var b = ev.relatedTarget; if (!b) return;
    var d = b.dataset, has = d.has === "1";
    var map = window.PNV_BADGE_EMBLEMS || {};
    document.getElementById("bmIcon").innerHTML = map[d.icon] || map._default || "";
    var cat = document.getElementById("bmCat");
    cat.textContent = <?= json_encode(t('badge.category.real_impact')) ?>;
    cat.className = "ach-cat ach-cat-impact mx-auto mt-2";
    document.getElementById("badgeModalTitle").textContent = d.name;
    document.getElementById("bmDesc").textContent = d.desc;
    var st = document.getElementById("bmState");
    if (has) {
      st.innerHTML = '<i class="bi bi-patch-check-fill text-success me-1"></i><span class="fw-semibold text-success">' + <?= json_encode(t('badge.unlocked')) ?> + (d.when ? " · " + d.when : "") + "</span>";
    } else {
      st.innerHTML = '<i class="bi bi-lock-fill text-muted me-1"></i><span class="fw-semibold text-muted">' + <?= json_encode(t('badge.how_to_earn')) ?> + "</span>";
    }
    var cur = parseInt(d.cur, 10) || 0, max = Math.max(1, parseInt(d.max, 10) || 1);
    var pct = has ? 100 : Math.min(100, Math.round(cur / max * 100));
    document.getElementById("bmBarFill").style.width = pct + "%";
    document.getElementById("bmBar").setAttribute("aria-valuenow", String(pct));
    document.getElementById("bmProgNum").textContent = Math.min(cur, max) + " / " + max;
    document.getElementById("bmReq").textContent = d.req;
  });
});
</script>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
