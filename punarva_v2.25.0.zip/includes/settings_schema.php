<?php
/**
 * PUNARVA – Global System Settings registry (v2.18.0 — correct section separation).
 * Single source of truth: groups + fields, defaults, validation rules.
 * Consumed by admin/settings.php (render+save) and enforcement points (init.php, services...).
 * All values are stored in the existing `settings` table (setting_key => setting_value).
 *
 * v2.18.0 policy (per settings IA spec):
 *  - The page has exactly EIGHT top-level sections, each with only its own settings:
 *      1. General Settings      — Site Identity + Regional & Language ONLY (small!)
 *      2. Registration & Login  — registration switches + login experience
 *      3. Notifications         — workflow notifications + announcement banner toggle
 *      4. Services & Integrations — scanner / maps / QR / email / SMS
 *      5. Maintenance           — maintenance mode + message (NO destructive controls ever)
 *      6. Privacy & Public Access — public QR tracking + public passport fields
 *      7. Security Settings     — Login Protection, Session Security, Password Policy
 *                                 and the read-only Always-Enforced Protections
 *      8. System Health         — read-only technical status (never shows credentials)
 *  - NO setting key, default, validation or enforcement point was changed in v2.18.0 —
 *    this is purely an information-architecture regroup (values survive untouched).
 *  - Security has NO ON/OFF switches for protections: brute-force protection, login
 *    rate limiting and login activity logging are permanently active (code-enforced);
 *    only their numeric thresholds are configurable.
 *  - Password complexity (upper/lower/number/special) is ALWAYS enforced server-side —
 *    shown as a requirement, not a set of switches.
 *  - CSRF, HttpOnly cookies, session-ID regeneration, security logging, auto Secure
 *    cookies and SameSite=Lax stay ALWAYS ENFORCED server-side (read-only indicators).
 *  - No server/cPanel/DB credentials, no destructive operations, no announcement content
 *    editing (content lives in the Announcements module — Settings only has the display toggle).
 *  - Privacy & Public Access defaults are privacy-first; the public endpoint filters
 *    every field server-side.
 *  - v2.14.0: the waste scanner is manual-only. External automated classification is
 *    retired, so no AI wording appears anywhere in the UI (plain "manual scanner").
 */

function settings_schema(): array
{
    return [
        'general' => [
            'title' => 'General Settings', 'icon' => 'bi-sliders',
            'desc'  => 'Platform identity and regional defaults',
            'fields' => [
                ['_sub', 'sub', 'Site Identity', null],
                ['platform_name',    'text',  'Platform Name',       'PUNARVA',             'help', 'Shown in the header brand and page titles'],
                ['platform_tagline', 'text',  'Tagline',             'From Waste to Worth', 'help', 'Shown under the brand name'],
                ['support_email',    'email', 'Support Email',       'support@punarva.local'],
                ['support_phone',    'text',  'Support Phone',       '+91-90000-00000'],
                ['_sub', 'sub', 'Regional & Language', null],
                ['default_language', 'select', 'Default Language', 'en', 'options', [
                    ['value' => 'en', 'label' => 'English'], ['value' => 'hi', 'label' => 'हिन्दी (Hindi)'], ['value' => 'bn', 'label' => 'বাংলা (Bengali)']]],
                ['timezone', 'select', 'Time Zone', 'Asia/Kolkata', 'options', [
                    ['value' => 'Asia/Kolkata', 'label' => 'Asia/Kolkata (IST)'], ['value' => 'UTC', 'label' => 'UTC'], ['value' => 'Asia/Dubai', 'label' => 'Asia/Dubai'], ['value' => 'Europe/London', 'label' => 'Europe/London'], ['value' => 'America/New_York', 'label' => 'America/New_York']]],
                ['date_format', 'select', 'Date Format', 'd M Y', 'options', [
                    ['value' => 'd M Y', 'label' => '01 Jan 2026'], ['value' => 'Y-m-d', 'label' => '2026-01-01'], ['value' => 'd/m/Y', 'label' => '01/01/2026'], ['value' => 'm/d/Y', 'label' => '01/01/2026 (US)']]],
                ['time_format', 'select', 'Time Format', '12', 'options', [['value' => '12', 'label' => '12-hour (2:30 PM)'], ['value' => '24', 'label' => '24-hour (14:30)']]],
                ['number_format', 'select', 'Number Format', 'international', 'options', [
                    ['value' => 'international', 'label' => 'International (1,234,567)'], ['value' => 'indian', 'label' => 'Indian (12,34,567)']]],
                ['default_city',     'text',  'Default City',        'Dumka'],
                ['default_state',    'text',  'Default State',       'Jharkhand'],
                ['default_country',  'text',  'Default Country',     'India'],
            ],
        ],
        'registration' => [
            'title' => 'Registration & Login', 'icon' => 'bi-person-plus',
            'desc'  => 'Who can sign up and how the login screen behaves',
            'fields' => [
                ['registration_enabled',        'switch', 'User Registration', 1, 'confirm', 'New users will not be able to create accounts while this is off. Continue?'],
                ['citizen_registration_enabled','switch', 'Citizen Registration', 1],
                ['business_registration_enabled','switch','Business Registration', 1],
                ['_note_roles', 'note', 'Roles are always assigned server-side. The browser can never choose or elevate a role — self-registration creates Citizens and Business accounts only.', null],
                ['password_reset_enabled', 'switch', 'Password Reset (Forgot Password)', 1],
                ['remember_me_enabled',    'switch', 'Show "Remember me" on login', 1, 'help', 'Extends the idle timeout of that session'],
                ['login_session_hours',    'number', 'Login Session Duration (hours, 0 = until idle timeout)', 0, 'min', 0, 'max', 720],
            ],
        ],
        'notifications' => [
            'title' => 'Notifications', 'icon' => 'bi-bell',
            'desc'  => 'In-app workflow notifications and the announcement banner',
            'fields' => [
                ['notifications_enabled', 'switch', 'Notifications Enabled', 1, 'confirm', 'Workflow notifications (assignment, collection, completion) will stop for everyone. Continue?'],
                ['notif_inapp', 'switch', 'In-App Notifications', 1],
                ['notif_retention_days', 'number', 'Notification Retention (days)', 90, 'min', 7, 'max', 365, 'help', 'Applied by scheduled cleanup jobs'],
                ['announcement_display', 'switch', 'Show Latest Announcement as Dashboard Banner', 1, 'help', 'Displays the most recent announcement from the Announcements module on dashboards for 7 days. Create/edit announcements in Admin → Announcements.'],
            ],
        ],
        'services' => [
            'title' => 'Services & Integrations', 'icon' => 'bi-plug',
            'desc'  => 'Scanner, maps, QR and messaging services',
            'fields' => [
                ['scanner_mode_status', 'info', 'Scanner Mode', null, 'fn', 'scanner_mode'],
                ['maps_enabled', 'switch', 'Maps Enabled', 1, 'confirm', 'Leaflet maps on dashboards will be hidden. Continue?'],
                ['map_status', 'info', 'Map Provider', null, 'fn', 'map_status'],
                ['qr_enabled', 'switch', 'QR Generation Enabled', 1, 'help', 'Renders passport QR codes (public visibility is controlled in Privacy & Public Access below)'],
                ['email_service_status', 'info', 'Email Service', null, 'fn', 'email_status'],
                ['sms_service_status',   'info', 'SMS Service',   null, 'fn', 'sms_status'],
            ],
        ],
        'maintenance' => [
            'title' => 'Maintenance', 'icon' => 'bi-tools',
            'desc'  => 'Maintenance mode and its message',
            'fields' => [
                ['maintenance_mode',    'switch', 'Maintenance Mode', 0, 'confirm', 'All non-admin users will see a maintenance page. Continue?'],
                ['maintenance_message', 'textarea', 'Maintenance Message', 'PUNARVA is undergoing scheduled maintenance. We will be back shortly.'],
                ['_note_destructive', 'note', 'PUNARVA deliberately has no database reset, SQL console, file/upload deletion or server controls in the admin panel. Database and server administration belong outside the application (phpMyAdmin / hosting panel).', null],
            ],
        ],
        'privacy' => [
            'title' => 'Privacy & Public Access', 'icon' => 'bi-eye-slash',
            'desc'  => 'Public QR tracking and the fields it may show',
            'fields' => [
                ['public_tracking_enabled', 'switch', 'Public QR Tracking Enabled', 1, 'confirm', 'The public tracking page will stop showing any journey. Continue?'],
                ['_sub', 'sub', 'Public Passport Fields (safe data only)', null],
                ['show_waste_id',  'switch', 'Passport ID & QR', 1, 'help', 'Hides the Waste ID text and the public QR box on the public tracking page'],
                ['show_category',  'switch', 'Waste Category & Material', 1],
                ['show_weight',    'switch', 'Weight', 1],
                ['show_status',    'switch', 'Collection Status & Date', 1],
                ['show_timeline',  'switch', 'Journey Timeline', 1],
                ['show_facility',  'switch', 'Verified Facility', 1],
                ['show_outcome',   'switch', 'Processing / Recycling Outcome', 1],
                ['show_impact',    'switch', 'Estimated Environmental Impact', 1],
                ['_note', 'note', 'Privacy-first defaults. Citizen name, mobile number, email, exact address, collector identity, internal user IDs, exact GPS coordinates, credentials and API keys are permanently excluded from public tracking — filtered server-side before any page or API response. This cannot be overridden by any setting.', null],
            ],
        ],
        'security' => [
            'title' => 'Security Settings', 'icon' => 'bi-shield-lock',
            'desc'  => 'Login protection, sessions and password policy — critical protections stay permanently enforced',
            'fields' => [
                ['_sub', 'sub', 'Login Protection', null],
                ['max_login_attempts', 'number', 'Maximum Failed Login Attempts', 5, 'min', 3, 'max', 10, 'help', 'Number of consecutive failed login attempts allowed before temporary protection is triggered'],
                ['login_lock_minutes', 'number', 'Temporary Lock Duration (minutes)', 15, 'min', 1, 'max', 1440, 'help', 'How long login attempts remain temporarily blocked after the maximum failed attempts is reached'],
                ['_always_bf',   'always', 'Brute-Force Protection', 'Locks the login form after the maximum failed attempts. Always enforced — cannot be disabled.'],
                ['_always_rate', 'always', 'Login Rate Limiting', 'Per-IP + per-email throttling of login attempts. Always enforced — cannot be disabled.'],
                ['_always_llog', 'always', 'Login Activity Logging', 'Successful and failed login attempts are written to the audit log. Always enforced — cannot be disabled.'],
                ['_sub', 'sub', 'Session Security', null],
                ['session_idle_minutes', 'number', 'Idle Session Timeout (minutes)', 30, 'min', 5, 'max', 1440, 'help', 'Automatically signs users out after the configured period of inactivity — enforced server-side, never by browser timers'],
                ['force_logout_all', 'action', 'Force Logout All Users', null, 'confirm', 'Force Logout All Users? This will invalidate all active user sessions. Every user will need to sign in again. Enter your current password to continue.', 'help', 'Invalidates all active user sessions. Users will be required to sign in again on their next request. Users and their data are never deleted — passwords and roles are never modified.'],
                ['_sub', 'sub', 'Password Policy', null],
                ['password_min_length', 'number', 'Minimum Password Length', 8, 'min', 8, 'max', 128, 'help', 'Applies to registration, password change, password reset and admin-created users'],
                ['_always_pw', 'always', 'Password Complexity Requirements', 'Passwords must contain: at least one uppercase letter, at least one lowercase letter, at least one number and at least one special character — enforced server-side everywhere. Always enforced — cannot be disabled.'],
                ['_sub', 'sub', 'Always-Enforced Protections', null],
                ['_always_csrf',    'always', 'CSRF Protection', 'Every state-changing request (POST/PUT/PATCH/DELETE) must carry a valid CSRF token and is rejected without one. Cannot be disabled.'],
                ['_always_httponly','always', 'HttpOnly Cookies', 'Session cookies are inaccessible to JavaScript on every request. Cannot be disabled.'],
                ['_always_regen',   'always', 'Session ID Regeneration', 'Session IDs are regenerated after login and privilege changes to prevent session fixation. Cannot be disabled.'],
                ['_always_seclog',  'always', 'Security Logging', 'Security-sensitive events are recorded in the audit log. Cannot be disabled.'],
                ['_always_secure',  'always', 'Secure Cookies', 'Session cookies automatically use the Secure attribute whenever the application is served over HTTPS. Cannot be disabled.'],
                ['_always_samesite','always', 'SameSite Cookies', 'Session cookies use SameSite=Lax — strong CSRF defence without breaking normal navigation. Cannot be disabled.'],
            ],
        ],
        'health' => [
            'title' => 'System Health', 'icon' => 'bi-heart-pulse',
            'desc'  => 'Read-only technical status — never shows credentials or secrets',
            'fields' => [
                ['_health', 'health', null, null],
            ],
        ],
    ];
}

/** Ensure the extended columns exist (safe, idempotent, backward compatible with old installs). */
function settings_ensure_columns(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        $cols = array_column(Database::all('SHOW COLUMNS FROM settings'), 'Field');
        if (!in_array('setting_group', $cols, true)) Database::run('ALTER TABLE settings ADD COLUMN setting_group VARCHAR(30) NULL');
        if (!in_array('updated_by', $cols, true))    Database::run('ALTER TABLE settings ADD COLUMN updated_by INT NULL');
    } catch (Throwable $e) { error_log('settings_ensure_columns: ' . $e->getMessage()); }
}

/** Read-only computed values shown in Services / System Health. Never reveals secrets. */
function settings_info_value(string $key): string
{
    switch ($key) {
        case 'scanner_mode':
            // v2.14.0 — the scanner is manual by design (v2.18.0: no AI wording in the UI)
            return 'Manual — users select the waste category themselves';
        case 'map_status':       return 'OpenStreetMap + Leaflet 1.9 (vendored locally)';
        case 'email_status':     return 'PHP mail() — Local mode (password-reset links)';
        case 'sms_status':       return 'Not configured';
        case 'db_status':        try { Database::val('SELECT 1'); $v = (string) (Database::one('SELECT VERSION() AS v')['v'] ?? ''); $maj = $v !== '' ? ' — Connected · v' . e(explode('-', $v)[0]) : ' — Connected'; return 'MySQL/MariaDB' . $maj; } catch (Throwable $e) { return 'Unreachable'; }
        case 'storage_status':
            $ok = is_dir(UPLOAD_DIR) && is_writable(UPLOAD_DIR);
            return $ok ? 'Writable' : 'NOT writable — uploads will fail';
        case 'app_status':
            $db  = settings_info_value('db_status') !== 'Unreachable';
            $st  = str_starts_with(settings_info_value('storage_status'), 'Writable');
            return ($db && $st) ? 'Operational' : 'Degraded';
        default: return '';
    }
}

/** Server-side validation for one field value. $f is the schema field row. */
function settings_validate_field(array $f, $v): ?string
{
    $type = $f[1];
    switch ($type) {
        case 'switch':  return in_array($v, ['0', '1', ''], true) ? null : 'Invalid boolean value.';
        case 'number':
            $v = trim((string) $v);
            if ($v === '' || !is_numeric($v)) return ucfirst((string) ($f[2] ?? 'Value')) . ' must be a number.';
            // v2.15.0: integer only — reject decimals, exponents, "+5", "007" style input
            if ((string) (int) $v !== $v) return ucfirst((string) ($f[2] ?? 'Value')) . ' must be a whole number (integer).';
            for ($i = 4; $i < count($f) - 1; $i++) {
                if ($f[$i] === 'min'  && (float) $v < (float) $f[$i + 1]) return ucfirst((string) $f[2]) . " must be at least {$f[$i + 1]}.";
                if ($f[$i] === 'max'  && (float) $v > (float) $f[$i + 1]) return ucfirst((string) $f[2]) . " must be at most {$f[$i + 1]}.";
            }
            return null;
        case 'email':
            return $v === '' || filter_var($v, FILTER_VALIDATE_EMAIL) ? null : 'Please enter a valid email address.';
        case 'select':
            $opts = ( ($i = array_search('options', $f, true)) !== false ) ? ($f[$i + 1] ?? []) : [];
            foreach ($opts as $o) if ((string) $o['value'] === (string) $v) return null;
            return 'Please choose a valid option.';
        case 'text': case 'textarea': case 'password':
            return mb_strlen($v) <= 500 ? null : ucfirst((string) $f[2]) . ' must be at most 500 characters.';
        default: return null; // info/action/sub/always/note/health are never saved
    }
}
