<?php
/**
 * PUNARVA — minimal .env loader (v2.5.0)
 * --------------------------------------
 * Loads the project-root `.env` file into PHP's environment WITHOUT overriding
 * variables that are already set (real environment always wins — safe for
 * Apache SetEnv / hosting panels).
 *
 * Design rules:
 *  - Zero dependencies (no Composer/Redis/Docker) — XAMPP-compatible.
 *  - Supports: KEY=value, quoted values, blank lines and # comments.
 *  - Never echo/return secret values; on parse problems it writes to the server
 *    log only and continues (fail-safe, app keeps running with defaults).
 *  - Values are NOT exposed to output or JavaScript anywhere (config defines only).
 */

function pnv_load_env(string $file): void
{
    static $loaded = false;
    if ($loaded) return;
    $loaded = true;
    if (!is_file($file) || !is_readable($file)) return; // no .env → XAMPP defaults keep working
    try {
        $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#') continue;
            $pos = strpos($line, '=');
            if ($pos === false) continue;
            $key = trim(substr($line, 0, $pos));
            $val = trim(substr($line, $pos + 1));
            if ($key === '' || !preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $key)) continue;
            // strip optional surrounding quotes
            if (strlen($val) >= 2 && (($val[0] === '"' && substr($val, -1) === '"') || ($val[0] === "'" && substr($val, -1) === "'"))) {
                $val = substr($val, 1, -1);
            }
            // real environment variables always win (never override the server config)
            if (getenv($key) !== false || array_key_exists($key, $_ENV) || array_key_exists($key, $_SERVER)) continue;
            $_ENV[$key] = $val;
            $_SERVER[$key] = $val;
            putenv("$key=$val");
        }
    } catch (Throwable $e) {
        error_log('PUNARVA .env parse problem (non-fatal): ' . $e->getMessage());
    }
}
