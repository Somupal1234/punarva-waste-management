<?php
/**
 * Admin CRUD entity registry – powers admin/module.php for most management tables.
 * Each entity: table, label, icon, searchable columns, list columns, form fields, filters.
 * field types: text, number, textarea, select, email, password, date, color, icon, checkbox
 */
function admin_entities(): array
{
    $roleOptions = fn() => array_map(fn($r) => ['value' => $r['id'], 'label' => $r['name']], Database::all('SELECT id, name FROM roles'));
    $catOptions  = fn() => array_map(fn($c) => ['value' => $c['id'], 'label' => $c['name']], Database::all('SELECT id, name FROM waste_categories'));
    $facOptions  = fn() => array_map(fn($f) => ['value' => $f['id'], 'label' => $f['name']], Database::all('SELECT id, name FROM facilities ORDER BY name'));

    return [
        'users' => [
            'table' => 'users', 'label' => 'Users & Roles', 'icon' => 'bi-people', 'order' => 'created_at DESC',
            'search' => ['name', 'email', 'phone'],
            'filters' => [
                'role_id' => ['label' => 'Role', 'options' => $roleOptions],
                'status'  => ['label' => 'Status', 'options' => fn() => [['value' => 'ACTIVE', 'label' => 'ACTIVE'], ['value' => 'INACTIVE', 'label' => 'INACTIVE'], ['value' => 'SUSPENDED', 'label' => 'SUSPENDED']]],
            ],
            'list' => [
                'id' => '#', 'name' => 'Name', 'email' => 'Email', 'phone' => 'Phone',
                ['col' => "COALESCE((SELECT name FROM roles r WHERE r.id = u.role_id),'')", 'alias' => 'role_name', 'label' => 'Role', 'join' => 'u'],
                ['col' => 'status', 'label' => 'Status', 'badge' => ['ACTIVE' => 'success', 'INACTIVE' => 'secondary', 'SUSPENDED' => 'danger']],
                'created_at' => 'Created',
            ],
            'from' => 'users u',
            'fields' => [
                ['name', 'Full name', 'text', true], ['email', 'Email', 'email', true],
                ['phone', 'Phone', 'phone', true],
                ['role_id', 'Role', 'select', true, $roleOptions],
                ['facility_id', 'Facility (recyclers)', 'select', false, $facOptions],
                ['organization_id', 'Organization ID (business)', 'number', false],
                ['password_plain', 'Password (leave blank to keep)', 'password', false],
                ['status', 'Status', 'select', true, fn() => [['value' => 'ACTIVE', 'label' => 'ACTIVE'], ['value' => 'INACTIVE', 'label' => 'INACTIVE'], ['value' => 'SUSPENDED', 'label' => 'SUSPENDED']]],
                ['language', 'Language', 'select', false, fn() => [['value' => 'en', 'label' => 'English'], ['value' => 'hi', 'label' => 'Hindi'], ['value' => 'bn', 'label' => 'Bengali']]],
            ],
        ],
        'waste_categories' => [
            'table' => 'waste_categories', 'label' => 'Waste Categories', 'icon' => 'bi-recycle', 'order' => 'id',
            'search' => ['name', 'code'],
            'list' => [
                'id' => '#', ['col' => 'icon', 'label' => '', 'icon' => true], 'name' => 'Name', 'code' => 'Code',
                'bin_type' => 'Bin', ['col' => 'color', 'label' => 'Color', 'color' => true],
                ['col' => 'is_recyclable', 'label' => 'Recyclable', 'bool' => true],
                ['col' => 'status', 'label' => 'Status', 'badge' => ['ACTIVE' => 'success', 'INACTIVE' => 'secondary']],
            ],
            'fields' => [
                ['name', 'Name', 'text', true], ['code', 'Code (UNIQUE)', 'text', true],
                ['description', 'Description', 'textarea', false], ['bin_type', 'Bin type', 'text', true],
                ['icon', 'Bootstrap icon', 'text', false], ['color', 'Color', 'color', false],
                ['recycling_guidance', 'Recycling guidance', 'textarea', false],
                ['is_recyclable', 'Recyclable stream', 'checkbox', false],
                ['status', 'Status', 'select', true, fn() => [['value' => 'ACTIVE', 'label' => 'ACTIVE'], ['value' => 'INACTIVE', 'label' => 'INACTIVE']]],
            ],
        ],
        'facilities' => [
            'table' => 'facilities', 'label' => 'Facilities', 'icon' => 'bi-buildings', 'order' => 'name',
            'search' => ['name', 'code', 'city'],
            'list' => ['id' => '#', 'code' => 'Code', 'name' => 'Name', 'facility_type' => 'Type', 'city' => 'City',
                       'capacity_kg_day' => 'Capacity/day', 'status' => ['label' => 'Status', 'badge' => ['ACTIVE' => 'success', 'INACTIVE' => 'secondary']]],
            'fields' => [
                ['name', 'Facility name', 'text', true], ['code', 'Code', 'text', true],
                ['facility_type', 'Type (SORTING/COMPOST/MRF/E-WASTE)', 'text', true],
                ['address_line', 'Address', 'text', false], ['city', 'City', 'text', false],
                ['ward', 'Ward', 'text', false], ['latitude', 'Latitude', 'number', false], ['longitude', 'Longitude', 'number', false],
                ['contact_person', 'Contact person', 'text', false], ['phone', 'Phone', 'text', false], ['email', 'Email', 'email', false],
                ['capacity_kg_day', 'Capacity (kg/day)', 'number', false],
                ['status', 'Status', 'select', true, fn() => [['value' => 'ACTIVE', 'label' => 'ACTIVE'], ['value' => 'INACTIVE', 'label' => 'INACTIVE']]],
            ],
        ],
        'organizations' => [
            'table' => 'organizations', 'label' => 'Organizations', 'icon' => 'bi-bank', 'order' => 'created_at DESC',
            'search' => ['name', 'city'],
            'list' => ['id' => '#', 'name' => 'Name', 'org_type' => 'Type', 'email' => 'Email', 'phone' => 'Phone',
                       'status' => ['label' => 'Status', 'badge' => ['ACTIVE' => 'success', 'INACTIVE' => 'secondary']]],
            'fields' => [
                ['name', 'Organization name', 'text', true],
                ['org_type', 'Type', 'select', true, fn() => array_map(fn($v) => ['value' => $v, 'label' => $v], ['SCHOOL','OFFICE','RESTAURANT','SHOP','HOSPITAL','APARTMENT','GOVERNMENT','OTHER'])],
                ['email', 'Email', 'email', false], ['phone', 'Phone', 'text', false],
                ['address_line', 'Address', 'text', false], ['city', 'City', 'text', false],
                ['status', 'Status', 'select', true, fn() => [['value' => 'ACTIVE', 'label' => 'ACTIVE'], ['value' => 'INACTIVE', 'label' => 'INACTIVE']]],
            ],
        ],
        'vehicles' => [
            'table' => 'vehicles', 'label' => 'Vehicles', 'icon' => 'bi-bus-front', 'order' => 'vehicle_number',
            'search' => ['vehicle_number', 'driver_name'],
            'filters' => ['facility_id' => ['label' => 'Facility', 'options' => $facOptions]],
            'list' => ['id' => '#', 'vehicle_number' => 'Vehicle', 'vehicle_type' => 'Type', 'capacity_kg' => 'Capacity',
                       'driver_name' => 'Driver', 'driver_phone' => 'Phone',
                       'status' => ['label' => 'Status', 'badge' => ['ACTIVE' => 'success', 'MAINTENANCE' => 'warning', 'INACTIVE' => 'secondary']]],
            'fields' => [
                ['vehicle_number', 'Vehicle number', 'text', true],
                ['facility_id', 'Facility', 'select', true, $facOptions],
                ['vehicle_type', 'Type (TIPPER/DUMPER/TEMPO)', 'text', false],
                ['capacity_kg', 'Capacity (kg)', 'number', false],
                ['driver_name', 'Driver name', 'text', false], ['driver_phone', 'Driver phone', 'text', false],
                ['status', 'Status', 'select', true, fn() => array_map(fn($v) => ['value' => $v, 'label' => $v], ['ACTIVE','MAINTENANCE','INACTIVE'])],
            ],
        ],
        'reward_rules' => [
            'table' => 'reward_rules', 'label' => 'Reward Rules', 'icon' => 'bi-trophy', 'order' => 'id',
            'search' => ['name', 'code'],
            'list' => ['id' => '#', 'name' => 'Rule', 'action_type' => 'Action', 'points' => 'Points',
                       'status' => ['label' => 'Status', 'badge' => ['ACTIVE' => 'success', 'INACTIVE' => 'secondary']]],
            'fields' => [
                ['name', 'Rule name', 'text', true], ['code', 'Code (unique)', 'text', true],
                ['description', 'Description', 'textarea', false],
                ['action_type', 'Action', 'select', true, fn() => array_map(fn($k) => ['value' => $k, 'label' => REWARD_ACTIONS[$k]], array_keys(REWARD_ACTIONS))],
                ['points', 'Points', 'number', true],
                ['status', 'Status', 'select', true, fn() => [['value' => 'ACTIVE', 'label' => 'ACTIVE'], ['value' => 'INACTIVE', 'label' => 'INACTIVE']]],
            ],
        ],
        'impact_factors' => [
            'table' => 'impact_factors', 'label' => 'Impact Factors', 'icon' => 'bi-globe-americas', 'order' => 'id',
            'search' => [],
            'filters' => ['category_id' => ['label' => 'Category', 'options' => $catOptions]],
            'list' => [
                'id' => '#',
                ['col' => "(SELECT name FROM waste_categories wc WHERE wc.id = f.category_id)", 'alias' => 'category', 'label' => 'Category', 'join' => 'f'],
                'co2_kg_per_kg' => 'CO₂e kg/kg', 'water_l_per_kg' => 'Water L/kg', 'energy_kwh_per_kg' => 'Energy kWh/kg',
                'landfill_diverted_pct' => '% diverted', 'methodology_version' => 'Methodology',
                ['col' => 'status', 'label' => 'Status', 'badge' => ['ACTIVE' => 'success', 'INACTIVE' => 'secondary']],
            ],
            'from' => 'impact_factors f',
            'fields' => [
                ['category_id', 'Waste category', 'select', true, $catOptions],
                ['co2_kg_per_kg', 'CO₂e avoided (kg per kg)', 'number', true],
                ['water_l_per_kg', 'Water saved (L per kg)', 'number', false],
                ['energy_kwh_per_kg', 'Energy saved (kWh per kg)', 'number', false],
                ['landfill_diverted_pct', '% diverted from disposal', 'number', false],
                ['methodology_version', 'Methodology version', 'text', false],
                ['status', 'Status', 'select', true, fn() => [['value' => 'ACTIVE', 'label' => 'ACTIVE'], ['value' => 'INACTIVE', 'label' => 'INACTIVE']]],
            ],
        ],
        'articles' => [
            'table' => 'articles', 'label' => 'Learning Articles', 'icon' => 'bi-journal-bookmark', 'order' => 'created_at DESC',
            'search' => ['title', 'topic'],
            'list' => ['id' => '#', 'title' => 'Title', 'topic' => 'Topic', 'views' => 'Views',
                       'status' => ['label' => 'Status', 'badge' => ['PUBLISHED' => 'success', 'DRAFT' => 'secondary']], 'created_at' => 'Created'],
            'fields' => [
                ['title', 'Title', 'text', true], ['slug', 'Slug (URL)', 'text', true],
                ['topic', 'Topic', 'text', true], ['summary', 'Summary', 'textarea', true],
                ['content', 'Content', 'textarea', true],
                ['status', 'Status', 'select', true, fn() => [['value' => 'PUBLISHED', 'label' => 'PUBLISHED'], ['value' => 'DRAFT', 'label' => 'DRAFT']]],
            ],
        ],
        'quizzes' => [
            'table' => 'quizzes', 'label' => 'Quizzes', 'icon' => 'bi-patch-question', 'order' => 'id',
            'search' => ['title'],
            'list' => ['id' => '#', 'title' => 'Quiz', 'topic' => 'Topic', 'reward_points' => 'Reward',
                       'pass_score_pct' => 'Pass %',
                       ['col' => "(SELECT COUNT(*) FROM quiz_questions qq WHERE qq.quiz_id = quizzes.id)", 'alias' => 'questions', 'label' => 'Questions'],
                       'status' => ['label' => 'Status', 'badge' => ['ACTIVE' => 'success', 'INACTIVE' => 'secondary']]],
            'fields' => [
                ['title', 'Title', 'text', true], ['topic', 'Topic', 'text', false],
                ['description', 'Description', 'textarea', false],
                ['reward_points', 'Reward points', 'number', true], ['pass_score_pct', 'Pass score (%)', 'number', true],
                ['status', 'Status', 'select', true, fn() => [['value' => 'ACTIVE', 'label' => 'ACTIVE'], ['value' => 'INACTIVE', 'label' => 'INACTIVE']]],
            ],
        ],
        'quiz_questions' => [
            'table' => 'quiz_questions', 'label' => 'Quiz Questions', 'icon' => 'bi-question-circle', 'order' => 'quiz_id, id',
            'search' => ['question'],
            'filters' => ['quiz_id' => ['label' => 'Quiz', 'options' => fn() => array_map(fn($q) => ['value' => $q['id'], 'label' => $q['title']], Database::all('SELECT id, title FROM quizzes'))]],
            'list' => [
                'id' => '#',
                ['col' => "(SELECT title FROM quizzes q WHERE q.id = f.quiz_id)", 'alias' => 'quiz', 'label' => 'Quiz', 'join' => 'f'],
                'question' => 'Question', 'correct_index' => 'Correct option (0-3)',
            ],
            'from' => 'quiz_questions f',
            'fields' => [
                ['quiz_id', 'Quiz', 'select', true, fn() => array_map(fn($q) => ['value' => $q['id'], 'label' => $q['title']], Database::all('SELECT id, title FROM quizzes'))],
                ['question', 'Question', 'text', true],
                ['options', 'Options (JSON array of 4)', 'textarea', true],
                ['correct_index', 'Correct option index (0-3)', 'number', true],
            ],
        ],
    ];
}
