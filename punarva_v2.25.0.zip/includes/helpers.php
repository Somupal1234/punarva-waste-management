<?php
/**
 * Shared helper functions used across the whole application.
 */

function db(): PDO { return Database::pdo(); }

function e(?string $s): string { return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8'); }

/**
 * CSRF-protected logout URL (v2.7.0): token session-bound hai — doosri site <img src> se
 * kisi ko force-logout nahi kar sakti (logout CSRF hardening).
 */
function logout_url(): string
{
    return url('logout.php?t=' . csrf_token());
}

function url(string $path = ''): string { return BASE_URL . ($path === '' ? '' : '/' . ltrim($path, '/')); }

/**
 * Asset URL with automatic cache-busting: ?v=APP_VERSION.<filemtime-hash>.
 * Unlike APP_VERSION alone, replacing a single file (e.g. via FTP) changes its
 * mtime and immediately busts every browser cache — no config edit needed.
 */
function asset_url(string $path): string {
    $full = dirname(__DIR__) . '/' . ltrim($path, '/');
    $m = @filemtime($full);
    return url($path) . '?v=' . APP_VERSION . ($m ? '.' . substr(md5((string) $m), 0, 6) : '');
}

/** Absolute URL (current scheme + host) – used for QR codes that are scanned from phones. */
function absolute_url(string $path = ''): string {
    $https = ($_SERVER['HTTPS'] ?? '') === 'on' || strtolower($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return $scheme . '://' . $host . url($path);
}

function redirect(string $path): never {
    header('Location: ' . (str_starts_with($path, 'http') ? $path : url($path)));
    exit;
}

function is_api_request(): bool {
    return str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/')
        || (isset($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json')
            && ($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET'
            && str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/'));
}

// ---------- JSON ----------
function json_out(bool $success, string $message = '', $data = null, array $errors = [], int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => $success, 'message' => $message, 'data' => $data, 'errors' => $errors],
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function json_ok(string $message = 'Success', $data = null): never { json_out(true, $message, $data); }
function json_err(string $message, array $errors = [], int $status = 400): never { json_out(false, $message, null, $errors, $status); }

// ---------- Flash messages ----------
function flash(string $type, string $message): void { $_SESSION['flash'][] = ['type' => $type, 'message' => $message]; }
function get_flashes(): array { $f = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); return $f; }

// ---------- Auth / RBAC ----------
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function current_role(): ?string { return $_SESSION['user']['role_code'] ?? null; }
function is_logged_in(): bool { return isset($_SESSION['user']); }

function require_login(): array {
    if (!is_logged_in()) {
        if (is_api_request()) json_err('Authentication required.', [], 401);
        flash('warning', 'Please log in to continue.');
        redirect('login.php');
    }
    return $_SESSION['user'];
}
function require_role(string ...$roles): array {
    $user = require_login();
    if (!in_array($user['role_code'], $roles, true)) {
        if (is_api_request()) json_err('You do not have permission to perform this action.', [], 403);
        flash('danger', 'You are not authorized to access that page.');
        redirect(ROLE_HOME[$user['role_code']] ?? 'index.php');
    }
    return $user;
}

// ---------- CSRF ----------
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
/**
 * Pages that render a Leaflet map. Leaflet CSS/JS is loaded ONLY for these
 * (see views/layouts/*_header.php / *_footer.php). Add new map pages here.
 */
/** Global banners (e.g. disabled features) — rendered once by layouts, session-based. */
function add_global_banner(string $type, string $message): void {
    $_SESSION['global_banners'][] = ['type' => $type, 'message' => $message];
}
function get_global_banners(): array {
    $b = $_SESSION['global_banners'] ?? [];
    unset($_SESSION['global_banners']);
    return $b;
}

/**
 * Canonical waste-category icon map (code => Bootstrap Icon class).
 * SINGLE SOURCE OF TRUTH — every category icon on the platform resolves through
 * pnv_cat_icon()/pnv_cat_badge(); the DB icon column mirrors these values.
 */
function pnv_cat_icons(): array {
    static $map = null;
    if ($map === null) {
        $map = [
            'WET_WASTE' => 'bi-egg-fried',                   // food scraps / organic
            'DRY_WASTE' => 'bi-box2',                        // dry recyclables
            'PLASTIC'   => 'bi-cup-straw',                   // plastic packaging/bottle
            'PAPER'     => 'bi-newspaper',                   // paper sheet
            'CARDBOARD' => 'bi-box-seam',                    // cardboard box
            'GLASS'     => 'bi-cup',                         // glass tumbler/jar
            'METAL'     => 'bi-nut-fill',                    // metal piece/can
            'E_WASTE'   => 'bi-cpu',                         // electronics / circuit
            'TEXTILE'   => 'bi-bag-heart-fill',              // clothing / donation bag
            'ORGANIC'   => 'bi-tree',                        // garden / leaf
            'HAZARDOUS' => 'bi-exclamation-triangle-fill',   // hazard warning
            'SANITARY'  => 'bi-bandaid-fill',                // hygiene waste
            'MIXED'     => 'bi-trash3-fill',                 // general/mixed bin
            'OTHER'     => 'bi-question-circle-fill',        // miscellaneous
        ];
    }
    return $map;
}

/** Resolve a category icon: canonical by code, then DB value, then safe fallback. Never broken. */
function pnv_cat_icon(string $code = '', string $dbIcon = ''): string {
    $map = pnv_cat_icons();
    $code = strtoupper(trim($code));
    if ($code !== '' && isset($map[$code])) return $map[$code];
    $dbIcon = trim($dbIcon);
    return ($dbIcon !== '' && str_starts_with($dbIcon, 'bi-')) ? $dbIcon : $map['OTHER'];
}

/** The one tinted category tile used everywhere (app-icon style, DB colour as accent). */
function pnv_cat_badge(string $icon, string $color, int $size = 44, string $code = ''): string {
    $ic = e(pnv_cat_icon($code, $icon));
    $col = e($color !== '' ? $color : '#90a4ae');
    return '<span class="logo-mark cat-badge" style="width:' . (int) $size . 'px;height:' . (int) $size . 'px;--cat:' . $col . '"><i class="bi ' . $ic . '" aria-hidden="true"></i></span>';
}

/**
 * Map a server-side validation message to the most likely form field (heuristics).
 * Server-side validation remains the source of truth; this only improves UX reporting.
 */
function pnv_field_error(?string $msg, array $map): ?string {
    if (!$msg) return null;
    $lm = strtolower($msg);
    foreach ($map as $needle => $field) {
        if (str_contains($lm, $needle)) return $field;
    }
    return null;
}

/** Pages that render Chart.js graphs — vendor chart.umd.min.js loads only here. */
function pnv_needs_charts(): bool {
    $base = basename($_SERVER['SCRIPT_NAME'] ?? '');
    $dir  = basename(dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    return ($dir === 'admin' && in_array($base, ['analytics.php', 'dashboard.php'], true))
        || ($dir === 'citizen' && in_array($base, ['dashboard.php', 'impact.php'], true))
        || ($dir === 'business' && in_array($base, ['impact.php', 'dashboard.php'], true));
}

/** v2.25.0 — themed Chart.js bootstrap: vendor + PUNARVA chart system (order matters). */
function pnv_chart_assets(): string {
    return '<script src="' . url('assets/vendor/chartjs/chart.umd.min.js') . '"></script>' . "\n"
         . '<script src="' . asset_url('assets/js/pnv-charts.js') . '"></script>';
}

function pnv_needs_map(): bool {
    // v2.12.0 — Maps Enabled (System Settings → Integrations) gates every Leaflet
    // enqueue server-side; with maps off, map containers simply stay empty.
    if ((string) setting('maps_enabled', '1') !== '1') return false;
    return in_array(basename($_SERVER['SCRIPT_NAME'] ?? ''), [
        'map.php', 'hotspots.php', 'passport-view.php', 'pickup-create.php',
        'pickup-view.php', 'reports.php', 'assignment-view.php', 'route.php',
        'facility.php', 'report.php', 'track.php',
    ], true);
}

function csrf_field(): string { return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">'; }

// ---------- Views ----------
function view(string $tpl, array $vars = []): void {
    extract($vars, EXTR_SKIP);
    include dirname(__DIR__) . '/views/' . $tpl . '.php';
}

// ---------- Formatting ----------
function fmt_kg($kg): string { return rtrim(rtrim(number_format((float) $kg, 2, '.', ','), '0'), '.') . ' kg'; }
function fmt_dt(?string $dt, string $fmt = 'd M Y, h:i A'): string {
    if (!$dt) return '—';
    return date($fmt, strtotime($dt));
}
function fmt_num($n): string { return number_format((float) $n); }
function initials(string $name): string {
    $p = preg_split('/\s+/', trim($name));
    return strtoupper(substr($p[0] ?? 'U', 0, 1) . (isset($p[1]) ? substr($p[1], 0, 1) : ''));
}
function status_badge(string $status, array $labels, array $colors): string {
    $color = $colors[$status] ?? 'secondary';
    $label = e($labels[$status] ?? ucwords(strtolower(str_replace('_', ' ', $status))));
    return '<span class="badge text-bg-' . $color . ' status-badge">' . $label . '</span>';
}
function pickup_badge(string $s): string { return status_badge($s, PICKUP_STATUS_LABELS, PICKUP_STATUS_COLORS); }
function waste_badge(string $s): string { return status_badge($s, WASTE_STAGE_LABELS, WASTE_STAGE_COLORS); }
function report_badge(string $s): string { return status_badge($s, REPORT_STATUS_LABELS, REPORT_STATUS_COLORS); }

function time_ago(?string $dt): string {
    if (!$dt) return '—';
    $diff = time() - strtotime($dt);
    if ($diff < 60) return 'just now';
    if ($diff < 3600) return floor($diff / 60) . ' min ago';
    if ($diff < 86400) return floor($diff / 3600) . ' hr ago';
    if ($diff < 2592000) return floor($diff / 86400) . ' days ago';
    return fmt_dt($dt, 'd M Y');
}

// ---------- Settings ----------
function setting(string $key, $default = null) {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try { foreach (Database::all('SELECT setting_key, setting_value FROM settings') as $r) $cache[$r['setting_key']] = $r['setting_value']; }
        catch (Throwable $e) { $cache = []; }
    }
    return $cache[$key] ?? $default;
}

// ---------- Pagination ----------
function paginate_request(int $total, int $perPage = PER_PAGE): array {
    $pages = max(1, (int) ceil($total / $perPage));
    $page  = min($pages, max(1, (int) ($_GET['page'] ?? 1)));
    return ['page' => $page, 'pages' => $pages, 'offset' => ($page - 1) * $perPage, 'limit' => $perPage, 'total' => $total];
}
function pagination_links(array $pg, array $extraQuery = []): string {
    if ($pg['pages'] <= 1) return '';
    $qs = function (int $p) use ($extraQuery) {
        return '?' . http_build_query(array_merge($_GET, $extraQuery, ['page' => $p]));
    };
    $html = '<nav><ul class="pagination pagination-sm justify-content-center mt-3">';
    $html .= '<li class="page-item ' . ($pg['page'] <= 1 ? 'disabled' : '') . '"><a class="page-link" href="' . e(urldecode($qs($pg['page'] - 1))) . '">&laquo;</a></li>';
    for ($i = 1; $i <= $pg['pages']; $i++) {
        if ($pg['pages'] > 9 && abs($i - $pg['page']) > 3 && $i !== 1 && $i !== $pg['pages']) {
            if (abs($i - $pg['page']) === 4) $html .= '<li class="page-item disabled"><span class="page-link">…</span></li>';
            continue;
        }
        $html .= '<li class="page-item ' . ($i === $pg['page'] ? 'active' : '') . '"><a class="page-link" href="' . e(urldecode($qs($i))) . '">' . $i . '</a></li>';
    }
    $html .= '<li class="page-item ' . ($pg['page'] >= $pg['pages'] ? 'disabled' : '') . '"><a class="page-link" href="' . e(urldecode($qs($pg['page'] + 1))) . '">&raquo;</a></li>';
    return $html . '</ul></nav>';
}

// ---------- Secure upload ----------
function handle_upload(?array $file, string $subdir = 'waste', array $allowedExt = ['jpg','jpeg','png','webp']): ?string {
    if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
    if ($file['error'] === UPLOAD_ERR_INI_SIZE || $file['error'] === UPLOAD_ERR_FORM_SIZE) throw new RuntimeException('File exceeds the maximum size of ' . round(UPLOAD_MAX_BYTES / 1048576) . ' MB.');
    if ($file['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Upload failed (code ' . $file['error'] . ').');
    if ($file['size'] <= 0 || $file['size'] > UPLOAD_MAX_BYTES) throw new RuntimeException('File exceeds the maximum size of ' . round(UPLOAD_MAX_BYTES / 1048576) . ' MB.');
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExt, true)) throw new RuntimeException('File type not allowed.');
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = $finfo->file($file['tmp_name']);
    $allowedMime = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($allowedMime[$mime]) || $allowedMime[$mime] !== $ext) throw new RuntimeException('File content is not a valid image.');
    $info = @getimagesize($file['tmp_name']);
    if ($info === false) throw new RuntimeException('File is not a readable image.');
    if ($info[0] < 20 || $info[1] < 20) throw new RuntimeException('Image dimensions are too small.');
    $dir = UPLOAD_DIR . '/' . preg_replace('/[^a-z0-9_\-]/', '', $subdir);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $name = date('Ymd') . '-' . bin2hex(random_bytes(8)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) throw new RuntimeException('Could not store uploaded file.');
    return $subdir . '/' . $name;
}
function upload_url(?string $rel): ?string { return $rel ? url(UPLOAD_URL . '/' . $rel) : null; }

// ---------- Validation ----------
function val_str(array $src, string $key, int $max = 500, bool $required = true, ?string $field = null, int $min = 0): string {
    $v = trim((string) ($src[$key] ?? ''));
    if ($v === '' && $required) throw new InvalidArgumentException(($field ?? ucfirst($key)) . ' is required.');
    if ($v !== '' && $min > 0 && mb_strlen($v) < $min) throw new InvalidArgumentException(($field ?? ucfirst($key)) . ' must be at least ' . $min . ' characters.');
    if (mb_strlen($v) > $max) throw new InvalidArgumentException(($field ?? ucfirst($key)) . " must be at most $max characters.");
    return $v;
}

/**
 * Validate + normalize an Indian mobile number.
 * Canonical storage format: exactly 10 digits, first digit 6-9 (e.g. 9876543210).
 * Accepts common input forms: 9876543210, +91 98765 43210, +91-9876543210, 09876543210, 0091 9876543210.
 * Returns the normalized 10-digit string (or null when optional + empty). Throws on invalid input.
 */
function val_phone(array $src, string $key = 'phone', bool $required = true, ?string $field = null): ?string {
    $raw = (string) ($src[$key] ?? '');
    $v = preg_replace('/[\s\-\.\(\)\/]/', '', trim($raw)); // strip separators users commonly type
    // strip country code / leading zero prefixes only when a 10-digit tail follows
    if (preg_match('/^(?:\+?0091|\+91|91|0)(\d{10})$/', $v, $m)) $v = $m[1];
    if ($v === '') {
        if ($required) throw new InvalidArgumentException(t('val.phone_required'));
        return null;
    }
    if (!preg_match('/^[6-9]\d{9}$/', $v)) throw new InvalidArgumentException(t('val.phone_invalid'));
    // obvious placeholder values (same digit repeated / well-known sequences)
    if (preg_match('/^(\d)\1{9}$/', $v) || $v === '0123456789' || $v === '9876543210') throw new InvalidArgumentException(t('val.phone_placeholder'));
    return $v;
}
function val_float(array $src, string $key, float $min = 0, float $max = 100000, bool $required = true, ?string $field = null): ?float {
    $v = $src[$key] ?? null;
    if (($v === null || $v === '') && !$required) return null;
    if (!is_numeric($v)) throw new InvalidArgumentException(($field ?? ucfirst($key)) . ' must be a number.');
    $v = (float) $v;
    if ($v < $min || $v > $max) throw new InvalidArgumentException(($field ?? ucfirst($key)) . " must be between $min and $max.");
    return round($v, 3);
}
function val_email(array $src, string $key = 'email'): string {
    $v = (string) ($src[$key] ?? '');
    // strip invisible characters that sneak in via copy-paste (NBSP, zero-width, BOM, soft hyphen, fullwidth space)
    $v = str_replace(["\u{00A0}", "\u{200B}", "\u{200C}", "\u{200D}", "\u{FEFF}", "\u{00AD}", "\u{3000}"], '', $v);
    $v = trim((string) $v);
    if (!filter_var($v, FILTER_VALIDATE_EMAIL) || strlen($v) > 190) throw new InvalidArgumentException('Please enter a valid email address.');
    return strtolower($v);
}
function val_latlng(array $src): array {
    $lat = $src['latitude'] ?? null; $lng = $src['longitude'] ?? null;
    if ($lat === null || $lat === '' || $lng === null || $lng === '') return [null, null];
    if (!is_numeric($lat) || !is_numeric($lng) || abs((float) $lat) > 90 || abs((float) $lng) > 180) throw new InvalidArgumentException('Invalid coordinates.');
    return [round((float) $lat, 6), round((float) $lng, 6)];
}

// ---------- Haversine distance (km) ----------
function geo_distance_km(float $lat1, float $lng1, float $lat2, float $lng2): float {
    $r = 6371; $dLat = deg2rad($lat2 - $lat1); $dLng = deg2rad($lng2 - $lng1);
    $a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;
    return $r * 2 * atan2(sqrt($a), sqrt(1 - $a));
}

// ---------- Codes ----------
function rand_code(string $prefix): string { return $prefix . '-' . date('ymd') . '-' . strtoupper(bin2hex(random_bytes(3))); }

// ---------- Request helpers ----------
/**
 * v2.4.0 — Server-side re-encode of an uploaded image.
 * Decodes the stored file with GD and re-writes it as a clean JPEG (quality 85).
 * Strips EXIF/metadata and any embedded payloads (a classic upload-attack surface).
 * Graceful: if GD is unavailable the original validated file is kept untouched.
 */
function reencode_upload(?string $relPath, string $subdir = 'waste'): ?string {
    if (!$relPath) return $relPath;
    if (!function_exists('imagecreatefromjpeg') || !function_exists('getimagesize')) return $relPath;
    $abs = dirname(__DIR__) . '/uploads/' . $relPath;
    if (!is_file($abs)) return $relPath;
    $info = @getimagesize($abs);
    if (!$info) return $relPath;
    $img = match ($info[2]) {
        IMAGETYPE_JPEG => @imagecreatefromjpeg($abs),
        IMAGETYPE_PNG => @imagecreatefrompng($abs),
        IMAGETYPE_WEBP => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($abs) : null,
        default => null,
    };
    if (!$img) return $relPath; // decode failed → keep original (already validated by handle_upload)
    // Orient using EXIF (JPEG only) so phone photos are not stored sideways
    if ($info[2] === IMAGETYPE_JPEG && function_exists('exif_read_data')) {
        $exif = @exif_read_data($abs);
        $o = (int) ($exif['Orientation'] ?? 1);
        $img = match ($o) {
            3 => imagerotate($img, 180, 0),
            6 => imagerotate($img, -90, 0),
            8 => imagerotate($img, 90, 0),
            default => $img,
        };
    }
    $tmp = $abs . '.re.jpg';
    $ok = false;
    if (imagejpeg($img, $tmp, 85)) {
        $newName = preg_replace('/\.(jpg|jpeg|png|webp)$/i', '.jpg', $relPath);
        $newAbs = dirname(__DIR__) . '/uploads/' . $newName;
        if ($ok = @rename($tmp, $newAbs)) {
            if ($newName !== $relPath) @unlink($abs); // extension changed (png/webp → jpg)
            $relPath = $newName;
        }
    }
    if (!$ok && is_file($tmp)) @unlink($tmp);
    if (function_exists('imagedestroy')) imagedestroy($img);
    return $relPath;
}

function post_val(string $key, $default = null) { return $_POST[$key] ?? $default; }
function get_val(string $key, $default = null) { return $_GET[$key] ?? $default; }
function is_post(): bool { return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'; }
function client_ip(): string { return substr($_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0', 0, 45); }
function client_agent(): string { return substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255); }

// ================= Audit trail presentation (v2.16.0) =================

/**
 * Action filter CATEGORIES (v2.17.0) — mapping only; historical action values are
 * never rewritten. Each category lists the underlying technical codes it covers.
 */
function audit_action_categories(): array
{
    return [
        'login'       => ['label' => 'Login',                 'actions' => ['LOGIN', 'LOGIN_SUCCESS', 'LOGIN_FAILED', 'ACCOUNT_LOCKED']],
        'logout'      => ['label' => 'Logout',                'actions' => ['LOGOUT']],
        'security'    => ['label' => 'Security / Session',    'actions' => ['PASSWORD_CHANGED', 'PASSWORD_RESET_REQUESTED', 'PASSWORD_RESET_DONE', 'FORCE_LOGOUT_ALL', 'FORCE_LOGOUT_DENIED', 'SESSIONS_REVOKED']],
        'user_role'   => ['label' => 'User & Role Changes',   'actions' => ['REGISTER', 'PROFILE_UPDATED']],
        'pickup'      => ['label' => 'Pickup Changes',        'actions' => ['PICKUP_CREATED', 'PICKUP_ASSIGNED', 'PICKUP_COMPLETED', 'PICKUP_CANCELLED']],
        'shift_punch' => ['label' => 'Shift / Punch Changes', 'actions' => ['DRIVER_PUNCH_IN', 'DRIVER_PUNCH_OUT']],
        'shift_pdf'   => ['label' => 'Shift PDF Download',    'actions' => ['SHIFT_PDF', 'SHIFT_REPORT_PDF', 'SHIFT_PDF_FAILED', 'SHIFT_PDF_DENIED', 'SHIFT_REPORT_NO_DATA']],
        'waste'       => ['label' => 'Waste Changes',         'actions' => ['WASTE_RECEIVED', 'WASTE_STAGE_CHANGE', 'WASTE_FINAL_OUTCOME', 'REPORT_CREATED']],
        'waste_scan'  => ['label' => 'Waste Scan',            'actions' => ['SCAN_SAVED']],
        'audit_export'=> ['label' => 'Audit Log Export',      'actions' => ['AUDIT_EXPORTED', 'AUDIT_EXPORT_PDF', 'AUDIT_EXPORT_FAILED']],
        'announcement'=> ['label' => 'Announcement',          'actions' => ['ANNOUNCEMENT_CREATED', 'ANNOUNCEMENT_UPDATED', 'ANNOUNCEMENT_PUBLISHED', 'ANNOUNCEMENT_UNPUBLISHED', 'ANNOUNCEMENT_DELETED']],
        'other'       => ['label' => 'Other Activity',        'actions' => ['CREATE', 'UPDATE', 'DELETE', 'STATUS_CHANGE', 'BADGE_SAVE', 'BADGE_TOGGLE', 'HOTSPOT_RECOMPUTE', 'QUIZ_ATTEMPT', 'OTP_REQUESTED', 'EMAIL_LINK_SENT']],
    ];
}

/** Readable labels for a dynamic PICKUP_x or REPORT_x action (category mapping uses exact codes above). */
function audit_action_label(string $code): string
{
    static $map = [
        'LOGIN_SUCCESS' => 'Login Successful', 'LOGIN' => 'Login', 'LOGIN_FAILED' => 'Login Failed',
        'LOGOUT' => 'Logged Out', 'ACCOUNT_LOCKED' => 'Account Temporarily Locked',
        'PASSWORD_CHANGED' => 'Password Changed', 'PASSWORD_RESET_REQUESTED' => 'Password Reset Requested',
        'PASSWORD_RESET_DONE' => 'Password Reset Completed', 'REGISTER' => 'User Registered',
        'EMAIL_VERIFIED' => 'Email Verified', 'EMAIL_LINK_SENT' => 'Verification Email Sent',
        'MOBILE_VERIFIED' => 'Mobile Number Verified', 'OTP_REQUESTED' => 'OTP Requested',
        'FORCE_LOGOUT_ALL' => 'All User Sessions Invalidated', 'FORCE_LOGOUT_DENIED' => 'Force Logout Denied (Re-auth Failed)',
        'SESSIONS_REVOKED' => 'Sessions Revoked by Admin',
        'SETTING_CHANGED' => 'Setting Changed', 'SETTINGS_UPDATED' => 'Settings Updated',
        'PICKUP_CREATED' => 'Pickup Request Created', 'PICKUP_ASSIGNED' => 'Pickup Assigned',
        'PICKUP_COMPLETED' => 'Pickup Completed', 'PICKUP_CANCELLED' => 'Pickup Cancelled',
        'SHIFT_PDF' => 'Shift PDF Downloaded', 'SHIFT_PDF_FAILED' => 'Shift PDF Generation Failed',
        'SHIFT_PDF_DENIED' => 'Shift PDF Access Denied', 'SHIFT_REPORT_PDF' => 'Shift Report PDF Downloaded',
        'SHIFT_REPORT_NO_DATA' => 'Shift Report — No Data', 'DRIVER_PUNCH_IN' => 'Shift Started (Punch In)',
        'DRIVER_PUNCH_OUT' => 'Shift Ended (Punch Out)',
        'REPORT_CREATED' => 'Waste Report Created', 'WASTE_RECEIVED' => 'Waste Received at Facility',
        'WASTE_STAGE_CHANGE' => 'Waste Stage Changed', 'WASTE_FINAL_OUTCOME' => 'Waste Final Outcome Recorded',
        'SCAN_SAVED' => 'Waste Scan Saved',
        'ANNOUNCEMENT_CREATED' => 'Announcement Created', 'ANNOUNCEMENT_UPDATED' => 'Announcement Updated',
        'ANNOUNCEMENT_PUBLISHED' => 'Announcement Published', 'ANNOUNCEMENT_UNPUBLISHED' => 'Announcement Unpublished',
        'ANNOUNCEMENT_DELETED' => 'Announcement Deleted',
        'BADGE_SAVE' => 'Badge Saved', 'BADGE_TOGGLE' => 'Badge Toggled', 'HOTSPOT_RECOMPUTE' => 'Hotspots Recomputed',
        'PROFILE_UPDATED' => 'Profile Updated', 'QUIZ_ATTEMPT' => 'Quiz Attempted',
        'CREATE' => 'Record Created', 'UPDATE' => 'Record Updated', 'DELETE' => 'Record Deleted',
        'STATUS_CHANGE' => 'Status Changed', 'AUDIT_EXPORTED' => 'Audit Log Exported (CSV)',
        'AUDIT_EXPORT_PDF' => 'Audit Log Exported (PDF)',
    ];
    if (isset($map[$code])) return $map[$code];
    if (str_starts_with($code, 'PICKUP_')) return 'Pickup Status Changed (' . ucwords(strtolower(substr($code, 7)), '_') . ')';
    if (str_starts_with($code, 'REPORT_')) return 'Waste Report Status Changed (' . ucwords(strtolower(substr($code, 7)), '_') . ')';
    return ucwords(strtolower(str_replace('_', ' ', $code)));
}

/** Central MODULE code → readable name. DB values stay untouched. */
function audit_module_label(string $module): string
{
    static $map = [
        'auth' => 'Authentication', 'account' => 'Account', 'pickup' => 'Pickup',
        'waste' => 'Waste Management', 'waste_scans' => 'Waste Scanner', 'reports' => 'Waste Reports',
        'driver_shifts' => 'Driver Shifts', 'tracking' => 'Tracking', 'notifications' => 'Notifications',
        'announcements' => 'Announcements', 'settings' => 'System Settings', 'badges' => 'Badges',
        'learning' => 'Learning', 'verification' => 'Verification', 'analytics' => 'Analytics',
        'audit' => 'Audit Logs', 'pickups' => 'Pickup', 'routes' => 'Routes', 'vehicles' => 'Vehicles',
        'facilities' => 'Facilities', 'users' => 'Users', 'hotspots' => 'Hotspots',
    ];
    return $map[$module] ?? ucwords($module);
}

/** Human IP display: ONLY the actual stored IPv6 loopback (::1) is shown as localhost — never fabricated. */
function audit_display_ip(?string $ip): string
{
    $ip = trim((string) $ip);
    if ($ip === '') return '—';
    if ($ip === '::1') return '127.0.0.1 (localhost)';
    return $ip;
}

/** Keys whose values must NEVER appear in any audit display/export. */
function audit_is_sensitive_key(string $k): bool
{
    return (bool) preg_match('/pass|token|secret|csrf|session|api_key|apikey|hash|authorization|cookie/i', $k);
}

/** Turn stored old/new values into readable "Label: value" pairs (JSON → lines; redacts secrets). */
function audit_details_pairs(?string $old, ?string $new): array
{
    $pairs = [];
    foreach (['Old' => $old, 'New' => $new] as $tag => $raw) {
        $raw = trim((string) $raw);
        if ($raw === '') continue;
        $j = json_decode($raw, true);
        if (is_array($j)) {
            foreach ($j as $k => $v) {
                if (!is_string($k)) continue;
                $val = is_scalar($v) ? (string) $v : json_encode($v, JSON_UNESCAPED_UNICODE);
                if (audit_is_sensitive_key($k)) $val = '•••• (redacted)';
                $label = ucwords(str_replace('_', ' ', $k));
                $pairs[] = ($tag === 'Old' && count($j) > 1 ? '' : '') . $label . ': ' . mb_strimwidth((string) $val, 0, 160, '…');
            }
        } elseif (preg_match('/^([a-z_0-9 ]+)= (.+)$/i', $raw, $m) || preg_match('/^([a-z_0-9 ]+)=?(.*)$/', $raw, $m)) {
            $pairs[] = (audit_is_sensitive_key($m[1]) ? ucwords(str_replace('_', ' ', $m[1])) . ': •••• (redacted)' : ucwords(str_replace('_', ' ', $m[1])) . ': ' . mb_strimwidth(trim($m[2]), 0, 160, '…'));
        } else {
            $pairs[] = $tag . ': ' . mb_strimwidth($raw, 0, 180, '…');
        }
    }
    return $pairs;
}

/** Short one-line summary for table cells / CSV. */
function audit_details_summary(?string $old, ?string $new, int $max = 90): string
{
    $s = implode(' · ', audit_details_pairs($old, $new));
    return $s === '' ? '—' : mb_strimwidth($s, 0, $max, '…');
}

/**
 * Server-side audit filter builder (shared by admin/audit.php and admin/audit-export.php).
 * Returns ['where','params','applied','mod','act','uid','range','from','to','ip','q','per'].
 * Every value is validated server-side; queries use prepared statements.
 */
function audit_filters(): array
{
    $mod = (string) get_val('module', '');
    $act = (string) get_val('action', '');
    $uid = (string) get_val('user', '');
    $range = (string) get_val('range', '');
    $from = (string) get_val('from', '');
    $to = (string) get_val('to', '');
    $ip = trim((string) get_val('ip', ''));
    $q = trim((string) get_val('q', ''));
    $per = (int) get_val('per', 25);
    if (!in_array($per, [25, 50, 100], true)) $per = 25;
    if (!in_array($range, ['today', '7', '30', 'custom', ''], true)) $range = '';
    foreach (['from' => &$from, 'to' => &$to] as $k => $v2) {
        if ($v2 !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $v2)) $$k = '';
    }

    $where = '1=1'; $params = []; $applied = [];
    if ($mod !== '') { $where .= ' AND a.module = ?'; $params[] = $mod; $applied[] = 'Module: ' . audit_module_label($mod); }
    if ($act !== '') {
        $cat = audit_action_categories()[$act] ?? null;
        if ($cat !== null) { // v2.17.0: action filter sends a readable CATEGORY key
            $where .= ' AND a.action IN (' . implode(',', array_fill(0, count($cat['actions']), '?')) . ')';
            array_push($params, ...$cat['actions']);
            $applied[] = 'Action: ' . $cat['label'];
        } else {            // back-compat: a literal technical action code
            $where .= ' AND a.action = ?'; $params[] = $act;
            $applied[] = 'Action: ' . audit_action_label($act);
        }
    }
    if ($uid !== '' && $uid !== 'none') { $where .= ' AND a.user_id = ?'; $params[] = (int) $uid; $applied[] = 'User #' . (int) $uid; }
    if ($uid === 'none') { $where .= ' AND a.user_id IS NULL'; $applied[] = 'User: system'; }
    if ($range === 'today') { $where .= ' AND a.created_at >= CURDATE()'; $applied[] = 'Date: Today'; }
    elseif ($range === '7') { $where .= ' AND a.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)'; $applied[] = 'Date: Last 7 Days'; }
    elseif ($range === '30') { $where .= ' AND a.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)'; $applied[] = 'Date: Last 30 Days'; }
    elseif ($range === 'custom') {
        if ($from !== '') { $where .= ' AND a.created_at >= ?'; $params[] = $from . ' 00:00:00'; $applied[] = 'From: ' . $from; }
        if ($to !== '') { $where .= ' AND a.created_at <= ?'; $params[] = $to . ' 23:59:59'; $applied[] = 'To: ' . $to; }
    }
    if ($ip !== '') { $where .= ' AND a.ip LIKE ?'; $params[] = $ip . '%'; $applied[] = 'IP: ' . $ip . '*'; } // server-side only since v2.17.0 (no UI filter)
    if ($q !== '') {
        // v2.17.0 — ONE global search: user/action/module/record/ip always; metadata
        // (old/new values) is searched ONLY on rows whose metadata contains NO sensitive
        // keys — secrets can never be matched, surfacing or exposed through search.
        $SENS = ['%pass%', '%token%', '%secret%', '%csrf%', '%session%', '%api%key%', '%hash%', '%authorization%']; // static — no user input, safe inline
        $base = ['u.name', 'u.email', 'CAST(a.record_id AS CHAR)', 'a.ip', 'a.action', 'a.module'];
        $qCond = '(' . implode(' LIKE ? OR ', $base) . ' LIKE ?';
        array_push($params, ...array_fill(0, count($base), "%$q%"));
        $guardOld = "a.old_value IS NULL OR (a.old_value NOT LIKE '%pass%'" . implode('', array_map(fn($p) => " AND a.old_value NOT LIKE '$p'", $SENS)) . ')';
        $guardNew = "a.new_value IS NULL OR (a.new_value NOT LIKE '%pass%'" . implode('', array_map(fn($p) => " AND a.new_value NOT LIKE '$p'", $SENS)) . ')';
        $qCond .= " OR (($guardOld) AND ($guardNew) AND (a.old_value LIKE ? OR a.new_value LIKE ?))";
        array_push($params, "%$q%", "%$q%");
        // human-label match (e.g. "shift pdf downloaded" finds SHIFT_PDF rows)
        foreach (Database::all('SELECT DISTINCT action FROM audit_logs') as $r) {
            if (stripos(audit_action_label($r['action']), $q) !== false || stripos($r['action'], $q) !== false) {
                $qCond .= ' OR a.action = ?'; $params[] = $r['action'];
            }
        }
        foreach (Database::all('SELECT DISTINCT module FROM audit_logs') as $r) {
            if (stripos(audit_module_label($r['module']), $q) !== false || stripos($r['module'], $q) !== false) {
                $qCond .= ' OR a.module = ?'; $params[] = $r['module'];
            }
        }
        $where .= ' AND ' . $qCond . ')';
        $applied[] = 'Search: "' . $q . '"';
    }
    return compact('where', 'params', 'applied', 'mod', 'act', 'uid', 'range', 'from', 'to', 'ip', 'q', 'per');
}

/** Short exception class name for audit metadata (never the message/paths). */
function short_class(Throwable $e): string
{
    return (new ReflectionClass($e))->getShortName();
}
