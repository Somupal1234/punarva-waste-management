<?php
/**
 * PUNARVA — v2.4.2 schema self-heal (root-cause fix for collector-login SQLSTATE 42S22
 * "Unknown column 'driver_user_id'").
 *
 * WHY THIS EXISTS: v2.4.0 introduced live truck tracking. Its schema is additive and ships
 * as a proper, idempotent migration (database/upgrade-v2.4.0.sql): vehicles.driver_user_id
 * (user↔vehicle link used for server-side RBAC), driver_shifts, driver_locations and
 * waste_reports.accuracy_m/location_captured_at. If an existing install runs the new code
 * against a pre-2.4.0 database, the first tracking query fails with SQLSTATE 42S22.
 *
 * WHAT THIS DOES (no columns invented — only the SHIPPED migration is applied):
 *   1. Fast path: settings.db_schema_version = '2.4.0' → ready (one cached SELECT).
 *   2. Otherwise: verify via information_schema. Present → set the flag, ready.
 *   3. Missing  → apply database/upgrade-v2.4.0.sql once (statement by statement,
 *      duplicate-object errors tolerated), re-verify, set the flag.
 *   4. If the schema still cannot be prepared (e.g. DB user without DDL rights, file
 *      missing), the app DEGRADES GRACEFULLY: pnv_schema_ready() returns false and the
 *      tracking features show a clean "database upgrade required" message instead of any
 *      SQL error. Everything else keeps working.
 *
 * These functions NEVER throw and NEVER expose SQL errors to users (details go to the log).
 */

/** Raw information_schema check — no caching, no side effects. Throws nothing. */
function pnv_schema_objects_present(): bool {
    try {
        $row = Database::one(
            "SELECT (SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'driver_shifts')
                  + (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'vehicles' AND column_name = 'driver_user_id')
                  + (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'waste_reports' AND column_name = 'accuracy_m') AS n"
        );
        return (bool) $row && (int) $row['n'] === 3;
    } catch (Throwable $e) {
        error_log('PUNARVA schema check failed: ' . $e->getMessage());
        return false;
    }
}

function pnv_schema_ready(): bool {
    static $ready = null;
    if ($ready !== null) return $ready;
    try {
        if ((string) setting('db_schema_version', '') === '2.4.0') return $ready = true;
        if (!pnv_schema_objects_present()) return $ready = false;
        Database::run("INSERT INTO settings (setting_key, setting_value, description, setting_group)
                       VALUES ('db_schema_version', '2.4.0', 'Applied database schema version (set by the app after verifying required objects)', 'system')
                       ON DUPLICATE KEY UPDATE setting_value = '2.4.0'");
        return $ready = true;
    } catch (Throwable $e) {
        error_log('PUNARVA schema flag update failed: ' . $e->getMessage());
        return $ready = false;
    }
}

/** Apply the shipped, idempotent v2.4.0 migration once. Never throws. */
function pnv_apply_shipped_migration(): bool {
    $file = dirname(__DIR__) . '/database/upgrade-v2.4.0.sql';
    if (!is_file($file)) { error_log('PUNARVA schema upgrade file missing: ' . $file); return false; }
    $sql = (string) @file_get_contents($file);
    // strip -- comment lines, split on statement-terminating semicolons (file contains no
    // routines/triggers and no semicolons inside string literals — verified in v2.4.0)
    $sql = preg_replace('/^--.*$/m', '', $sql);
    $stmts = array_values(array_filter(array_map('trim', preg_split('/;[\s]*(?:\r?\n|$)/', $sql)), fn($s) => $s !== ''));
    $tolerated = [1050, 1060, 1061, 1091]; // table/column/index already exists — idempotency
    foreach ($stmts as $stmt) {
        try {
            Database::run($stmt);
        } catch (PDOException $e) {
            $mysqlCode = (int) ($e->errorInfo[1] ?? 0);
            if (!in_array($mysqlCode, $tolerated, true)) {
                error_log('PUNARVA schema upgrade statement failed: ' . $e->getMessage());
                return false;
            }
        } catch (Throwable $e) {
            error_log('PUNARVA schema upgrade failed: ' . $e->getMessage());
            return false;
        }
    }
    return true;
}

/**
 * Boot-time entry point (called from init.php). Best-effort self-heal: if the tracking
 * schema is missing, apply the shipped migration once; then record the version flag.
 */
function pnv_ensure_schema(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        if (pnv_schema_ready()) return;
        if (!pnv_apply_shipped_migration()) return; // graceful mode — features degrade cleanly
        if (!pnv_schema_objects_present()) { error_log('PUNARVA schema upgrade did not produce the required objects.'); return; }
        Database::run("INSERT INTO settings (setting_key, setting_value, description, setting_group)
                       VALUES ('db_schema_version', '2.4.0', 'Applied database schema version (set by the app after verifying required objects)', 'system')
                       ON DUPLICATE KEY UPDATE setting_value = '2.4.0'");
    } catch (Throwable $e) {
        error_log('PUNARVA ensure_schema failed (non-fatal): ' . $e->getMessage());
    }
}
