<?php
/**
 * Minimal i18n layer: English base + Hindi + Bengali for common UI strings.
 * Usage: t('nav.home') – falls back to English, then a humanised key.
 */
function init_language(): void
{
    $supported = ['en', 'hi', 'bn'];
    $dbDefault = (string) setting('default_language', 'en');
    if (!in_array($dbDefault, $supported, true)) $dbDefault = 'en';
    $lang = $dbDefault;
    if (isset($_GET['lang']) && in_array($_GET['lang'], $supported, true)) {
        $lang = $_GET['lang'];
        $_SESSION['lang'] = $lang;
        if (current_user()) Database::update('users', ['language' => $lang], 'id = ?', [current_user()['id']]);
    } elseif (!empty($_SESSION['lang']) && in_array($_SESSION['lang'], $supported, true)) {
        $lang = $_SESSION['lang'];
    } elseif (current_user() && !empty(current_user()['language'])) {
        $lang = current_user()['language'];
    }
    $GLOBALS['__lang'] = $lang;
    $GLOBALS['__dict'] = require __DIR__ . '/../lang/en.php';
    if ($lang !== 'en') {
        $localized = require __DIR__ . '/../lang/' . $lang . '.php';
        $GLOBALS['__dict'] = array_merge($GLOBALS['__dict'], $localized);
    }
}

function current_lang(): string { return $GLOBALS['__lang'] ?? 'en'; }

function lang_selector(): string
{
    $cur = current_lang();
    $uri = strtok($_SERVER['REQUEST_URI'] ?? '/', '?');
    $html = '<form method="get" class="lang-form" data-autosubmit><select name="lang" class="form-select form-select-sm" aria-label="Language">';
    foreach (['en' => 'English', 'hi' => 'हिन्दी', 'bn' => 'বাংলা'] as $code => $label) {
        $html .= '<option value="' . $code . '"' . ($code === $cur ? ' selected' : '') . '>' . $label . '</option>';
    }
    // preserve other query params
    foreach ($_GET as $k => $v) if ($k !== 'lang') $html .= '<input type="hidden" name="' . e($k) . '" value="' . e(is_array($v) ? implode(',', $v) : (string) $v) . '">';
    return $html . '</select></form>';
}

function t(string $key): string
{
    $dict = $GLOBALS['__dict'] ?? [];
    if (isset($dict[$key])) return $dict[$key];
    $part = substr($key, (int) strrpos($key, '.') + 1);
    return ucfirst(str_replace(['_', '-'], ' ', $part));
}
