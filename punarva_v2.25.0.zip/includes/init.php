<?php
/**
 * PUNARVA bootstrap – include this at the top of every entry point.
 */
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/settings_schema.php';
require_once __DIR__ . '/../config/database.php';

// ---- Autoload services / middleware / models ----
spl_autoload_register(function (string $class): void {
    foreach (['services', 'middleware', 'models'] as $dir) {
        $f = __DIR__ . '/../' . $dir . '/' . $class . '.php';
        if (is_file($f)) { require_once $f; return; }
    }
    // middleware classes live together in one shared file
    if (is_file(__DIR__ . '/../middleware/middleware.php')) {
        require_once __DIR__ . '/../middleware/middleware.php';
    }
});

// ---- Secure session ----
if (session_status() === PHP_SESSION_NONE) {
    // HTTPS ya preview-proxy ke peeche detect karo (X-Forwarded-Proto: https)
    $isHttps = (($_SERVER['HTTPS'] ?? '') === 'on')
        || strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
    session_name(SESSION_NAME);
    // Cookie flags (v2.12.0): ALWAYS-ENFORCED server-side — HttpOnly on, Secure automatic under
    // HTTPS, SameSite=Lax fixed. Not configurable via System Settings (read-only indicators there).
    $isHttpsProto = (($_SERVER['HTTPS'] ?? '') === 'on')
        || strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => BASE_PATH ?: '/',
        'secure'   => $isHttpsProto,
        'httponly' => true,
        'samesite' => $isHttpsProto ? 'None' : 'Lax', // HTTPS/proxy contexts need None+Secure (embedded preview); plain HTTP stays Lax
    ]);
    session_start();
    if ($isHttps) {
        // CHIPS partitioned cookie (modern browsers third-party context me bhi allow karte hain)
        header_remove('Set-Cookie');
        header('Set-Cookie: ' . SESSION_NAME . '=' . urlencode(session_id())
            . '; Path=' . (BASE_PATH ?: '/')
            . '; Secure; HttpOnly; SameSite=None; Partitioned', false);
    }
}

// ---- Session lifecycle (System Settings se, server-side enforced) ----
$_SESSION['last_activity'] = $_SESSION['last_activity'] ?? time();
$idleMin = min(1440, max(5, (int) setting('session_idle_minutes', 30))); // v2.15.0 clamped to settings-spec range (5–1440)
if (!empty($_SESSION['remember'])) $idleMin *= 6;                     // "Remember me" extends idle window
$maxHours = (int) setting('login_session_hours', 0);                  // hard cap (0 = off)
$forcedEpoch = (int) setting('sessions_epoch', 0);                    // "Force logout all"
$expiredIdle = time() - (int) $_SESSION['last_activity'] > $idleMin * 60;
$expiredMax  = $maxHours > 0 && !empty($_SESSION['auth_epoch']) && time() - (int) $_SESSION['auth_epoch'] > $maxHours * 3600;
$forcedOut   = $forcedEpoch > 0 && !empty($_SESSION['auth_epoch']) && (int) $_SESSION['auth_epoch'] <= $forcedEpoch;
if ($expiredIdle || $expiredMax || $forcedOut) {
    $wasLoggedIn = isset($_SESSION['user']);
    $_SESSION = [];
    session_destroy();
    session_start();
    session_regenerate_id(true);
    if ($wasLoggedIn) {
        flash('info', $forcedOut && !$expiredIdle && !$expiredMax
            ? 'You were logged out by the administrator.'
            : 'Your session expired. Please log in again.');
    }
}
$_SESSION['last_activity'] = time();

// ---- Role-based session enforcement (server-side registry; single-session roles: admin/collector) ----
if (!empty($_SESSION['user'])) {
    try {
        if (!SessionRegistry::enforce((int) $_SESSION['user']['id'])) {
            AuthService::logout(); // destroys session — flash needs a fresh one after this
            if (session_status() === PHP_SESSION_NONE) { session_start(); session_regenerate_id(true); }
            flash('info', 'Your session ended because your account was signed in from another device, or your session was revoked. Please log in again.');
            if (is_api_request()) { http_response_code(401); header('Content-Type: application/json'); echo json_encode(['success' => false, 'message' => 'Session revoked. Please log in again.', 'data' => null, 'errors' => []]); exit; }
            redirect('login.php');
        }
    } catch (Throwable $e) {
        error_log('SessionRegistry: ' . $e->getMessage());
        // Registry verify NA kar saken to single-session roles (admin/collector) ke liye bypass allowed NAHI — fail-closed.
        // Multi-session roles (citizen/business/recycler) availability ke liye fail-open; idle/absolute timeouts phir bhi lagu.
        if (SessionRegistry::singleSession((string) ($_SESSION['user']['role_code'] ?? ''))) {
            AuthService::logout();
            if (session_status() === PHP_SESSION_NONE) { session_start(); session_regenerate_id(true); }
            flash('warning', 'We could not verify your session security state. Please log in again.');
            if (is_api_request()) { http_response_code(401); header('Content-Type: application/json'); echo json_encode(['success' => false, 'message' => 'Session could not be verified. Please log in again.', 'data' => null, 'errors' => []]); exit; }
            redirect('login.php');
        }
    }
}

// ---- Maintenance / public-site walls (admins bypass; login page always reachable) ----
$__script = basename($_SERVER['SCRIPT_NAME'] ?? '');
$__isApi  = is_api_request();
$__user   = $_SESSION['user'] ?? null;
$__isAdmin = is_array($__user) && ($__user['role_code'] ?? '') === ROLE_ADMIN;
$__authPages = ['login.php', 'logout.php'];
if (!$__isAdmin && !in_array($__script, $__authPages, true)) {
    $__wall = null;
    if ((string) setting('maintenance_mode', '0') === '1') $__wall = (string) setting('maintenance_message', 'PUNARVA is undergoing scheduled maintenance. We will be back shortly.');
    if ($__wall !== null) {
        if ($__isApi) { http_response_code(503); header('Content-Type: application/json'); echo json_encode(['success' => false, 'message' => $__wall, 'data' => null, 'errors' => []]); exit; }
        http_response_code(503);
        ?><!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Maintenance · PUNARVA</title><link rel="icon" type="image/png" href="<?= url('assets/images/favicon.png') ?>">
        <link rel="stylesheet" href="<?= url('assets/vendor/bootstrap/bootstrap.min.css') ?>">
        <link rel="stylesheet" href="<?= url('assets/vendor/bootstrap-icons/bootstrap-icons.min.css') ?>">
        <link rel="stylesheet" href="<?= url('assets/css/style.css') ?>"></head>
        <body><div class="auth-page"><div class="container py-5 text-white text-center">
        <img src="<?= url('assets/images/logo-full.png') ?>" alt="PUNARVA" style="height:110px" class="mb-3">
        <h1 class="h3 fw-bold" style="color:#ffe9a8">Under Maintenance</h1>
        <p class="opacity-75 mx-auto" style="max-width:520px"><?= htmlspecialchars($__wall, ENT_QUOTES, 'UTF-8') ?></p>
        <a class="btn btn-light mt-2" href="<?= url('login.php') ?>">Admin login</a></div></div></body></html><?php
        exit;
    }
}

// ---- Security headers (PHP-side: Apache aur PHP dev server dono par kaam karte hain) ----
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(self), camera=(self), microphone=(), payment=()'); // v2.4.0 camera=(self) for citizen report capture
    // CSP: inline scripts/styles allowed (existing pages compatible); external origins blocked
    $csp = "default-src 'self'; "
         . "script-src 'self' 'unsafe-inline'; "
         . "style-src 'self' 'unsafe-inline'; "
         . "img-src 'self' data: https://tile.openstreetmap.org https://*.tile.openstreetmap.org; "
         . "font-src 'self' data:; "
         . "connect-src 'self'; "
         . "object-src 'none'; base-uri 'self'; form-action 'self'";
    // Clickjacking protection — sirf jab localhost/XAMPP par chal rahe ho
    // (embedded preview iframe na toote isliye proxy hosts par skip)
    $host = (string) ($_SERVER['HTTP_HOST'] ?? '');
    if (preg_match('/^(localhost|127\.0\.0\.1)(:\d+)?$/i', $host)) {
        header('X-Frame-Options: SAMEORIGIN');
        $csp .= "; frame-ancestors 'self'";
    }
    header('Content-Security-Policy: ' . $csp);
    // v2.5.0 — HSTS only in secure (HTTPS) contexts; plain HTTP/localhost unaffected
    if (!empty($isHttps)) header('Strict-Transport-Security: max-age=15552000; includeSubDomains');
}

// ---- Error handling ----
set_error_handler(function ($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) return false;
    throw new ErrorException($message, 0, $severity, $file, $line);
});
set_exception_handler(function (Throwable $e): void {
    if (!is_dir(LOG_DIR)) @mkdir(LOG_DIR, 0775, true);
    @file_put_contents(LOG_DIR . '/app-' . date('Y-m-d') . '.log',
        '[' . date('c') . '] ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() . PHP_EOL . $e->getTraceAsString() . PHP_EOL . PHP_EOL,
        FILE_APPEND);
    if (APP_DEBUG && !is_api_request()) {
        // v2.10.0 fix: show a friendly location hint only — NEVER the absolute server path
        echo '<div style="font-family:monospace;background:#fff3f3;border:1px solid #f5c2c7;padding:16px;margin:16px;border-radius:8px">'
           . '<strong>' . htmlspecialchars($e->getMessage()) . '</strong><br><small>'
           . htmlspecialchars(basename($e->getFile()) . ' @ line ' . $e->getLine()) . '</small></div>';
    } elseif (is_api_request()) {
        json_out(false, 'An internal error occurred.', null, [], 500);
    } else {
        http_response_code(500);
        include dirname(__DIR__) . '/500.php';
    }
    exit;
});

// ---- v2.4.2 schema self-heal (root-cause fix: SQLSTATE 42S22 driver_user_id on pre-2.4.0 DBs) ----
// Applies the SHIPPED idempotent migration database/upgrade-v2.4.0.sql once when the schema is
// missing; never throws, never shows SQL errors. If it cannot prepare the schema, tracking
// features degrade gracefully (see TrackingService) and everything else keeps working.
require_once __DIR__ . '/schema_check.php';
pnv_ensure_schema();

// ---- Language ----
require_once dirname(__DIR__) . '/views/components/badge-icons.php'; // built-in premium SVG badge library (v2.8.0)
require_once __DIR__ . '/lang.php';
init_language();

// ---- CSRF: enforce on every state-changing request (POST/PUT/DELETE) ----
CSRFMiddleware::enforce();

// ---- v2.14.0: AI scanner toggle retired — the scanner is always manual (no global toggle needed) ----
