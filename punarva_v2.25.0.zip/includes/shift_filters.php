<?php
/**
 * Shift-filter helpers (v2.9.0) — shared by admin/shifts.php, admin/shifts-pdf.php
 * and the collector's own-shift PDF path. All values are validated server-side;
 * SQL is always parameterised. Returns a human-readable filter label for reports.
 *
 * Filter contract (GET):
 *   range  = today|yesterday|week|month|custom
 *   from   = YYYY-MM-DD (custom only)   to = YYYY-MM-DD (custom only)
 *   driver = users.id (collector)       truck = vehicles.id
 *   status = ACTIVE|ENDED               gps   = live|stale|none
 */

function shift_filters_parse(): array
{
    $range = (string) get_val('range', 'all');
    if (!in_array($range, ['all', 'today', 'yesterday', 'week', 'month', 'custom'], true)) $range = 'all';
    $from = (string) get_val('from', '');
    $to = (string) get_val('to', '');
    $isDate = fn(string $s): bool => (bool) preg_match('/^\d{4}-\d{2}-\d{2}$/', $s) && strtotime($s);
    if ($range === 'custom' && !$isDate($from) && !$isDate($to)) $range = 'all';
    if ($range !== 'custom') { $from = ''; $to = ''; }
    $from = $isDate($from) ? $from : '';
    $to = $isDate($to) ? $to : '';

    $driver = (int) get_val('driver', 0);
    $truck = (int) get_val('truck', 0);
    $status = strtoupper((string) get_val('status', ''));
    if (!in_array($status, ['ACTIVE', 'ENDED'], true)) $status = '';
    $gps = strtolower((string) get_val('gps', ''));
    if (!in_array($gps, ['live', 'stale', 'none'], true)) $gps = '';

    $where = ['1=1'];
    $params = [];
    $labels = [];

    switch ($range) {
        case 'today':     $where[] = 'DATE(ds.started_at) = CURDATE()'; $labels[] = 'Date: Today (' . date('d M Y') . ')'; break;
        case 'yesterday': $where[] = 'DATE(ds.started_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)'; $labels[] = 'Date: Yesterday (' . date('d M Y', strtotime('-1 day')) . ')'; break;
        case 'week':      $where[] = 'ds.started_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)'; $labels[] = 'Date: Last 7 days'; break;
        case 'month':     $where[] = 'ds.started_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)'; $labels[] = 'Date: Last 30 days'; break;
        case 'custom':
            if ($from && $to)      { $where[] = 'DATE(ds.started_at) BETWEEN ? AND ?'; $params[] = $from; $params[] = $to; $labels[] = 'Date: ' . date('d M Y', strtotime($from)) . ' – ' . date('d M Y', strtotime($to)); }
            elseif ($from)         { $where[] = 'DATE(ds.started_at) >= ?'; $params[] = $from; $labels[] = 'Date: from ' . date('d M Y', strtotime($from)); }
            elseif ($to)           { $where[] = 'DATE(ds.started_at) <= ?'; $params[] = $to; $labels[] = 'Date: up to ' . date('d M Y', strtotime($to)); }
            break;
        default: $labels[] = 'Date: All';
    }
    if ($driver) { $where[] = 'ds.driver_user_id = ?'; $params[] = $driver; $labels[] = 'Driver: #' . $driver; }
    if ($truck)  { $where[] = 'ds.vehicle_id = ?'; $params[] = $truck; $labels[] = 'Truck: #' . $truck; }
    if ($status) { $where[] = 'ds.status = ?'; $params[] = $status; $labels[] = 'Status: ' . $status; }
    if ($gps === 'live')  { $where[] = 'ds.status = "ACTIVE" AND ds.last_ping_at >= DATE_SUB(NOW(), INTERVAL 60 SECOND)'; $labels[] = 'GPS: Live'; }
    if ($gps === 'stale') { $where[] = 'ds.status = "ACTIVE" AND ds.last_ping_at < DATE_SUB(NOW(), INTERVAL 60 SECOND)'; $labels[] = 'GPS: Stale'; }
    if ($gps === 'none')  { $where[] = 'ds.last_ping_at IS NULL AND NOT EXISTS (SELECT 1 FROM driver_locations dl WHERE dl.shift_id = ds.id)'; $labels[] = 'GPS: None'; }

    return [
        'where' => '(' . implode(') AND (', $where) . ')',
        'params' => $params,
        'labels' => $labels,
        'range' => $range, 'from' => $from, 'to' => $to,
        'driver' => $driver, 'truck' => $truck, 'status' => $status, 'gps' => $gps,
    ];
}

/** Human duration like "6h 05m" (or "45m"). */
function shift_duration(?string $start, ?string $end): string
{
    if (!$start || !$end) return '—';
    $s = strtotime($start);
    $e = strtotime($end);
    if ($e < $s) return '—';
    $m = (int) round(($e - $s) / 60);
    return sprintf('%dh %02dm', intdiv($m, 60), $m % 60);
}

/** App-format time "09:05 AM" / date "16 Sep 2026" (app timezone: Asia/Kolkata). */
function shift_time(?string $dt): string
{
    return $dt ? date('h:i A', strtotime($dt)) : '—';
}

function shift_date(?string $dt): string
{
    return $dt ? date('d M Y', strtotime($dt)) : '—';
}

/** Lightweight GPS badge for a shift row (no trail loaded). */
function shift_gps_badge(array $s): string
{
    if ($s['status'] === 'ACTIVE') {
        $st = TrackingService::statusFor($s['last_ping_at']);
        if ($st === 'LIVE') return '<span class="badge text-bg-success">LIVE</span>';
        if ($st === 'UPDATING') return '<span class="badge text-bg-warning text-dark">STALE</span>';
        return '<span class="badge text-bg-secondary">NO GPS</span>';
    }
    $has = (int) Database::val('SELECT COUNT(*) FROM driver_locations WHERE shift_id = ?', [(int) $s['id']]) > 0;
    return $has ? '<span class="badge text-bg-info">RECORDED</span>' : '<span class="badge text-bg-light border text-muted">NONE</span>';
}

/** Safe PDF filename fragment. */
function shift_pdf_safe(string $s): string
{
    return trim(preg_replace('/[^A-Za-z0-9._-]+/', '_', $s), '_');
}
