<?php
require_once __DIR__ . '/includes/init.php';
http_response_code(404);
$pageTitle = 'Page not found';
view('layouts/public_header', compact('pageTitle'));
?>
<section class="container py-5 text-center">
  <div style="font-size:5rem">🗂️</div>
  <h1 class="fw-bold">404 — Page not found</h1>
  <p class="text-muted">The page you are looking for was moved, removed or never existed.</p>
  <a class="btn btn-pnv px-4" href="<?= url('index.php') ?>"><i class="bi bi-house me-1"></i>Back to home</a>
</section>
<?php view('layouts/public_footer');
