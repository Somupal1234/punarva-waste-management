# PUNARVA — VS Code / Windows में कैसे चलाएँ (Quick Start)

> ⚠️ **ग़लती जो अक्सर होती है:** VS Code का **Live Server** extension (port 5500) PHP नहीं चला सकता —
> वह केवल static files दिखाता है (इसीलिए फ़ोल्डर की listing दिखती है)। PUNARVA को चलाने के लिए
> **PHP + MySQL** ज़रूरी है। नीचे दो तरीके हैं।

---

## ✅ तरीका 1 — XAMPP (recommended, सबसे आसान)

1. **XAMPP install करें** → https://www.apachefriends.org (अगर पहले से है तो skip)
2. XAMPP Control Panel खोलें → **Apache** और **MySQL** दोनों **Start** करें
3. पूरा `punarva` फ़ोल्डर copy करके यहाँ paste करें:
   ```
   C:\xampp\htdocs\punarva
   ```
4. Browser में खोलें: **http://localhost/phpmyadmin**
   - *Import* tab → इसी क्रम में import करें:
     1. `database/schema.sql`
     2. `database/seed.sql`
     3. `database/settings_defaults.sql`
     4. `database/migrations/` में से **002 → 003 → 004 → 005** (क्रम से; 001 सिर्फ marker है) — 004/005 badges system बनाते हैं, इनके बिना Badges पेज नहीं चलेगा।
   - **पुराना data रखना है?** (v2.0.x से upgrade) — नया install flow मत चलाओ; `database/upgrade-v2.1.0.sql` वाला पुराना upgrade path इस्तेमाल करें और migrations केवल बताए क्रम से। schema.sql पूरा `punarva_db` database DROP करके बनाता है — सिर्फ fresh install पर।
5. अब खोलें: **http://localhost/punarva/**
6. Login page पर **5 अलग tabs** हैं — Admin / Citizen / Collector / Recycler / Business.
   अपनी role का tab चुनकर login करें (गलत tab पर login करने पर साफ़ error दिखेगा)।
   Password: `Punarva@123` · **Forgot password?** link से reset link तुरंत screen पर मिलेगा (XAMPP में email server नहीं होता)।

**VS Code में code देखने/एडिट करने के लिए:** VS Code से `C:\xampp\htdocs\punarva` फ़ोल्डर खोलें —
code वहीं से एडिट करें, browser में http://localhost/punarva/ पर परिणाम देखें (Live Server की ज़रूरत नहीं)।

---

## ✅ तरीका 2 — VS Code Terminal में PHP built-in server

*(अगर XAMPP नहीं चलाना, पर PHP install है)*

1. **PHP install** होना चाहिए: check करें — VS Code terminal में टाइप करें `php -v`
   - नहीं है तो XAMPP के अंदर की PHP भी चलेगी: `C:\xampp\php\php.exe`
2. **MySQL चालू करें** (XAMPP → MySQL Start, या installed MySQL/MariaDB service)
   - DB import ऊपर step 4 जैसा ही (phpMyAdmin या command line से)
3. VS Code terminal में (punarva folder के अंदर):
   ```
   cd path\to\punarva
   php -S 127.0.0.1:8000
   ```
   (XAMPP की PHP use कर रहे हैं तो: `C:\xampp\php\php.exe -S 127.0.0.1:8000`)
4. Browser: **http://127.0.0.1:8000**

Windows में double-click के लिए project में `run-windows.bat` फ़ाइल भी दी गई है।

---

## सामान्य गलतियाँ

| समस्या | कारण / समाधान |
|---|---|
| Live Server (5500) पर फ़ाइलें listing दिखती हैं | Live Server PHP नहीं चलाता — तरीका 1 या 2 अपनाएँ |
| "Database connection failed" | MySQL start नहीं है या `schema.sql`/`seed.sql` import नहीं किए |
| Login नहीं हो रहा | seed.sql import करें — demo password: `Punarva@123` |
| Map tiles नहीं दिखते | Internet ज़रूरी है (OpenStreetMap tiles) — बाकी सब offline चलता है |

पूरी installation guide: `README.md` (section 3)
