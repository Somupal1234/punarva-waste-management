<?php
if (!defined('APP_NAME')) { require_once __DIR__ . '/includes/init.php'; }
http_response_code(500);
$pageTitle = 'Server error';
view('layouts/public_header', compact('pageTitle'));
?>
<section class="container py-5 text-center">
  <div style="font-size:5rem">⚠️</div>
  <h1 class="fw-bold">500 — Something went wrong</h1>
  <p class="text-muted">An unexpected error occurred. Our team has been notified.</p>
  <a class="btn btn-pnv px-4" href="<?= url('index.php') ?>"><i class="bi bi-house me-1"></i>Back to home</a>
</section>
<?php view('layouts/public_footer');
