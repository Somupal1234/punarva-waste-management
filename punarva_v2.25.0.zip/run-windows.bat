@echo off
REM ============================================================
REM  PUNARVA - quick development server (Windows)
REM  Uses PHP from PATH, or falls back to XAMPP's PHP.
REM  NOTE: MySQL must be running (XAMPP -> MySQL -> Start)
REM  and database/schema.sql + database/seed.sql must be imported.
REM ============================================================
title PUNARVA dev server
cd /d "%~dp0"

where php >nul 2>nul
if %errorlevel%==0 (
    echo [PUNARVA] Starting on http://127.0.0.1:8000  (PHP from PATH)
    php -S 127.0.0.1:8000
    goto :end
)

if exist "C:\xampp\php\php.exe" (
    echo [PUNARVA] Starting on http://127.0.0.1:8000  (XAMPP PHP)
    "C:\xampp\php\php.exe" -S 127.0.0.1:8000
    goto :end
)

echo [ERROR] PHP not found. Install XAMPP and use C:\xampp\htdocs\punarva instead.
echo         See QUICKSTART-VSCODE.md
pause
:end
pause
