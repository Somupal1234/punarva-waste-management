<?php
require_once __DIR__ . '/includes/init.php';

/** The 5 dedicated login panels (no mixing – role is validated on the server too). */
$loginRoles = [
    ROLE_ADMIN     => ['icon' => 'bi-shield-lock',  'title' => 'Admin / Municipality',  'desc' => 'Central administration console – assignments, analytics, governance'],
    ROLE_CITIZEN   => ['icon' => 'bi-person',       'title' => 'Citizen',               'desc' => 'Households & residents – scan waste, request pickups, track passports'],
    ROLE_COLLECTOR => ['icon' => 'bi-truck',        'title' => 'Collector',             'desc' => 'Field collection crew – assignments, routes & collection'],
    ROLE_RECYCLER  => ['icon' => 'bi-recycle',      'title' => 'Recycler / Facility',   'desc' => 'Facility operators – sorting, processing & final outcomes'],
    ROLE_BUSINESS  => ['icon' => 'bi-bank',         'title' => 'Business / Institution','desc' => 'Offices, schools, restaurants, hospitals & institutions'],
];

$selectedRole = (string) post_val('role', get_val('role', ROLE_ADMIN));
if (!isset($loginRoles[$selectedRole])) $selectedRole = ROLE_ADMIN;

// ---- Account switching: agar koi aur account logged-in hai to pehle usse bahar ----
// (a) explicit "Switch account" button, ya (b) koi role-login form submit hua
// (stale page se bhi) => purana session turant khatam, phir naya login process.
if (is_logged_in() && ((string) post_val('switch_account', '') === '1' || (is_post() && post_val('role') !== null))) {
    $prev = current_user()['name'] ?? 'your previous account';
    try { SessionRegistry::revokeCurrent(); } catch (Throwable $e) { /* registry row of the ending session must not stay active */ }
    $_SESSION = [];
    session_destroy();
    session_start();
    session_regenerate_id(true);
    flash('info', 'You were logged out of ' . e($prev) . '. Now select your role and log in.');
}

// ---- Ab bhi logged-in hai? "Already logged in" gate dikhao ----
if (is_logged_in()) {
    $u    = current_user();
    $home = ROLE_HOME[$u['role_code']] ?? 'index.php';
    $roleLabel = ROLE_LABELS[$u['role_code']] ?? ($u['role_code'] ?? 'User');
    $pageTitle = 'Switch account';
    ?><!DOCTYPE html>
<html lang="<?= e(current_lang()) ?>">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="PUNARVA — From Waste to Worth. A transparent digital waste-management ecosystem with traceable Waste Passports, QR tracking and estimated environmental impact.">
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<title><?= e($pageTitle . ' · ' . setting('platform_name', APP_NAME)) ?></title>
<link rel="icon" type="image/png" href="<?= url('assets/images/favicon.png') ?>">
<link rel="stylesheet" href="<?= url('assets/vendor/bootstrap/bootstrap.min.css') ?>">
<link rel="stylesheet" href="<?= url('assets/vendor/bootstrap-icons/bootstrap-icons.min.css') ?>">
<link rel="stylesheet" href="<?= asset_url('assets/css/style.css') ?>">
</head>
<body class="login-page">
<div class="auth-page py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-8 col-lg-5">
        <div class="card auth-card">
          <div class="card-body p-4 text-center">
            <div class="mb-3"><img class="logo-lg" src="<?= url('assets/images/logo-full.png') ?>" alt="PUNARVA"></div>
            <div class="display-6 mb-2">👋</div>
            <h1 class="h4 fw-bold mb-1">You're already logged in</h1>
            <p class="text-muted small mb-1">as <strong><?= e($u['name']) ?></strong></p>
            <p><span class="badge rounded-pill text-bg-success"><?= e($roleLabel) ?></span></p>
            <?php foreach (get_flashes() as $f): ?>
              <div class="alert alert-<?= e($f['type']) ?> small alert-auto"><?= e($f['message']) ?></div>
            <?php endforeach; ?>
            <a class="btn btn-pnv w-100 py-2 mb-2" href="<?= url($home) ?>">
              <i class="bi bi-arrow-right-circle me-1"></i>Continue to my dashboard</a>
            <form method="post">
              <?= csrf_field() ?>
              <input type="hidden" name="switch_account" value="1">
              <button class="btn btn-outline-secondary w-100 py-2">
                <i class="bi bi-box-arrow-right me-1"></i>Switch account — log in as another role</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="<?= asset_url('assets/js/password-toggle.js') ?>" defer></script>
</body></html><?php
    exit;
}

// ---- Login attempt ----
if (is_post()) {
    try {
        $pass  = (string) post_val('password', '');
        if ($pass === '') throw new InvalidArgumentException('Please enter your password.');
        $email = val_email($_POST);
        AuthService::attempt($email, $pass);
        // dedicated login enforcement: role tab must match the account role
        $actual = current_user()['role_code'];
        if ($actual !== $selectedRole) {
            unset($_SESSION['user']); // do not keep the half-login
            throw new InvalidArgumentException(
                'This is the ' . ROLE_LABELS[$selectedRole] . ' login, but this account is registered as "' .
                ROLE_LABELS[$actual] . '". Please use the "' . ROLE_LABELS[$actual] . '" tab below.');
        }
        flash('success', 'Welcome back, ' . e(current_user()['name']) . '!');
        redirect(ROLE_HOME[$actual] ?? 'index.php');
    } catch (InvalidArgumentException | RuntimeException $e) {
        $loginError = $e->getMessage();
        $f = pnv_field_error($loginError, ['password' => 'password', 'email' => 'email']);
        if ($f) $fieldErrors[$f] = $loginError;
    } catch (Throwable $e) {
        $loginError = APP_DEBUG ? $e->getMessage() : 'Login failed. Please try again.';
    }
}
$fieldErrors = $fieldErrors ?? [];
$pageTitle = t('login.title');
?>
<!DOCTYPE html>
<html lang="<?= e(current_lang()) ?>">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<title><?= e($pageTitle . ' · ' . setting('platform_name', APP_NAME)) ?></title>
<link rel="icon" type="image/png" href="<?= url('assets/images/favicon.png') ?>">
<link rel="stylesheet" href="<?= url('assets/vendor/bootstrap/bootstrap.min.css') ?>">
<link rel="stylesheet" href="<?= url('assets/vendor/bootstrap-icons/bootstrap-icons.min.css') ?>">
<link rel="stylesheet" href="<?= asset_url('assets/css/style.css') ?>">
</head>
<body class="login-page">
<a class="skip-link" href="#main-content"><?= t('a11y.skip') ?></a>
<main id="main-content"><div class="auth-page py-5">
  <div class="container">
    <div class="row justify-content-center align-items-center g-4">
      <div class="col-lg-4 text-white d-none d-lg-block">
        <a class="brand-logo mb-4" href="<?= url('index.php') ?>" style="color:#fff">
          <img src="<?= url('assets/images/logo-icon.png') ?>" alt="PUNARVA logo">
          <span class="text-white"><?= e(setting('platform_name', 'PUNARVA')) ?><small><?= e(setting('platform_tagline', t('foot.tagline'))) ?></small></span>
        </a>
        <h2 class="fw-bold" style="color:#ffe9a8"><?= e(t('foot.message')) ?></h2>
        <p class="opacity-75"><?= t('login.pitch_sub') ?></p>
        <ul class="list-unstyled small opacity-75 d-grid gap-2 mt-4">
          <li><i class="bi bi-shield-check me-2"></i><?= t('login.pitch1') ?></li>
          <li><i class="bi bi-qr-code me-2"></i><?= t('login.pitch2') ?></li>
          <li><i class="bi bi-trophy me-2"></i><?= t('login.pitch3') ?></li>
        </ul>
      </div>
      <div class="col-md-8 col-lg-6 col-xl-5">
        <div class="card auth-card p-1">
          <div class="card-body p-4">
            <div class="text-center mb-3"><img src="<?= url('assets/images/logo-full.png') ?>" alt="PUNARVA – From Waste to Worth" style="height:86px"></div>
            <h1 class="h4 fw-bold mb-1 text-center"><?= t('login.title') ?></h1>
            <p class="text-muted small text-center mb-3"><?= t('login.select_role') ?></p>

            <div id="cookieWarn" class="alert alert-warning small d-none">
              <i class="bi bi-exclamation-triangle me-1"></i>
              <strong>Cookies blocked!</strong> Is preview window me session save nahi ho payega.
              Preview ko <strong>new tab</strong> me kholen (⤴ button) ya XAMPP me chalayein —
              wahan login perfectly kaam karega.
            </div>

            <?php foreach (get_flashes() as $f): ?>
              <div class="alert alert-<?= e($f['type']) ?> small alert-auto"><?= e($f['message']) ?></div>
            <?php endforeach; ?>
            <?php if (!empty($loginError)): ?>
              <div role="alert" class="alert alert-danger small alert-auto"><i class="bi bi-exclamation-triangle me-1"></i><?= e($loginError) ?></div>
            <?php endif; ?>

            <!-- ===== dedicated role tabs: pure links (no JS needed) ===== -->
            <ul class="nav nav-pills role-tabs mb-3">
              <?php foreach ($loginRoles as $code => $meta): ?>
                <li class="nav-item flex-fill">
                  <a class="nav-link text-center <?= $code === $selectedRole ? 'active' : '' ?>"
                     href="<?= url('login.php?role=' . e($code)) ?>"
                     title="<?= e($meta['title']) ?>">
                    <i class="bi <?= e($meta['icon']) ?> me-1"></i><span class="d-none d-sm-inline"><?= e(explode(' /', $meta['title'])[0]) ?></span>
                  </a>
                </li>
              <?php endforeach; ?>
            </ul>

            <?php $meta = $loginRoles[$selectedRole]; ?>
            <div class="alert alert-light border small mb-3">
              <i class="text-pnv bi <?= e($meta['icon']) ?> me-1"></i>
              <strong><?= e($meta['title']) ?> login</strong> — <?= e($meta['desc']) ?>
            </div>

            <form method="post" novalidate>
              <?= csrf_field() ?>
              <input type="hidden" name="role" value="<?= e($selectedRole) ?>">
              <div class="mb-3">
                <label for="login-email" class="form-label fw-semibold small"><?= t('login.email') ?> <span class="required-asterisk" aria-hidden="true">*</span></label>
                <div class="input-group login-field">
                  <span class="input-group-text bg-white"><i class="bi bi-envelope"></i></span>
                  <input id="login-email" name="email" type="email" class="form-control<?= isset($fieldErrors['email']) ? ' is-invalid' : '' ?>" aria-invalid="<?= isset($fieldErrors['email']) ? 'true' : 'false' ?>"<?= isset($fieldErrors['email']) ? ' aria-describedby="err-email"' : '' ?> value="<?= e(post_val('email', '')) ?>" required autofocus autocomplete="username">
                </div>
                    <?php if (isset($fieldErrors['email'])): ?><div class="invalid-feedback" id="err-email"><?= e($fieldErrors['email']) ?></div><?php endif; ?>
              </div>
              <div class="mb-1">
                <label for="login-password" class="form-label fw-semibold small"><?= t('login.password') ?> <span class="required-asterisk" aria-hidden="true">*</span></label>
                <div class="input-group login-field">
                  <span class="input-group-text bg-white"><i class="bi bi-lock"></i></span>
                  <input id="login-password" name="password" type="password" class="form-control<?= isset($fieldErrors['password']) ? ' is-invalid' : '' ?>" aria-invalid="<?= isset($fieldErrors['password']) ? 'true' : 'false' ?>"<?= isset($fieldErrors['password']) ? ' aria-describedby="err-password"' : '' ?> required autocomplete="current-password">
                </div>
                    <?php if (isset($fieldErrors['password'])): ?><div class="invalid-feedback" id="err-password"><?= e($fieldErrors['password']) ?></div><?php endif; ?>
              </div>
              <div class="text-end mb-3">
                <a class="text-pnv small fw-semibold" href="<?= url('forgot-password.php?role=' . e($selectedRole)) ?>">
                  <i class="bi bi-key me-1"></i><?= t('login.forgot') ?></a>
              </div>
              <button class="btn btn-pnv w-100 py-2"><i class="bi bi-box-arrow-in-right me-1"></i>
                Login as <?= e($meta['title']) ?></button>
            </form>

            <hr>
            <div class="small text-center">
              <?= t('login.no_account') ?> <a href="<?= url('register.php') ?>" class="text-pnv fw-bold"><?= t('nav.register') ?></a>
              <span class="text-muted">·</span>
              <a href="<?= url('index.php') ?>" class="text-pnv fw-semibold">Back to home</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div></main>
<script>
// cookie support check – preview iframes kabhi cookies block kar dete hain
(function () {
  var blocked = false;
  try {
    document.cookie = 'pnv_ck=1; path=/; SameSite=Lax';
    blocked = document.cookie.indexOf('pnv_ck=') === -1;
    document.cookie = 'pnv_ck=; Max-Age=0; path=/';
  } catch (e) { blocked = true; }
  if (blocked) document.getElementById('cookieWarn').classList.remove('d-none');
})();
</script>
<script src="<?= asset_url('assets/js/password-toggle.js') ?>" defer></script>
</body></html>
