<?php
require_once __DIR__ . '/includes/init.php';
$pageTitle = 'Waste Guide'; $activeNav = 'guide';
$categories = Database::all('SELECT * FROM waste_categories WHERE status = "ACTIVE" ORDER BY id');
view('layouts/public_header', compact('pageTitle', 'activeNav'));
?>
<section class="py-5">
  <div class="container">
    <div class="text-center mb-4">
      <div class="section-eyebrow">Segregation guidance</div>
      <h1 class="h2 fw-bold"><?= t('page.guide') ?></h1>
      <p class="text-muted small">This guide is served straight from the municipality-managed category database.</p>
    </div>
    <div class="row g-4">
      <?php foreach ($categories as $c): ?>
        <div class="col-md-6 col-lg-4" id="cat-<?= e($c['code']) ?>">
          <div class="card h-100">
            <div class="card-body p-4">
              <div class="d-flex align-items-center gap-3 mb-3">
                <?= pnv_cat_badge($c['icon'], $c['color'], 44, $c['code']) ?>
                <div>
                  <h5 class="fw-bold mb-0"><?= e($c['name']) ?></h5>
                  <span class="badge text-bg-light border"><i class="bi bi-trash3 me-1"></i><?= e($c['bin_type']) ?></span>
                  <?php if ($c['is_recyclable']): ?><span class="badge text-bg-success ms-1">Recyclable</span><?php endif; ?>
                </div>
              </div>
              <p class="small text-muted"><?= e($c['description']) ?></p>
              <?php if ($c['recycling_guidance']): ?>
                <div class="small p-2 rounded-3" style="background:#f2f8f4;color:#2c4a3a"><i class="bi bi-recycle me-1"></i><?= e($c['recycling_guidance']) ?></div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="text-center mt-5">
      <a class="btn btn-pnv btn-lg px-4" href="<?= url('citizen/scanner.php') ?>"><i class="bi bi-stars me-2"></i>Not sure? Scan your waste</a>
    </div>
  </div>
</section>
<?php view('layouts/public_footer');
