<?php
require_once __DIR__ . '/includes/init.php';
$pageTitle = 'Report Waste';
$activeNav = 'report';
$user = current_user();
$categories = Database::all('SELECT * FROM waste_categories WHERE status = "ACTIVE" ORDER BY name');

$fieldErrors = [];
if (is_post()) {
    try {
        $description = val_str($_POST, 'description', 1000, true, 'Description');
        $address     = val_str($_POST, 'address_line', 255, true, 'Address');
        [$lat, $lng] = val_latlng($_POST);
        $image = handle_upload($_FILES['photo'] ?? null, 'reports');
        $reportCode = rand_code('PNVR');
        $id = Database::insert('waste_reports', [
            'report_code'  => $reportCode,
            'user_id'      => $user['id'] ?? null,
            'category_id'  => (int) post_val('category_id', 0) ?: null,
            'description'  => $description,
            'image_path'   => $image,
            'address_line' => $address,
            'ward'         => val_str($_POST, 'ward', 40, false) ?: null,
            'city'         => val_str($_POST, 'city', 80, false) ?: (string) setting('default_city', 'Dumka'),
            'latitude'     => $lat, 'longitude' => $lng,
            'status'       => 'SUBMITTED',
        ]);
        HotspotService::refreshAsync();
        if ($user) {
            NotificationService::send((int) $user['id'], 'REPORT', 'Report submitted',
                'Your waste report ' . $reportCode . ' was received and will be verified by the municipality.', 'waste_report', $id);
        }
        NotificationService::sendToRoles([ROLE_ADMIN], 'REPORT', 'New waste report',
            ($user['name'] ?? 'A guest') . ' reported unmanaged waste at ' . $address . ' (' . $reportCode . ').', 'waste_report', $id);
        AuditService::log('REPORT_CREATED', 'reports', $id, null, ['code' => $reportCode]);
        flash('success', 'Report ' . $reportCode . ' submitted successfully. The municipality will verify it shortly.');
        redirect($user ? 'citizen/reports.php' : 'report.php');
    } catch (InvalidArgumentException | RuntimeException $e) {
        $reportError = $e->getMessage();
        $f = pnv_field_error($reportError, ['description' => 'description', 'address' => 'address_line',
            'photo' => 'photo', 'image' => 'photo', 'upload' => 'photo', 'category' => 'category_id', 'location' => 'latitude']);
        if ($f) $fieldErrors[$f] = $reportError;
    } catch (Throwable $e) {
        $reportError = APP_DEBUG ? $e->getMessage() : 'Could not submit the report. Please try again.';
    }
}
view('layouts/public_header', compact('pageTitle', 'activeNav'));
?>
<section class="container py-5">
  <div class="row g-4">
    <div class="col-lg-5">
      <div class="section-eyebrow">Community watch</div>
      <h1 class="h2 fw-bold"><?= t('page.report') ?></h1>
      <p class="text-muted small">See garbage piling up in your street or ward? Report it — the municipality verifies,
        assigns a cleanup crew and tracks it to resolution. Verified reports feed the <strong>hotspot analytics</strong> engine.</p>
      <div class="card mb-3"><div class="card-body small">
        <div class="d-flex gap-2 mb-2"><i class="text-pnv bi bi-1-circle-fill"></i><div><strong>Submit</strong> with photo + location</div></div>
        <div class="d-flex gap-2 mb-2"><i class="text-pnv bi bi-2-circle-fill"></i><div><strong>Municipality verifies</strong> the report</div></div>
        <div class="d-flex gap-2 mb-2"><i class="text-pnv bi bi-3-circle-fill"></i><div><strong>Crew assigned</strong> and cleanup tracked</div></div>
        <div class="d-flex gap-2"><i class="text-pnv bi bi-4-circle-fill"></i><div><strong>Resolved</strong> — hotspot scores update automatically</div></div>
      </div></div>
      <div class="alert alert-light border small">
        <i class="bi bi-info-circle me-1"></i>You can report without an account, but logging in lets you
        <strong>track the report status</strong> and earn rewards when verified.
        <?php if (!$user): ?><a href="<?= url('login.php') ?>" class="fw-bold">Log in</a><?php endif; ?>
      </div>
    </div>

    <div class="col-lg-7">
      <div class="card">
        <div class="card-body p-4">
          <?php if (!empty($reportError)): ?><div role="alert" class="alert alert-danger alert-auto"><?= e($reportError) ?></div><?php endif; ?>
          <form method="post" enctype="multipart/form-data" novalidate>
            <?= csrf_field() ?>
            <div class="row g-3">
              <div class="col-md-6">
                <label for="rep-category_id" class="form-label fw-semibold small">Waste type <span class="required-asterisk" aria-hidden="true">*</span></label>
                <select id="rep-category_id" class="form-select" name="category_id" required>
                  <option value="">Select type…</option>
                  <?php foreach ($categories as $c): ?>
                    <option value="<?= (int) $c['id'] ?>" <?= post_val('category_id') == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-6">
                <label for="rep-photo" class="form-label fw-semibold small">Photo</label>
                <input id="rep-photo" type="file" class="form-control" name="photo" accept="image/*">
                <div class="form-text">JPG/PNG/WebP, max 5 MB.</div>
              </div>
              <div class="col-12">
                <label for="rep-description" class="form-label fw-semibold small">Description <span class="required-asterisk" aria-hidden="true">*</span></label>
                <textarea id="rep-description" name="description" class="form-control<?= isset($fieldErrors['description']) ? ' is-invalid' : '' ?>" aria-invalid="<?= isset($fieldErrors['description']) ? 'true' : 'false' ?>"<?= isset($fieldErrors['description']) ? ' aria-describedby="err-description"' : '' ?> name="description" rows="3" required
                  placeholder="What kind of waste? How long has it been there? Any overflow/burning?"><?= e(post_val('description', '')) ?></textarea>
              </div>
              <div class="col-md-8">
                <label for="rep-address_line" class="form-label fw-semibold small">Location / address <span class="required-asterisk" aria-hidden="true">*</span></label>
                <input id="rep-address_line" name="address_line" class="form-control<?= isset($fieldErrors['address_line']) ? ' is-invalid' : '' ?>" aria-invalid="<?= isset($fieldErrors['address_line']) ? 'true' : 'false' ?>"<?= isset($fieldErrors['address_line']) ? ' aria-describedby="err-address_line"' : '' ?> name="address_line" required value="<?= e(post_val('address_line', '')) ?>" placeholder="Street, landmark, area"><?php if (isset($fieldErrors['address_line'])): ?><div class="invalid-feedback" id="err-address_line"><?= e($fieldErrors['address_line']) ?></div><?php endif; ?>
              </div>
              <div class="col-md-4">
                <label for="rep-ward" class="form-label fw-semibold small">Ward</label>
                <input id="rep-ward" class="form-control" name="ward" value="<?= e(post_val('ward', '')) ?>" placeholder="e.g. Ward 21">
              </div>
              <div class="col-12">
                <label class="form-label fw-semibold small">Pin the spot on the map <span class="text-muted fw-normal">(click the map)</span></label>
                <div id="reportMap" class="map-box" style="height:280px"></div>
                <div class="row g-2 mt-2">
                  <div class="col-4 col-md-3"><input class="form-control form-control-sm" name="latitude" id="latInput" aria-label="Latitude" placeholder="Latitude" value="<?= e(post_val('latitude', '')) ?>"></div>
                  <div class="col-4 col-md-3"><input class="form-control form-control-sm" name="longitude" id="lngInput" aria-label="Longitude" placeholder="Longitude" value="<?= e(post_val('longitude', '')) ?>"></div>
                  <div class="col-4 col-md-3"><button type="button" class="btn btn-sm btn-soft w-100" id="btnGeolocate" title="Use my location" aria-label="Use my location to fill coordinates"><i class="bi bi-geo-alt me-1"></i>Use my location</button></div>
                  <input type="hidden" name="city" value="Patna">
                </div>
              </div>
              <div class="col-12">
                <button class="btn btn-pnv px-4"><i class="bi bi-megaphone me-1"></i>Submit Report</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
<script>
  // map.js footer me load hota hai — DOMContentLoaded ke baad pnvMap available hoga
  document.addEventListener('DOMContentLoaded', () => {
    pnvMap('reportMap', { clickTarget: { latInput: 'latInput', lngInput: 'lngInput' }, zoom: 12 });
  });
</script>
<?php view('layouts/public_footer'); ?>
