<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_BUSINESS);
$pageTitle = 'Bulk Pickup Request'; $activeMenu = 'bulk';
$orgId = (int) $user['organization_id'];
$categories = Database::all('SELECT * FROM waste_categories WHERE status = "ACTIVE" ORDER BY id');
$addresses = Database::all('SELECT * FROM addresses WHERE user_id = ?', [$user['id']]);
$slots = ['06:00-09:00','09:00-12:00','12:00-15:00','15:00-18:00','18:00-20:00'];
if ($orgId && !empty($_POST['bulk'])) {
    try {
        $created = 0; $errors = [];
        $rows = $_POST['items'] ?? [];
        foreach ($rows as $i => $row) {
            if (empty($row['category_id']) || empty($row['estimated_weight']) || empty($row['address_line'])) { continue; }
            $payload = [
                'category_id' => $row['category_id'], 'estimated_weight' => $row['estimated_weight'],
                'preferred_date' => $_POST['preferred_date'] ?? '', 'time_slot' => $_POST['time_slot'] ?? '09:00-12:00',
                'address_line' => $row['address_line'], 'ward' => $row['ward'] ?? '',
                'latitude' => $row['latitude'] ?? null, 'longitude' => $row['longitude'] ?? null,
                'notes' => ($row['notes'] ?? '') , 'organization_id' => $orgId,
            ];
            try { PickupService::create($user, $payload); $created++; }
            catch (Throwable $e) { $errors[] = 'Row ' . ($i + 1) . ': ' . $e->getMessage(); }
        }
        if ($created) flash('success', $created . ' pickup request(s) created.');
        if ($errors) flash('warning', 'Some rows failed: ' . implode(' | ', $errors));
        redirect('business/pickups.php');
    } catch (Throwable $e) { flash('danger', $e->getMessage()); }
}
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="card">
  <div class="card-body p-4">
    <h5 class="fw-bold mb-1"><i class="text-pnv bi bi-stack me-2"></i>Bulk pickup request</h5>
    <p class="text-muted small">Add one row per waste stream / location. All rows share the pickup date and time slot. Category, weight and address are required in each filled row — completely empty rows are ignored.</p>
    <form method="post" id="bulkForm"><?= csrf_field() ?><input type="hidden" name="bulk" value="1">
      <div class="row g-3 mb-3">
        <div class="col-md-4"><label class="form-label fw-semibold small">Pickup date <span class="required-asterisk" aria-hidden="true">*</span></label>
          <input type="date" class="form-control" name="preferred_date" min="<?= date('Y-m-d') ?>" value="<?= date('Y-m-d', strtotime('+1 day')) ?>" required></div>
        <div class="col-md-4"><label class="form-label fw-semibold small">Time slot <span class="required-asterisk" aria-hidden="true">*</span></label>
          <select class="form-select" name="time_slot" required><?php foreach ($slots as $s): ?><option><?= $s ?></option><?php endforeach; ?></select></div>
      </div>
      <div id="rowsWrap">
        <div class="card border mb-2 row-template d-none">
          <div class="card-body p-3">
            <div class="row g-2 align-items-end">
              <div class="col-md-3"><label class="form-label small fw-semibold">Category <span class="required-asterisk" aria-hidden="true">*</span></label>
                <select class="form-select form-select-sm" name="items[0][category_id]"><option value="">Select…</option>
                  <?php foreach ($categories as $c): ?><option value="<?= (int) $c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
              <div class="col-md-2"><label class="form-label small fw-semibold">Weight (kg) <span class="required-asterisk" aria-hidden="true">*</span></label>
                <input type="number" step="0.1" min="0.1" class="form-control form-control-sm" name="items[0][estimated_weight]"></div>
              <div class="col-md-3"><label class="form-label small fw-semibold">Address <span class="required-asterisk" aria-hidden="true">*</span></label>
                <input class="form-control form-control-sm" name="items[0][address_line]"></div>
              <div class="col-md-1"><label class="form-label small fw-semibold">Ward</label>
                <input class="form-control form-control-sm" name="items[0][ward]"></div>
              <div class="col-md-1"><label class="form-label small fw-semibold">Lat</label>
                <input class="form-control form-control-sm" name="items[0][latitude]"></div>
              <div class="col-md-1"><label class="form-label small fw-semibold">Lng</label>
                <input class="form-control form-control-sm" name="items[0][longitude]"></div>
              <div class="col-md-1 text-end"><button type="button" class="btn btn-sm btn-outline-danger remove-row"><i class="bi bi-trash"></i></button></div>
              <div class="col-md-12"><input class="form-control form-control-sm" name="items[0][notes]" placeholder="Notes (optional)"></div>
            </div>
          </div>
        </div>
      </div>
      <button type="button" class="btn btn-soft btn-sm mb-3" id="addRow"><i class="bi bi-plus-lg me-1"></i>Add waste stream</button>
      <div>
        <button class="btn btn-pnv px-4"><i class="bi bi-send me-1"></i>Submit bulk request</button>
      </div>
    </form>
  </div>
</div>
<script>
(function () {
  const wrap = document.getElementById('rowsWrap');
  const tpl = wrap.querySelector('.row-template');
  let idx = 0;
  function addRow() {
    idx++;
    const clone = tpl.cloneNode(true);
    clone.classList.remove('d-none');
    clone.innerHTML = clone.innerHTML.replaceAll('items[0][', 'items[' + idx + '][');
    wrap.appendChild(clone);
  }
  document.getElementById('addRow').addEventListener('click', addRow);
  wrap.addEventListener('click', (e) => {
    if (e.target.closest('.remove-row')) e.target.closest('.card').remove();
  });
  addRow(); addRow();
})();
</script>
<?php $pageScripts = '<script>
// v2.2.0: bulk rows — jis row me kuch bhi bharna shuru karo to teeno zaroori fields TURANT required
// (poori khali rows allowed — server unhe skip karta hai; adhoora row browser + server dono rokte hain)
function pnvBulkRowSync(card) {
  if (!card || card.offsetParent === null) return; // template hidden
  var cat = card.querySelector("select[name$=\"[category_id]\"]");
  var wt  = card.querySelector("input[name$=\"[estimated_weight]\"]");
  var ad  = card.querySelector("input[name$=\"[address_line]\"]");
  if (!cat || !wt || !ad) return;
  var filled = !!(cat.value || wt.value || ad.value);
  [cat, wt, ad].forEach(function (el) { if (filled) el.setAttribute("required", ""); else el.removeAttribute("required"); });
}
document.addEventListener("input", function (ev) {
  var card = ev.target && ev.target.closest ? ev.target.closest("#rowsWrap .card") : null;
  if (card) pnvBulkRowSync(card);
}, true);
document.addEventListener("change", function (ev) {
  var card = ev.target && ev.target.closest ? ev.target.closest("#rowsWrap .card") : null;
  if (card) pnvBulkRowSync(card);
}, true);
document.addEventListener("click", function (ev) {
  var f = ev.target && ev.target.closest ? ev.target.closest("#bulkForm") : null;
  if (!f) return;
  f.querySelectorAll("#rowsWrap .card").forEach(pnvBulkRowSync); // submit-button click par bhi rows sync (Enter/implicit submit cover)
}, true);
document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll("#rowsWrap .card").forEach(pnvBulkRowSync);
});
</script>';
require dirname(__DIR__) . '/views/layouts/dash_footer.php';
