<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_BUSINESS);
$pageTitle = 'Periodic Summary'; $activeMenu = 'summary';
$orgId = (int) $user['organization_id'];
$month = (string) get_val('month', date('Y-m'));
if (!preg_match('/^\d{4}-\d{2}$/', $month)) $month = date('Y-m');
$start = $month . '-01'; $end = date('Y-m-t', strtotime($start));

$summary = Database::one(
  'SELECT COUNT(*) AS pickups, COALESCE(SUM(estimated_weight),0) AS est_weight
   FROM pickup_requests WHERE organization_id = ? AND created_at BETWEEN ? AND ? AND status <> "CANCELLED"', [$orgId, $start, $end]) ?? [];
$collected = Database::one(
  'SELECT COUNT(*) AS n, COALESCE(SUM(wt.current_weight),0) AS w FROM waste_transactions wt
   WHERE wt.source_type = "BUSINESS" AND wt.source_user_id IN (SELECT id FROM users WHERE organization_id = ?)
     AND wt.created_at BETWEEN ? AND ?', [$orgId, $start, $end]) ?? [];
$byCat = Database::all(
  'SELECT wc.name, wc.color, SUM(pr.estimated_weight) AS total FROM pickup_requests pr
   JOIN waste_categories wc ON wc.id = pr.category_id
   WHERE pr.organization_id = ? AND pr.created_at BETWEEN ? AND ? AND pr.status <> "CANCELLED"
   GROUP BY pr.category_id ORDER BY total DESC', [$orgId, $start, $end]);
$outcomes = Database::all(
  'SELECT wt.final_outcome, COUNT(*) AS n, SUM(wt.current_weight) AS w FROM waste_transactions wt
   WHERE wt.source_type = "BUSINESS" AND wt.source_user_id IN (SELECT id FROM users WHERE organization_id = ?)
     AND wt.final_outcome IS NOT NULL AND wt.completed_at BETWEEN ? AND ? GROUP BY wt.final_outcome', [$orgId, $start, $end]);
$impact = Database::one(
  'SELECT COALESCE(SUM(ei.co2_saved_kg),0) AS co2, COALESCE(SUM(ei.water_saved_l),0) AS water
   FROM environmental_impacts ei JOIN waste_transactions wt ON wt.id = ei.waste_transaction_id
   WHERE wt.source_type = "BUSINESS" AND wt.source_user_id IN (SELECT id FROM users WHERE organization_id = ?)
     AND wt.completed_at BETWEEN ? AND ?', [$orgId, $start, $end]) ?? [];
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="card mb-3">
  <div class="card-header d-flex align-items-center flex-wrap gap-2">
    <i class="text-pnv bi bi-file-earmark-bar-graph me-1"></i>Periodic Summary — <?= e(date('F Y', strtotime($start))) ?>
    <form class="d-flex gap-2 ms-auto">
      <input type="month" class="form-control form-control-sm" name="month" value="<?= e($month) ?>" max="<?= date('Y-m') ?>">
      <button class="btn btn-sm btn-pnv">View</button>
      <button type="button" class="btn btn-sm btn-soft" onclick="window.print()"><i class="bi bi-printer"></i></button>
    </form>
  </div>
  <div class="card-body p-4">
    <div class="row g-3 mb-4">
      <div class="col-md-3"><div class="border rounded-3 p-3 text-center"><div class="fs-4 fw-bold"><?= (int) $summary['pickups'] ?></div><div class="small text-muted">pickup requests</div></div></div>
      <div class="col-md-3"><div class="border rounded-3 p-3 text-center"><div class="fs-4 fw-bold"><?= fmt_kg($summary['est_weight']) ?></div><div class="small text-muted">estimated waste offered</div></div></div>
      <div class="col-md-3"><div class="border rounded-3 p-3 text-center"><div class="fs-4 fw-bold"><?= (int) $collected['n'] ?></div><div class="small text-muted">collections completed</div></div></div>
      <div class="col-md-3"><div class="border rounded-3 p-3 text-center"><div class="fs-4 fw-bold"><?= fmt_kg($collected['w']) ?></div><div class="small text-muted">collected weight</div></div></div>
    </div>
    <div class="row g-4">
      <div class="col-md-6">
        <h6 class="fw-bold">Waste by category</h6>
        <?php if (!$byCat): ?><div class="small text-muted">No data this period.</div>
        <?php else: foreach ($byCat as $c): $pct = $summary['est_weight'] > 0 ? round($c['total'] / $summary['est_weight'] * 100) : 0; ?>
          <div class="mb-2">
            <div class="d-flex justify-content-between small"><span><span class="dot" style="background:<?= e($c['color']) ?>"></span><?= e($c['name']) ?></span><span><?= fmt_kg($c['total']) ?></span></div>
            <div class="progress" style="height:7px"><div class="progress-bar" style="width:<?= $pct ?>%;background:<?= e($c['color']) ?>"></div></div>
          </div>
        <?php endforeach; endif; ?>
      </div>
      <div class="col-md-6">
        <h6 class="fw-bold">Recycling outcomes</h6>
        <?php if (!$outcomes): ?><div class="small text-muted">No completed outcomes this period.</div>
        <?php else: foreach ($outcomes as $o): ?>
          <div class="d-flex justify-content-between border-bottom py-2 small">
            <span><?= waste_badge($o['final_outcome']) ?></span>
            <span><strong><?= (int) $o['n'] ?></strong> loads · <?= fmt_kg($o['w']) ?></span>
          </div>
        <?php endforeach; endif; ?>
        <div class="alert alert-light border small mt-3 mb-0">
          <i class="bi bi-globe-americas me-1"></i>Estimated impact this period:
          <strong><?= number_format((float) $impact['co2'], 2) ?> kg CO₂e</strong> avoided ·
          <strong><?= fmt_num($impact['water']) ?> L</strong> water saved (<?= e(METHODOLOGY_VERSION) ?>).
        </div>
      </div>
    </div>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php';
