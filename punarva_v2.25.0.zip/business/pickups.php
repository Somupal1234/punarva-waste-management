<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_BUSINESS);
$pageTitle = 'Pickup Records'; $activeMenu = 'pickups';
$orgId = (int) $user['organization_id'];
$q = trim((string) get_val('q', '')); $status = (string) get_val('status', '');
$where = 'pr.organization_id = ?'; $params = [$orgId];
if ($q !== '') { $where .= ' AND (pr.pickup_code LIKE ? OR wc.name LIKE ?)'; $params[] = "%$q%"; $params[] = "%$q%"; }
if ($status !== '' && in_array($status, PICKUP_STATUSES, true)) { $where .= ' AND pr.status = ?'; $params[] = $status; }
$total = (int) Database::val("SELECT COUNT(*) FROM pickup_requests pr JOIN waste_categories wc ON wc.id = pr.category_id WHERE $where", $params);
$pg = paginate_request($total);
$rows = Database::all(
    "SELECT pr.*, wc.name AS category_name, wc.color FROM pickup_requests pr
     JOIN waste_categories wc ON wc.id = pr.category_id
     LEFT JOIN waste_transactions wt ON wt.pickup_request_id = pr.id
     WHERE $where ORDER BY pr.created_at DESC LIMIT {$pg['limit']} OFFSET {$pg['offset']}", $params);
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="card">
  <div class="card-header d-flex align-items-center"><i class="text-pnv bi bi-truck me-2"></i>Pickup Records
    <span class="badge text-bg-light border"><?= $total ?></span></div>
  <div class="card-body">
    <form class="row g-2 mb-3">
      <div class="col-md-4"><input class="form-control form-control-sm" name="q" placeholder="Search…" value="<?= e($q) ?>"></div>
      <div class="col-md-3"><select class="form-select form-select-sm" name="status"><option value="">All statuses</option>
        <?php foreach (PICKUP_STATUSES as $st): ?><option <?= $status === $st ? 'selected' : '' ?>><?= $st ?></option><?php endforeach; ?></select></div>
      <div class="col-md-4 d-flex gap-2"><button class="btn btn-sm btn-pnv px-3">Filter</button>
        <a class="btn btn-sm btn-outline-secondary" href="<?= url('business/pickups.php') ?>">Reset</a></div>
    </form>
    <?php if (!$rows): ?><div class="empty-state"><i class="bi bi-inbox"></i><div class="mt-2">No pickup records.</div></div>
    <?php else: ?>
      <div class="table-responsive"><table class="table table-hover align-middle">
        <thead><tr><th>Code</th><th>Category</th><th>Weight</th><th>Scheduled</th><th>Status</th><th>Passport</th></tr></thead>
        <tbody>
          <?php foreach ($rows as $r): $wt = Database::one('SELECT id, waste_id FROM waste_transactions WHERE pickup_request_id = ?', [$r['id']]); ?>
            <tr>
              <td class="fw-bold"><?= e($r['pickup_code']) ?></td>
              <td><span class="dot" style="background:<?= e($r['color']) ?>"></span><?= e($r['category_name']) ?></td>
              <td><?= fmt_kg($r['estimated_weight']) ?></td>
              <td class="small"><?= fmt_dt($r['preferred_date'], 'd M Y') ?> <?= e($r['time_slot']) ?></td>
              <td><?= pickup_badge($r['status']) ?></td>
              <td><?php if ($wt): ?><a class="font-mono btn btn-sm btn-soft" href="<?= url('business/passports.php') ?>"><?= e($wt['waste_id']) ?></a><?php else: echo '—'; endif; ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody></table></div>
      <?= pagination_links($pg) ?>
    <?php endif; ?>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php';
