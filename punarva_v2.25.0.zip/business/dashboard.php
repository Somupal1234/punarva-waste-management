<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_BUSINESS);
$pageTitle = 'Organization Dashboard'; $activeMenu = 'dash';
$orgId = (int) $user['organization_id'];
$org = $orgId ? Database::one('SELECT * FROM organizations WHERE id = ?', [$orgId]) : null;

$kpi = [
    'pickups' => (int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE organization_id = ?', [$orgId]),
    'weight'  => (float) (Database::val('SELECT COALESCE(SUM(estimated_weight),0) FROM pickup_requests WHERE organization_id = ? AND status <> "CANCELLED"', [$orgId])),
    'passports' => (int) Database::val('SELECT COUNT(*) FROM waste_transactions WHERE source_type = "BUSINESS" AND source_user_id = ?', [$user['id']]),
    'open' => (int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE organization_id = ? AND status IN ("REQUESTED","ASSIGNED","ACCEPTED","ON_THE_WAY","ARRIVED","COLLECTED")', [$orgId]),
];
// org impact: aggregate over all users of the organization
$impact = Database::one(
    'SELECT COALESCE(SUM(ei.co2_saved_kg),0) AS co2, COALESCE(SUM(ei.water_saved_l),0) AS water,
            COALESCE(SUM(ei.energy_saved_kwh),0) AS energy, COALESCE(SUM(ei.quantity),0) AS qty
     FROM environmental_impacts ei
     JOIN waste_transactions wt ON wt.id = ei.waste_transaction_id
     WHERE wt.source_type = "BUSINESS" AND wt.source_user_id IN (SELECT id FROM users WHERE organization_id = ?)', [$orgId]) ?? [];
$recent = Database::all(
    'SELECT pr.*, wc.name AS category_name, wc.color FROM pickup_requests pr
     JOIN waste_categories wc ON wc.id = pr.category_id
     WHERE pr.organization_id = ? ORDER BY pr.created_at DESC LIMIT 6', [$orgId]);
// v2.25.0 — operational analytics (organization's own live data)
$bMonthly = Database::all(
    'SELECT DATE_FORMAT(created_at, "%b %y") AS ym, COALESCE(SUM(estimated_weight),0) AS total, COUNT(*) AS n
     FROM pickup_requests WHERE organization_id = ? AND status <> "CANCELLED"
     GROUP BY YEAR(created_at), MONTH(created_at) ORDER BY YEAR(created_at), MONTH(created_at) LIMIT 12', [$orgId]);
$bMix = Database::all(
    'SELECT wc.name, wc.color, COALESCE(SUM(pr.estimated_weight),0) AS total
     FROM pickup_requests pr JOIN waste_categories wc ON wc.id = pr.category_id
     WHERE pr.organization_id = ? AND pr.status <> "CANCELLED"
     GROUP BY pr.category_id ORDER BY total DESC LIMIT 6', [$orgId]);
$bStatus = Database::all('SELECT status, COUNT(*) AS n FROM pickup_requests WHERE organization_id = ? GROUP BY status', [$orgId]);
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="alert alert-light border d-flex align-items-center gap-3 flex-wrap">
  <span class="logo-mark" style="width:40px;height:40px"><i class="bi bi-bank"></i></span>
  <div>
    <strong><?= e($org['name'] ?? 'Organization') ?></strong>
    <span class="badge text-bg-light border ms-1"><?= e($org['org_type'] ?? 'ORG') ?></span>
    <div class="small text-muted"><?= e($org['address_line'] ?? '') ?> <?= e($org['city'] ?? '') ?></div>
  </div>
  <span class="badge text-bg-<?= ($org['status'] ?? '') === 'ACTIVE' ? 'success' : 'secondary' ?> ms-auto"><?= e($org['status'] ?? '—') ?></span>
</div>
<div class="row g-3 mb-4">
  <?php $cards = [
    ['kpi-blue','bi-truck', fmt_num($kpi['pickups']),'TOTAL PICKUP REQUESTS'],
    ['kpi-green','bi-scale', fmt_kg($kpi['weight']),'TOTAL WASTE HANDED OVER'],
    ['kpi-teal','bi-passport', fmt_num($kpi['passports']),'WASTE PASSPORTS'],
    ['kpi-amber','bi-hourglass-split', fmt_num($kpi['open']),'ACTIVE PICKUPS'],
  ];
  foreach ($cards as [$c,$i,$v,$l]): ?>
    <div class="col-6 col-lg-3"><div class="kpi-card <?= $c ?> p-3"><i class="bi <?= $i ?> kpi-icon"></i>
      <div class="kpi-value"><?= $v ?></div><div class="kpi-label"><?= e($l) ?></div></div></div>
  <?php endforeach; ?>
</div>
<?php
// v2.25.0 — pickup status progression (workflow order, live counts)
$bFlowColors = ['REQUESTED' => '#f2b32c', 'ASSIGNED' => '#3d9be9', 'ACCEPTED' => '#1b6ca8', 'ON_THE_WAY' => '#0b7285', 'ARRIVED' => '#8e5cd9', 'COLLECTED' => '#12b886', 'COMPLETED' => '#0e7a4f'];
$bFlowIcons = ['REQUESTED' => 'bi-plus-circle', 'ASSIGNED' => 'bi-person-check', 'ACCEPTED' => 'bi-hand-thumbs-up', 'ON_THE_WAY' => 'bi-truck', 'ARRIVED' => 'bi-geo-alt', 'COLLECTED' => 'bi-box-seam', 'COMPLETED' => 'bi-check-circle-fill'];
$statusMap = [];
foreach ($bStatus as $s) $statusMap[$s['status']] = (int) $s['n'];
$bTotal = array_sum(array_diff_key($statusMap, ['CANCELLED' => 0]));
$bSteps = [];
foreach (['REQUESTED','ASSIGNED','ACCEPTED','ON_THE_WAY','ARRIVED','COLLECTED','COMPLETED'] as $st) {
    if (!isset(PICKUP_STATUS_LABELS[$st])) continue;
    $bSteps[] = ['name' => PICKUP_STATUS_LABELS[$st], 'color' => $bFlowColors[$st], 'icon' => $bFlowIcons[$st],
                 'value' => $statusMap[$st] ?? 0, 'count' => true, 'base' => $bTotal ?: 1];
}
?>
<div class="row g-3 mb-1">
  <div class="col-lg-7"><div class="chart-card h-100">
    <div class="chart-head"><h2 class="chart-title"><i class="bi bi-graph-up-arrow"></i>Collection trend</h2><span class="chart-sub">est. kg · last 12 months</span></div>
    <div class="pnv-chart pnv-chart-md">
      <?php if ($bMonthly): ?><canvas id="bTrend" role="img" aria-label="Area chart: estimated waste handed over by month in kilograms"></canvas>
      <?php else: ?><div class="chart-empty"><i class="bi bi-graph-up"></i><div>No pickups yet — create a bulk request to start your trend.</div></div><?php endif; ?>
    </div>
  </div></div>
  <div class="col-lg-5"><div class="chart-card h-100">
    <div class="chart-head"><h2 class="chart-title"><i class="bi bi-bar-chart-line"></i>Waste mix</h2><span class="chart-sub">kg · share</span></div>
    <?php if ($bMix): ?><div id="bMix" class="pnv-mix"></div>
    <?php else: ?><div class="chart-empty"><i class="bi bi-bar-chart"></i><div>Category mix appears after your first pickup.</div></div><?php endif; ?>
  </div></div>
</div>
<div class="row g-3 mb-4">
  <div class="col-12"><div class="chart-card">
    <div class="chart-head"><h2 class="chart-title"><i class="bi bi-truck"></i>Pickup performance</h2><span class="chart-sub">requests by workflow stage</span></div>
    <?php if ($bTotal > 0): ?><div id="bFlow" class="pnv-flow pnv-flow--grid"></div>
    <?php else: ?><div class="chart-empty"><i class="bi bi-truck"></i><div>No pickup activity yet.</div></div><?php endif; ?>
  </div></div>
</div>
<div class="row g-4">
  <div class="col-lg-4">
    <div class="panel-dark card mb-3">
      <div class="card-body p-4">
        <div class="d-flex justify-content-between"><h6 class="fw-bold mb-0"><i class="bi bi-globe-americas me-2"></i>Estimated Impact</h6>
          <span class="badge text-bg-light">Estimated</span></div>
        <div class="row text-center mt-3">
          <div class="col-4"><div class="fw-bold"><?= number_format((float) $impact['co2'],1) ?></div><div class="small opacity-75">kg CO₂e</div></div>
          <div class="col-4"><div class="fw-bold"><?= fmt_num($impact['water']) ?></div><div class="small opacity-75">L water</div></div>
          <div class="col-4"><div class="fw-bold"><?= number_format((float) $impact['energy'],1) ?></div><div class="small opacity-75">kWh</div></div>
        </div>
        <a class="btn btn-light btn-sm fw-bold mt-3" href="<?= url('business/impact.php') ?>">Impact report</a>
      </div>
    </div>
    <div class="card"><div class="card-header">Quick actions</div><div class="card-body d-grid gap-2">
      <a class="btn btn-pnv" href="<?= url('business/bulk-pickup.php') ?>"><i class="bi bi-stack me-1"></i>New bulk pickup request</a>
      <a class="btn btn-soft" href="<?= url('business/summary.php') ?>"><i class="bi bi-file-earmark-bar-graph me-1"></i>Periodic summary</a>
      <a class="btn btn-soft" href="<?= url('business/passports.php') ?>"><i class="bi bi-passport me-1"></i>Waste passports</a>
    </div></div>
  </div>
  <div class="col-lg-8">
    <div class="card">
      <div class="card-header d-flex align-items-center"><i class="text-pnv bi bi-truck me-2"></i>Recent pickups
        <a class="btn btn-sm btn-soft ms-auto" href="<?= url('business/pickups.php') ?>">All records</a></div>
      <div class="card-body p-0">
        <?php if (!$recent): ?><div class="empty-state py-4"><i class="bi bi-truck"></i><div>No pickups yet — create a bulk request.</div></div>
        <?php else: foreach ($recent as $r): ?>
          <div class="notif-item d-flex justify-content-between align-items-center">
            <div><strong><?= e($r['pickup_code']) ?></strong>
              <div class="small text-muted"><span class="dot" style="background:<?= e($r['color']) ?>"></span><?= e($r['category_name']) ?> · <?= fmt_kg($r['estimated_weight']) ?> · <?= fmt_dt($r['preferred_date'], 'd M Y') ?> <?= e($r['time_slot']) ?></div></div>
            <?= pickup_badge($r['status']) ?>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
  </div>
</div>
<?php $pageScripts = '<script>
' . ($bMonthly ? 'PNV_CHART.area("bTrend", { labels: ' . json_encode(array_column($bMonthly, 'ym')) . ', suffix: "",
  series: [{ label: "Waste handed over", data: ' . json_encode(array_map(fn($r) => round((float) $r['total'], 1), $bMonthly)) . ', color: "#0e7a4f" }] });' : '') . '
' . ($bMix ? 'PNV_CHART.renderMix("#bMix", ' . json_encode(array_map(fn($m) => ['name' => $m['name'], 'color' => $m['color'], 'value' => round((float) $m['total'], 1)], $bMix)) . ');' : '') . '
' . ($bTotal > 0 ? 'PNV_CHART.renderFlow("#bFlow", ' . json_encode($bSteps) . ', ' . ($bTotal ?: 1) . ');' : '') . '
</script>';
require dirname(__DIR__) . '/views/layouts/dash_footer.php';
