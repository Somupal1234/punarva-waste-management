<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_BUSINESS);
$pageTitle = 'Environmental Impact'; $activeMenu = 'impact';
$orgId = (int) $user['organization_id'];
$summary = Database::one(
    'SELECT COALESCE(SUM(ei.co2_saved_kg),0) AS co2, COALESCE(SUM(ei.water_saved_l),0) AS water,
            COALESCE(SUM(ei.energy_saved_kwh),0) AS energy, COALESCE(SUM(ei.landfill_diverted_kg),0) AS diverted, COUNT(*) AS records
     FROM environmental_impacts ei
     JOIN waste_transactions wt ON wt.id = ei.waste_transaction_id
     WHERE wt.source_type = "BUSINESS" AND wt.source_user_id IN (SELECT id FROM users WHERE organization_id = ?)', [$orgId]) ?? [];
$monthly = Database::all(
    'SELECT DATE_FORMAT(wt.created_at, "%b %y") AS ym, SUM(ei.co2_saved_kg) AS co2, SUM(ei.quantity) AS qty
     FROM environmental_impacts ei JOIN waste_transactions wt ON wt.id = ei.waste_transaction_id
     WHERE wt.source_type = "BUSINESS" AND wt.source_user_id IN (SELECT id FROM users WHERE organization_id = ?)
     GROUP BY ym ORDER BY MIN(wt.created_at) LIMIT 12', [$orgId]);
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="row g-3 mb-4">
  <?php $cards = [['kpi-violet','bi-cloud-arrow-down', number_format((float) $summary['co2'],1).' kg','EST. CO₂e AVOIDED'],
    ['kpi-blue','bi-droplet', fmt_num($summary['water']).' L','EST. WATER SAVED'],
    ['kpi-teal','bi-lightning-charge', number_format((float) $summary['energy'],1).' kWh','EST. ENERGY SAVED'],
    ['kpi-green','bi-recycle', fmt_kg($summary['diverted']),'EST. DIVERTED FROM DUMP']];
  foreach ($cards as [$c,$i,$v,$l]): ?>
    <div class="col-6 col-lg-3"><div class="kpi-card <?= $c ?> p-3"><i class="bi <?= $i ?> kpi-icon"></i>
      <div class="kpi-value"><?= $v ?></div><div class="kpi-label"><?= e($l) ?></div>
      <div class="small opacity-75 mt-1">Estimated — <?= e(METHODOLOGY_VERSION) ?></div></div></div>
  <?php endforeach; ?>
</div>
<div class="alert alert-light border small"><i class="bi bi-info-circle me-1"></i><strong>Estimated impact</strong> = quantity × configured factor — suitable for
  sustainability communication with an "estimated" label, not measured carbon accounting.</div>
<div class="chart-card">
  <div class="chart-head"><h2 class="chart-title"><i class="bi bi-graph-up-arrow"></i>Monthly trend</h2><span class="chart-sub">CO₂e avoided · waste recycled</span></div>
  <div class="pnv-chart pnv-chart-md">
  <?php if ($monthly): ?><canvas id="trend" role="img" aria-label="Line chart: monthly estimated CO2e avoided and waste recycled"></canvas>
  <?php else: ?><div class="chart-empty"><i class="bi bi-graph-up"></i><div>Impact data appears when your waste completes recycling.</div></div><?php endif; ?>
  </div>
</div>
<?php $pageScripts = '<script>
if (document.getElementById("trend")) PNV_CHART.area("trend", { labels: ' . json_encode(array_column($monthly, 'ym')) . ', suffix: "",
  series: [
    { label: "CO₂e avoided", data: ' . json_encode(array_map(fn($r) => round((float) $r['co2'], 2), $monthly)) . ', color: "#0e7a4f" },
    { label: "Waste recycled", data: ' . json_encode(array_map(fn($r) => round((float) $r['qty'], 2), $monthly)) . ', color: "#7ccb5f", fill: false, dash: [5, 4] }] });
</script>';
require dirname(__DIR__) . '/views/layouts/dash_footer.php';
