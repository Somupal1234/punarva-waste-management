<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_BUSINESS);
$pageTitle = 'Waste Passports'; $activeMenu = 'passports';
$orgId = (int) $user['organization_id'];
$where = 'wt.source_type = "BUSINESS" AND wt.source_user_id IN (SELECT id FROM users WHERE organization_id = ?)';
$params = [$orgId];
$total = (int) Database::val("SELECT COUNT(*) FROM waste_transactions wt WHERE $where", $params);
$pg = paginate_request($total);
$rows = Database::all(
    "SELECT wt.*, wc.name AS category_name, wc.color, f.name AS facility_name
     FROM waste_transactions wt JOIN waste_categories wc ON wc.id = wt.category_id
     LEFT JOIN facilities f ON f.id = wt.facility_id
     WHERE $where ORDER BY wt.created_at DESC LIMIT {$pg['limit']} OFFSET {$pg['offset']}", $params);
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="card">
  <div class="card-header"><i class="text-pnv bi bi-passport me-2"></i>Organization Waste Passports <span class="badge text-bg-light border"><?= $total ?></span></div>
  <div class="card-body">
    <?php if (!$rows): ?><div class="empty-state"><i class="bi bi-passport"></i><div class="mt-2">No passports yet.</div></div>
    <?php else: ?>
      <div class="table-responsive"><table class="table table-hover align-middle">
        <thead><tr><th>Waste ID</th><th>Category</th><th>Weight</th><th>Facility</th><th>Status</th><th></th></tr></thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td class="font-mono fw-bold"><?= e($r['waste_id']) ?></td>
              <td><span class="dot" style="background:<?= e($r['color']) ?>"></span><?= e($r['category_name']) ?></td>
              <td><?= fmt_kg($r['current_weight']) ?></td>
              <td class="small"><?= e($r['facility_name'] ?? '—') ?></td>
              <td><?= waste_badge($r['current_stage']) ?></td>
              <td><a class="btn btn-sm btn-soft" target="_blank" href="<?= url('track.php?id=' . urlencode($r['waste_id'])) ?>">Public view</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody></table></div>
      <?= pagination_links($pg) ?>
    <?php endif; ?>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php';
