<?php
/**
 * TrackingService – Smart truck/driver live tracking (v2.4.0).
 *
 * Data model (existing tables reused): vehicles = truck registry (driver_user_id links
 * the collector LOGIN), driver_shifts = PUNCH IN/OUT registry + cached latest fix,
 * driver_locations = per-shift breadcrumb history (capped per shift).
 *
 * All input validation is server-side (numeric ranges, ranges/units), all SQL is
 * prepared statements via Database::*. Authorization is enforced by the API callers
 * (driver endpoints = own data only; admin endpoints = role admin).
 */
class TrackingService
{
    /** Fresh-fix window (LIVE) and stale window (UPDATING) in seconds. */
    public const LIVE_WINDOW = 60;
    public const UPDATING_WINDOW = 300;
    /** Server-side ping throttle: ignore pings closer together than this (seconds). */
    public const PING_MIN_GAP = 3;
    /** Minimum movement (metres) to store a new breadcrumb within the gap window. */
    public const PING_MIN_METRES = 8;
    /** Max breadcrumb rows kept per shift (oldest pruned). */
    public const MAX_ROWS_PER_SHIFT = 600;
    /** Reject implausible GPS fixes. */
    public const MAX_ACCURACY_M = 500.0;

    /** Truck assigned to a collector login (ACTIVE vehicle only). */
    public static function vehicleFor(int $driverUserId): ?array
    {
        return Database::one(
            'SELECT id, vehicle_number, vehicle_type, driver_name, status, facility_id
             FROM vehicles WHERE driver_user_id = ? AND status = "ACTIVE" LIMIT 1',
            [$driverUserId]
        );
    }

    /** Open (ACTIVE) shift for a driver, with cached last fix. */
    public static function activeShift(int $driverUserId): ?array
    {
        return Database::one(
            'SELECT * FROM driver_shifts WHERE driver_user_id = ? AND status = "ACTIVE" ORDER BY id DESC LIMIT 1',
            [$driverUserId]
        );
    }

    /** PUNCH IN — requires an assigned ACTIVE vehicle; closes stale shifts first (safety). */
    public static function punchIn(int $driverUserId): array
    {
        if (!self::schemaReady()) throw new RuntimeException('Tracking is temporarily unavailable: the database upgrade (database/upgrade-v2.4.0.sql) has not been applied. Please contact the administrator.');
        $vehicle = self::vehicleFor($driverUserId);
        if (!$vehicle) throw new InvalidArgumentException('No active vehicle is assigned to your account. Please contact the administrator.');
        Database::run('UPDATE driver_shifts SET status = "ENDED", ended_at = ? WHERE driver_user_id = ? AND status = "ACTIVE"', [date('Y-m-d H:i:s'), $driverUserId]);
        $now = date('Y-m-d H:i:s');
        $shiftId = Database::insert('driver_shifts', [
            'driver_user_id' => $driverUserId,
            'vehicle_id'     => (int) $vehicle['id'],
            'status'         => 'ACTIVE',
            'started_at'     => $now,
            'created_at'     => $now,
        ]);
        AuditService::log('DRIVER_PUNCH_IN', 'tracking', $shiftId, null, ['vehicle' => $vehicle['vehicle_number']]);
        return self::driverStatus($driverUserId);
    }

    /** PUNCH OUT — ends the ACTIVE shift (idempotent). */
    public static function punchOut(int $driverUserId): array
    {
        if (!self::schemaReady()) throw new RuntimeException('Tracking is temporarily unavailable: the database upgrade (database/upgrade-v2.4.0.sql) has not been applied. Please contact the administrator.');
        $shift = self::activeShift($driverUserId);
        if ($shift) {
            Database::run('UPDATE driver_shifts SET status = "ENDED", ended_at = ? WHERE id = ?', [date('Y-m-d H:i:s'), (int) $shift['id']]);
            AuditService::log('DRIVER_PUNCH_OUT', 'tracking', (int) $shift['id'], null, ['vehicle_id' => (int) $shift['vehicle_id']]);
        }
        return self::driverStatus($driverUserId);
    }

    /** GPS ping — validated, throttled, deduped; updates cached fix + history. */
    public static function ping(int $driverUserId, float $lat, float $lng, ?float $accuracy, ?float $speed, ?float $heading): array
    {
        if (!self::schemaReady()) throw new RuntimeException('Tracking is temporarily unavailable: the database upgrade (database/upgrade-v2.4.0.sql) has not been applied.');
        if ($lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) throw new InvalidArgumentException('Invalid coordinates.');
        if ($accuracy !== null && ($accuracy < 0 || $accuracy > self::MAX_ACCURACY_M)) $accuracy = null;
        if ($speed !== null && ($speed < 0 || $speed > 70.0)) $speed = null;
        if ($heading !== null && ($heading < 0 || $heading >= 360)) $heading = null;

        $shift = self::activeShift($driverUserId);
        if (!$shift) throw new RuntimeException('Tracking is not active. Please PUNCH IN first.');

        // Server-side throttle: skip near-duplicate pings (no movement + recent)
        $last = Database::one('SELECT latitude, longitude, recorded_at FROM driver_locations WHERE shift_id = ? ORDER BY id DESC LIMIT 1', [(int) $shift['id']]);
        if ($last) {
            $gap = time() - strtotime((string) $last['recorded_at']);
            if ($gap < self::PING_MIN_GAP) return self::driverStatus($driverUserId);
            $moved = self::haversine((float) $last['latitude'], (float) $last['longitude'], $lat, $lng);
            if ($gap < 25 && $moved < self::PING_MIN_METRES) return self::driverStatus($driverUserId);
        }

        $now = date('Y-m-d H:i:s');
        Database::run(
            'INSERT INTO driver_locations (shift_id, driver_user_id, vehicle_id, latitude, longitude, accuracy_m, speed_mps, heading_deg, recorded_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [(int) $shift['id'], $driverUserId, (int) $shift['vehicle_id'], $lat, $lng, $accuracy, $speed, $heading, $now]
        );
        Database::run(
            'UPDATE driver_shifts SET last_lat = ?, last_lng = ?, last_accuracy = ?, last_speed = ?, last_heading = ?, last_ping_at = ? WHERE id = ?',
            [$lat, $lng, $accuracy, $speed, $heading, $now, (int) $shift['id']]
        );
        self::pruneHistory((int) $shift['id']);
        return self::driverStatus($driverUserId);
    }

    /** v2.4.2: tracking schema present? (self-healed at boot; false → degrade cleanly) */
    public static function schemaReady(): bool { return function_exists('pnv_schema_ready') ? pnv_schema_ready() : false; }

    /** Driver's own tracking status (vehicle + shift + computed state). */
    public static function driverStatus(int $driverUserId): array
    {
        if (!self::schemaReady()) return ['vehicle' => null, 'shift' => null, 'schema_ready' => false];
        $vehicle = self::vehicleFor($driverUserId);
        $shift = self::activeShift($driverUserId);
        return [
            'vehicle'      => $vehicle ? ['id' => (int) $vehicle['id'], 'number' => $vehicle['vehicle_number'], 'type' => $vehicle['vehicle_type']] : null,
            'driver_name'  => $vehicle ? ($vehicle['driver_name'] ?: '') : '',
            'shift'        => $shift ? [
                'id'           => (int) $shift['id'],
                'started_at'   => $shift['started_at'],
                'last_lat'     => $shift['last_lat'] !== null ? (float) $shift['last_lat'] : null,
                'last_lng'     => $shift['last_lng'] !== null ? (float) $shift['last_lng'] : null,
                'accuracy'     => $shift['last_accuracy'] !== null ? (float) $shift['last_accuracy'] : null,
                'speed'        => $shift['last_speed'] !== null ? (float) $shift['last_speed'] : null,
                'heading'      => $shift['last_heading'] !== null ? (float) $shift['last_heading'] : null,
                'last_ping_at' => $shift['last_ping_at'],
                'status'       => self::statusFor($shift['last_ping_at']),
            ] : null,
        ];
    }

    /** ADMIN: all trucks with ACTIVE shifts + computed live state (for the ops map). */
    public static function activeTrucks(): array
    {
        if (!self::schemaReady()) return []; // v2.4.2 graceful: ops map still renders other layers
        $rows = Database::all(
            'SELECT ds.id AS shift_id, ds.driver_user_id, ds.vehicle_id, ds.started_at, ds.last_lat, ds.last_lng,
                    ds.last_accuracy, ds.last_speed, ds.last_heading, ds.last_ping_at,
                    v.vehicle_number, v.vehicle_type, u.name AS driver_account
             FROM driver_shifts ds
             JOIN vehicles v ON v.id = ds.vehicle_id
             JOIN users u ON u.id = ds.driver_user_id
             WHERE ds.status = "ACTIVE"
             ORDER BY ds.last_ping_at DESC'
        );
        return array_map(function (array $r): array {
            return [
                'shift_id'    => (int) $r['shift_id'],
                'vehicle_id'  => (int) $r['vehicle_id'],
                'vehicle'     => $r['vehicle_number'],
                'vehicle_type'=> $r['vehicle_type'],
                'driver'      => $r['driver_account'] ?: $r['vehicle_number'],
                'lat'         => $r['last_lat'] !== null ? (float) $r['last_lat'] : null,
                'lng'         => $r['last_lng'] !== null ? (float) $r['last_lng'] : null,
                'accuracy'    => $r['last_accuracy'] !== null ? (float) $r['last_accuracy'] : null,
                'speed'       => $r['last_speed'] !== null ? (float) $r['last_speed'] : null,
                'heading'     => $r['last_heading'] !== null ? (float) $r['last_heading'] : null,
                'last_ping_at'=> $r['last_ping_at'],
                'started_at'  => $r['started_at'],
                'state'       => self::statusFor($r['last_ping_at']),
            ];
        }, $rows);
    }

    /** ADMIN: full breadcrumb route of one shift + shift metadata. */
    public static function shiftRoute(int $shiftId): array
    {
        if (!self::schemaReady()) throw new RuntimeException('Tracking is temporarily unavailable: the database upgrade (database/upgrade-v2.4.0.sql) has not been applied.');
        $shift = Database::one(
            'SELECT ds.*, v.vehicle_number, u.name AS driver_account
             FROM driver_shifts ds JOIN vehicles v ON v.id = ds.vehicle_id JOIN users u ON u.id = ds.driver_user_id
             WHERE ds.id = ?',
            [$shiftId]
        );
        if (!$shift) throw new InvalidArgumentException('Shift not found.');
        $points = Database::all(
            'SELECT latitude, longitude, accuracy_m, speed_mps, heading_deg, recorded_at
             FROM driver_locations WHERE shift_id = ? ORDER BY recorded_at, id',
            [$shiftId]
        );
        return [
            'shift_id'   => (int) $shift['id'],
            'vehicle'    => $shift['vehicle_number'],
            'driver'     => $shift['driver_account'],
            'status'     => $shift['status'],
            'started_at' => $shift['started_at'],
            'ended_at'   => $shift['ended_at'],
            'state'      => $shift['status'] === 'ACTIVE' ? self::statusFor($shift['last_ping_at']) : 'OFFLINE',
            'points'     => array_map(fn($p) => [
                'lat' => (float) $p['latitude'], 'lng' => (float) $p['longitude'],
                'acc' => $p['accuracy_m'] !== null ? (float) $p['accuracy_m'] : null,
                'spd' => $p['speed_mps'] !== null ? (float) $p['speed_mps'] : null,
                'hdg' => $p['heading_deg'] !== null ? (float) $p['heading_deg'] : null,
                't'   => $p['recorded_at'],
            ], $points),
        ];
    }

    /** LIVE / UPDATING / OFFLINE — never claim LIVE without a fresh server-side fix. */
    public static function statusFor(?string $lastPingAt): string
    {
        if (!$lastPingAt) return 'OFFLINE';
        $age = time() - strtotime((string) $lastPingAt);
        if ($age <= self::LIVE_WINDOW) return 'LIVE';
        if ($age <= self::UPDATING_WINDOW) return 'UPDATING';
        return 'OFFLINE';
    }

    private static function pruneHistory(int $shiftId): void
    {
        Database::run(
            'DELETE dl FROM driver_locations dl
             LEFT JOIN (SELECT id FROM driver_locations WHERE shift_id = ? ORDER BY id DESC LIMIT ?) keep ON keep.id = dl.id
             WHERE dl.shift_id = ? AND keep.id IS NULL',
            [$shiftId, self::MAX_ROWS_PER_SHIFT, $shiftId]
        );
    }

    private static function haversine(float $lat1, float $lng1, float $lat2, float $lng2): float
    {
        $r = 6371000.0;
        $dLat = deg2rad($lat2 - $lat1);
        $dLng = deg2rad($lng2 - $lng1);
        $a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;
        return 2 * $r * asin(min(1.0, sqrt($a)));
    }
}
