<?php
/**
 * ImpactService – Estimated environmental impact.
 * Formula: Estimated Impact = Quantity × Configured Factor (see impact_factors).
 * All outputs are clearly labelled "Estimated" and carry a methodology version.
 */
class ImpactService
{
    /** Calculate + persist impact for a waste transaction. Returns impact row or null if no factor configured. */
    public static function calculateForTransaction(int $txId): ?array
    {
        $tx = Database::one('SELECT * FROM waste_transactions WHERE id = ?', [$txId]);
        if (!$tx) return null;

        $existing = Database::one('SELECT * FROM environmental_impacts WHERE waste_transaction_id = ?', [$txId]);
        if ($existing) return $existing; // idempotent

        $factor = Database::one('SELECT * FROM impact_factors WHERE category_id = ? AND status = "ACTIVE" LIMIT 1', [$tx['category_id']]);
        if (!$factor) return null;

        $q = (float) $tx['current_weight'];
        $impact = [
            'waste_transaction_id' => $txId,
            'category_id'          => $tx['category_id'],
            'quantity'             => $q,
            'co2_saved_kg'         => round($q * (float) $factor['co2_kg_per_kg'], 3),
            'water_saved_l'        => round($q * (float) $factor['water_l_per_kg'], 2),
            'energy_saved_kwh'     => round($q * (float) $factor['energy_kwh_per_kg'], 3),
            'landfill_diverted_kg' => round($q * (float) ($factor['landfill_diverted_pct'] ?? 100) / 100, 3),
            'methodology_version'  => $factor['methodology_version'] ?: METHODOLOGY_VERSION,
        ];
        Database::insert('environmental_impacts', $impact);
        WasteJourneyService::addEvent($txId, 'IMPACT_CALCULATED', [
            'actor_role' => 'SYSTEM',
            'notes'      => 'Estimated impact calculated (' . $impact['methodology_version'] . '): CO2e avoided ' .
                            $impact['co2_saved_kg'] . ' kg, water saved ' . $impact['water_saved_l'] . ' L.',
            'quantity'   => $q,
        ]);
        return Database::one('SELECT * FROM environmental_impacts WHERE waste_transaction_id = ?', [$txId]);
    }

    public static function forTransaction(int $txId): ?array
    {
        return Database::one('SELECT * FROM environmental_impacts WHERE waste_transaction_id = ?', [$txId]);
    }

    /** Aggregated estimated impact for one source user (citizen or organization). */
    public static function summaryForUser(int $userId): array
    {
        return Database::one(
            'SELECT COALESCE(SUM(ei.quantity),0) AS qty, COALESCE(SUM(ei.co2_saved_kg),0) AS co2,
                    COALESCE(SUM(ei.water_saved_l),0) AS water, COALESCE(SUM(ei.energy_saved_kwh),0) AS energy,
                    COALESCE(SUM(ei.landfill_diverted_kg),0) AS diverted, COUNT(*) AS records
             FROM environmental_impacts ei
             JOIN waste_transactions wt ON wt.id = ei.waste_transaction_id
             WHERE wt.source_user_id = ?', [$userId]) ?? [];
    }

    /** Global estimated impact (admin dashboards). */
    public static function globalSummary(): array
    {
        return Database::one(
            'SELECT COALESCE(SUM(quantity),0) AS qty, COALESCE(SUM(co2_saved_kg),0) AS co2,
                    COALESCE(SUM(water_saved_l),0) AS water, COALESCE(SUM(energy_saved_kwh),0) AS energy,
                    COALESCE(SUM(landfill_diverted_kg),0) AS diverted, COUNT(*) AS records
             FROM environmental_impacts') ?? [];
    }

    /** Equivalent-car-style helper text (still estimated). */
    public static function equivalents(array $summary): array
    {
        $co2 = (float) ($summary['co2'] ?? 0);
        return [
            'trees'    => round($co2 / 21, 1),            // ~21 kg CO2 / tree / year
            'car_km'   => round($co2 / 0.12, 0),          // ~120 g CO2 / km
            'phone'    => round((float) ($summary['energy'] ?? 0) / 0.012, 0), // ~12 Wh smartphone charge
        ];
    }
}
