<?php
/**
 * ShiftPdfService (v2.13.0) — branded letterhead PDF reports, shared by
 * admin/shift-pdf.php (single shift), admin/shifts-pdf.php (filtered management
 * report) and collector/shift-pdf.php (own shift only, IDOR-safe).
 *
 * Reliability contract (the "PDF won't download" class of bugs can never come back):
 *  - The whole build runs under a suppress-and-log error handler + deprecation-immune
 *    error_reporting + display_errors off. A benign XAMPP PHP-version warning can
 *    therefore NEVER abort a download again; the strict handler is restored after.
 *  - PnvReportPDF subclasses tFPDF with #[\AllowDynamicProperties] (PHP 8.2+ proof).
 *  - Output buffers are flushed right before the stream (tFPDF refuses to send once
 *    any byte has leaked).
 *  - Every failure is logged with full detail to storage/logs; the user sees only a
 *    clean, safe message.
 *
 * No-data rule (v2.13.0): the filtered management report refuses to generate a PDF
 * when zero records match the filters — checked server-side BEFORE the PDF library
 * is even loaded. No blank or letterhead-only PDF is ever produced.
 *
 * §13: GPS appears as a lightweight summary (points, window, last accuracy) — never
 * bulk points. Branding uses ONLY configured values (platform name, tagline, support
 * contact, default city/state) — nothing is invented.
 */
require_once dirname(__DIR__) . '/vendor/tfpdf/font/unifont/ttfonts.php';
require_once dirname(__DIR__) . '/vendor/tfpdf/tfpdf.php';

#[\AllowDynamicProperties]
class PnvReportPDF extends tFPDF
{
    public string $refNo = '';
    public string $reportTitle = 'REPORT';
    public string $genOn = '';

    public function Header(): void
    {
        if ($this->PageNo() < 2) return; // page 1 draws the full letterhead manually
        $this->SetTextColor(14, 122, 79);
        $this->SetFont('DejaVu', 'B', 8);
        $this->SetY(10);
        $this->Cell(0, 5, 'PUNARVA — ' . $this->reportTitle . ' (continued)', 0, 1, 'L');
        $this->SetDrawColor(14, 122, 79);
        $this->SetLineWidth(0.4);
        $this->Line(14, 16, $this->GetPageWidth() - 14, 16); // v2.17.1 dynamic (portrait = 196, unchanged)
        $this->SetY(20);
    }

    public function pageBreakTrigger(): float
    {
        return (float) $this->PageBreakTrigger; // protected in tFPDF — safe accessor for the table renderer
    }

    public function Footer(): void
    {
        $this->SetY(-16);
        $this->SetDrawColor(200, 210, 204);
        $this->SetLineWidth(0.3);
        $this->Line(14, $this->GetY() - 1.5, $this->GetPageWidth() - 14, $this->GetY() - 1.5); // v2.17.1 dynamic (portrait = 196, unchanged)
        $this->SetFont('DejaVu', '', 7);
        $this->SetTextColor(110, 110, 110);
        $this->Cell(105, 4.4, 'PUNARVA — Municipal Waste Management Platform', 0, 0, 'L');
        $this->Cell(0, 4.4, 'Page ' . $this->PageNo() . ' of {nb}', 0, 1, 'R');
        $this->Cell(0, 3.4, 'Generated on: ' . ($this->genOn !== '' ? $this->genOn : date('d M Y, h:i A'))
            . '  ·  Ref: ' . $this->refNo . '  ·  Internal operational record, not a government document.', 0, 0, 'C');
    }
}

class ShiftPdfService
{
    /**
     * Build the branded document shell (letterhead + fonts). Public since v2.16.0 —
     * any PUNARVA report (shift PDFs, audit exports) shares this ONE engine.
     */
    public static function open(string $reportTitle, string $orientation = 'P'): PnvReportPDF
    {
        // v2.16.0 — PATH-SAFE FONT VALIDATION (root-cause hardening for the
        // "Can't open file …/unifont/DejaVuSans.ttf" error): the two Unicode font
        // files are resolved dynamically from the APPLICATION ROOT — identical
        // layout on XAMPP (C:\\xampp\\htdocs\\punarva) and Linux — and verified
        // to exist AND be readable BEFORE any PDF work starts. A missing or
        // unreadable font therefore fails cleanly (clean message + log + audit),
        // never as a raw filesystem error and never as a corrupted download.
        $fontDir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR
            . 'tfpdf' . DIRECTORY_SEPARATOR . 'font' . DIRECTORY_SEPARATOR . 'unifont' . DIRECTORY_SEPARATOR;
        // v2.16.1 — also reject TRUNCATED (partial FTP/extraction) and CORRUPTED fonts:
        // a real DejaVuSans TTF is ~700 KB and starts with a TrueType magic header.
        foreach (['DejaVuSans.ttf', 'DejaVuSans-Bold.ttf'] as $fontFile) {
            $fontPath = $fontDir . $fontFile;
            if (!is_file($fontPath) || !is_readable($fontPath) || (int) @filesize($fontPath) < 100000) {
                error_log('[PUNARVA] PDF Unicode font missing/truncated/unreadable: ' . $fontFile . ' (expected inside the package "vendor/tfpdf/font/unifont" folder, ~700 KB each)');
                throw new RuntimeException('The PDF Unicode fonts are missing, incomplete or unreadable on this server. Please re-copy the complete "vendor/tfpdf/font" folder from the original PUNARVA package and try again (or open tools/pdf_selftest.php as administrator for a diagnosis).');
            }
            $magic = (string) @file_get_contents($fontPath, false, null, 0, 4);
            if ($magic !== "\x00\x01\x00\x00" && substr($magic, 0, 4) !== 'true' && substr($magic, 0, 4) !== 'OTTO') {
                error_log('[PUNARVA] PDF Unicode font corrupted (bad magic header): ' . $fontFile);
                throw new RuntimeException('A PDF Unicode font file on this server is corrupted. Please re-copy the complete "vendor/tfpdf/font" folder from the original PUNARVA package and try again.');
            }
        }
        $pdf = new PnvReportPDF($orientation, 'mm', 'A4'); // v2.17.1: optional orientation (default portrait — existing documents unchanged)
        $pdf->refNo = 'PNV-SR-' . date('ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));
        $pdf->reportTitle = $reportTitle;
        $pdf->genOn = date('d M Y, h:i A');
        $pdf->AliasNbPages('{nb}');
        $pdf->SetMargins(14, 14, 14);
        $pdf->SetAutoPageBreak(true, 24);
        $pdf->AddFont('DejaVu', '', 'DejaVuSans.ttf', true);
        $pdf->AddFont('DejaVu', 'B', 'DejaVuSans-Bold.ttf', true);
        $pdf->AddPage();

        // ---- Letterhead (configured data only; nothing invented) ----
        $logo = dirname(__DIR__) . '/assets/images/logo-full.png';
        $top = 11;
        if (is_file($logo)) {
            try { $pdf->Image($logo, 14, $top, 0, 14); } catch (Throwable $e) { /* text-only fallback */ }
        }
        $pdf->SetXY(14, $top + 15.5);
        $pdf->SetFont('DejaVu', 'B', 13.5);
        $pdf->SetTextColor(14, 122, 79);
        $pdf->Cell(0, 6.4, (string) setting('platform_name', 'PUNARVA'), 0, 1, 'L');
        $pdf->SetFont('DejaVu', '', 8);
        $pdf->SetTextColor(90, 110, 98);
        $pdf->Cell(0, 4, 'From Waste to Worth', 0, 1, 'L');
        $contact = array_filter([
            (string) setting('support_email', ''),
            (string) setting('support_phone', ''),
            trim((string) setting('default_city', '') . ((string) setting('default_state', '') !== '' ? ', ' . (string) setting('default_state', '') : '')),
        ], fn($v) => $v !== '');
        $cy = $top + 1;
        foreach ($contact as $line) {
            $pdf->SetXY($pdf->GetPageWidth() - 92, $cy); // v2.17.1 dynamic (portrait = 118, unchanged)
            $pdf->SetFont('DejaVu', '', 8);
            $pdf->SetTextColor(90, 110, 98);
            $pdf->Cell(78, 4.2, (string) $line, 0, 0, 'R');
            $cy += 4.4;
        }
        $pdf->SetY($top + 28);
        $pdf->SetDrawColor(14, 122, 79);
        $pdf->SetLineWidth(0.8);
        $pdf->Line(14, $pdf->GetY(), $pdf->GetPageWidth() - 14, $pdf->GetY()); // v2.17.1 dynamic (portrait = 196, unchanged)
        $pdf->SetY($pdf->GetY() + 6);
        return $pdf;
    }

    /** Public wrapper: shared report head for all PUNARVA documents (v2.16.0). */
    public static function reportHeadPublic(PnvReportPDF $pdf, string $title, array $meta): void
    {
        self::reportHead($pdf, $title, $meta);
    }

    /** Public wrapper: shared summary block for all PUNARVA documents (v2.16.0). */
    public static function summaryBlockPublic(PnvReportPDF $pdf, array $items): void
    {
        self::summaryBlock($pdf, $items);
    }

    /** Green-ruled report title + meta block. */
    private static function reportHead(PnvReportPDF $pdf, string $title, array $meta): void
    {
        $pdf->SetFont('DejaVu', 'B', 15);
        $pdf->SetTextColor(20, 20, 20);
        $pdf->Cell(0, 8, $title, 0, 1, 'L');
        $pdf->Ln(1);
        $pdf->SetTextColor(70, 80, 74);
        foreach ($meta as [$k, $v]) {
            $pdf->SetFont('DejaVu', 'B', 8.6);
            $pdf->Cell(40, 4.6, $k . ':', 0, 0, 'L');
            $pdf->SetFont('DejaVu', '', 8.6);
            $pdf->Cell(0, 4.6, (string) $v, 0, 1, 'L');
        }
        $pdf->Ln(2.5);
    }

    /** Zebra table that never splits a row across pages. Widths must sum to 182. */
    private static function table(PnvReportPDF $pdf, array $headers, array $widths, array $rows, array $aligns = []): void
    {
        $aligns = $aligns ?: array_fill(0, count($headers), 'L');
        $rowH = 6.8;
        $pdf->SetDrawColor(190, 205, 197);
        $pdf->SetLineWidth(0.2);
        $pdf->SetFont('DejaVu', 'B', 8.4);
        $pdf->SetFillColor(14, 122, 79);
        $pdf->SetTextColor(255, 255, 255);
        foreach ($headers as $i => $h) $pdf->Cell($widths[$i], 7.2, $h, 1, 0, 'L', true);
        $pdf->Ln();
        $fill = false;
        foreach ($rows as $cells) {
            if ($pdf->GetY() + $rowH > $pdf->pageBreakTrigger()) $pdf->AddPage(); // clean break before the row
            $pdf->SetFont('DejaVu', '', 8.2);
            $pdf->SetTextColor(25, 30, 27);
            $pdf->SetFillColor(243, 248, 245);
            foreach ($cells as $i => $c) $pdf->Cell($widths[$i], $rowH, mb_substr((string) $c, 0, 34), 1, 0, $aligns[$i], $fill);
            $pdf->Ln();
            $fill = !$fill;
        }
    }

    private static function summaryBlock(PnvReportPDF $pdf, array $items): void
    {
        if ($pdf->GetY() > $pdf->pageBreakTrigger() - 30) $pdf->AddPage();
        $pdf->Ln(4);
        $pdf->SetFont('DejaVu', 'B', 10);
        $pdf->SetTextColor(20, 20, 20);
        $pdf->Cell(0, 6.4, 'Report Summary', 0, 1, 'L');
        foreach ($items as $k => $v) {
            $pdf->SetFont('DejaVu', 'B', 9);
            $pdf->Cell(64, 5.2, (string) $k . ':', 0, 0, 'L');
            $pdf->SetFont('DejaVu', '', 9);
            $pdf->Cell(0, 5.2, (string) $v, 0, 1, 'L');
        }
    }

    /** Shielded runner — ALL PDF code executes inside this. */
    public static function shielded(callable $fn): void
    {
        $prevHandler = set_error_handler(function ($severity, $message, $file, $line) {
            if (!(error_reporting() & $severity)) return false;
            error_log('[PUNARVA] shift-pdf suppressed notice: ' . $message . ' @' . basename((string) $file) . ':' . $line);
            return true;
        });
        $prevEr = error_reporting(error_reporting() & ~(E_DEPRECATED | E_NOTICE));
        $prevDe = ini_set('display_errors', '0');
        try {
            $fn();
        } finally {
            ini_set('display_errors', $prevDe ?: '');
            error_reporting($prevEr);
            set_error_handler($prevHandler);
        }
    }

    public static function stream(PnvReportPDF $pdf, string $name, ?callable $onSuccess = null): void
    {
        // v2.14.0 — byte-level airtight streaming:
        // (1) build the PDF in memory ('S') so NOTHING can echo between headers and body,
        // (2) verify the %PDF magic ourselves — a corrupt/empty document is never downloaded,
        // (3) wipe every output buffer, then send exact Content-Length and stop.
        $bytes = $pdf->Output('S', $name);
        if (!is_string($bytes) || strlen($bytes) < 100 || strncmp($bytes, '%PDF-', 5) !== 0) {
            throw new RuntimeException('PDF document did not render a valid %PDF body (' . strlen((string) $bytes) . ' bytes).');
        }
        while (ob_get_level() > 0) { @ob_end_clean(); } // zero stray bytes before the stream
        if (headers_sent($hsFile, $hsLine)) {
            throw new RuntimeException('Output already started at ' . $hsFile . ':' . $hsLine . ' — PDF headers cannot be sent.');
        }
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        header('Content-Length: ' . strlen($bytes));
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, max-age=0, must-revalidate');
        // v2.16.0: the download is only audit-logged once a valid PDF body is guaranteed
        if ($onSuccess) $onSuccess($name, $pdf->refNo);
        echo $bytes;
        exit;
    }

    /** Friendly failure: full detail to the server log, safe message to the user,
     *  and a SHIFT_PDF_FAILED audit event (never recorded as a successful download).
     *  The audit carries only actor/role/shift + exception CLASS — never paths/messages. */
    private static function fail(Throwable $e, string $backTo, array $ctx = []): void
    {
        error_log('[PUNARVA] shift PDF failed: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
        AuditService::log('SHIFT_PDF_FAILED', 'driver_shifts', isset($ctx['shift']) ? (int) $ctx['shift'] : null, null,
            ['by' => $ctx['by'] ?? null, 'role' => $ctx['role'] ?? '', 'reason' => short_class($e)]);
        @file_put_contents(
            (defined('LOG_DIR') ? LOG_DIR : sys_get_temp_dir()) . '/app-' . date('Y-m-d') . '.log',
            '[' . date('c') . '] shift PDF failed: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() . PHP_EOL . $e->getTraceAsString() . PHP_EOL . PHP_EOL,
            FILE_APPEND
        );
        flash('danger', 'Unable to generate the PDF right now. Please try again — if it keeps failing, contact the administrator (the technical reason has been recorded in the server log).');
        redirect($backTo);
    }

    // ------------------------------------------------------------ single shift PDF
    public static function downloadFor(array $user, bool $isAdmin, int $id): void
    {
        $role = $user['role_code'] ?? '';
        if (!in_array($role, [ROLE_ADMIN, ROLE_COLLECTOR], true)) {
            flash('danger', 'You are not allowed to download shift reports.');
            redirect(ROLE_HOME[$role] ?? 'index.php');
        }
        $backTo = $isAdmin ? 'admin/shifts.php' : 'collector/shifts.php';
        try {
            $shift = Database::one(
                'SELECT ds.*, u.name AS driver_name, v.vehicle_number, v.vehicle_type
                 FROM driver_shifts ds
                 JOIN users u ON u.id = ds.driver_user_id
                 JOIN vehicles v ON v.id = ds.vehicle_id
                 WHERE ds.id = ?',
                [$id]
            );
            if (!$shift) {
                flash('warning', 'Shift record not found.');
                redirect($backTo);
            }
            // IDOR: collectors may only export their OWN shift
            if (!$isAdmin && (int) $shift['driver_user_id'] !== (int) $user['id']) {
                AuditService::log('SHIFT_PDF_DENIED', 'driver_shifts', $id, null, ['by' => (int) $user['id']]);
                flash('danger', 'You can only download your own shift report.');
                redirect('collector/shifts.php');
            }

            // §13 GPS summary — aggregates only
            $pts = (int) Database::val('SELECT COUNT(*) FROM driver_locations WHERE shift_id = ?', [$id]);
            $first = Database::val('SELECT MIN(recorded_at) FROM driver_locations WHERE shift_id = ?', [$id]);
            $last = Database::val('SELECT MAX(recorded_at) FROM driver_locations WHERE shift_id = ?', [$id]);
            $lastAcc = Database::val('SELECT accuracy_m FROM driver_locations WHERE shift_id = ? ORDER BY id DESC LIMIT 1', [$id]);
            $gpsStatus = $shift['status'] === 'ACTIVE' ? TrackingService::statusFor($shift['last_ping_at']) : (($pts || $shift['last_ping_at']) ? 'RECORDED' : 'UNAVAILABLE');

            self::shielded(function () use ($shift, $gpsStatus, $pts, $first, $last, $lastAcc, $user, $isAdmin) {
                $pdf = self::open('Shift Report');
                self::reportHead($pdf, 'SHIFT REPORT', [
                    ['Reference No', $pdf->refNo],
                    ['Generated On', date('d F Y, h:i A')],
                    ['Report Generated By', $user['name'] . ' (' . ($isAdmin ? 'Administrator' : 'Waste Collector') . ')'],
                ]);

                self::table($pdf,
                    ['Field', 'Details'],
                    [52, 130],
                    [
                        ['Driver / Collector', $shift['driver_name']],
                        ['Truck', $shift['vehicle_number'] . ($shift['vehicle_type'] ? ' · ' . $shift['vehicle_type'] : '')],
                        ['Shift Date', shift_date($shift['started_at'])],
                        ['Punch In', shift_time($shift['started_at'])],
                        ['Punch Out', shift_time($shift['ended_at'])],
                        ['Duration', shift_duration($shift['started_at'], $shift['ended_at'])],
                        ['Shift Status', $shift['status']],
                        ['GPS Status', $gpsStatus],
                        ['Last GPS Update', $shift['last_ping_at'] ? shift_date($shift['last_ping_at']) . ', ' . shift_time($shift['last_ping_at']) : 'Not available'],
                        ['Punch-In Location', $pts ? 'Available' : 'Not available'],
                        ['GPS Points', (string) $pts . ($lastAcc !== null ? ' (last accuracy ' . round((float) $lastAcc, 1) . ' m)' : '')],
                        ['Trail Window', $pts ? shift_date($first) . ' ' . shift_time($first) . ' → ' . shift_time($last) : '—'],
                    ]
                );

                self::summaryBlock($pdf, [
                    'Shift Result' => $shift['status'] === 'ENDED'
                        ? 'Completed shift · duration ' . shift_duration($shift['started_at'], $shift['ended_at'])
                        : 'Shift in progress',
                    'GPS Coverage' => $pts ? $pts . ' location points recorded (summary only)' : 'No GPS trail recorded for this shift',
                ]);

                $name = 'PNV-Shift-Report-' . $pdf->refNo . '.pdf';
                self::stream($pdf, $name, function (string $fname, string $ref) use ($shift, $user) {
                    AuditService::log('SHIFT_PDF', 'driver_shifts', (int) $shift['id'], null,
                        ['by' => (int) $user['id'], 'role' => $user['role_code'] ?? '', 'shift_id' => (int) $shift['id'], 'ref' => $ref]);
                });
            });
        } catch (Throwable $e) {
            self::fail($e, $backTo, ['by' => (int) $user['id'], 'role' => $role, 'shift' => $id]);
        }
    }

    // --------------------------------------------- filtered management report (admin)
    public static function managementReport(array $user): void
    {
        $backTo = 'admin/shifts.php';
        try {
            $f = shift_filters_parse();
            // preserve the user's filters when we bounce back with a message
            $qs = $_SERVER['QUERY_STRING'] ?? '';
            $backFiltered = $qs !== '' ? $backTo . '?' . $qs : $backTo;

            // ---- NO-DATA RULE: count with the SAME filters as the report query ----
            $total = (int) Database::val('SELECT COUNT(*) FROM driver_shifts ds WHERE ' . $f['where'], $f['params']);
            if ($total === 0) {
                AuditService::log('SHIFT_REPORT_NO_DATA', 'driver_shifts', null, null, ['filters' => implode('; ', $f['labels'])]);
                flash('warning', 'No shift records found for the selected filters. PDF download is unavailable because there is no data.');
                redirect($backFiltered);
            }

            $cap = 1000; // §17: bounded memory; more rows are summarised, not silently dumped
            $rows = Database::all(
                'SELECT ds.id, ds.status, ds.started_at, ds.ended_at, ds.last_ping_at,
                        u.name AS driver_name, v.vehicle_number
                 FROM driver_shifts ds
                 JOIN users u ON u.id = ds.driver_user_id
                 JOIN vehicles v ON v.id = ds.vehicle_id
                 WHERE ' . $f['where'] . '
                 ORDER BY ds.started_at DESC, ds.id DESC
                 LIMIT ' . ($cap + 1),
                $f['params']
            );
            $truncated = count($rows) > $cap;
            $rows = array_slice($rows, 0, $cap);

            // summary over the SAME filtered set (exact SQL counts)
            $active = (int) Database::val('SELECT COUNT(*) FROM driver_shifts ds WHERE ' . $f['where'] . ' AND ds.status = "ACTIVE"', $f['params']);
            $ended = (int) Database::val('SELECT COUNT(*) FROM driver_shifts ds WHERE ' . $f['where'] . ' AND ds.status = "ENDED"', $f['params']);
            $nogps = (int) Database::val('SELECT COUNT(*) FROM driver_shifts ds WHERE ' . $f['where'] . ' AND ds.last_ping_at IS NULL AND NOT EXISTS (SELECT 1 FROM driver_locations dl WHERE dl.shift_id = ds.id)', $f['params']);

            // driver/truck labels for the filter line
            if ($f['driver']) {
                $d = Database::one('SELECT name FROM users WHERE id = ?', [$f['driver']]);
                foreach ($f['labels'] as &$lb) if (str_starts_with($lb, 'Driver:')) $lb = 'Driver: ' . ($d['name'] ?? '#' . $f['driver']);
                unset($lb);
            }

            self::shielded(function () use ($f, $rows, $truncated, $cap, $active, $ended, $nogps, $total, $user) {
                $pdf = self::open('Shift Management Report');
                $range = ($f['from'] ?: 'beginning') . '  →  ' . ($f['to'] ?: date('Y-m-d'));
                self::reportHead($pdf, 'SHIFT MANAGEMENT REPORT', [
                    ['Reference No', $pdf->refNo],
                    ['Generated On', date('d F Y, h:i A')],
                    ['Report Generated By', $user['name'] . ' (Administrator)'],
                    ['Date Range', $range],
                    ['Filters', $f['labels'] ? implode(' · ', $f['labels']) : 'None (all records)'],
                ]);

                $tableRows = [];
                foreach ($rows as $r) {
                    $tableRows[] = [
                        shift_date($r['started_at']),
                        $r['driver_name'],
                        $r['vehicle_number'],
                        shift_time($r['started_at']),
                        shift_time($r['ended_at']),
                        shift_duration($r['started_at'], $r['ended_at']),
                        $r['status'],
                        $r['last_ping_at'] ? 'Last fix ' . shift_time($r['last_ping_at']) : 'No GPS',
                    ];
                }
                self::table($pdf,
                    ['Date', 'Driver', 'Truck', 'Punch In', 'Punch Out', 'Duration', 'Status', 'GPS'],
                    [22, 38, 22, 18, 18, 18, 18, 28],
                    $tableRows
                );
                if ($truncated) {
                    $pdf->Ln(2);
                    $pdf->SetFont('DejaVu', '', 8);
                    $pdf->SetTextColor(110, 110, 110);
                    $pdf->Cell(0, 4.4, 'Report truncated to the first ' . $cap . ' matching records (a larger result set was summarised, not silently dumped).', 0, 1, 'L');
                }

                self::summaryBlock($pdf, [
                    'Total Shifts' => number_format((float) $total) . ' matching record(s)',
                    'Active Shifts' => number_format((float) $active),
                    'Completed Shifts' => number_format((float) $ended),
                    'GPS Unavailable' => number_format((float) $nogps),
                ]);

                $name = 'PNV-Shift-Report-' . $pdf->refNo . '.pdf';
                self::stream($pdf, $name, function (string $fname, string $ref) use ($rows, $f, $user) {
                    AuditService::log('SHIFT_REPORT_PDF', 'driver_shifts', null, null,
                        ['by' => (int) $user['id'], 'role' => $user['role_code'] ?? '', 'rows' => count($rows), 'filters' => implode('; ', $f['labels']), 'ref' => $ref]);
                });
            });
        } catch (Throwable $e) {
            self::fail($e, $backTo, ['by' => (int) $user['id'], 'role' => $user['role_code'] ?? '']);
        }
    }
}
