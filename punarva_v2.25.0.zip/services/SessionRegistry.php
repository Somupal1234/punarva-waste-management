<?php
/**
 * SessionRegistry — DB-backed, server-side per-user session control.
 *
 * Policy (role-based):
 *   Admin / Collector  → exactly ONE active session. A new login immediately
 *                        revokes every previous session of that user; the old
 *                        device is logged out on its very next request.
 *   Citizen / Business / Recycler → multiple concurrent sessions allowed.
 *
 * Also powers: password change → revoke other sessions,
 *              forgot-password reset / account disable → revoke ALL sessions.
 *
 * Timezone-safe: all timestamps are written and compared with SQL NOW()
 * (never PHP time vs MySQL time). Idle/absolute timeouts stay in init.php
 * and remain fully enforced.
 */
class SessionRegistry
{
    /** Roles that may hold only one active session at a time. */
    public const SINGLE_SESSION_ROLES = [ROLE_ADMIN, ROLE_COLLECTOR];

    public static function singleSession(string $roleCode): bool
    {
        return in_array($roleCode, self::SINGLE_SESSION_ROLES, true);
    }

    public static function ensureTable(): void
    {
        Database::run('CREATE TABLE IF NOT EXISTS user_sessions (
            session_id  VARCHAR(191) PRIMARY KEY,
            user_id     INT UNSIGNED NOT NULL,
            ip          VARCHAR(45)  NULL,
            user_agent  VARCHAR(255) NULL,
            created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            revoked_at  DATETIME NULL,
            KEY idx_us_user (user_id, revoked_at),
            CONSTRAINT fk_us_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    }

    /**
     * Record the current PHP session (call AFTER session_regenerate_id on login).
     * Single-session roles: every previous session of the user is revoked first.
     */
    public static function register(int $userId, string $roleCode): void
    {
        self::ensureTable();
        if (self::singleSession($roleCode)) {
            $n = self::revokeOthers($userId);
            if ($n > 0) {
                AuditService::log('SESSIONS_REVOKED', 'auth', $userId, null,
                    ['count' => $n, 'reason' => 'new login superseded old session(s)', 'role' => $roleCode]);
            }
        }
        Database::run(
            'INSERT INTO user_sessions (session_id, user_id, ip, user_agent, last_seen_at)
             VALUES (?, ?, ?, ?, NOW())
             ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), ip = VALUES(ip),
                user_agent = VALUES(user_agent), revoked_at = NULL, last_seen_at = NOW()',
            [session_id(), $userId, client_ip(), substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255)]
        );
    }

    /**
     * Per-request check for logged-in users. Returns false when the current
     * session was revoked (superseded by a newer login / password reset / disable)
     * OR has no registry row at all (session predates the registry, or the
     * registry was reset by a DB re-import). Missing rows must NEVER be
     * self-healed back to active — that would resurrect sessions a newer
     * login already superseded. Such users simply log in again (the new
     * login re-registers the row correctly).
     */
    public static function enforce(int $userId): bool
    {
        self::ensureTable();
        $sid = session_id();
        if ($sid === '') return true;
        $row = Database::one('SELECT revoked_at FROM user_sessions WHERE session_id = ? AND user_id = ?', [$sid, $userId]);
        if (!$row) return false; // unregistered/legacy session → re-authenticate (no resurrection)
        if ($row['revoked_at'] !== null) return false;
        Database::run('UPDATE user_sessions SET last_seen_at = NOW() WHERE session_id = ?', [$sid]);
        return true;
    }

    /** Revoke every ACTIVE session of a user except the given session id. Returns affected count. */
    public static function revokeOthers(int $userId, ?string $except = null): int
    {
        self::ensureTable();
        $sql = 'UPDATE user_sessions SET revoked_at = NOW() WHERE user_id = ? AND revoked_at IS NULL';
        $params = [$userId];
        if ($except !== null && $except !== '') { $sql .= ' AND session_id <> ?'; $params[] = $except; }
        return Database::run($sql, $params)->rowCount();
    }

    /** Revoke ALL sessions of a user (password reset / account disable). Returns affected count. */
    public static function revokeAll(int $userId): int
    {
        self::ensureTable();
        return Database::run('UPDATE user_sessions SET revoked_at = NOW() WHERE user_id = ? AND revoked_at IS NULL', [$userId])->rowCount();
    }

    /** Mark the CURRENT session revoked (logout path). */
    public static function revokeCurrent(): void
    {
        $sid = session_id();
        if ($sid === '') return;
        self::ensureTable();
        Database::run('UPDATE user_sessions SET revoked_at = NOW() WHERE session_id = ? AND revoked_at IS NULL', [$sid]);
    }
}
