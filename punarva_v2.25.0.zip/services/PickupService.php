<?php
/**
 * PickupService – citizen/organization pickup requests, collector assignment and the
 * REQUESTED → … → COMPLETED state machine (including cancellation rules).
 */
class PickupService
{
    public static function create(array $user, array $d): array
    {
        $categoryId = (int) ($d['category_id'] ?? 0);
        $category   = Database::one('SELECT * FROM waste_categories WHERE id = ? AND status = "ACTIVE"', [$categoryId]);
        if (!$category) throw new InvalidArgumentException('Please choose a valid waste category.');

        $weight = val_float($d, 'estimated_weight', 0.1, 5000, true, 'Estimated weight');
        $date   = val_str($d, 'preferred_date', 10);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || strtotime($date) === false) {
            throw new InvalidArgumentException('Pickup date is invalid.');
        }
        if (strtotime($date) < strtotime(date('Y-m-d'))) throw new InvalidArgumentException('Pickup date cannot be in the past.');
        $slot = val_str($d, 'time_slot', 30);
        if (!in_array($slot, ['06:00-09:00','09:00-12:00','12:00-15:00','15:00-18:00','18:00-20:00'], true)) {
            throw new InvalidArgumentException('Please choose a valid time slot.');
        }
        $address = val_str($d, 'address_line', 255, true, 'Pickup address');
        [$lat, $lng] = val_latlng($d);
        $image = handle_upload($d['image'] ?? null, 'waste');

        $orgId = $user['role_code'] === ROLE_BUSINESS ? $user['organization_id'] : ($d['organization_id'] ?? null);
        $pickupCode = rand_code('PNVP');
        $id = Database::insert('pickup_requests', [
            'pickup_code'      => $pickupCode,
            'user_id'          => $user['id'],
            'organization_id'  => $orgId ?: null,
            'category_id'      => $categoryId,
            'estimated_weight' => $weight,
            'preferred_date'   => $date,
            'time_slot'        => $slot,
            'address_line'     => $address,
            'ward'             => val_str($d, 'ward', 40, false) ?: null,
            'city'             => val_str($d, 'city', 80, false) ?: (string) setting('default_city', 'Dumka'),
            'latitude'         => $lat, 'longitude' => $lng,
            'notes'            => val_str($d, 'notes', 500, false) ?: null,
            'image_path'       => $image,
            'status'           => 'REQUESTED',
        ]);
        NotificationService::send((int) $user['id'], 'PICKUP', 'Pickup request created',
            'Your pickup ' . ($d['pickup_code'] ?? '') . ' has been received and is awaiting assignment.', 'pickup_request', $id);
        NotificationService::sendToRoles([ROLE_ADMIN], 'PICKUP', 'New pickup request',
            ($user['name']) . ' requested a ' . $category['name'] . ' pickup (' . fmt_kg($weight) . ').', 'pickup_request', $id);
        AuditService::log('PICKUP_CREATED', 'pickup', $id, null, ['category' => $category['name'], 'weight' => $weight]);
        return Database::one('SELECT * FROM pickup_requests WHERE id = ?', [$id]);
    }

    public static function assign(int $pickupId, int $collectorId, array $actor): array
    {
        $pickup = Database::one('SELECT * FROM pickup_requests WHERE id = ?', [$pickupId]);
        if (!$pickup) throw new InvalidArgumentException('Pickup request not found.');
        if (!in_array($pickup['status'], ['REQUESTED', 'ASSIGNED'], true)) {
            throw new InvalidArgumentException('This pickup can no longer be assigned (status: ' . $pickup['status'] . ').');
        }
        $collector = Database::one(
            'SELECT u.*, f.name AS facility_name FROM users u LEFT JOIN facilities f ON f.id = u.facility_id
             WHERE u.id = ? AND u.status = "ACTIVE" AND u.role_id = (SELECT id FROM roles WHERE code = "collector")', [$collectorId]);
        if (!$collector) throw new InvalidArgumentException('Selected collector is not an active collector.');

        $pdo = db();
        Database::begin();
        try {
            $existing = Database::one('SELECT * FROM pickup_assignments WHERE pickup_request_id = ?', [$pickupId]);
            if ($existing) {
                if ((int) $existing['collector_id'] === $collectorId) throw new InvalidArgumentException('This pickup is already assigned to that collector.');
                Database::update('pickup_assignments',
                    ['collector_id' => $collectorId, 'status' => 'ASSIGNED', 'assigned_at' => date('Y-m-d H:i:s'), 'assigned_by' => $actor['id']],
                    'id = ?', [$existing['id']]);
                $assignmentId = (int) $existing['id'];
            } else {
                $assignmentId = Database::insert('pickup_assignments', [
                    'pickup_request_id' => $pickupId, 'collector_id' => $collectorId,
                    'status' => 'ASSIGNED', 'assigned_by' => $actor['id'], 'assigned_at' => date('Y-m-d H:i:s'),
                ]);
            }
            Database::update('pickup_requests', ['status' => 'ASSIGNED', 'updated_at' => date('Y-m-d H:i:s')], 'id = ?', [$pickupId]);
            Database::commit();
        } catch (Throwable $e) { Database::rollBack(); throw $e; }

        NotificationService::send($collectorId, 'PICKUP', 'New pickup assigned',
            'Pickup ' . $pickup['pickup_code'] . ' (' . fmt_kg($pickup['estimated_weight']) . ') was assigned to you.', 'pickup_request', $pickupId);
        NotificationService::send((int) $pickup['user_id'], 'PICKUP', 'Collector assigned',
            'A collector has been assigned to your pickup ' . $pickup['pickup_code'] . '.', 'pickup_request', $pickupId);
        AuditService::log('PICKUP_ASSIGNED', 'pickup', $pickupId, $pickup['status'], 'ASSIGNED');
        return Database::one('SELECT * FROM pickup_assignments WHERE id = ?', [$assignmentId]);
    }

    /** Collector / admin state transitions with ownership + machine validation. */
    public static function transition(int $assignmentId, string $newStatus, array $user, array $d = []): array
    {
        $a = Database::one(
            'SELECT pa.*, pr.pickup_code, pr.user_id AS citizen_id, pr.category_id, pr.estimated_weight,
                    pr.address_line, pr.ward, pr.latitude, pr.longitude, pr.notes, pr.created_at AS requested_at,
                    pr.organization_id, cu.name AS citizen_name, wc.name AS category_name, wc.is_recyclable
             FROM pickup_assignments pa
             JOIN pickup_requests pr ON pr.id = pa.pickup_request_id
             JOIN users cu ON cu.id = pr.user_id
             JOIN waste_categories wc ON wc.id = pr.category_id
             WHERE pa.id = ?', [$assignmentId]);
        if (!$a) throw new InvalidArgumentException('Assignment not found.');
        if ($user['role_code'] === ROLE_COLLECTOR) OwnershipMiddleware::assignmentOwner($a, $user);

        $allowed = PICKUP_TRANSITIONS[$a['status']] ?? [];
        if (!in_array($newStatus, $allowed, true)) {
            throw new InvalidArgumentException('Invalid transition: ' . $a['status'] . ' → ' . $newStatus . '.');
        }

        $now = date('Y-m-d H:i:s');
        $tx = null; // v2.4.3: waste transaction (existing or newly created) — used for the citizen notification
        $data = ['status' => $newStatus, 'updated_at' => $now];
        $prData = ['status' => $newStatus, 'updated_at' => $now];
        switch ($newStatus) {
            case 'ACCEPTED':  $data['accepted_at'] = $now; break;
            case 'ON_THE_WAY': $data['started_at'] = $now; break;
            case 'ARRIVED':   $data['arrived_at'] = $now; break;
            case 'COLLECTED':
                $data['collected_at'] = $now;
                $data['actual_weight'] = val_float($d, 'actual_weight', 0.05, 5000, true, 'Actual weight');
                $data['proof_image']   = handle_upload($d['proof_image'] ?? null, 'proofs');
                $data['remarks']       = val_str($d, 'remarks', 300, false) ?: null;
                break;
            case 'COMPLETED':  $data['completed_at'] = $now; break;  // v2.11.1 fix: was never written by the flow
            case 'CANCELLED':
                $prData['cancelled_at'] = $now;
                $data['remarks'] = val_str($d, 'remarks', 300, false) ?: null;
                break;
        }

        $pdo = db();
        Database::begin();
        try {
            Database::update('pickup_assignments', $data, 'id = ?', [$assignmentId]);
            Database::update('pickup_requests', $prData, 'id = ?', [$a['pickup_request_id']]);

            if ($newStatus === 'COMPLETED') {
                // v2.4.3 — idempotency guard: a double-click / retry after a partial failure must
                // never hit the UNIQUE(pickup_request_id) key again (SQLSTATE 23000/1062).
                // Locking read serialises concurrent completes: the second request waits, then
                // sees the committed Waste Transaction and skips creation (statuses above are
                // simply re-written with the same values). A pre-existing orphan row (from an
                // old partial failure) is healed the same way.
                $tx = Database::one('SELECT id, waste_id FROM waste_transactions WHERE pickup_request_id = ? FOR UPDATE', [$a['pickup_request_id']]);
            }
            if ($newStatus === 'COMPLETED' && !$tx) {
                // 1) record completion, 2) create Waste Transaction (unique Waste ID) – one DB transaction
                $pickupRow = Database::one('SELECT * FROM pickup_requests WHERE id = ?', [$a['pickup_request_id']]);
                $assignmentRow = Database::one(
                    'SELECT pa.*, u.name AS collector_name FROM pickup_assignments pa JOIN users u ON u.id = pa.collector_id WHERE pa.id = ?',
                    [$assignmentId]);
                $assignmentRow['actual_weight'] = $data['actual_weight'] ?? ($assignmentRow['actual_weight'] ?? $a['estimated_weight']);
                $assignmentRow['proof_image']   = $data['proof_image'] ?? null;
                $assignmentRow['collected_at']  = $data['collected_at'] ?? $assignmentRow['collected_at'];
                $tx = WasteJourneyService::createFromPickup($pickupRow, $assignmentRow);
                WasteJourneyService::addEvent((int) $tx['id'], 'PICKUP_COMPLETED', [
                    'actor_id' => $user['id'], 'actor_role' => 'COLLECTOR',
                    'location' => $a['address_line'],
                    'notes' => 'Pickup ' . $a['pickup_code'] . ' completed. Waste Passport is now active.',
                    'quantity' => $data['actual_weight'] ?? null,
                ]);
                // v2.8.0: pickup COMPLETED is a verified real-world activity → Real Impact badges
                // (idempotent; replaces the old points award). $a['citizen_id'] = pickup owner.
                if ($a['citizen_id']) {
                    BadgeService::evaluateRealImpact((int) $a['citizen_id'], 'pickup', (int) $a['pickup_request_id']);
                }
            }
            Database::commit();
        } catch (Throwable $e) { Database::rollBack(); throw $e; }

        // Notifications
        $msg = [
            'ACCEPTED'   => 'Collector accepted your pickup ' . $a['pickup_code'] . '.',
            'ON_THE_WAY' => 'Your collector is on the way for pickup ' . $a['pickup_code'] . '.',
            'ARRIVED'    => 'Your collector has arrived for pickup ' . $a['pickup_code'] . '.',
            'COLLECTED'  => 'Your waste was collected (' . fmt_kg($data['actual_weight'] ?? 0) . '). Passport will activate on completion.',
            'COMPLETED'  => 'Pickup ' . $a['pickup_code'] . ' completed. Your Waste ID: ' . ($tx['waste_id'] ?? '—'),
            'CANCELLED'  => 'Pickup ' . $a['pickup_code'] . ' was cancelled.',
        ][$newStatus] ?? 'Pickup ' . $a['pickup_code'] . ' updated.';
        NotificationService::send((int) $a['citizen_id'], 'PICKUP', 'Pickup ' . strtolower(PICKUP_STATUS_LABELS[$newStatus]), $msg, 'pickup_request', $a['pickup_request_id']);
        if ($newStatus === 'COMPLETED') {
            AuditService::log('PICKUP_COMPLETED', 'pickup', (int) $a['pickup_request_id'], $a['status'], 'COMPLETED');
        } else {
            AuditService::log('PICKUP_' . $newStatus, 'pickup', (int) $a['pickup_request_id'], $a['status'], $newStatus);
        }
        return Database::one('SELECT pa.*, pr.pickup_code, pr.status AS pickup_status FROM pickup_assignments pa JOIN pickup_requests pr ON pr.id = pa.pickup_request_id WHERE pa.id = ?', [$assignmentId]);
    }

    public static function cancel(int $pickupId, array $user, string $reason = ''): void
    {
        $pickup = Database::one('SELECT * FROM pickup_requests WHERE id = ?', [$pickupId]);
        if (!$pickup) throw new InvalidArgumentException('Pickup request not found.');
        // v2.20.0 IDOR fix: ownership check for EVERY non-admin canceller — the endpoint
        // allows CITIZEN + BUSINESS + ADMIN, but previously only CITIZEN was ownership-
        // checked, so a business account could cancel any other user's pickup by id.
        if ($user['role_code'] !== ROLE_ADMIN) OwnershipMiddleware::pickupOwner($pickup, $user);
        $allowed = PICKUP_TRANSITIONS[$pickup['status']] ?? [];
        if (!in_array('CANCELLED', $allowed, true)) {
            throw new InvalidArgumentException('This pickup can no longer be cancelled (status: ' . $pickup['status'] . ').');
        }
        $now = date('Y-m-d H:i:s');
        Database::update('pickup_requests', ['status' => 'CANCELLED', 'cancelled_at' => $now, 'updated_at' => $now], 'id = ?', [$pickupId]);
        Database::update('pickup_assignments', ['status' => 'CANCELLED', 'remarks' => $reason ?: 'Cancelled'], 'pickup_request_id = ? AND status NOT IN ("COMPLETED","CANCELLED")', [$pickupId]);
        NotificationService::send((int) $pickup['user_id'], 'PICKUP', 'Pickup cancelled',
            'Pickup ' . $pickup['pickup_code'] . ' was cancelled.', 'pickup_request', $pickupId);
        AuditService::log('PICKUP_CANCELLED', 'pickup', $pickupId, $pickup['status'], 'CANCELLED');
    }

    /** Simple workload-based auto assignment: least open assignments among active collectors. */
    public static function autoAssign(int $pickupId, array $actor): array
    {
        $collectorId = Database::val(
            'SELECT u.id FROM users u
             LEFT JOIN pickup_assignments pa ON pa.collector_id = u.id AND pa.status IN ("ASSIGNED","ACCEPTED","ON_THE_WAY","ARRIVED")
             WHERE u.role_id = (SELECT id FROM roles WHERE code = "collector") AND u.status = "ACTIVE"
             GROUP BY u.id ORDER BY COUNT(pa.id) ASC, u.id ASC LIMIT 1');
        if (!$collectorId) throw new RuntimeException('No active collector is available for assignment.');
        return self::assign($pickupId, (int) $collectorId, $actor);
    }
}
