<?php
/**
 * VerificationService — genuine ownership verification (mobile OTP / email link).
 *
 * FORMAT VALIDATION ≠ GENUINE VERIFICATION.
 * A value passing syntax checks stays "unverified" until a real verification
 * mechanism confirms ownership. When no provider is configured the service
 * reports NOT_CONFIGURED and NEVER fakes a successful verification.
 *
 * Providers (settings-driven, no vendor dependency):
 *   sms_provider  = none | log (DEV ONLY: writes to storage/logs/sms.log) | webhook (generic HTTP SMS gateway)
 *   email_verification_provider = none | log (DEV ONLY) | smtp (uses smtp_* settings)
 */
class VerificationService
{
    public const SMS_TTL_SETTING = 'otp_ttl_minutes';

    /** Is a real SMS sending path configured? */
    public static function smsConfigured(): bool
    {
        return in_array((string) setting('sms_provider', 'none'), ['log', 'webhook'], true)
            && ((string) setting('sms_provider', 'none') !== 'webhook' || trim((string) setting('sms_webhook_url', '')) !== '');
    }

    /** Is a real email sending path configured? */
    public static function emailConfigured(): bool
    {
        return in_array((string) setting('email_verification_provider', 'none'), ['log', 'smtp'], true)
            && ((string) setting('email_verification_provider', 'none') !== 'smtp' || trim((string) setting('smtp_host', '')) !== '');
    }

    /** Ensure the storage table exists (self-healing like AuthService::ensureResetTable). */
    public static function ensureTable(): void
    {
        Database::run('CREATE TABLE IF NOT EXISTS verification_codes (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNSIGNED NOT NULL,
            channel ENUM("MOBILE","EMAIL") NOT NULL,
            code_hash CHAR(64) NOT NULL,
            attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
            expires_at DATETIME NOT NULL,
            consumed_at DATETIME NULL DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY idx_vcode_user (user_id, channel),
            KEY idx_vcode_created (created_at),
            CONSTRAINT fk_vcode_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    }

    // ---------------------------------------------------------------- mobile OTP

    /**
     * Generate + deliver a mobile OTP. Returns 'SENT' or 'NOT_CONFIGURED'.
     * The plaintext code is never stored, never returned, never logged in HTML/JS/API.
     * Rate limits: resend cooldown + hourly cap per user.
     */
    public static function requestMobileOtp(array $user): string
    {
        if (!self::smsConfigured()) return 'NOT_CONFIGURED';
        self::ensureTable();

        $cooldown = max(0, (int) setting('otp_resend_cooldown_seconds', 60));
        // SQL-side comparison: immune to PHP/MySQL timezone differences (sandbox PHP=IST, MySQL=UTC)
        $since = Database::val('SELECT TIMESTAMPDIFF(SECOND, MAX(created_at), NOW()) FROM verification_codes WHERE user_id = ? AND channel = "MOBILE"', [(int) $user['id']]);
        if ($since !== null && (int) $since < $cooldown) {
            throw new RuntimeException(t('verify.otp_cooldown'));
        }
        $hourly = max(1, (int) setting('otp_max_per_hour', 3));
        if ((int) Database::val('SELECT COUNT(*) FROM verification_codes WHERE user_id = ? AND channel = "MOBILE" AND created_at > DATE_SUB(NOW(), INTERVAL 60 MINUTE)', [(int) $user['id']]) >= $hourly) {
            throw new RuntimeException(t('verify.otp_rate'));
        }

        $code = '';
        for ($i = 0; $i < 6; $i++) $code .= (string) random_int(0, 9);
        $hash = hash('sha256', $code . '|' . (int) $user['id']); // hashed-at-rest; plaintext discarded
        $ttl  = max(1, (int) setting(self::SMS_TTL_SETTING, 10));
        Database::run('INSERT INTO verification_codes (user_id, channel, code_hash, expires_at) VALUES (?, "MOBILE", ?, DATE_ADD(NOW(), INTERVAL ' . $ttl . ' MINUTE))', [(int) $user['id'], $hash]);

        $phone = (string) ($user['phone'] ?? '');
        $message = 'PUNARVA: your verification code is ' . $code . ' (valid ' . $ttl . ' minutes). Do not share it.';
        self::sendSms($phone, $message);
        AuditService::log('OTP_REQUESTED', 'verification', (int) $user['id']);
        return 'SENT';
    }

    /** Verify a mobile OTP server-side. One-time use; max attempts; invalidates on success. */
    public static function verifyMobileOtp(array $user, string $code): bool
    {
        self::ensureTable();
        $code = preg_replace('/\D/', '', (string) $code);
        if ($code === '') throw new InvalidArgumentException(t('verify.otp_invalid'));

        $maxAttempts = max(1, (int) setting('otp_max_attempts', 5));
        $row = Database::one(
            'SELECT * FROM verification_codes WHERE user_id = ? AND channel = "MOBILE" AND consumed_at IS NULL AND expires_at > NOW() ORDER BY id DESC LIMIT 1',
            [(int) $user['id']]
        );
        if (!$row) throw new RuntimeException(t('verify.otp_expired'));
        if ((int) $row['attempts'] >= $maxAttempts) {
            Database::run('UPDATE verification_codes SET consumed_at = NOW() WHERE id = ?', [(int) $row['id']]);
            throw new RuntimeException(t('verify.otp_too_many'));
        }

        if (!hash_equals((string) $row['code_hash'], hash('sha256', $code . '|' . (int) $user['id']))) {
            $attempts = (int) $row['attempts'] + 1;
            if ($attempts >= $maxAttempts) {
                Database::run('UPDATE verification_codes SET attempts = ?, consumed_at = NOW() WHERE id = ?', [$attempts, (int) $row['id']]);
                throw new RuntimeException(t('verify.otp_too_many'));
            }
            Database::run('UPDATE verification_codes SET attempts = ? WHERE id = ?', [$attempts, (int) $row['id']]);
            throw new InvalidArgumentException(t('verify.otp_invalid'));
        }

        Database::run('UPDATE verification_codes SET consumed_at = NOW() WHERE id = ?', [(int) $row['id']]);
        Database::run('UPDATE users SET phone_verified = 1, phone_verified_at = NOW() WHERE id = ?', [(int) $user['id']]);
        AuditService::log('MOBILE_VERIFIED', 'verification', (int) $user['id']);
        return true;
    }

    // ---------------------------------------------------------------- email link

    /**
     * Create + deliver an email-verification link. Returns 'SENT' or 'NOT_CONFIGURED'.
     * Token: 32 random bytes, only the SHA-256 hash is stored; single use; 24h expiry.
     */
    public static function requestEmailVerification(array $user): string
    {
        if (!self::emailConfigured()) return 'NOT_CONFIGURED';
        self::ensureTable();

        $hourly = max(1, (int) setting('otp_max_per_hour', 3));
        if ((int) Database::val('SELECT COUNT(*) FROM verification_codes WHERE user_id = ? AND channel = "EMAIL" AND created_at > DATE_SUB(NOW(), INTERVAL 60 MINUTE)', [(int) $user['id']]) >= $hourly) {
            throw new RuntimeException(t('verify.otp_rate'));
        }

        $token = bin2hex(random_bytes(32));
        $hash  = hash('sha256', $token);
        Database::run('INSERT INTO verification_codes (user_id, channel, code_hash, expires_at) VALUES (?, "EMAIL", ?, DATE_ADD(NOW(), INTERVAL 24 HOUR))', [(int) $user['id'], $hash]);

        $link = rtrim((string) setting('app_url', self::guessBase()), '/') . '/verify-email.php?t=' . $token;
        $sent = self::sendEmail(
            (string) $user['email'],
            'Verify your PUNARVA email address',
            "Namaste " . $user['name'] . ",\n\nOpen this link within 24 hours to verify your email address:\n" . $link . "\n\nIf you did not create a PUNARVA account, you can ignore this email."
        );
        if (!$sent) throw new RuntimeException(t('verify.send_failed'));
        AuditService::log('EMAIL_LINK_SENT', 'verification', (int) $user['id']);
        return 'SENT';
    }

    /** Consume an email token (single use). Returns the user id on success. */
    public static function verifyEmailToken(string $token): ?int
    {
        self::ensureTable();
        $token = trim((string) $token);
        if (!preg_match('/^[a-f0-9]{64}$/', $token)) return null;
        $row = Database::one(
            'SELECT * FROM verification_codes WHERE channel = "EMAIL" AND consumed_at IS NULL AND expires_at > NOW() AND code_hash = ? LIMIT 1',
            [hash('sha256', $token)]
        );
        if (!$row) return null;
        Database::run('UPDATE verification_codes SET consumed_at = NOW() WHERE id = ?', [(int) $row['id']]);
        Database::run('UPDATE users SET email_verified = 1, email_verified_at = NOW() WHERE id = ?', [(int) $row['user_id']]);
        AuditService::log('EMAIL_VERIFIED', 'verification', (int) $row['user_id']);
        return (int) $row['user_id'];
    }

    // ---------------------------------------------------------------- transports

    /** SMS delivery. 'log' = DEV ONLY transport. 'webhook' = generic HTTP gateway. */
    private static function sendSms(string $phone, string $message): bool
    {
        $provider = (string) setting('sms_provider', 'none');
        if ($provider === 'webhook') {
            $url = trim((string) setting('sms_webhook_url', ''));
            if ($url === '') throw new RuntimeException(t('verify.send_failed'));
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode(['to' => $phone, 'message' => $message], JSON_UNESCAPED_UNICODE),
                CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 10,
            ]);
            $body = curl_exec($ch);
            $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            curl_close($ch);
            if ($body === false || $code < 200 || $code >= 300) throw new RuntimeException(t('verify.send_failed')); // honest: provider did not accept
            return true;
        }
        // DEV transport: server-side log only. Never enable in production; never rendered to any page.
        $dir = dirname(__DIR__) . '/storage/logs';
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
        @file_put_contents($dir . '/sms.log', '[' . date('Y-m-d H:i:s') . "] DEV-ONLY SMS (sms_provider=log; not a real delivery) to $phone: $message\n", FILE_APPEND);
        return true;
    }

    /** Email delivery. 'log' = DEV ONLY. 'smtp' = minimal SMTP client (plain/TLS-auth via smtp_* settings). */
    private static function sendEmail(string $to, string $subject, string $body): bool
    {
        $provider = (string) setting('email_verification_provider', 'none');
        if ($provider === 'smtp') {
            $host = trim((string) setting('smtp_host', ''));
            $port = (int) setting('smtp_port', '587');
            $user = (string) setting('smtp_username', '');
            $pass = (string) setting('smtp_password', '');
            $from = trim((string) setting('smtp_from_address', $user));
            if ($host === '' || $from === '') throw new RuntimeException(t('verify.send_failed'));
            $remote = ($port === 465 ? 'ssl://' : '') . $host . ':' . $port;
            $fp = @stream_socket_client($remote, $errno, $errstr, 12);
            if (!$fp) throw new RuntimeException(t('verify.send_failed'));
            $read = function () use ($fp): string {
                $data = '';
                while ($line = fgets($fp, 515)) { $data .= $line; if (isset($line[3]) && $line[3] === ' ') break; }
                return $data;
            };
            $cmd = function (string $c, array $expect) use ($fp, $read): string {
                fwrite($fp, $c . "\r\n");
                $r = $read();
                if (!in_array((int) substr($r, 0, 1), $expect, true)) throw new RuntimeException(t('verify.send_failed'));
                return $r;
            };
            $read();
            $cmd('EHLO punarva.local', [2]);
            if ($user !== '') {
                $cmd('AUTH LOGIN', [3]);
                $cmd(base64_encode($user), [3]);
                $cmd(base64_encode($pass), [2]);
            }
            $cmd('MAIL FROM:<' . $from . '>', [2]);
            $cmd('RCPT TO:<' . $to . '>', [2, 5]); // 5 = some providers defer; final DATA will still guard
            $cmd('DATA', [3]);
            $headers = "From: " . (setting('smtp_from_name', 'PUNARVA')) . " <$from>\r\nTo: <$to>\r\nSubject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n";
            fwrite($fp, $headers . $body . "\r\n.\r\n");
            $r = $read();
            fclose($fp);
            if ((int) substr($r, 0, 1) !== 2) throw new RuntimeException(t('verify.send_failed')); // honest: not accepted
            return true;
        }
        // DEV transport
        $dir = dirname(__DIR__) . '/storage/logs';
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
        @file_put_contents($dir . '/mail.log', '[' . date('Y-m-d H:i:s') . "] DEV-ONLY EMAIL (email_verification_provider=log; not a real delivery) to $to / $subject\n$body\n", FILE_APPEND);
        return true;
    }

    private static function guessBase(): string
    {
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443;
        return 'http' . ($https ? 's' : '') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
    }
}
