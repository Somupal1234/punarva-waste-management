<?php
/**
 * WasteJourneyService – the heart of the Waste Passport.
 * Creates waste transactions with unique Waste IDs, records journey events,
 * validates the stage state machine and triggers impact + rewards on completion.
 */
class WasteJourneyService
{
    /** Generate the next unique Waste ID, e.g. PNV-2026-000042 (atomic via id_sequences). */
    public static function generateWasteId(): string
    {
        $year = (int) date('Y');
        $pdo  = db();
        Database::begin();
        try {
            $row = Database::run('SELECT last_number FROM id_sequences WHERE year = ? FOR UPDATE', [$year])->fetch();
            if ($row === false) {
                Database::run('INSERT INTO id_sequences (year, last_number) VALUES (?, 1)', [$year]);
                $n = 1;
            } else {
                $n = (int) $row['last_number'] + 1;
                Database::run('UPDATE id_sequences SET last_number = ? WHERE year = ?', [$n, $year]);
            }
            Database::commit();
        } catch (Throwable $e) {
            Database::rollBack();
            throw $e;
        }
        return sprintf('PNV-%d-%06d', $year, $n);
    }

    /**
     * Create a Waste Transaction when a pickup completes.
     * Backfills journey events (identified → requested → assigned → collected) from history.
     */
    public static function createFromPickup(array $pickup, array $assignment): array
    {
        $pdo = db();
        Database::begin();
        try {
            $wasteId = self::generateWasteId();
            $txId = Database::insert('waste_transactions', [
                'waste_id'         => $wasteId,
                'pickup_request_id'=> $pickup['id'],
                'source_user_id'   => $pickup['user_id'],
                'source_type'      => $pickup['organization_id'] ? 'BUSINESS' : 'CITIZEN',
                'category_id'      => $pickup['category_id'],
                'initial_weight'   => $assignment['actual_weight'],
                'current_weight'   => $assignment['actual_weight'],
                'current_stage'    => 'COLLECTED',
                'origin_address'   => $pickup['address_line'],
                'ward'             => $pickup['ward'] ?? null,
                'latitude'         => $pickup['latitude'],
                'longitude'        => $pickup['longitude'],
                'facility_id'      => null,
            ]);

            // Backfilled history events
            self::addEvent($txId, 'WASTE_IDENTIFIED', [
                'event_time' => $pickup['created_at'], 'actor_id' => $pickup['user_id'], 'actor_role' => 'CITIZEN',
                'location' => $pickup['address_line'], 'quantity' => $pickup['estimated_weight'],
                'notes' => 'Waste identified and segregation guidance generated' .
                           ($pickup['notes'] ? ' – ' . $pickup['notes'] : ''),
            ], false);
            self::addEvent($txId, 'PICKUP_REQUESTED', [
                'event_time' => $pickup['created_at'], 'actor_id' => $pickup['user_id'], 'actor_role' => 'CITIZEN',
                'location' => $pickup['address_line'], 'quantity' => $pickup['estimated_weight'],
            ], false);
            if (!empty($assignment['assigned_at'])) {
                self::addEvent($txId, 'COLLECTOR_ASSIGNED', [
                    'event_time' => $assignment['assigned_at'], 'actor_id' => $assignment['collector_id'], 'actor_role' => 'COLLECTOR',
                    'location' => $pickup['address_line'],
                    'notes' => 'Collector assigned: ' . ($assignment['collector_name'] ?? ''),
                ], false);
            }
            self::addEvent($txId, 'COLLECTED', [
                'event_time' => $assignment['collected_at'] ?: date('Y-m-d H:i:s'),
                'actor_id' => $assignment['collector_id'], 'actor_role' => 'COLLECTOR',
                'location' => $pickup['address_line'], 'quantity' => $assignment['actual_weight'],
                'proof_image' => $assignment['proof_image'] ?? null,
                'notes' => 'Waste collected by ' . ($assignment['collector_name'] ?? 'collector') .
                           '. Verified weight: ' . fmt_kg($assignment['actual_weight']) . '.',
            ], false);

            Database::insert('map_locations', [
                'location_type' => 'WASTE', 'reference_id' => $txId, 'title' => $wasteId,
                'latitude' => $pickup['latitude'], 'longitude' => $pickup['longitude'], 'status' => 'COLLECTED',
            ]);
            Database::commit();
        } catch (PDOException $e) {
            Database::rollBack();
            // v2.4.3 — extra safety: if the Waste Transaction already exists (double-submit that
            // slipped past the outer guard), return the existing one instead of a raw SQL error.
            if ((int) ($e->errorInfo[1] ?? 0) === 1062) {
                $existing = Database::one('SELECT * FROM waste_transactions WHERE pickup_request_id = ?', [$pickup['id']]);
                if ($existing) return $existing;
            }
            throw $e;
        } catch (Throwable $e) {
            Database::rollBack();
            throw $e;
        }
        return Database::one('SELECT * FROM waste_transactions WHERE id = ?', [$txId]);
    }

    /** Append a journey event (Waste Passport auto-updates from these). */
    public static function addEvent(int $txId, string $eventType, array $opts = [], bool $notifySource = true): void
    {
        $tx = Database::one('SELECT * FROM waste_transactions WHERE id = ?', [$txId]);
        if (!$tx) throw new InvalidArgumentException('Waste transaction not found.');

        Database::insert('waste_journey_events', [
            'waste_transaction_id' => $txId,
            'event_type'           => $eventType,
            'event_time'           => $opts['event_time'] ?? date('Y-m-d H:i:s'),
            'location'             => $opts['location'] ?? null,
            'actor_id'             => $opts['actor_id'] ?? (current_user()['id'] ?? null),
            'actor_role'           => $opts['actor_role'] ?? (current_user()['role_code'] ?? 'SYSTEM'),
            'facility_id'          => $opts['facility_id'] ?? $tx['facility_id'],
            'quantity'             => $opts['quantity'] ?? null,
            'notes'                => $opts['notes'] ?? null,
            'proof_image'          => $opts['proof_image'] ?? null,
        ]);

        if ($notifySource && $tx['source_user_id']) {
            NotificationService::send(
                (int) $tx['source_user_id'], 'WASTE_PASSPORT',
                'Waste Passport updated: ' . $tx['waste_id'],
                ($opts['passport_label'] ?? $eventType) . (($opts['location'] ?? null) ? ' – ' . $opts['location'] : ''),
                'waste_transaction', $txId
            );
        }
    }

    /** Validate + perform a stage transition (state machine). Returns updated transaction. */
    public static function setStage(int $txId, string $newStage, array $opts = []): array
    {
        $tx = Database::one('SELECT * FROM waste_transactions WHERE id = ?', [$txId]);
        if (!$tx) throw new InvalidArgumentException('Waste transaction not found.');
        $current = $tx['current_stage'];
        $allowed = WASTE_TRANSITIONS[$current] ?? [];
        if (!in_array($newStage, $allowed, true)) {
            throw new InvalidArgumentException("Invalid stage transition: $current → $newStage.");
        }

        $data = ['current_stage' => $newStage, 'current_weight' => $opts['quantity'] ?? $tx['current_weight']];
        if ($opts['facility_id'] ?? null) $data['facility_id'] = $opts['facility_id'];

        $isFinal = in_array($newStage, FINAL_OUTCOMES, true);
        if ($isFinal) {
            $data['final_outcome'] = $newStage;
            $data['completed_at']  = date('Y-m-d H:i:s');
        }
        Database::update('waste_transactions', $data, 'id = ?', [$txId]);

        $eventType = ['SORTED' => 'SORTED', 'PROCESSING' => 'PROCESSING_STARTED', 'PROCESSED' => 'PROCESSED'][$newStage] ?? 'FINAL_OUTCOME';
        self::addEvent($txId, $eventType, array_merge([
            'passport_label' => 'Waste ' . strtolower(WASTE_STAGE_LABELS[$newStage]),
            'notes'          => $opts['notes'] ?? ('Stage updated to ' . WASTE_STAGE_LABELS[$newStage] .
                             ' at ' . ($opts['facility_name'] ?? 'the processing facility') . '.'),
        ], $opts));

        // ---- Completion side-effects: impact + reward ----
        if ($isFinal) {
            if ($newStage !== 'RESIDUAL_DISPOSAL') {
                $impact = ImpactService::calculateForTransaction($txId);
                self::addEvent($txId, 'IMPACT_CALCULATED', [
                    'actor_role' => 'SYSTEM',
                    'notes' => $impact
                        ? 'Estimated environmental impact calculated: ' . fmt_kg($impact['co2_saved_kg']) . ' CO2e avoided, ' .
                          number_format((float) $impact['water_saved_l'], 1) . ' L water saved (' . $impact['methodology_version'] . ').'
                        : 'No impact factor configured for this category yet.',
                ], false);
            }
            if ($tx['source_user_id'] && $newStage !== 'RESIDUAL_DISPOSAL') {
                // v2.8.0: verified facility processing → Real Impact badges (idempotent; replaces points)
                BadgeService::evaluateRealImpact((int) $tx['source_user_id'], 'recycling', (int) $txId);
                self::addEvent($txId, 'IMPACT_BADGES_EVALUATED', [
                    'actor_role' => 'SYSTEM',
                    'notes' => 'Real Impact badges re-evaluated for the source account.',
                ], false);
            }
            NotificationService::send((int) $tx['source_user_id'], 'WASTE_PASSPORT',
                'Journey completed: ' . $tx['waste_id'],
                'Final outcome: ' . WASTE_STAGE_LABELS[$newStage] . '. Open the Waste Passport to see the full story.',
                'waste_transaction', $txId);
            AuditService::log('WASTE_FINAL_OUTCOME', 'waste', $txId, $current, $newStage);
        } else {
            AuditService::log('WASTE_STAGE_CHANGE', 'waste', $txId, $current, $newStage);
        }

        return Database::one('SELECT * FROM waste_transactions WHERE id = ?', [$txId]);
    }

    public static function timeline(int $txId): array
    {
        return Database::all(
            'SELECT e.*, f.name AS facility_name, u.name AS actor_name
             FROM waste_journey_events e
             LEFT JOIN facilities f ON f.id = e.facility_id
             LEFT JOIN users u ON u.id = e.actor_id
             WHERE e.waste_transaction_id = ? ORDER BY e.event_time ASC, e.id ASC', [$txId]);
    }

    public static function trackByWasteId(string $wasteId): ?array
    {
        return Database::one(
            'SELECT wt.*, wc.name AS category_name, wc.code AS category_code, wc.color AS category_color, wc.bin_type,
                    f.name AS facility_name, f.city AS facility_city, f.facility_type
             FROM waste_transactions wt
             JOIN waste_categories wc ON wc.id = wt.category_id
             LEFT JOIN facilities f ON f.id = wt.facility_id
             WHERE wt.waste_id = ?', [strtoupper(trim($wasteId))]);
    }
}
