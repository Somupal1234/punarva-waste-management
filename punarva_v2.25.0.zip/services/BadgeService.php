<?php
/**
 * BadgeService (v2.10.0) — Premium achievements: Learning + Real Impact.
 *
 * Model (v2.11.0 — REAL IMPACT ONLY):
 *  Every badge is earned ONLY from verified real-world records (completed pickups,
 *  verified/resolved reports, facility-processed recycling, verified scans).
 *  Learning content (quizzes/learn hub) remains on the site but awards NO badges.
 *
 * Guarantees:
 *  - Idempotent awards (unique user+badge pre-check) — refresh/retry/click-safe.
 *  - Browser never decides eligibility; every award is computed server-side from DB records.
 *  - Ranking is computed from the same verified records, cached briefly (settings table).
 */

class BadgeService
{
    /** Award a badge if the user does not have it. Returns badge row on NEW award, null otherwise. */
    public static function award(int $userId, string $badgeKey, string $sourceType = 'system', ?int $sourceId = null): ?array
    {
        $badge = Database::one('SELECT * FROM badges WHERE badge_key = ? AND is_active = 1', [$badgeKey]);
        if (!$badge) return null;
        $exists = (int) Database::val('SELECT COUNT(*) FROM user_badges WHERE user_id = ? AND badge_id = ?', [$userId, $badge['id']]);
        if ($exists) return null; // already earned — idempotent
        try {
            Database::insert('user_badges', [
                'user_id' => $userId, 'badge_id' => (int) $badge['id'],
                'source_type' => mb_substr($sourceType, 0, 40), 'source_id' => $sourceId,
            ]);
        } catch (Throwable $e) {
            return null; // duplicate race lost — fine, still idempotent
        }
        NotificationService::send($userId, 'badge', 'New badge earned: ' . $badge['name'], $badge['description'], 'badge', (int) $badge['id']);
        return $badge;
    }

    /** Verified real-world activity counts for a citizen (pickups COMPLETED, reports VERIFIED/RESOLVED, facility-processed recycling). */
    public static function realCounts(int $userId): array
    {
        return [
            'pickups_completed'   => (int) Database::val('SELECT COUNT(*) FROM pickup_requests WHERE user_id = ? AND status = "COMPLETED"', [$userId]),
            'reports_verified'    => (int) Database::val('SELECT COUNT(*) FROM waste_reports WHERE user_id = ? AND status IN ("VERIFIED","RESOLVED")', [$userId]),
            'reports_resolved'    => (int) Database::val('SELECT COUNT(*) FROM waste_reports WHERE user_id = ? AND status = "RESOLVED"', [$userId]),
            'recycling_completed' => (int) Database::val('SELECT COUNT(*) FROM waste_transactions WHERE source_user_id = ? AND completed_at IS NOT NULL', [$userId]),
            'scans_completed'     => (int) Database::val('SELECT COUNT(*) FROM waste_scans WHERE user_id = ? AND status IN ("completed","corrected")', [$userId]),
        ];
    }

    public static function verifiedActivities(int $userId): int
    {
        $c = self::realCounts($userId);
        return $c['pickups_completed'] + $c['reports_verified'] + $c['recycling_completed'];
    }

    private static function meets(string $type, int $value, array $rc, array $extra = []): bool
    {
        return match ($type) {
            'pickups_completed'   => $rc['pickups_completed'] >= $value,
            'reports_verified'    => $rc['reports_verified'] >= $value,
            'reports_resolved'    => $rc['reports_resolved'] >= $value,
            'recycling_completed' => $rc['recycling_completed'] >= $value,
            'verified_activities' => self::verifiedActivities($extra['user_id'] ?? 0) >= $value,
            'scan_count'          => $rc['scans_completed'] >= $value,
            default               => false,
        };
    }

    /** Re-evaluate ALL active Real Impact badges for a user. Returns newly earned badges. Call after any verified real activity. */
    public static function evaluateRealImpact(int $userId, string $sourceType = 'system', ?int $sourceId = null): array
    {
        $rc = self::realCounts($userId);
        $extra = ['user_id' => $userId];
        $new = [];
        foreach (Database::all('SELECT * FROM badges WHERE is_active = 1 AND category = "real_impact"') as $b) {
            if (self::meets($b['criteria_type'], (int) $b['criteria_value'], $rc, $extra)) {
                $awarded = self::award($userId, $b['badge_key'], $sourceType, $sourceId);
                if ($awarded) $new[] = $awarded;
            }
        }
        if ($new) self::invalidateRanking();
        return $new;
    }

/** Completed/corrected scan → Real Impact scan_count badges (Waste Sorter), evaluated server-side. */
    public static function recordScanActivity(int $userId, int $scanId): array
    {
        $rc = self::realCounts($userId);
        $new = [];
        foreach (Database::all('SELECT * FROM badges WHERE is_active = 1 AND criteria_type = "scan_count"') as $b) {
            if (self::meets('scan_count', (int) $b['criteria_value'], $rc)) {
                $awarded = self::award($userId, $b['badge_key'], 'scan', $scanId);
                if ($awarded) $new[] = $awarded;
            }
        }
        if ($new) self::invalidateRanking();
        return $new;
    }

    public static function counts(int $userId): array
    {
        $row = Database::one('SELECT
            COUNT(*) AS total,
            COALESCE(SUM(b.category = "real_impact"),0) AS real_impact
            FROM user_badges ub JOIN badges b ON b.id = ub.badge_id WHERE ub.user_id = ?', [$userId]);
        return ['total' => (int) $row['total'], 'real_impact' => (int) $row['real_impact']];
    }

    public static function forUser(int $userId): array
    {
        return Database::all('SELECT b.*, ub.awarded_at, ub.source_type, ub.source_id
            FROM user_badges ub JOIN badges b ON b.id = ub.badge_id
            WHERE ub.user_id = ? ORDER BY ub.awarded_at DESC', [$userId]);
    }

    /** Safe public display name: first name + last initial (never email/phone). */
    public static function displayName(string $name): string
    {
        $parts = preg_split('/\s+/', trim($name)) ?: [];
        $first = $parts[0] ?? 'Citizen';
        $initial = isset($parts[1]) ? ' ' . mb_strtoupper(mb_substr($parts[1], 0, 1)) . '.' : '';
        return $first . $initial;
    }

    /** Cached community ranking from verified records. TTL 20 s; movement vs previous published snapshot. */
    public static function ranking(int $forUserId, int $topN = 8): array
    {
        $cache = json_decode((string) setting('impact_ranking_cache', ''), true) ?: [];
        $now = time();
        if (empty($cache['at']) || $now - (int) $cache['at'] > 20) {
            $rows = Database::all(
                'SELECT u.id, u.name,
                    (SELECT COUNT(*) FROM pickup_requests pr WHERE pr.user_id = u.id AND pr.status = "COMPLETED")
                  + (SELECT COUNT(*) FROM waste_reports wr WHERE wr.user_id = u.id AND wr.status IN ("VERIFIED","RESOLVED"))
                  + (SELECT COUNT(*) FROM waste_transactions wt WHERE wt.source_user_id = u.id AND wt.completed_at IS NOT NULL) AS impact_count,
                    (SELECT COUNT(*) FROM user_badges ub JOIN badges b ON b.id = ub.badge_id
                      WHERE ub.user_id = u.id AND b.category = "real_impact") AS real_badges
                 FROM users u
                 JOIN roles r ON r.id = u.role_id AND r.code = "CITIZEN"
                 WHERE u.status = "ACTIVE"
                 HAVING impact_count > 0 OR real_badges > 0
                 ORDER BY impact_count DESC, real_badges DESC, u.id ASC
                 LIMIT 200');
            $list = [];
            foreach ($rows as $i => $rw) $list[] = [
                'id' => (int) $rw['id'], 'display_name' => self::displayName($rw['name']),
                'impact_count' => (int) $rw['impact_count'], 'real_badges' => (int) $rw['real_badges'],
            ];
            // movement vs previous snapshot (by user id order)
            $prev = [];
            foreach (($cache['list'] ?? []) as $j => $old) $prev[(int) $old['id']] = $j;
            foreach ($list as $i => &$entry) {
                $entry['rank'] = $i + 1;
                $entry['movement'] = !array_key_exists($entry['id'], $prev) ? 'flat'
                    : ($i < $prev[$entry['id']] ? 'up' : ($i > $prev[$entry['id']] ? 'down' : 'flat'));
            }
            unset($entry);
            $cache = ['at' => $now, 'list' => $list];
            Database::run('INSERT INTO settings (setting_key, setting_value, setting_group, description)
                VALUES ("impact_ranking_cache", ?, "achievements", "Cached community ranking snapshot")
                ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)', [json_encode($cache)]);
        }
        $list = $cache['list'] ?? [];
        $top = array_slice($list, 0, $topN);
        $me = null; $meIdx = null;
        foreach ($list as $i => $e) if ($e['id'] === $forUserId) { $meIdx = $i; $me = $e; break; }
        return [
            'updated_at' => date('c', (int) ($cache['at'] ?? $now)),
            'users' => $top,
            'me' => $me ? ['rank' => $me['rank'], 'display_name' => $me['display_name'], 'impact_count' => $me['impact_count'],
                          'real_badges' => $me['real_badges'], 'movement' => $me['movement'],
                          'in_top' => $meIdx !== null && $meIdx < $topN] : null,
        ];
    }

    public static function invalidateRanking(): void
    {
        Database::run('UPDATE settings SET setting_value = ? WHERE setting_key = "impact_ranking_cache"',
            [json_encode(['at' => 0, 'list' => []])]);
    }
}
