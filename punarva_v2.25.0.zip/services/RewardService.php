<?php
/**
 * DEPRECATED (v2.8.0): The points/rewards concept is retired from the UI and all call sites.
 * Kept ONLY so historical reward_transactions rows remain explainable; do not use in new code.
 * Replaced by BadgeService (Learning + Real Impact) — see docs + report.
 */
/**
 * RewardService – idempotent reward transactions.
 * A unique index on (user_id, rule_id, reference_type, reference_id) makes double-award impossible.
 */
class RewardService
{
    /** @return array|null the created transaction, or null when already awarded (idempotent). */
    public static function award(string $actionType, int $userId, string $refType, int $refId, ?string $reasonSuffix = null): ?array
    {
        $rules = Database::all('SELECT * FROM reward_rules WHERE action_type = ? AND status = "ACTIVE"', [$actionType]);
        if (!$rules) return null;

        $last = null;
        foreach ($rules as $rule) {
            $reason = $rule['name'] . ($reasonSuffix ? ' – ' . $reasonSuffix : '');
            try {
                $id = Database::insert('reward_transactions', [
                    'user_id' => $userId, 'rule_id' => $rule['id'], 'points' => $rule['points'],
                    'reason' => $reason, 'reference_type' => $refType, 'reference_id' => $refId,
                ]);
            } catch (PDOException $e) {
                if ((int) $e->getCode() === 23000) continue; // already awarded for this reference
                throw $e;
            }
            $last = Database::one('SELECT * FROM reward_transactions WHERE id = ?', [$id]);
            NotificationService::send($userId, 'REWARD', 'Reward earned: +' . $rule['points'] . ' points', $reason, $refType, $refId);
        }
        return $last;
    }

    public static function balance(int $userId): int
    {
        return (int) Database::val('SELECT COALESCE(SUM(points),0) FROM reward_transactions WHERE user_id = ?', [$userId]);
    }

    public static function history(int $userId, int $limit = 100): array
    {
        return Database::all(
            'SELECT rt.*, rr.name AS rule_name, rr.action_type FROM reward_transactions rt
             JOIN reward_rules rr ON rr.id = rt.rule_id
             WHERE rt.user_id = ? ORDER BY rt.created_at DESC LIMIT ' . (int) $limit, [$userId]);
    }

    public static function totalAwarded(): int
    {
        return (int) Database::val('SELECT COALESCE(SUM(points),0) FROM reward_transactions');
    }
}
