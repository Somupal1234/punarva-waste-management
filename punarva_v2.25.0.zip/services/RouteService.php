<?php
/**
 * RouteService – Suggested Route (rule-based MVP).
 * Nearest-neighbour ordering over the collector's open pickups for a day + haversine distances.
 * This is a simple heuristic, NOT AI-optimised routing.
 */
class RouteService
{
    public static function suggestForCollector(int $collectorId, ?string $date = null): array
    {
        $date = $date ?: date('Y-m-d');
        $pickups = Database::all(
            'SELECT pa.id AS assignment_id, pr.id AS pickup_id, pr.pickup_code, pr.address_line, pr.ward,
                    pr.latitude, pr.longitude, pr.preferred_date, pr.time_slot, pr.status,
                    wc.name AS category_name, pr.estimated_weight, u.name AS citizen_name, cu.phone AS citizen_phone
             FROM pickup_assignments pa
             JOIN pickup_requests pr ON pr.id = pa.pickup_request_id
             JOIN waste_categories wc ON wc.id = pr.category_id
             JOIN users u ON u.id = pr.user_id
             LEFT JOIN users cu ON cu.id = pa.collector_id
             WHERE pa.collector_id = ? AND pr.preferred_date = ?
               AND pa.status IN ("ASSIGNED","ACCEPTED","ON_THE_WAY","ARRIVED")
               AND pr.latitude IS NOT NULL AND pr.longitude IS NOT NULL
             ORDER BY pr.time_slot, pr.id', [$collectorId, $date]);

        if (!$pickups) return ['stops' => [], 'total_km' => 0, 'plan_id' => null];

        // Start at the collector's base (their facility if linked), else the first pickup.
        $base = Database::one(
            'SELECT f.latitude, f.longitude, f.name FROM users u JOIN facilities f ON f.id = u.facility_id WHERE u.id = ?',
            [$collectorId]);
        $curLat = $base['latitude'] ?? (float) $pickups[0]['latitude'];
        $curLng = $base['longitude'] ?? (float) $pickups[0]['longitude'];

        $remaining = $pickups;
        $ordered = [];
        $total = 0.0;
        while ($remaining) {
            $bestIdx = null; $bestDist = PHP_FLOAT_MAX;
            foreach ($remaining as $i => $p) {
                $d = geo_distance_km((float) $curLat, (float) $curLng, (float) $p['latitude'], (float) $p['longitude']);
                if ($d < $bestDist) { $bestDist = $d; $bestIdx = $i; }
            }
            $next = $remaining[$bestIdx];
            $total += $bestDist;
            $next['leg_km'] = round($bestDist, 2);
            $ordered[] = $next;
            $curLat = (float) $next['latitude']; $curLng = (float) $next['longitude'];
            unset($remaining[$bestIdx]);
            $remaining = array_values($remaining);
        }
        if ($base) $total += geo_distance_km($curLat, $curLng, (float) $base['latitude'], (float) $base['longitude']);

        // persist plan (one per collector/day)
        $plan = Database::one('SELECT * FROM route_plans WHERE collector_id = ? AND plan_date = ?', [$collectorId, $date]);
        $pdo = db(); Database::begin();
        try {
            if ($plan) {
                Database::update('route_plans', ['total_distance_km' => round($total, 2), 'status' => 'ACTIVE'], 'id = ?', [$plan['id']]);
                Database::run('DELETE FROM route_stops WHERE route_plan_id = ?', [$plan['id']]);
                $planId = (int) $plan['id'];
            } else {
                $planId = Database::insert('route_plans', [
                    'collector_id' => $collectorId, 'plan_date' => $date,
                    'total_distance_km' => round($total, 2), 'status' => 'ACTIVE',
                ]);
            }
            foreach ($ordered as $i => $p) {
                Database::insert('route_stops', [
                    'route_plan_id' => $planId, 'pickup_request_id' => $p['pickup_id'],
                    'stop_order' => $i + 1, 'distance_from_prev_km' => $p['leg_km'], 'status' => 'PENDING',
                ]);
            }
            Database::commit();
        } catch (Throwable $e) { Database::rollBack(); throw $e; }

        return ['stops' => $ordered, 'total_km' => round($total, 2), 'plan_id' => $planId, 'base' => $base];
    }
}
