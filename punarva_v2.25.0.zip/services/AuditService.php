<?php
/** Audit logging for important system/administrative actions. */
class AuditService
{
    public static function log(string $action, string $module, ?int $recordId = null, $old = null, $new = null): void
    {
        try {
            $user = current_user();
            Database::insert('audit_logs', [
                'user_id'    => $user['id'] ?? null,
                'action'     => $action,
                'module'     => $module,
                'record_id'  => $recordId,
                'old_value'  => $old === null ? null : (is_scalar($old) ? (string) $old : json_encode($old, JSON_UNESCAPED_UNICODE)),
                'new_value'  => $new === null ? null : (is_scalar($new) ? (string) $new : json_encode($new, JSON_UNESCAPED_UNICODE)),
                'ip'         => client_ip(),
                'user_agent' => client_agent(),
            ]);
        } catch (Throwable $e) {
            error_log('Audit log failed: ' . $e->getMessage());
        }
    }
}
