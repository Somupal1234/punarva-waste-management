<?php
/** Authentication + registration + login rate limiting. */
class AuthService
{
    /** Login limiter knobs. v2.15.0: ALWAYS ENFORCED — only the thresholds are configurable
     *  (System Settings → Security Settings). Values are clamped server-side to the allowed
     *  ranges (3–10 attempts, 1–1440 minutes) so even a tampered DB row cannot weaken this. */
    private static function limiter(): array
    {
        return [
            'enabled' => true,
            'max'     => min(10, max(3, (int) setting('max_login_attempts', 5))),
            'window'  => min(1440, max(1, (int) setting('login_lock_minutes', 15))),
        ];
    }

    /** Password policy (System Settings → Security Settings). Returns error message or null.
     *  v2.15.0: complexity rules are ALWAYS ENFORCED server-side for registration, password
     *  change, password reset and admin-created users — no switches exist. */
    public static function policyError(string $pw): ?string
    {
        $min = min(128, max(8, (int) setting('password_min_length', 8)));
        if (strlen($pw) < $min) return "Password must be at least $min characters long.";
        if (!preg_match('/[A-Z]/', $pw)) return 'Password must contain an uppercase letter.';
        if (!preg_match('/[a-z]/', $pw)) return 'Password must contain a lowercase letter.';
        if (!preg_match('/\d/', $pw)) return 'Password must contain a number.';
        if (!preg_match('/[^A-Za-z0-9]/', $pw)) return 'Password must contain a special character.';
        return null;
    }

    private static function secLog(string $action, string $detail): void
    {
        // v2.15.0 — login activity logging is ALWAYS ON (Security Settings shows it as an
        // always-enforced protection; the old toggle row was removed by migration 011).
        AuditService::log($action, 'auth', null, $detail, null);
    }

    public static function register(array $d): int
    {
        $name  = val_str($d, 'name', 120, true, null, 2);
        $email = val_email($d);
        $phone = val_phone($d, 'phone', true); // REQUIRED, normalized to 10 digits
        if ((string) setting('registration_enabled', '1') !== '1') throw new RuntimeException('New registrations are currently disabled by the administrator.');
        // registration rate limit per network (abuse prevention; normal users unaffected)
        $maxReg = max(1, (int) setting('registration_max_per_hour', 5));
        if ((int) Database::val('SELECT COUNT(*) FROM audit_logs WHERE action = ? AND ip = ? AND created_at > DATE_SUB(NOW(), INTERVAL 60 MINUTE)', ['REGISTER', client_ip()]) >= $maxReg) {
            throw new RuntimeException(t('reg.ratelimited'));
        }
        $roleCode = ($d['role'] ?? ROLE_CITIZEN) === ROLE_BUSINESS ? ROLE_BUSINESS : ROLE_CITIZEN; // server decides roles
        if ($roleCode === ROLE_BUSINESS && (string) setting('business_registration_enabled', '1') !== '1')
            throw new RuntimeException('Business registration is currently disabled. Please register as a Citizen.');
        if ((string) setting('citizen_registration_enabled', '1') !== '1')
            throw new RuntimeException('Citizen registration is currently disabled by the administrator.');
        $pass  = (string) ($d['password'] ?? '');
        $conf  = (string) ($d['password_confirm'] ?? '');
        if ($err = self::policyError($pass)) throw new InvalidArgumentException($err);
        if ($pass !== $conf)   throw new InvalidArgumentException('Passwords do not match.');

        if (Database::val('SELECT id FROM users WHERE email = ?', [$email])) {
            throw new InvalidArgumentException(t('val.email_duplicate'));
        }
        if (Database::val('SELECT id FROM users WHERE phone = ?', [$phone])) {
            throw new InvalidArgumentException(t('val.phone_duplicate'));
        }

        $pdo = db();
        Database::begin();
        try {
            $roleId = (int) Database::val('SELECT id FROM roles WHERE code = ?', [$roleCode]);
            $orgId  = null;
            if ($roleCode === ROLE_BUSINESS) {
                $orgName = val_str($d, 'org_name', 160, true, 'Organization name');
                $orgId = Database::insert('organizations', [
                    'name' => $orgName,
                    'org_type' => val_str($d, 'org_type', 40, false) ?: 'OTHER',
                    'email' => $email, 'phone' => $phone,
                    'address_line' => val_str($d, 'address_line', 255, false),
                    'city' => val_str($d, 'city', 80, false), 'status' => 'ACTIVE',
                ]);
            }
            try {
                $userId = Database::insert('users', [
                    'role_id' => $roleId, 'name' => $name, 'email' => $email, 'phone' => $phone,
                    'password_hash' => password_hash($pass, PASSWORD_DEFAULT),
                    'status' => 'ACTIVE', 'language' => 'en', 'organization_id' => $orgId,
                ]);
            } catch (PDOException $e) { // race-condition safety: UNIQUE(email/phone) hit between check and insert
                if ((string) $e->getCode() === '23000') throw new InvalidArgumentException(t('val.account_duplicate'));
                throw $e;
            }
            // Default address for citizens
            if ($roleCode === ROLE_CITIZEN && !empty($d['address_line'])) {
                Database::insert('addresses', [
                    'user_id' => $userId, 'label' => 'Home', 'address_line' => val_str($d, 'address_line', 255, false),
                    'city' => val_str($d, 'city', 80, false) ?: (string) setting('default_city', 'Dumka'), 'state' => 'Bihar',
                    'ward' => val_str($d, 'ward', 40, false), 'is_default' => 1,
                    'latitude' => $d['latitude'] ?? null, 'longitude' => $d['longitude'] ?? null,
                ]);
            }
            Database::commit();
            AuditService::log('REGISTER', 'auth', $userId, null, ['email' => $email, 'role' => $roleCode]);
            return $userId;
        } catch (Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    /** Returns true on success; sets the session user. Rate limited per IP + email. */
    public static function attempt(string $email, string $password): bool
    {
        $email = strtolower(trim($email));
        if (self::tooManyAttempts($email)) {
            $L = self::limiter();
            if ($L['enabled']) throw new RuntimeException('Too many failed login attempts. Please try again in ' . $L['window'] . ' minutes.');
        }
        $user = Database::one(
            'SELECT u.*, r.code AS role_code, r.name AS role_name FROM users u JOIN roles r ON r.id = u.role_id WHERE u.email = ?',
            [$email]);
        if (!$user || !password_verify($password, $user['password_hash'])) {
            self::recordFailedAttempt($email);
            throw new InvalidArgumentException('Invalid email or password.');
        }
        if ($user['status'] !== 'ACTIVE') {
            throw new RuntimeException('Your account is ' . strtolower($user['status']) . '. Contact the administrator.');
        }
        self::clearAttempts($email);
        session_regenerate_id(true); // prevent session fixation
        $_SESSION['auth_epoch'] = time();
        unset($_SESSION['remember']);
        if (!empty($_POST['remember']) && (string) setting('remember_me_enabled', '1') === '1') $_SESSION['remember'] = true;
        self::secLog('LOGIN_SUCCESS', 'email=' . $email);
        $_SESSION['user'] = [
            'id' => (int) $user['id'], 'name' => $user['name'], 'email' => $user['email'],
            'role_code' => $user['role_code'], 'role_name' => $user['role_name'],
            'facility_id' => $user['facility_id'] !== null ? (int) $user['facility_id'] : null,
            'organization_id' => $user['organization_id'] !== null ? (int) $user['organization_id'] : null,
            'avatar' => $user['avatar_path'],
        ];
        Database::update('users', ['last_login_at' => date('Y-m-d H:i:s')], 'id = ?', [$user['id']]);
        SessionRegistry::register((int) $user['id'], (string) $user['role_code']); // single-session roles supersede old logins here
        AuditService::log('LOGIN', 'auth', (int) $user['id']);
        return true;
    }

    public static function logout(): void
    {
        if (current_user()) {
            AuditService::log('LOGOUT', 'auth', (int) current_user()['id']);
            try { SessionRegistry::revokeCurrent(); } catch (Throwable $e) { /* never block logout */ }
        }
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
    }

    private static function tooManyAttempts(string $email): bool
    {
        $n = (int) Database::val(
            'SELECT COUNT(*) FROM login_attempts WHERE (ip = ? OR email = ?) AND attempted_at > DATE_SUB(NOW(), INTERVAL ' . max(1, (int) setting('login_lock_minutes', 15)) . ' MINUTE)',
            [client_ip(), $email]);
        // v2.15.0: same clamped threshold as limiter() — no code path can read an unclamped value
        return $n >= min(10, max(3, (int) setting('max_login_attempts', 5)));
    }

    private static function recordFailedAttempt(string $email): void
    {
        Database::insert('login_attempts', ['email' => $email, 'ip' => client_ip()]);
        self::secLog('LOGIN_FAILED', 'email=' . $email . ' ip=' . client_ip());
        // v2.16.0 — one-time "account temporarily locked" audit event exactly at the
        // threshold crossing (spec: Account lock must be captured; not on every retry)
        $window = max(1, (int) setting('login_lock_minutes', 15));
        $max = min(10, max(3, (int) setting('max_login_attempts', 5)));
        $n = (int) Database::val(
            'SELECT COUNT(*) FROM login_attempts WHERE (ip = ? OR email = ?) AND attempted_at > DATE_SUB(NOW(), INTERVAL ' . $window . ' MINUTE)',
            [client_ip(), $email]);
        if ($n === $max) {
            AuditService::log('ACCOUNT_LOCKED', 'auth', null, null, ['email' => $email, 'ip' => client_ip(), 'window_minutes' => $window]);
        }
    }

    private static function clearAttempts(string $email): void
    {
        Database::run('DELETE FROM login_attempts WHERE email = ? OR ip = ?', [$email, client_ip()]);
    }

    // ---------------- Forgot / Reset Password ----------------

    /** Lazy-migration: table bhi auto-create ho jaye purani installs par (re-import ki zarurat nahi). */
    public static function ensureResetTable(): void
    {
        Database::run(
            'CREATE TABLE IF NOT EXISTS password_resets (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL,
                token_hash CHAR(64) NOT NULL UNIQUE,
                expires_at DATETIME NOT NULL,
                used_at DATETIME NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_prst_user (user_id),
                CONSTRAINT fk_prst_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB');
    }

    /**
     * Create a single-use reset token (valid 60 min, max 3/hour per email).
     * Returns the plain token (caller emails it; on local dev it is shown on screen).
     * Returns null when the email is unknown (silent – avoids account enumeration).
     */
    public static function requestPasswordReset(string $email): ?string
    {
        self::ensureResetTable();
        $user = Database::one('SELECT id FROM users WHERE email = ?', [strtolower($email)]);
        if (!$user) return null;
        $recent = (int) Database::val(
            'SELECT COUNT(*) FROM password_resets WHERE user_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)',
            [$user['id']]);
        if ($recent >= 3) throw new RuntimeException('Too many reset requests for this email. Please try again after some time.');
        $token = bin2hex(random_bytes(32));
        Database::insert('password_resets', [
            'user_id'    => $user['id'],
            'token_hash' => hash('sha256', $token),
            'expires_at' => date('Y-m-d H:i:s', time() + 3600),
        ]);
        AuditService::log('PASSWORD_RESET_REQUESTED', 'auth', (int) $user['id']);
        return $token;
    }

    public static function validateResetToken(string $token): ?array
    {
        self::ensureResetTable();
        return Database::one(
            'SELECT pr.id, pr.user_id, u.email FROM password_resets pr
             JOIN users u ON u.id = pr.user_id
             WHERE pr.token_hash = ? AND pr.used_at IS NULL AND pr.expires_at > NOW()',
            [hash('sha256', $token)]);
    }

    /** Consume the token and set the new password. */
    public static function resetPassword(string $token, string $password, string $confirm): string
    {
        $row = self::validateResetToken($token);
        if (!$row) throw new InvalidArgumentException('This reset link is invalid or has expired. Please request a new one.');
        if ($err = self::policyError($password)) throw new InvalidArgumentException($err);
        if ($password !== $confirm) throw new InvalidArgumentException('Passwords do not match.');
        Database::update('users', ['password_hash' => password_hash($password, PASSWORD_DEFAULT)], 'id = ?', [$row['user_id']]);
        Database::update('password_resets', ['used_at' => date('Y-m-d H:i:s')], 'id = ?', [$row['id']]);
        SessionRegistry::revokeAll((int) $row['user_id']); // password reset kicks every active session of this user
        NotificationService::send((int) $row['user_id'], 'ACCOUNT', 'Password changed',
            'Your PUNARVA password was reset successfully. If this was not you, contact the administrator immediately.');
        AuditService::log('PASSWORD_RESET_DONE', 'auth', (int) $row['user_id']);
        return (string) $row['email'];
    }
}
