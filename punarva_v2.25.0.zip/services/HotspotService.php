<?php
/**
 * HotspotService – rule-based MVP hotspot scoring (NOT machine learning).
 * score = reports×10 + recent(30d)×15 + unresolved×25, grouped by ward.
 */
class HotspotService
{
    public static function recompute(): int
    {
        $rows = Database::all(
            'SELECT COALESCE(NULLIF(ward, ""), "Unwarded") AS ward,
                    AVG(latitude) AS latitude, AVG(longitude) AS longitude,
                    COUNT(*) AS report_count,
                    SUM(created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) AS recent_reports,
                    SUM(status IN ("SUBMITTED","VERIFIED","ASSIGNED","IN_PROGRESS")) AS unresolved_reports
             FROM waste_reports
             WHERE status <> "REJECTED"
             GROUP BY COALESCE(NULLIF(ward, ""), "Unwarded")');

        $pdo = db(); Database::begin();
        try {
            Database::run('DELETE FROM hotspot_scores');
            foreach ($rows as $r) {
                $score = ((int) $r['report_count']) * 10 + ((int) $r['recent_reports']) * 15 + ((int) $r['unresolved_reports']) * 25;
                $status = $score >= 80 ? 'CRITICAL' : ($score >= 50 ? 'HIGH' : ($score >= 25 ? 'MEDIUM' : 'LOW'));
                Database::insert('hotspot_scores', [
                    'ward' => $r['ward'],
                    'latitude' => $r['latitude'] !== null ? round((float) $r['latitude'], 6) : null,
                    'longitude' => $r['longitude'] !== null ? round((float) $r['longitude'], 6) : null,
                    'report_count' => (int) $r['report_count'],
                    'recent_reports' => (int) $r['recent_reports'],
                    'unresolved_reports' => (int) $r['unresolved_reports'],
                    'estimated_volume_kg' => ((int) $r['report_count']) * 12, // ~12 kg per unmanaged dump estimate
                    'hotspot_score' => min($score, 150),
                    'status' => $status,
                    'last_calculated_at' => date('Y-m-d H:i:s'),
                ]);
            }
            Database::commit();
        } catch (Throwable $e) { Database::rollBack(); throw $e; }
        return count($rows);
    }

    /** Keep scores fresh after a new report arrives. */
    public static function refreshAsync(): void
    {
        try { self::recompute(); } catch (Throwable $e) { error_log('Hotspot recompute failed: ' . $e->getMessage()); }
    }

    public static function all(): array
    {
        return Database::all('SELECT * FROM hotspot_scores ORDER BY hotspot_score DESC');
    }
}
