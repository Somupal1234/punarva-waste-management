<?php
/** Database-backed notification system. */
class NotificationService
{
    public static function send(int $userId, string $type, string $title, string $message, ?string $refType = null, ?int $refId = null): void
    {
        if ((string) setting('notifications_enabled', '1') !== '1' || (string) setting('notif_inapp', '1') !== '1') return; // global off switch
        try {
            Database::insert('notifications', [
                'user_id' => $userId, 'type' => $type, 'title' => $title, 'message' => $message,
                'reference_type' => $refType, 'reference_id' => $refId,
            ]);
        } catch (Throwable $e) { error_log('Notification failed: ' . $e->getMessage()); }
    }

    /** Send to every user having one of the given roles (or all roles when empty). */
    public static function sendToRoles(array $roleCodes, string $type, string $title, string $message, ?string $refType = null, ?int $refId = null): void
    {
        $sql = 'SELECT id FROM users WHERE status = "ACTIVE"' .
               ($roleCodes ? ' AND role_id IN (SELECT id FROM roles WHERE code IN (' . implode(',', array_fill(0, count($roleCodes), '?')) . '))' : '');
        foreach (Database::all($sql, $roleCodes) as $u) {
            self::send((int) $u['id'], $type, $title, $message, $refType, $refId);
        }
    }

    public static function unreadCount(int $userId): int
    {
        return (int) Database::val('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND type <> "REWARD" AND is_read = 0', [$userId]);
    }

    public static function listFor(int $userId, int $limit = 30): array
    {
        return Database::all('SELECT * FROM notifications WHERE user_id = ? AND type <> "REWARD" ORDER BY created_at DESC LIMIT ' . (int) $limit, [$userId]);
    }

    public static function markRead(int $userId, ?int $id = null): int
    {
        if ($id) return Database::update('notifications', ['is_read' => 1], 'id = ? AND user_id = ?', [$id, $userId]);
        return Database::update('notifications', ['is_read' => 1], 'user_id = ?', [$userId]);
    }
}
