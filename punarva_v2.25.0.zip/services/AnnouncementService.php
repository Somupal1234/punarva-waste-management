<?php
/**
 * AnnouncementService (v2.13.0) — real announcement management.
 * Content lives in the `announcements` table (draft / scheduled / published, optional
 * publish + expiry windows, target roles). Publishing fans out in-app notifications to
 * the targeted roles (preserves the pre-2.13 notification behaviour); the dashboard
 * banner reads the latest ACTIVE announcement for the viewer's role.
 * No demo/fake announcements are ever inserted automatically — an empty system simply
 * shows "No active announcements available." in the admin console.
 */
class AnnouncementService
{
    public const ROLES = ['admin', 'citizen', 'collector', 'business', 'recycler'];

    /** Normalise the posted role selection into a stored target_roles string. */
    public static function normalizeRoles(array $posted): string
    {
        $picked = array_values(array_intersect(self::ROLES, array_map('strval', $posted)));
        if (!$picked || count($picked) === count(self::ROLES)) return 'ALL';
        return implode(',', $picked);
    }

    /** Effective lifecycle state derived from real timestamps (never stored). */
    public static function effectiveStatus(array $row): string
    {
        if (($row['status'] ?? '') !== 'published') return 'draft';
        $now = date('Y-m-d H:i:s');
        if (!empty($row['publish_at']) && $row['publish_at'] > $now) return 'scheduled';
        if (!empty($row['expires_at']) && $row['expires_at'] <= $now) return 'expired';
        return 'active';
    }

    public static function find(int $id): ?array
    {
        return Database::one('SELECT * FROM announcements WHERE id = ?', [$id]) ?: null;
    }

    /** All rows, newest first (admin console list). */
    public static function all(): array
    {
        return Database::all('SELECT a.*, u.name AS author_name FROM announcements a
                              LEFT JOIN users u ON u.id = a.created_by
                              ORDER BY COALESCE(a.publish_at, a.created_at) DESC, a.id DESC') ?: [];
    }

    /** Latest ACTIVE announcement visible to a role (dashboard banner). NULL = none. */
    public static function activeForRole(string $roleCode): ?array
    {
        $now = date('Y-m-d H:i:s');
        $row = Database::one(
            "SELECT * FROM announcements
             WHERE status = 'published'
               AND (publish_at IS NULL OR publish_at <= ?)
               AND (expires_at IS NULL OR expires_at > ?)
               AND (target_roles = 'ALL' OR FIND_IN_SET(?, target_roles))
             ORDER BY COALESCE(publish_at, created_at) DESC, id DESC LIMIT 1",
            [$now, $now, $roleCode]
        );
        return $row ?: null;
    }

    /** Create/update. Returns the row id. Throws InvalidArgumentException on bad input. */
    public static function save(int $id, string $title, string $message, ?string $publishAt, ?string $expiresAt, string $targetRoles, int $userId): int
    {
        $title = trim($title); $message = trim($message);
        if ($title === '' || mb_strlen($title) > 120) throw new InvalidArgumentException('Title is required (max 120 characters).');
        if ($message === '' || mb_strlen($message) > 500) throw new InvalidArgumentException('Message is required (max 500 characters).');
        if ($expiresAt && $publishAt && $expiresAt < $publishAt) throw new InvalidArgumentException('Expiry must be after the publish date.');
        foreach (['publishAt' => $publishAt, 'expiresAt' => $expiresAt] as $label => $dt) {
            if ($dt && !preg_match('/^\d{4}-\d{2}-\d{2}( \d{2}:\d{2}(:\d{2})?)?$/', $dt)) throw new InvalidArgumentException("Invalid $label date.");
        }
        $data = [
            'title' => $title, 'message' => $message,
            'publish_at'  => $publishAt ?: null,
            'expires_at'  => $expiresAt ?: null,
            'target_roles' => in_array($targetRoles, ['ALL'], true) || $targetRoles !== '' ? $targetRoles : 'ALL',
        ];
        if ($id) {
            if (!self::find($id)) throw new InvalidArgumentException('Announcement not found.');
            Database::update('announcements', $data, 'id = ?', [$id]);
            AuditService::log('ANNOUNCEMENT_UPDATED', 'announcements', $id, null, ['title' => $title]);
            return $id;
        }
        $data['created_by'] = $userId;
        $newId = (int) Database::insert('announcements', $data);
        AuditService::log('ANNOUNCEMENT_CREATED', 'announcements', $newId, null, ['title' => $title]);
        return $newId;
    }

    /** Publish (draft→published). Fans out in-app notifications ONCE per publish action. */
    public static function publish(int $id, int $userId): void
    {
        $row = self::find($id);
        if (!$row) throw new InvalidArgumentException('Announcement not found.');
        if ($row['status'] === 'published') return; // idempotent
        Database::update('announcements', ['status' => 'published'], 'id = ?', [$id]);
        $roles = $row['target_roles'] === 'ALL' ? [] : array_filter(explode(',', $row['target_roles']));
        NotificationService::sendToRoles($roles, 'ANNOUNCEMENT', $row['title'], $row['message']);
        AuditService::log('ANNOUNCEMENT_PUBLISHED', 'announcements', $id, null, ['roles' => $row['target_roles'], 'by' => $userId]);
    }

    /** Unpublish (back to draft; banner + future notifications stop). */
    public static function unpublish(int $id, int $userId): void
    {
        if (!self::find($id)) throw new InvalidArgumentException('Announcement not found.');
        Database::update('announcements', ['status' => 'draft'], 'id = ?', [$id]);
        AuditService::log('ANNOUNCEMENT_UNPUBLISHED', 'announcements', $id, null, ['by' => $userId]);
    }

    /** Delete with the row (admin-created content only reaches this path; confirm is enforced client+server flow). */
    public static function delete(int $id, int $userId): void
    {
        $row = self::find($id);
        if (!$row) throw new InvalidArgumentException('Announcement not found.');
        Database::delete('announcements', 'id = ?', [$id]);
        AuditService::log('ANNOUNCEMENT_DELETED', 'announcements', $id, $row['title'], null);
    }
}
