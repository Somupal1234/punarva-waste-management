<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_RECYCLER);
$pageTitle = 'Process Waste'; $activeMenu = 'incoming';
$facilityId = (int) $user['facility_id'];
$facility = Database::one('SELECT * FROM facilities WHERE id = ?', [$facilityId]);

$id = (int) get_val('id', 0);
$tx = Database::one(
    'SELECT wt.*, wc.name AS category_name, wc.code AS category_code, wc.color AS category_color, wc.bin_type, wc.is_recyclable,
            f.name AS facility_name, pr.pickup_code
     FROM waste_transactions wt
     JOIN waste_categories wc ON wc.id = wt.category_id
     LEFT JOIN facilities f ON f.id = wt.facility_id
     LEFT JOIN pickup_requests pr ON pr.id = wt.pickup_request_id
     WHERE wt.id = ?', [$id]);
if (!$tx) { flash('warning', 'Waste transaction not found.'); redirect('recycler/incoming.php'); }
// unassigned COLLECTED waste can be claimed by this facility; otherwise must belong to it (or be admin)
if ($tx['facility_id'] !== null && (int) $tx['facility_id'] !== $facilityId) {
    flash('danger', 'This waste is assigned to another facility.');
    redirect('recycler/incoming.php');
}

$nextMap = ['COLLECTED' => 'SORTED', 'SORTED' => 'PROCESSING', 'PROCESSING' => 'PROCESSED', 'PROCESSED' => implode('|', array_diff(FINAL_OUTCOMES, ['RESIDUAL_DISPOSAL']))];

if (is_post()) {
    try {
        $action = (string) post_val('action');
        if ($action === 'receive') {
            if ($tx['facility_id'] !== null) throw new InvalidArgumentException('Already received at a facility.');
            Database::update('waste_transactions', ['facility_id' => $facilityId], 'id = ?', [$id]);
            WasteJourneyService::addEvent($id, 'RECEIVED_AT_FACILITY', [
                'facility_id' => $facilityId, 'actor_role' => 'RECYCLER',
                'passport_label' => 'Waste received at facility',
                'notes' => 'Waste received at ' . $facility['name'] . ' (' . $facility['facility_type'] . ') for sorting.',
                'location' => $facility['city'],
            ]);
            // update map location status
            Database::update('map_locations', ['status' => 'RECEIVED'], "location_type = 'WASTE' AND reference_id = ?", [$id]);
            AuditService::log('WASTE_RECEIVED', 'waste', $id, null, $facilityId);
            flash('success', 'Waste received at your facility.');
        } elseif ($action === 'stage') {
            $newStage = (string) post_val('new_stage');
            WasteJourneyService::setStage($id, $newStage, [
                'facility_id' => $facilityId, 'facility_name' => $facility['name'],
                'quantity' => val_float($_POST, 'quantity', 0, 100000, false) ?? $tx['current_weight'],
                'notes' => val_str($_POST, 'notes', 400, false) ?: null,
            ]);
            flash('success', 'Stage updated to ' . WASTE_STAGE_LABELS[$newStage] . '.');
        }
        redirect('recycler/waste-view.php?id=' . $id);
    } catch (InvalidArgumentException | RuntimeException $e) {
        flash('danger', $e->getMessage());
    } catch (Throwable $e) {
        flash('danger', APP_DEBUG ? $e->getMessage() : 'Update failed.');
    }
    redirect('recycler/waste-view.php?id=' . $id);
}

$tx = Database::one('SELECT wt.*, wc.name AS category_name, wc.color AS category_color FROM waste_transactions wt JOIN waste_categories wc ON wc.id = wt.category_id WHERE wt.id = ?', [$id]);
$events = WasteJourneyService::timeline($id);
$impact = ImpactService::forTransaction($id);
$allowedNext = WASTE_TRANSITIONS[$tx['current_stage']] ?? [];
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="row g-4">
  <div class="col-lg-7">
    <div class="card mb-3">
      <div class="card-body p-4">
        <div class="d-flex align-items-center gap-3 flex-wrap">
          <div>
            <span class="passport-waste-id" style="font-size:1.1rem;padding:.35rem .8rem"><?= e($tx['waste_id']) ?></span>
            <div class="small text-muted mt-2">Pickup: <?= e($tx['pickup_code'] ?? '—') ?></div>
          </div>
          <div class="ms-auto text-end">
            <?= waste_badge($tx['current_stage']) ?>
            <?php if ($tx['final_outcome']): ?><div class="mt-2 small text-muted">Final: <?= waste_badge($tx['final_outcome']) ?></div><?php endif; ?>
          </div>
        </div>
        <div class="row g-3 mt-3">
          <div class="col-md-4"><div class="small text-muted fw-bold">CATEGORY</div>
            <div><span class="dot" style="background:<?= e($tx['category_color']) ?>"></span><?= e($tx['category_name']) ?></div></div>
          <div class="col-md-4"><div class="small text-muted fw-bold">WEIGHT</div><div><?= fmt_kg($tx['current_weight']) ?></div></div>
          <div class="col-md-4"><div class="small text-muted fw-bold">ORIGIN</div><div class="small"><?= e($tx['origin_address'] ?: '—') ?></div></div>
          <div class="col-md-6"><div class="small text-muted fw-bold">FACILITY</div><div class="small"><?= e($tx['facility_name'] ?? 'Not received yet') ?></div></div>
          <div class="col-md-6"><div class="small text-muted fw-bold">COLLECTED ON</div><div class="small"><?= fmt_dt($tx['created_at']) ?></div></div>
        </div>
        <a class="btn btn-sm btn-soft mt-3" href="<?= url('track.php?id=' . urlencode($tx['waste_id'])) ?>" target="_blank">
          <i class="bi bi-box-arrow-up-right me-1"></i>View public passport</a>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><i class="text-pnv bi bi-signpost-2 me-2"></i>Journey so far</div>
      <div class="card-body">
        <?php view('components/passport_timeline', ['events' => $events, 'tx' => $tx, 'public' => false]); ?>
      </div>
    </div>
  </div>

  <div class="col-lg-5">
    <?php if ($tx['facility_id'] === null): ?>
      <div class="card mb-3">
        <div class="card-header"><i class="bi bi-download me-2"></i>Receive intake</div>
        <div class="card-body p-4 text-center">
          <p class="small text-muted">This load has not been received at a facility yet. Claim it into
            <strong><?= e($facility['name'] ?? 'your facility') ?></strong> to start sorting.</p>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="receive">
            <button class="btn btn-pnv w-100"><i class="bi bi-box-arrow-in-down me-1"></i>Receive at My Facility</button>
          </form>
        </div>
      </div>
    <?php elseif ($allowedNext): ?>
      <div class="card mb-3">
        <div class="card-header"><i class="bi bi-arrow-repeat me-2"></i>Update processing stage</div>
        <div class="card-body p-4">
          <p class="small text-muted">Current stage: <strong><?= waste_badge($tx['current_stage']) ?></strong>.
            Allowed next stages are validated by the state machine — every update writes a journey event and updates the public passport.</p>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="stage">
            <div class="mb-3">
              <label class="form-label fw-semibold small">Next stage <span class="required-asterisk" aria-hidden="true">*</span></label>
              <select class="form-select" name="new_stage" required>
                <?php foreach ($allowedNext as $ns): ?>
                  <option value="<?= e($ns) ?>"><?= e(WASTE_STAGE_LABELS[$ns]) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label fw-semibold small">Quantity at this stage (kg)</label>
              <input type="number" step="0.05" min="0" class="form-control" name="quantity" value="<?= e($tx['current_weight']) ?>">
              <div class="form-text">Processing losses (e.g. moisture) reduce the recyclable weight.</div>
            </div>
            <div class="mb-3">
              <label class="form-label fw-semibold small">Notes</label>
              <textarea class="form-control" name="notes" rows="2" maxlength="400" placeholder="Process used, output material, batch no…"></textarea>
            </div>
            <button class="btn btn-pnv w-100"><i class="bi bi-check2-circle me-1"></i>Update Stage & Passport</button>
          </form>
          <?php if (in_array('RECYCLED', $allowedNext, true) || in_array('PROCESSED', $allowedNext, true) && false): endif; ?>
          <?php if ($tx['current_stage'] === 'PROCESSED'): ?>
            <div class="alert alert-info small mt-3 mb-0">
              <i class="bi bi-info-circle me-1"></i>Choosing a <strong>final outcome</strong> (Recycled / Recovered / Composted / Reused /
              Residual Disposal) closes the passport, auto-calculates the estimated environmental impact and credits reward points.
            </div>
          <?php endif; ?>
        </div>
      </div>
    <?php else: ?>
      <div class="card mb-3">
        <div class="card-header">Completed</div>
        <div class="card-body p-4 text-center">
          <div class="display-6">✅</div>
          <p class="fw-bold mb-1">Final outcome: <?= waste_badge($tx['final_outcome']) ?></p>
          <p class="small text-muted mb-0">Journey closed on <?= fmt_dt($tx['completed_at']) ?>.</p>
        </div>
      </div>
    <?php endif; ?>

    <?php if ($impact): ?>
      <div class="card">
        <div class="card-header"><i class="bi bi-globe-americas me-2"></i>Estimated impact (<?= e($impact['methodology_version']) ?>)</div>
        <div class="card-body p-4">
          <div class="row text-center g-3">
            <div class="col-4"><div class="text-pnv fs-5 fw-bold"><?= number_format((float) $impact['co2_saved_kg'], 2) ?></div><div class="small text-muted">kg CO₂e avoided</div></div>
            <div class="col-4"><div class="fs-5 fw-bold"><?= number_format((float) $impact['water_saved_l'], 0) ?></div><div class="small text-muted">L water saved</div></div>
            <div class="col-4"><div class="fs-5 fw-bold"><?= number_format((float) $impact['energy_saved_kwh'], 2) ?></div><div class="small text-muted">kWh saved</div></div>
          </div>
          <div class="small text-muted mt-3">Estimated impact = final quantity × configured factor. Values are indicative.</div>
        </div>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
