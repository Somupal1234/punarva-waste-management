<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_RECYCLER);
$pageTitle = 'My Facility'; $activeMenu = 'facility';
$facility = $user['facility_id'] ? Database::one('SELECT * FROM facilities WHERE id = ?', [$user['facility_id']]) : null;
$vehicles = $facility ? Database::all('SELECT * FROM vehicles WHERE facility_id = ? ORDER BY vehicle_number', [$facility['id']]) : [];
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<?php if (!$facility): ?>
  <div class="alert alert-warning">No facility linked to your account. Contact the administrator.</div>
<?php else: ?>
<div class="row g-4">
  <div class="col-lg-7">
    <div class="card mb-3">
      <div class="card-header"><i class="text-pnv bi bi-buildings me-2"></i>Facility profile</div>
      <div class="card-body p-4">
        <h5 class="fw-bold"><?= e($facility['name']) ?> <span class="badge text-bg-light border"><?= e($facility['facility_type']) ?></span></h5>
        <p class="small text-muted mb-2"><i class="bi bi-geo-alt me-1"></i><?= e($facility['address_line']) ?>, <?= e($facility['city']) ?><?= $facility['ward'] ? ' · ' . e($facility['ward']) : '' ?></p>
        <div class="row g-3 mt-2">
          <div class="col-md-4"><div class="small text-muted fw-bold">CODE</div><div><?= e($facility['code']) ?></div></div>
          <div class="col-md-4"><div class="small text-muted fw-bold">CAPACITY</div><div><?= fmt_kg($facility['capacity_kg_day']) ?>/day</div></div>
          <div class="col-md-4"><div class="small text-muted fw-bold">STATUS</div><div><span class="badge text-bg-<?= $facility['status'] === 'ACTIVE' ? 'success' : 'secondary' ?>"><?= e($facility['status']) ?></span></div></div>
          <div class="col-md-6"><div class="small text-muted fw-bold">CONTACT</div><div class="small"><?= e($facility['contact_person'] ?? '—') ?><br><i class="bi bi-telephone me-1"></i><?= e($facility['phone'] ?? '—') ?></div></div>
          <div class="col-md-6"><div class="small text-muted fw-bold">COORDS</div><div class="small" style="font-family:monospace"><?= e($facility['latitude'] . ', ' . $facility['longitude']) ?></div></div>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">Facility location</div>
      <div class="card-body"><div id="facilityMap" class="map-box" style="height:250px"></div></div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="card">
      <div class="card-header"><i class="text-pnv bi bi-bus-front me-2"></i>Vehicles</div>
      <div class="card-body p-0">
        <?php if (!$vehicles): ?><div class="empty-state py-4"><i class="bi bi-bus-front"></i><div>No vehicles registered.</div></div>
        <?php else: foreach ($vehicles as $v): ?>
          <div class="notif-item d-flex justify-content-between align-items-center">
            <div><strong><?= e($v['vehicle_number']) ?></strong>
              <div class="small text-muted"><?= e($v['vehicle_type']) ?> · <?= fmt_kg($v['capacity_kg']) ?> · driver: <?= e($v['driver_name'] ?? '—') ?></div></div>
            <span class="badge text-bg-<?= $v['status'] === 'ACTIVE' ? 'success' : 'secondary' ?>"><?= e($v['status']) ?></span>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
  </div>
</div>
<?php $pageScripts = '<script>pnvMap("facilityMap", { center: ' . json_encode([(float) $facility['latitude'], (float) $facility['longitude']]) . ', zoom: 14, markers: [{ lat: ' . json_encode((float) $facility['latitude']) . ', lng: ' . json_encode((float) $facility['longitude']) . ', title: ' . json_encode($facility['name']) . ', color: "teal", glyph: "bi-buildings" }] });</script>';
endif;
require dirname(__DIR__) . '/views/layouts/dash_footer.php';
