<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_RECYCLER);
$pageTitle = 'Facility Dashboard'; $activeMenu = 'dash';
$facilityId = (int) $user['facility_id'];
$facility = $facilityId ? Database::one('SELECT * FROM facilities WHERE id = ?', [$facilityId]) : null;

$kpi = [
    'incoming' => (int) Database::val('SELECT COUNT(*) FROM waste_transactions WHERE (facility_id = ? OR (facility_id IS NULL AND current_stage = "COLLECTED")) AND current_stage IN ("COLLECTED","SORTED")', [$facilityId]),
    'processing' => (int) Database::val('SELECT COUNT(*) FROM waste_transactions WHERE facility_id = ? AND current_stage IN ("SORTED","PROCESSING")', [$facilityId]),
    'done' => (int) Database::val('SELECT COUNT(*) FROM waste_transactions WHERE facility_id = ? AND final_outcome IS NOT NULL', [$facilityId]),
    'weightDone' => (float) (Database::val('SELECT COALESCE(SUM(current_weight),0) FROM waste_transactions WHERE facility_id = ? AND final_outcome IS NOT NULL', [$facilityId])),
];
$outcomes = Database::all(
    'SELECT final_outcome, COUNT(*) AS n, COALESCE(SUM(current_weight),0) AS w FROM waste_transactions
     WHERE facility_id = ? AND final_outcome IS NOT NULL GROUP BY final_outcome', [$facilityId]);
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<?php if (!$facility): ?>
  <div class="alert alert-warning"><i class="bi bi-exclamation-triangle me-1"></i>Your account is not linked to a facility yet.
    Ask the administrator to link your account to a recycling facility (Admin → Users → Edit).</div>
<?php endif; ?>
<div class="row g-3 mb-4">
  <?php $cards = [
    ['kpi-blue','bi-box-seam', fmt_num($kpi['incoming']), 'INCOMING / TO SORT', 'Awaiting first handling'],
    ['kpi-amber','bi-gear', fmt_num($kpi['processing']), 'IN PROCESSING', 'Sorted or processing'],
    ['kpi-green','bi-check2-circle', fmt_num($kpi['done']), 'COMPLETED', 'Final outcome recorded'],
    ['kpi-teal','bi-scale', fmt_kg($kpi['weightDone']), 'WEIGHT PROCESSED', 'Total handled'],
  ];
  foreach ($cards as [$c,$i,$v,$l,$s]): ?>
    <div class="col-6 col-lg-3"><div class="kpi-card <?= $c ?> p-3"><i class="bi <?= $i ?> kpi-icon"></i>
      <div class="kpi-value"><?= $v ?></div><div class="kpi-label"><?= e($l) ?></div>
      <div class="small opacity-75 mt-1"><?= e($s) ?></div></div></div>
  <?php endforeach; ?>
</div>
<div class="row g-4">
  <div class="col-lg-5">
    <div class="card mb-3">
      <div class="card-header"><i class="text-pnv bi bi-search me-2"></i>Find a Waste Passport</div>
      <div class="card-body">
        <form method="get" action="<?= url('recycler/incoming.php') ?>">
          <div class="input-group">
            <input class="form-control text-uppercase" name="q" placeholder="PNV-2026-000001">
            <button class="btn btn-pnv">Search</button>
          </div>
        </form>
        <?php if ($facility): ?>
        <hr>
        <div class="small text-muted fw-bold mb-1">FACILITY</div>
        <div class="d-flex align-items-center gap-2">
          <?= pnv_cat_badge('bi-buildings', 'var(--pnv-teal,#0b7285)', 36) ?>
          <div><strong><?= e($facility['name']) ?></strong>
            <div class="small text-muted"><?= e($facility['facility_type']) ?> · capacity <?= fmt_kg($facility['capacity_kg_day']) ?>/day</div></div>
        </div>
        <div class="small text-muted mt-2"><i class="bi bi-geo-alt me-1"></i><?= e($facility['address_line'] . ', ' . $facility['city']) ?></div>
        <?php endif; ?>
      </div>
    </div>
    <div class="card">
      <div class="card-header">Outcome distribution</div>
      <div class="card-body">
        <?php if (!$outcomes): ?><div class="empty-state py-3"><i class="bi bi-pie-chart"></i><div><?= t('misc.no_completed') ?></div></div>
        <?php else: ?>
          <?php foreach ($outcomes as $o): $pct = $kpi['weightDone'] > 0 ? round($o['w'] / $kpi['weightDone'] * 100) : 0; ?>
            <div class="mb-2">
              <div class="d-flex justify-content-between small"><span><?= e(WASTE_STAGE_LABELS[$o['final_outcome']]) ?> (<?= (int) $o['n'] ?>)</span><span><?= fmt_kg($o['w']) ?></span></div>
              <div class="progress" style="height:7px"><div class="progress-bar bg-success" style="width:<?= $pct ?>%"></div></div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div class="col-lg-7">
    <div class="card">
      <div class="card-header d-flex align-items-center">
        <i class="text-pnv bi bi-box-seam me-2"></i>Latest incoming waste
        <a class="btn btn-sm btn-soft ms-auto" href="<?= url('recycler/incoming.php') ?>">Open intake queue</a>
      </div>
      <div class="card-body p-0">
        <?php $latest = Database::all(
          'SELECT wt.*, wc.name AS category_name, wc.color FROM waste_transactions wt
           JOIN waste_categories wc ON wc.id = wt.category_id
           WHERE wt.facility_id = ? OR (wt.facility_id IS NULL AND wt.current_stage = "COLLECTED")
           ORDER BY wt.created_at DESC LIMIT 6', [$facilityId]); ?>
        <?php if (!$latest): ?>
          <div class="empty-state py-4"><i class="bi bi-inbox"></i><div><?= t('misc.no_routed') ?></div></div>
        <?php else: foreach ($latest as $t): ?>
          <div class="notif-item d-flex justify-content-between align-items-center">
            <div>
              <strong class="font-mono"><?= e($t['waste_id']) ?></strong>
              <div class="small text-muted"><span class="dot" style="background:<?= e($t['color']) ?>"></span><?= e($t['category_name']) ?> · <?= fmt_kg($t['current_weight']) ?></div>
            </div>
            <?= waste_badge($t['current_stage']) ?>
            <a class="btn btn-sm btn-soft" href="<?= url('recycler/waste-view.php?id=' . (int) $t['id']) ?>">Process</a>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
