<?php
/**
 * v2.4.4 — Recycler profile shares the account page (the shared implementation hides
 * saved addresses for recyclers). See collector/profile.php for the rationale.
 */
require dirname(__DIR__) . '/citizen/profile.php';
