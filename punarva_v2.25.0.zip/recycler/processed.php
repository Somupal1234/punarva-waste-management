<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_RECYCLER);
$pageTitle = 'Processed History'; $activeMenu = 'processed';
$facilityId = (int) $user['facility_id'];
$q = trim((string) get_val('q', ''));
$where = 'wt.facility_id = ? AND wt.final_outcome IS NOT NULL';
$params = [$facilityId];
if ($q !== '') { $where .= ' AND wt.waste_id LIKE ?'; $params[] = "%$q%"; }
$total = (int) Database::val("SELECT COUNT(*) FROM waste_transactions wt WHERE $where", $params);
$pg = paginate_request($total);
$rows = Database::all(
    "SELECT wt.*, wc.name AS category_name, wc.color, ei.co2_saved_kg
     FROM waste_transactions wt
     JOIN waste_categories wc ON wc.id = wt.category_id
     LEFT JOIN environmental_impacts ei ON ei.waste_transaction_id = wt.id
     WHERE $where ORDER BY wt.completed_at DESC LIMIT {$pg['limit']} OFFSET {$pg['offset']}", $params);
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="card">
  <div class="card-header d-flex align-items-center">
    <i class="text-pnv bi bi-arrow-repeat me-2"></i>Processed Waste <span class="badge text-bg-light border"><?= $total ?></span>
    <form class="d-flex gap-2 ms-auto"><input class="form-control form-control-sm text-uppercase" name="q" placeholder="Waste ID…" value="<?= e($q) ?>">
      <button class="btn btn-sm btn-pnv">Search</button></form>
  </div>
  <div class="card-body">
    <?php if (!$rows): ?><div class="empty-state"><i class="bi bi-inbox"></i><div class="mt-2"><?= t('misc.no_completed') ?></div></div>
    <?php else: ?>
      <div class="table-responsive"><table class="table table-hover align-middle">
        <thead><tr><th>Waste ID</th><th>Category</th><th>Final weight</th><th>Outcome</th><th>Completed</th><th>Est. CO₂e</th><th></th></tr></thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td class="font-mono fw-bold"><?= e($r['waste_id']) ?></td>
              <td><span class="dot" style="background:<?= e($r['color']) ?>"></span><?= e($r['category_name']) ?></td>
              <td><?= fmt_kg($r['current_weight']) ?></td>
              <td><?= waste_badge($r['final_outcome']) ?></td>
              <td class="small"><?= fmt_dt($r['completed_at'], 'd M Y') ?></td>
              <td class="small"><?= $r['co2_saved_kg'] !== null ? e(number_format((float) $r['co2_saved_kg'], 2)) . ' kg' : '—' ?></td>
              <td><a class="btn btn-sm btn-soft" href="<?= url('recycler/waste-view.php?id=' . (int) $r['id']) ?>">Details</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody></table></div>
      <?= pagination_links($pg) ?>
    <?php endif; ?>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php';
