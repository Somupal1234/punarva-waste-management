<?php
require_once __DIR__ . '/includes/init.php';
if (is_logged_in()) redirect(ROLE_HOME[current_role()]);

$orgTypes = ['SCHOOL' => 'School', 'OFFICE' => 'Office', 'RESTAURANT' => 'Restaurant', 'SHOP' => 'Shop',
             'HOSPITAL' => 'Hospital', 'APARTMENT' => 'Apartment', 'GOVERNMENT' => 'Government institution', 'OTHER' => 'Other'];

if ((string) setting('registration_enabled', '1') !== '1') {
    flash('warning', 'New registrations are currently disabled by the administrator.');
    redirect('login.php');
}

if (is_post()) {
    try {
        $id = AuthService::register($_POST);
        AuthService::attempt(strtolower(trim(post_val('email', ''))), post_val('password', ''));
        flash('success', 'Welcome to PUNARVA, ' . e(current_user()['name']) . '! Your account is ready.');
        redirect(ROLE_HOME[current_role()] ?? 'index.php');
    } catch (InvalidArgumentException | RuntimeException $e) {
        $regError = $e->getMessage();
        $f = pnv_field_error($regError, ['confirm' => 'password_confirm', 'password' => 'password',
            'email' => 'email', 'phone' => 'phone', 'mobile' => 'phone', 'org' => 'org_name', 'address' => 'address_line',
            'city' => 'city', 'ward' => 'ward', 'name' => 'name']);
        if ($f) $fieldErrors[$f] = $regError;
    } catch (Throwable $e) {
        $regError = APP_DEBUG ? $e->getMessage() : 'Registration failed. Please try again.';
    }
}
$fieldErrors = $fieldErrors ?? [];
$pageTitle = t('register.title');
?>
<!DOCTYPE html>
<html lang="<?= e(current_lang()) ?>">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="PUNARVA — From Waste to Worth. A transparent digital waste-management ecosystem with traceable Waste Passports, QR tracking and estimated environmental impact.">
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<title><?= e($pageTitle . ' · ' . APP_NAME) ?></title>
<link rel="stylesheet" href="<?= url('assets/vendor/bootstrap/bootstrap.min.css') ?>">
<link rel="stylesheet" href="<?= url('assets/vendor/bootstrap-icons/bootstrap-icons.min.css') ?>">
<link rel="stylesheet" href="<?= asset_url('assets/css/style.css') ?>">
</head>
<body>
<a class="skip-link" href="#main-content"><?= t('a11y.skip') ?></a>
<main id="main-content"><div class="auth-page py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-9 col-lg-6">
        <div class="text-center mb-3">
          <a class="brand-logo" href="<?= url('index.php') ?>" style="color:#fff">
            <img src="<?= url('assets/images/logo-icon.png') ?>" alt="PUNARVA logo">
            <span class="text-white">PUNARVA<small><?= e(t('foot.tagline')) ?></small></span>
          </a>
        </div>
        <div class="card auth-card">
          <div class="card-body p-4">
            <div class="text-center mb-3"><img class="logo-lg" src="<?= url('assets/images/logo-full.png') ?>" alt="PUNARVA – From Waste to Worth"></div>
            <h1 class="h4 fw-bold mb-1"><?= t('register.title') ?></h1>
            <p class="text-muted small">Join the waste-to-worth ecosystem — it takes a minute.</p>
            <?php if (!empty($regError)): ?>
              <div class="alert alert-danger small alert-auto"><i class="bi bi-exclamation-triangle me-1"></i><?= e($regError) ?></div>
            <?php endif; ?>
            <form method="post" novalidate>
              <?= csrf_field() ?>
              <div class="row g-3">
                <div class="col-md-6">
                  <label for="reg-name" class="form-label fw-semibold small"><?= t('register.name') ?> <span class="required-asterisk" aria-hidden="true">*</span></label>
                  <input id="reg-name" name="name" class="form-control<?= isset($fieldErrors['name']) ? ' is-invalid' : '' ?>" aria-invalid="<?= isset($fieldErrors['name']) ? 'true' : 'false' ?>"<?= isset($fieldErrors['name']) ? ' aria-describedby="err-name"' : '' ?> required value="<?= e(post_val('name', '')) ?>">
                    <?php if (isset($fieldErrors['name'])): ?><div class="invalid-feedback" id="err-name"><?= e($fieldErrors['name']) ?></div><?php endif; ?>
                </div>
                <div class="col-md-6">
                  <label for="reg-phone" class="form-label fw-semibold small"><?= t('common.phone') ?> <span class="required-asterisk" aria-hidden="true">*</span></label>
                  <input id="reg-phone" name="phone" class="form-control<?= isset($fieldErrors['phone']) ? ' is-invalid' : '' ?>" aria-invalid="<?= isset($fieldErrors['phone']) ? 'true' : 'false' ?>"<?= isset($fieldErrors['phone']) ? ' aria-describedby="err-phone"' : '' ?> value="<?= e(post_val('phone', '')) ?>" required aria-required="true" inputmode="tel" pattern="(\+91[\s-]?|0)?[6-9][0-9]{9}" maxlength="13" placeholder="98765 43210"><?php if (isset($fieldErrors['phone'])): ?><div class="invalid-feedback" id="err-phone"><?= e($fieldErrors['phone']) ?></div><?php endif; ?>
                  <div class="form-text small"><?= t('val.phone_hint') ?></div>
                </div>
                <div class="col-md-6">
                  <label for="reg-email" class="form-label fw-semibold small"><?= t('login.email') ?> <span class="required-asterisk" aria-hidden="true">*</span></label>
                  <input id="reg-email" name="email" type="email" class="form-control<?= isset($fieldErrors['email']) ? ' is-invalid' : '' ?>" aria-invalid="<?= isset($fieldErrors['email']) ? 'true' : 'false' ?>"<?= isset($fieldErrors['email']) ? ' aria-describedby="err-email"' : '' ?> required value="<?= e(post_val('email', '')) ?>">
                    <?php if (isset($fieldErrors['email'])): ?><div class="invalid-feedback" id="err-email"><?= e($fieldErrors['email']) ?></div><?php endif; ?>
                </div>
                <div class="col-md-6">
                  <label class="form-label fw-semibold small" for="roleSelect"><?= t('register.role') ?> <span class="required-asterisk" aria-hidden="true">*</span></label>
                  <select class="form-select" name="role" id="roleSelect" required>
                    <option value="citizen" <?= post_val('role') !== 'business' ? 'selected' : '' ?>>👤 Citizen / Household</option>
                    <option value="business" <?= post_val('role') === 'business' ? 'selected' : '' ?>>🏢 Business / Institution</option>
                  </select>
                </div>
              </div>
              <div id="bizFields" class="row g-3 mt-0 <?= post_val('role') === 'business' ? '' : 'd-none' ?>">
                <div class="col-md-7">
                  <label for="reg-org_name" class="form-label fw-semibold small">Organization name <span class="required-asterisk" aria-hidden="true">*</span></label>
                  <input id="reg-org_name" class="form-control" name="org_name" value="<?= e(post_val('org_name', '')) ?>">
                </div>
                <div class="col-md-5">
                  <label for="reg-org_type" class="form-label fw-semibold small">Organization type</label>
                  <select id="reg-org_type" class="form-select" name="org_type">
                    <?php foreach ($orgTypes as $k => $v): ?>
                      <option value="<?= e($k) ?>" <?= post_val('org_type') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>
              <div class="row g-3 mt-0">
                <div class="col-12">
                  <label for="reg-address_line" class="form-label fw-semibold small">Default address</label>
                  <input id="reg-address_line" class="form-control" name="address_line" placeholder="House / street / area" value="<?= e(post_val('address_line', '')) ?>">
                </div>
                <div class="col-md-6">
                  <label for="reg-ward" class="form-label fw-semibold small">Ward</label>
                  <input id="reg-ward" class="form-control" name="ward" placeholder="e.g. Ward 12" value="<?= e(post_val('ward', '')) ?>">
                </div>
                <div class="col-md-6">
                  <label for="reg-city" class="form-label fw-semibold small">City</label>
                  <input id="reg-city" class="form-control" name="city" value="<?= e(post_val('city', (string) setting('default_city', 'Dumka'))) ?>">
                </div>
                <div class="col-md-6">
                  <label for="reg-password" class="form-label fw-semibold small"><?= t('login.password') ?> <span class="required-asterisk" aria-hidden="true">*</span></label>
                  <input id="reg-password" name="password" type="password" class="form-control<?= isset($fieldErrors['password']) ? ' is-invalid' : '' ?>" aria-invalid="<?= isset($fieldErrors['password']) ? 'true' : 'false' ?>"<?= isset($fieldErrors['password']) ? ' aria-describedby="err-password"' : '' ?> required minlength="8"><?php if (isset($fieldErrors['password'])): ?><div class="invalid-feedback" id="err-password"><?= e($fieldErrors['password']) ?></div><?php endif; ?>
                  <div class="form-text">Minimum 8 characters.</div>
                </div>
                <div class="col-md-6">
                  <label for="reg-password_confirm" class="form-label fw-semibold small"><?= t('register.confirm') ?> <span class="required-asterisk" aria-hidden="true">*</span></label>
                  <input id="reg-password_confirm" name="password_confirm" type="password" class="form-control<?= isset($fieldErrors['password_confirm']) ? ' is-invalid' : '' ?>" aria-invalid="<?= isset($fieldErrors['password_confirm']) ? 'true' : 'false' ?>"<?= isset($fieldErrors['password_confirm']) ? ' aria-describedby="err-password_confirm"' : '' ?> required minlength="8"><?php if (isset($fieldErrors['password_confirm'])): ?><div class="invalid-feedback" id="err-password_confirm"><?= e($fieldErrors['password_confirm']) ?></div><?php endif; ?>
                </div>
              </div>
              <button class="btn btn-pnv w-100 py-2 mt-4"><i class="bi bi-person-plus me-1"></i><?= t('register.btn') ?></button>
            </form>
            <hr>
            <div class="small text-center"><?= t('register.have_account') ?> <a href="<?= url('login.php') ?>" class="text-pnv fw-bold"><?= t('nav.login') ?></a></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div></main>
<script>
document.getElementById('roleSelect').addEventListener('change', function () {
  document.getElementById('bizFields').classList.toggle('d-none', this.value !== 'business');
  var org = document.querySelector('[name=org_name]');
  if (org) org.required = this.value === 'business'; // conditional HTML5 validation matches server rules
});
document.addEventListener('DOMContentLoaded', function () {
  var rs = document.getElementById('roleSelect');
  if (rs && rs.value === 'business') { var org = document.querySelector('[name=org_name]'); if (org) org.required = true; }
});
</script>
<script src="<?= asset_url('assets/js/password-toggle.js') ?>" defer></script>
</body></html>
