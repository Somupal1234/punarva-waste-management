<?php
require_once __DIR__ . '/includes/init.php';

// Public email-verification endpoint: single-use token (64 hex chars), hash-matched server-side.
$token = trim((string) get_val('t', ''));
$uid = $token !== '' ? VerificationService::verifyEmailToken($token) : null;

if ($uid) {
    flash('success', t('verify.email_verified_ok'));
} else {
    flash('danger', t('verify.email_link_bad'));
}
redirect(is_logged_in() ? (ROLE_HOME[current_role()] ?? 'index.php') : 'index.php');
