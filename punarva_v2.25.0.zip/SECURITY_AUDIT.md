# PUNARVA — Security Audit & Hardening Report

**Project:** PUNARVA – From Waste to Worth (`/punarva/` on XAMPP)
**Scope:** Audit → Secure → Harden → Fix → Test of the *existing* application (no rebuild)
**Date:** September 2026 · **Stack:** PHP 8+, MySQL/MariaDB, Bootstrap 5, Apache/XAMPP

> This report describes practical security controls that are implemented and tested.
> **No software can be declared "100% secure" or "unhackable".** Remaining risks and
> production-recommendations are listed honestly in the last section.

---

## 1. Security Improvements (this pass)

| # | Improvement | Where |
|---|---|---|
| 1 | **Password show/hide (eye) toggle** — mandatory requirement. Accessible (`aria-label`, `aria-pressed`, keyboard focusable, ≥44px touch target). Default state: **hidden**. Toggles only the input `type` in-browser; the value is never copied to JS storage. Applied automatically to *every* password field: login, register, reset-password. | `assets/js/password-toggle.js`, `assets/css/style.css`, `login.php`, `register.php`, `reset-password.php` |
| 2 | **Security headers on every response** (PHP-side so they work on Apache *and* the PHP dev server): `X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin`, `Permissions-Policy: geolocation=(self), camera=(), microphone=(), payment=()`, `Content-Security-Policy` (see §8). | `includes/init.php` |
| 3 | **Clickjacking protection** — `X-Frame-Options: SAMEORIGIN` + `frame-ancestors 'self'` are sent when the app is served from `localhost/127.0.0.1` (XAMPP). Skipped on proxy/embed hosts so the sandboxed preview iframe keeps working; document to enable unconditionally in production. | `includes/init.php` |
| 4 | **Idle session timeout** — authenticated sessions auto-logout after **30 minutes** of inactivity (configurable `SESSION_IDLE_TIMEOUT`), with a friendly flash message. Session ID is regenerated on timeout-destroy. | `config/config.php`, `includes/init.php` |
| 5 | **Add-New admin form crash fixed** (`Cannot use object of type Closure as array`) — the crash masked the create-form for **all 10 admin CRUD entities**; options are now resolved (closure-aware) before use. Status defaults to `ACTIVE`; password mandatory for new users. | `admin/module.php` |
| 6 | **Add-New UX** — form opens as a dedicated page (list hidden), auto-scrolled, with *Back to list* — no hidden form at page bottom. | `admin/module.php` |
| 7 | **Dedicated role-tab login hardening** — role/`tab` is validated server-side; a citizen account cannot sign in through the Admin tab; stale sessions are cleanly destroyed when switching accounts; generic authentication error everywhere. | `login.php`, `services/AuthService.php` |
| 8 | **Forgot/Reset password** (added earlier, kept hardened): single-use **SHA-256-hashed** tokens, 60-minute expiry, 3 requests/hour/email limit, generic "if that email is registered…" response (no account enumeration), notification + audit entries. | `services/AuthService.php`, `forgot-password.php`, `reset-password.php` |
| 9 | Bulletproof `schema.sql` (FK-safe re-import) and `password_resets` table added to schema + lazy auto-create on old installs. | `database/schema.sql` |

## 2. Authentication Security

- Passwords stored with `password_hash()` (bcrypt cost 12); verified with `password_verify()`.
  No plaintext, reversible, logged, or URL-transmitted passwords. Passwords never enter JS/localStorage/sessionStorage — the eye toggle only flips the input type.
- Login: `session_regenerate_id(true)` on success (fixation-resistant); cookie `HttpOnly; SameSite=Lax` (dev) / `Secure; SameSite=None; Partitioned` behind HTTPS proxies.
- **Brute-force:** max **6 failed attempts per IP+email per 15 minutes**, then lockout message; attempts tracked in `login_attempts` table; generic error `Invalid email or password.` always (verified in testing — attempt 7 returns lockout).
- **Enumeration-safe:** login and forgot-password return generic messages; unknown emails produce no visible difference (verified: no reset link is rendered for unknown email).
- Idle timeout 30 min (§1.4). Logout clears `$_SESSION`, destroys the cookie and the session record.
- Password reset: expiring single-use hashed tokens (§1.8). New password minimum 8 chars, confirm-matched, hashed; audit-logged; user notified in-app.

## 3. Authorization (RBAC + Ownership/IDOR)

- Five roles (admin, citizen, collector, recycler, business) enforced at **three levels**:
  1. **Pages** — `require_role()` redirects unauthenticated to login (302) and wrong-role to their own console (verified: citizen → `/admin/dashboard.php` = 302).
  2. **APIs** — `require_login()` → `401`, `require_role()` → `403` (verified: citizen on `api/admin/dashboard.php` = 403; unauthenticated = 401).
  3. **Records** — ownership middleware: `OwnershipMiddleware::pickupOwner` (citizen's own pickups), collector assignment ownership (other collectors silently blocked — verified in E2E), `facilityWaste` (recycler sees only its facility's waste). Citizen viewing another's pickup = 302 (verified).
- Roles are **never** taken from the browser. Public registration is hard-limited server-side:
  `$roleCode = ($d['role'] ?? citizen) === business ? business : citizen;` — nobody can self-register as Admin/Collector/Recycler (mass-assignment impossible; explicit field allowlists used everywhere; admin-created privileged accounts).
- Public QR tracking uses the Waste ID as a *safe public identifier* and queries only public fields.

## 4. Database Security

- **100% PDO prepared statements** with bound parameters for every user-influenced query (verified by code review + SQLi attempts: `' OR '1'='1` login → validation-rejected; crafted `track.php?id=…' OR 1=1--` → safely escaped, no error, no data).
- Dynamic identifiers (status/stage transitions) are **allowlisted constants** (`PICKUP_STATUSES`, `WASTE_TRANSITIONS`, `REPORT_STATUSES`); list sorting is fixed server-side (no user ORDER BY injection surface); pagination ints are cast.
- Multi-step workflows (pickup completion → waste txn + Waste ID + events + notifications; recycling final → impact + reward) run inside **nested-safe transactions** (`Database::begin/commit/rollBack` with SAVEPOINTs).
- Schema: FKs with proper cascades, unique constraints (rewards idempotency: unique key on user+rule+reference; Waste ID sequence table with row-lock), indexes on hot paths.
- Least-privilege: app may run under a dedicated MySQL user; env overrides (`PUNARVA_DB_*`) supported; on XAMPP defaults documented. `config/`, `database/`, `storage/`, `includes/`, `services/`, `middleware/`, `lang/` are blocked from web access by root `.htaccess` (`RedirectMatch 403`), plus `FilesMatch` deny for config files. `.sql/.log/.md` should additionally be verified after deployment (see §10).

## 5. File Upload Security

`handle_upload()` (verified by live tests):
- extension **allowlist** (jpg/jpeg/png/webp) **and** real MIME via `finfo` — **mismatch → reject**;
- **content check** via `getimagesize` + minimum dimensions;
- size cap (`UPLOAD_MAX_BYTES`, 5 MB default; PHP `upload_max_filesize` is the outer bound);
- **random filenames** (`date + 16 hex random bytes`), original name never used; sub-directory name sanitized (no path traversal);
- `uploads/.htaccess`: `FilesMatch` deny for php/phtml/phar/cgi…, `php_flag engine off`, `RemoveHandler`, `-ExecCGI -Indexes` — uploaded files can never execute.

**Live tests:** PHP script renamed `.png` → **422 "File content is not a valid image."**; valid PNG → 200; oversized random file → rejected.

## 6. CSRF

- Every state-changing form POST carries a per-session CSRF token (`csrf_field()`); verified server-side (`$_POST['_csrf'] ?? HTTP_X_CSRF_TOKEN`).
- JSON APIs require the token via `X-CSRF-Token` header (tested: missing token → `419/403` "Invalid or missing CSRF token."; upload with token → 200).
- Coverage: login, register, forgot/reset password, pickups (create/cancel), collector transitions, recycler stages, reports, rewards, admin CRUD (create/update/delete/toggle), settings.

## 7. XSS (Cross-Site Scripting)

- All output escaped via `e()` (`htmlspecialchars(…, ENT_QUOTES, 'UTF-8')`) across views/components (spot-verified).
- **Stored-XSS test:** `<script>alert(1)</script>` in `track.php?id=…` renders escaped — raw script appears **0** times in HTML.
- JS uses safe DOM APIs; no user data `innerHTML`-interpolated (toast body is static/server-flash text); no `eval`.
- `Content-Security-Policy` restricts sources to `'self'` (+ inline, see §8) — external script injection is blocked.

## 8. Security Headers (implemented)

```
X-Content-Type-Options: nosniff
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: geolocation=(self), camera=(), microphone=(), payment=()
Content-Security-Policy:
  default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';
  img-src 'self' data: https://*.tile.openstreetmap.org; font-src 'self' data:;
  connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'
X-Frame-Options: SAMEORIGIN + frame-ancestors 'self'   (only on localhost — see §1.3)
```
- `'unsafe-inline'` is required by the existing page-level scripts; documented as a residual risk (§10) with a nonce-based upgrade path.
- OSM tile hosts are allowlisted in `img-src` because Leaflet loads map tiles; no other third-party origins are permitted.
- HSTS is **not** enabled — the app currently runs on `http://localhost` (XAMPP). Enable only after real HTTPS deployment (§10).

## 9. Rate Limiting & Business-Logic Integrity

- Login lockout (§2); password-reset 3/hour/email.
- **Server-authoritative state machines:** pickup `REQUESTED→…→COMPLETED`, waste `CREATED→…→final outcome`, report lifecycle — arbitrary jumps rejected server-side (`WASTE_TRANSITIONS` allowlist).
- **Rewards:** server-calculated from configured rules, idempotent via DB unique constraint (user+rule+reference type+id) — duplicate/manual point injection impossible (re-run returns "already awarded").
- **Impact:** `quantity × DB impact factor`, methodology version stamped, always labelled *Estimated*; client-supplied impact/points/weights are never trusted (actual weight is validated numeric server input, points/impact always recomputed server-side).
- Audit log (`AuditService`) records login, assignments, stage changes, reward/impact changes, admin edits, settings — user, action, module, record, old/new, IP, timestamp. Passwords/tokens are never logged.

## 10. Remaining Risks & Production Recommendations (honest list)

1. **CSP `'unsafe-inline'`** weakens script-injection protection. Upgrade path: move inline `<script>` blocks to bundled files or nonces (`script-src 'nonce-…'`).
2. **X-Frame-Options/frame-ancestors** are currently localhost-only so the hosted sandbox preview keeps working. For production: send them unconditionally.
3. **HSTS** must be enabled after HTTPS is actually deployed; `session.cookie_secure` is already HTTPS-aware.
4. **XAMPP dev defaults** (`root`/empty MySQL password, `APP_DEBUG=true`) are for local development only. Production: dedicated least-privilege DB user, `APP_DEBUG=false`, secrets via environment.
5. `.htaccess` protections require Apache with `AllowOverride All`. On non-Apache servers, replicate the deny rules in the server config; keep `database/`, `storage/`, `config/` outside the web root if possible.
6. **Password reset delivery** uses PHP `mail()`, which has no real MTA on XAMPP — the reset link is shown on-screen locally (convenient for demos, *not* for production). Wire SMTP in production and remove the on-screen fallback.
7. `mail()`-based delivery and the demo AI provider are clearly labelled; the real AI provider keeps keys server-side (`AI_API_KEY`/env) — rotate keys and set spend limits before public deployment.
8. Rate limiting is per-IP+email in DB — behind a reverse proxy, ensure `client_ip()` uses the trusted `X-Forwarded-For` hop only.
9. Session files on shared hosting should move to Redis/DB handler for multi-server setups.

## 11. Verified Test Matrix (post-hardening)

| Area | Test | Result |
|---|---|---|
| Auth | valid login → role dashboard 302/200 | ✅ |
| Auth | wrong password ×6 → generic error; 7th → lockout | ✅ |
| Auth | session cookie `HttpOnly; SameSite`; regenerate on login | ✅ |
| RBAC | citizen → admin/collector pages 302 | ✅ |
| RBAC | API unauth 401 / wrong-role 403 | ✅ |
| IDOR | citizen on another's pickup 302; collector cross-assignment blocked | ✅ |
| SQLi | login payload, track-id payload | ✅ rejected/escaped |
| XSS | `<script>` in public params → escaped (0 raw) | ✅ |
| CSRF | POST without token blocked (419/403); APIs need `X-CSRF-Token` | ✅ |
| Upload | PHP-as-PNG 422; valid PNG 200; oversized rejected | ✅ |
| Public track | phone/email: 0 leaks; citizen name masked ("Aarav S."); internal notes absent | ✅ |
| Methods | GET on create-endpoints → 401/405 (fail-closed) | ✅ |
| Headers | nosniff / referrer / permissions / CSP present | ✅ |
| UX | eye toggle on all password fields (hidden by default) | ✅ |
| Functionality | home, login, register, forgot/reset, citizen/collector/recycler/business/admin dashboards, Add-New form, track QR | ✅ all working |

---

## 12. Final Polish Pass (post-hardening)

- Live Map & Analytics now carry honest labels: *"Demo data · no real-time GPS/IoT"*, *"Computed live from the database"*, *"Impact figures are estimates"* — joining Hotspots ("rule-based MVP") and the Suggested Route ("rule-based MVP").
- Landing page gained a localized 4-step journey strip (en/hi/bn) explaining Scan → Pickup → Passport → Impact; all new strings exist in all three languages (67+10 keys, verified).
- Visual refinements are CSS-only (gradient wordmark, KPI accent ribbons, journey connector, focus-visible outlines, coarse-pointer touch targets, 16px inputs on mobile to prevent iOS zoom). No markup structure or workflow changed.
- Re-verified after polish: all public pages 200, all 5 role dashboards 200, CSRF 419 on tokenless POST, IDOR 302, security headers present, zero PII on public tracking.

---

**PUNARVA** remains fully functional after hardening: the complete
Citizen → Scanner → Pickup → Collector → Waste ID → Recycler → Passport → QR → Reward → Impact → Admin Analytics
workflow was re-verified end-to-end on the live database.
