<?php
require_once __DIR__ . '/includes/init.php';
$pageTitle = 'Learning Center'; $activeNav = 'learn';
$topic = get_val('topic', '');
$topics = Database::all('SELECT DISTINCT topic FROM articles WHERE status = "PUBLISHED" ORDER BY topic');
$articles = Database::all(
    'SELECT a.*, u.name AS author FROM articles a LEFT JOIN users u ON u.id = a.author_id
     WHERE a.status = "PUBLISHED" ' . ($topic ? 'AND a.topic = ? ' : '') . 'ORDER BY a.created_at DESC LIMIT 60',
    $topic ? [$topic] : []);
// active quizzes visible to logged-in citizens
$quizzes = Database::all('SELECT * FROM quizzes WHERE status = "ACTIVE" ORDER BY id');
$attempted = [];
if (current_user() && current_role() === 'citizen') {
    foreach (Database::all('SELECT quiz_id, MAX(score_pct) AS best, MAX(passed) AS passed FROM quiz_attempts WHERE user_id = ? GROUP BY quiz_id', [current_user()['id']]) as $at) {
        $attempted[$at['quiz_id']] = $at;
    }
}
view('layouts/public_header', compact('pageTitle', 'activeNav'));
?>
<section class="py-5">
  <div class="container">
    <div class="text-center mb-4">
      <div class="section-eyebrow">Learn & earn</div>
      <h1 class="h2 fw-bold"><?= t('page.learn') ?></h1>
      <p class="text-muted small">Read, understand, segregate better — and pass quizzes to earn reward points.</p>
    </div>

    <ul class="nav nav-pills justify-content-center mb-4">
      <li class="nav-item"><a class="nav-link <?= $topic === '' ? 'active' : '' ?>" style="<?= $topic === '' ? 'background:var(--pnv-green)' : 'color:var(--pnv-green-dark)' ?>" href="<?= url('learn.php') ?>">All topics</a></li>
      <?php foreach ($topics as $tp): ?>
        <li class="nav-item"><a class="nav-link <?= $topic === $tp['topic'] ? 'active' : '' ?>" style="<?= $topic === $tp['topic'] ? 'background:var(--pnv-green)' : 'color:var(--pnv-green-dark)' ?>" href="<?= url('learn.php?topic=' . urlencode($tp['topic'])) ?>"><?= e($tp['topic']) ?></a></li>
      <?php endforeach; ?>
    </ul>

    <?php if (current_user() && current_role() === 'citizen' && $quizzes): ?>
      <div class="card mb-4 border-0" style="background:linear-gradient(135deg,#0b3b28,#148554);color:#e8f5ec">
        <div class="card-body p-4">
          <h5 class="fw-bold"><i class="bi bi-patch-question me-2"></i>Knowledge quizzes — earn points!</h5>
          <div class="row g-3 mt-1">
            <?php foreach ($quizzes as $qz): $at = $attempted[$qz['id']] ?? null; ?>
              <div class="col-md-4">
                <div class="p-3 rounded-3 h-100" style="background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2)">
                  <strong><?= e($qz['title']) ?></strong>
                  <div class="small opacity-75 mt-1"><?= e($qz['description']) ?></div>
                  <div class="d-flex align-items-center flex-wrap mt-2 gap-2">
                    <?php if ($at && $at['passed']): ?><span class="badge text-bg-success">Passed (<?= (int) $at['best'] ?>%)</span>
                    <?php elseif ($at): ?><span class="badge text-bg-light">Best: <?= (int) $at['best'] ?>% (pass <?= (int) $qz['pass_score_pct'] ?>%)</span><?php endif; ?>
                    <a class="btn btn-sm btn-light ms-auto fw-bold" href="<?= url('citizen/quiz.php?id=' . (int) $qz['id']) ?>">
                      <?= $at && $at['passed'] ? 'Review' : ($at ? 'Retry' : 'Take quiz') ?></a>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    <?php elseif ($quizzes && !current_user()): ?>
      <div class="alert alert-light border small text-center">
        <i class="bi bi-trophy text-warning me-1"></i><strong><?= count($quizzes) ?> quizzes</strong> are available —
        <a href="<?= url('login.php') ?>">log in</a> as a citizen to earn reward points for passing them.
      </div>
    <?php endif; ?>

    <div class="row g-4">
      <?php if (!$articles): ?>
        <div class="col-12"><div class="empty-state"><i class="bi bi-journal-x"></i><div>No articles published yet.</div></div></div>
      <?php endif; ?>
      <?php foreach ($articles as $a): ?>
        <div class="col-md-6 col-lg-4">
          <a class="card h-100 text-decoration-none" href="<?= url('article.php?slug=' . urlencode($a['slug'])) ?>">
            <div class="card-body p-4">
              <span class="badge text-bg-light border mb-2"><?= e($a['topic']) ?></span>
              <h5 class="text-pnv-dark fw-bold"><?= e($a['title']) ?></h5>
              <p class="small text-muted mb-2"><?= e($a['summary']) ?></p>
              <div class="small text-muted"><i class="bi bi-clock me-1"></i><?= fmt_dt($a['created_at'], 'd M Y') ?>
                · <i class="bi bi-eye ms-1 me-1"></i><?= (int) $a['views'] ?> reads</div>
            </div>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php view('layouts/public_footer');
