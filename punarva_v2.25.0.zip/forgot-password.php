<?php
require_once __DIR__ . '/includes/init.php';
if (is_logged_in()) redirect(ROLE_HOME[current_role()]);

$role = (string) get_val('role', 'citizen');
$fieldErrors = [];
if (is_post()) {
    try {
        $email = val_email($_POST);
        $token = AuthService::requestPasswordReset($email);
        if ($token !== null) {
            $link = absolute_url('reset-password.php?token=' . $token);
            // Production: yahan email jaata hai. Local/XAMPP mein mail server nahi hota,
            // isliye link screen par bhi dikha dete hain (aur log file mein likhte hain).
            $sent = @mail($email, 'PUNARVA – Password Reset',
                "Open this link to reset your PUNARVA password (valid 60 minutes):\n$link",
                'From: no-reply@punarva.local');
            if (!is_dir(LOG_DIR)) @mkdir(LOG_DIR, 0775, true);
            @file_put_contents(LOG_DIR . '/password-resets.log', '[' . date('c') . '] ' . $link . PHP_EOL, FILE_APPEND);
            $resetLink = $sent ? null : $link;
        }
        $resetNotice = 'If that email is registered, a password reset link has been sent. The link is valid for 60 minutes.';
    } catch (RuntimeException $e) {
        $forgotError = $e->getMessage();
        if (pnv_field_error($forgotError, ['email' => 'email'])) $fieldErrors['email'] = $forgotError;
    } catch (Throwable $e) {
        $forgotError = APP_DEBUG ? $e->getMessage() : 'Could not process the request. Please try again.';
    }
}
?>
<!DOCTYPE html>
<html lang="<?= e(current_lang()) ?>">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="PUNARVA — From Waste to Worth. A transparent digital waste-management ecosystem with traceable Waste Passports, QR tracking and estimated environmental impact.">
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<title><?= e('Forgot Password · ' . APP_NAME) ?></title>
<link rel="icon" type="image/png" href="<?= url('assets/images/favicon.png') ?>">
<link rel="stylesheet" href="<?= url('assets/vendor/bootstrap/bootstrap.min.css') ?>">
<link rel="stylesheet" href="<?= url('assets/vendor/bootstrap-icons/bootstrap-icons.min.css') ?>">
<link rel="stylesheet" href="<?= asset_url('assets/css/style.css') ?>">
</head>
<body>
<a class="skip-link" href="#main-content"><?= t('a11y.skip') ?></a>
<main id="main-content"><div class="auth-page py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-8 col-lg-5">
        <div class="card auth-card">
          <div class="card-body p-4">
            <div class="text-center mb-3"><img class="logo-lg" src="<?= url('assets/images/logo-full.png') ?>" alt="PUNARVA"></div>
            <h1 class="h4 fw-bold mb-1 text-center"><i class="text-pnv bi bi-key me-2"></i>Forgot Password</h1>
            <p class="text-muted small text-center mb-4">Enter your account email — we'll generate a secure reset link (valid 60 minutes).</p>

            <?php if (!empty($forgotError)): ?>
              <div class="alert alert-danger small alert-auto"><?= e($forgotError) ?></div>
            <?php endif; ?>
            <?php if (!empty($resetNotice)): ?>
              <div class="alert alert-success small">
                <i class="bi bi-check2-circle me-1"></i><?= e($resetNotice) ?>
                <?php if (!empty($resetLink)): ?>
                  <hr>
                  <div class="small text-muted mb-1"><i class="bi bi-info-circle me-1"></i>
                    Local/XAMPP environment mein email server nahi hota, isliye aapka reset link seedha neeche hai:</div>
                  <div class="input-group input-group-sm">
                    <input class="form-control" value="<?= e($resetLink) ?>" readonly onclick="this.select()">
                    <a class="btn btn-pnv" href="<?= e($resetLink) ?>">Open</a>
                  </div>
                <?php endif; ?>
              </div>
            <?php endif; ?>

            <form method="post" novalidate>
              <?= csrf_field() ?>
              <div class="mb-3">
                <label class="form-label fw-semibold small"><?= t('login.email') ?> <span class="required-asterisk" aria-hidden="true">*</span></label>
                <div class="input-group">
                  <span class="input-group-text bg-white"><i class="bi bi-envelope"></i></span>
                  <input name="email" type="email" class="form-control<?= isset($fieldErrors['email']) ? ' is-invalid' : '' ?>" aria-invalid="<?= isset($fieldErrors['email']) ? 'true' : 'false' ?>"<?= isset($fieldErrors['email']) ? ' aria-describedby="err-email"' : '' ?> required autofocus<?php if (isset($fieldErrors['email'])): ?><div class="invalid-feedback" id="err-email"><?= e($fieldErrors['email']) ?></div><?php endif; ?>
                         value="<?= e(post_val('email', '')) ?>" placeholder="you@example.com">
                </div>
              </div>
              <button class="btn btn-pnv w-100 py-2"><i class="bi bi-send me-1"></i>Send Reset Link</button>
            </form>
            <hr>
            <div class="small text-center">
              <a href="<?= url('login.php' . ($role !== '' ? '?role=' . e($role) : '')) ?>" class="text-pnv fw-bold">
                <i class="bi bi-arrow-left me-1"></i>Back to login</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div></main>
<script src="<?= asset_url('assets/js/password-toggle.js') ?>" defer></script>
</body></html>
