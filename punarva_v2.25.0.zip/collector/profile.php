<?php
/**
 * v2.4.4 — Collector profile shares the account page (name/phone/language/avatar,
 * password change, verification). The shared implementation lives in citizen/profile.php,
 * which already authorises collectors and redirects role-relatively; this wrapper only
 * exists so the sidebar's role-relative "Profile" link (…/collector/profile.php) resolves.
 */
require dirname(__DIR__) . '/citizen/profile.php';
