<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_COLLECTOR);
$pageTitle = 'Execute Pickup'; $activeMenu = 'assignments';

$id = (int) get_val('id', 0);
$a = Database::one(
    'SELECT pa.*, pr.pickup_code, pr.preferred_date, pr.time_slot, pr.address_line, pr.ward, pr.city,
            pr.estimated_weight, pr.notes, pr.image_path, pr.status AS pickup_status, pr.latitude, pr.longitude,
            pr.user_id AS citizen_id, u.name AS citizen_name, u.phone AS citizen_phone,
            wc.name AS category_name, wc.color, wc.icon, wc.bin_type, wc.recycling_guidance
     FROM pickup_assignments pa
     JOIN pickup_requests pr ON pr.id = pa.pickup_request_id
     JOIN users u ON u.id = pr.user_id
     JOIN waste_categories wc ON wc.id = pr.category_id
     WHERE pa.id = ?', [$id]);
if (!$a) { flash('warning', 'Assignment not found.'); redirect('collector/assignments.php'); }
OwnershipMiddleware::assignmentOwner($a, $user);

if (is_post()) {
    $action = (string) post_val('action');
    try {
        $map = ['accept' => 'ACCEPTED', 'start' => 'ON_THE_WAY', 'arrive' => 'ARRIVED', 'complete' => 'COMPLETED'];
        if ($action === 'collect') {
            PickupService::transition($id, 'COLLECTED', $user, $_POST + ['proof_image' => $_FILES['proof_image'] ?? null]); // v2.11.1 fix: $_FILES was dropped — proof photo never saved
            flash('success', 'Waste recorded as collected. Now press "Complete pickup" to issue the Waste Passport.');
        } elseif ($action === 'complete') {
            $res = PickupService::transition($id, 'COMPLETED', $user, $_POST);
            $tx = Database::one('SELECT waste_id FROM waste_transactions WHERE pickup_request_id = ?', [$a['pickup_request_id']]);
            flash('success', 'Pickup completed! Waste Passport ' . ($tx['waste_id'] ?? '') . ' issued 🎉');
        } elseif (isset($map[$action])) {
            PickupService::transition($id, $map[$action], $user, $_POST);
            flash('success', 'Status updated to ' . PICKUP_STATUS_LABELS[$map[$action]] . '.');
        }
        redirect('collector/assignment-view.php?id=' . $id);
    } catch (InvalidArgumentException | RuntimeException $e) {
        flash('danger', $e->getMessage());
    } catch (Throwable $e) {
        // v2.4.3 — SQL/database problems must NEVER reach the UI as raw errors (log + clean message)
        error_log('PUNARVA pickup action failed: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
        $m = (string) $e->getMessage();
        flash('danger', (APP_DEBUG && !str_contains($m, 'SQLSTATE')) ? $m
            : 'This action could not be completed. Please refresh the page and try again — if it keeps failing, contact the administrator.');
    }
    redirect('collector/assignment-view.php?id=' . $id);
}
require dirname(__DIR__) . '/views/layouts/dash_header.php';
$st = $a['status'];
?>
<div class="row g-4">
  <div class="col-lg-7">
    <div class="card mb-3">
      <div class="card-body p-4">
        <div class="d-flex align-items-center gap-3 flex-wrap">
          <?= pnv_cat_badge($a['icon'], $a['color'], 46) ?>
          <div>
            <div class="fw-bold fs-5"><?= e($a['pickup_code']) ?></div>
            <div class="small text-muted"><?= e($a['category_name']) ?> · est. <?= fmt_kg($a['estimated_weight']) ?> · bin: <?= e($a['bin_type']) ?></div>
          </div>
          <div class="ms-auto"><?= pickup_badge($st) ?></div>
        </div>
        <div class="row g-3 mt-3">
          <div class="col-md-6"><div class="small text-muted fw-bold">CITIZEN</div><div><?= e($a['citizen_name']) ?>
            <?php if ($a['citizen_phone'] && in_array($st, ['ACCEPTED','ON_THE_WAY','ARRIVED'], true)): ?><div class="small"><i class="bi bi-telephone me-1"></i><?= e($a['citizen_phone']) ?></div><?php endif; ?></div></div>
          <div class="col-md-6"><div class="small text-muted fw-bold">SCHEDULE</div><div><?= fmt_dt($a['preferred_date'], 'D, d M Y') ?> · <?= e($a['time_slot']) ?></div></div>
          <div class="col-md-8"><div class="small text-muted fw-bold">ADDRESS</div><div class="small"><?= e($a['address_line']) ?><?= $a['ward'] ? ' · ' . e($a['ward']) : '' ?></div></div>
          <div class="col-md-4"><div class="small text-muted fw-bold">BANK / COORDS</div><div class="small" style="font-family:monospace"><?= $a['latitude'] ? e($a['latitude'] . ', ' . $a['longitude']) : '—' ?></div></div>
          <?php if ($a['notes']): ?><div class="col-12"><div class="small text-muted fw-bold">CITIZEN NOTES</div><div class="small"><?= e($a['notes']) ?></div></div><?php endif; ?>
          <?php if ($a['image_path']): ?>
            <div class="col-12"><div class="small text-muted fw-bold mb-1">CITIZEN PHOTO</div>
              <a href="<?= e(upload_url($a['image_path'])) ?>" target="_blank"><img alt="Collection proof photo" src="<?= e(upload_url($a['image_path'])) ?>" style="height:90px" class="rounded border"></a></div>
          <?php endif; ?>
        </div>

        <div class="stepper mt-4">
          <?php $flow = ['ASSIGNED','ACCEPTED','ON_THE_WAY','ARRIVED','COLLECTED','COMPLETED'];
          $idx = array_search($st, $flow, true);
          if ($idx === false) $idx = -1;
          foreach ($flow as $i => $s): ?>
            <div class="step <?= $i < $idx ? 'done' : ($i == $idx ? 'current' : '') ?>"><?= e(PICKUP_STATUS_LABELS[$s]) ?></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <?php if ($a['latitude']): ?>
      <div class="card"><div class="card-header">Navigation</div><div class="card-body">
        <div id="navMap" class="map-box" style="height:250px"></div>
        <a class="btn btn-sm btn-soft mt-2" target="_blank" href="https://www.openstreetmap.org/directions?to=<?= e($a['latitude']) ?>,<?= e($a['longitude']) ?>"><i class="bi bi-signpost-2 me-1"></i>Open directions in OpenStreetMap</a>
      </div></div>
    <?php endif; ?>
  </div>

  <div class="col-lg-5">
    <!-- action panel -->
    <div class="card mb-3">
      <div class="card-header"><i class="bi bi-lightning me-2" style="color:var(--pnv-amber)"></i>Actions</div>
      <div class="card-body p-4">
        <?php if ($st === 'ASSIGNED'): ?>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="accept">
            <p class="small text-muted">Accept this assignment to start the collection workflow.</p>
            <button class="btn btn-pnv w-100 py-2"><i class="bi bi-hand-thumbs-up me-1"></i>Accept Pickup</button></form>
        <?php elseif ($st === 'ACCEPTED'): ?>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="start">
            <p class="small text-muted">Leaving for the pickup location? Notify the citizen.</p>
            <button class="btn btn-pnv w-100 py-2"><i class="bi bi-play-fill me-1"></i>Start Journey (On the way)</button></form>
        <?php elseif ($st === 'ON_THE_WAY'): ?>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="arrive">
            <p class="small text-muted">Mark arrival when you reach the pickup point.</p>
            <button class="btn btn-pnv w-100 py-2"><i class="bi bi-geo me-1"></i>Mark Arrived</button></form>
        <?php elseif ($st === 'ARRIVED'): ?>
          <form method="post" enctype="multipart/form-data"><?= csrf_field() ?><input type="hidden" name="action" value="collect">
            <p class="small text-muted">Verify the waste, weigh it and record the collection.</p>
            <div class="mb-3">
              <label class="form-label fw-semibold small">Actual weight (kg) <span class="required-asterisk" aria-hidden="true">*</span></label>
              <input type="number" step="0.05" min="0.05" max="5000" class="form-control" name="actual_weight"
                     value="<?= e($a['estimated_weight']) ?>" required>
            </div>
            <div class="mb-3">
              <label class="form-label fw-semibold small">Proof photo</label>
              <input type="file" class="form-control" name="proof_image" accept="image/*">
              <div class="form-text">Maximum file size: 5 MB · Supported formats: JPG, PNG, WebP</div>
            </div>
            <div class="mb-3">
              <label class="form-label fw-semibold small">Remarks</label>
              <input class="form-control" name="remarks" maxlength="300" placeholder="e.g. clean segregated stream">
            </div>
            <button class="btn btn-pnv w-100 py-2"><i class="bi bi-truck me-1"></i>Record Collection</button>
          </form>
        <?php elseif ($st === 'COLLECTED'): ?>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="complete">
            <div class="alert alert-success small">
              <i class="bi bi-passport me-1"></i>Collected weight <strong><?= fmt_kg($a['actual_weight']) ?></strong>.
              Completing will <strong>generate the unique Waste ID & Waste Passport</strong> and notify the citizen.
            </div>
            <button class="btn btn-pnv w-100 py-2"><i class="bi bi-check2-circle me-1"></i>Complete Pickup & Issue Waste ID</button>
          </form>
        <?php elseif ($st === 'COMPLETED'): ?>
          <div class="alert alert-success mb-0"><i class="bi bi-check2-circle me-1"></i>Pickup completed.
            <?php $tx = Database::one('SELECT waste_id FROM waste_transactions WHERE pickup_request_id = ?', [$a['pickup_request_id']]);
            if ($tx): ?>Waste ID: <code><?= e($tx['waste_id']) ?></code><?php endif; ?></div>
        <?php else: ?>
          <div class="alert alert-secondary mb-0">This assignment is <?= e(strtolower($st)) ?> — no actions available.</div>
        <?php endif; ?>
      </div>
    </div>

    <?php if (!empty($a['recycling_guidance']) || true): ?>
    <div class="card mb-3">
      <div class="card-header">Category guidance</div>
      <div class="card-body small">
        <strong><span class="dot" style="background:<?= e($a['color']) ?>"></span><?= e($a['category_name']) ?></strong> → <?= e($a['bin_type']) ?>
        <div class="text-muted mt-1"><?= e($a['recycling_guidance']) ?></div>
      </div>
    </div>
    <?php endif; ?>

    <!-- status log -->
    <div class="card">
      <div class="card-header">Assignment log</div>
      <div class="card-body">
        <div class="journey">
          <?php foreach ([['assigned_at','Assigned to you'],['accepted_at','Accepted'],['started_at','Journey started'],
                          ['arrived_at','Arrived'],['collected_at','Collected'],['completed_at','Completed']] as [$col,$label]):
            if (empty($a[$col])) continue; ?>
            <div class="journey-item done">
              <span class="j-icon" style="width:30px;height:30px"><i class="bi bi-check"></i></span>
              <span class="j-title" style="font-size:.9rem"><?= e($label) ?></span>
              <div class="j-time"><?= fmt_dt($a[$col]) ?></div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $pageScripts = $a['latitude'] ? '<script>pnvMap("navMap", { center: [' . json_encode((float) $a['latitude']) . ',' . json_encode((float) $a['longitude']) . '], zoom: 15, markers: [{ lat: ' . json_encode((float) $a['latitude']) . ', lng: ' . json_encode((float) $a['longitude']) . ', title: ' . json_encode($a['pickup_code']) . ', color: "green", glyph: "bi-geo-alt-fill" }] });</script>' : '';
require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
