<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_COLLECTOR);
$pageTitle = 'Collection History'; $activeMenu = 'history';

$q = trim((string) get_val('q', ''));
$from = (string) get_val('from', '');
$where = 'pa.collector_id = ? AND pa.status = "COMPLETED"';
$params = [$user['id']];
if ($q !== '') { $where .= ' AND pr.pickup_code LIKE ?'; $params[] = "%$q%"; }
if ($from !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) { $where .= ' AND pa.completed_at >= ?'; $params[] = $from . ' 00:00:00'; }

$total = (int) Database::val("SELECT COUNT(*) FROM pickup_assignments pa JOIN pickup_requests pr ON pr.id = pa.pickup_request_id WHERE $where", $params);
$pg = paginate_request($total);
$rows = Database::all(
    "SELECT pa.*, COALESCE(pa.completed_at, pa.collected_at, pa.updated_at) AS completed_disp, pr.pickup_code, pr.address_line, wc.name AS category_name, wc.color, wt.waste_id
     FROM pickup_assignments pa
     JOIN pickup_requests pr ON pr.id = pa.pickup_request_id
     JOIN waste_categories wc ON wc.id = pr.category_id
     LEFT JOIN waste_transactions wt ON wt.pickup_request_id = pr.id
     WHERE $where ORDER BY completed_disp DESC LIMIT {$pg['limit']} OFFSET {$pg['offset']}", $params);
$sumWeight = (float) (Database::val("SELECT COALESCE(SUM(actual_weight),0) FROM pickup_assignments WHERE collector_id = ? AND status = 'COMPLETED'", [$user['id']]));
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="row g-3 mb-3">
  <div class="col-md-4"><div class="kpi-card kpi-green p-3"><i class="bi bi-check2-circle kpi-icon"></i>
    <div class="kpi-value"><?= fmt_num($total) ?></div><div class="kpi-label">COMPLETED COLLECTIONS</div></div></div>
  <div class="col-md-4"><div class="kpi-card kpi-teal p-3"><i class="bi bi-scale kpi-icon"></i>
    <div class="kpi-value"><?= fmt_kg($sumWeight) ?></div><div class="kpi-label">LIFETIME WEIGHT COLLECTED</div></div></div>
  <div class="col-md-4"><div class="kpi-card kpi-blue p-3"><i class="bi bi-passport kpi-icon"></i>
    <div class="kpi-value"><?= fmt_num((int) Database::val('SELECT COUNT(*) FROM waste_transactions wt JOIN pickup_assignments pa ON pa.pickup_request_id = wt.pickup_request_id WHERE pa.collector_id = ?', [$user['id']])) ?></div>
    <div class="kpi-label">WASTE PASSPORTS ISSUED</div></div></div>
</div>
<div class="card">
  <div class="card-header"><i class="text-pnv bi bi-clock-history me-2"></i>Completed pickups</div>
  <div class="card-body">
    <form class="row g-2 mb-3">
      <div class="col-md-4"><input class="form-control form-control-sm" name="q" placeholder="Search pickup code…" value="<?= e($q) ?>"></div>
      <div class="col-md-3"><input type="date" class="form-control form-control-sm" name="from" value="<?= e($from) ?>"></div>
      <div class="col-md-4 d-flex gap-2"><button class="btn btn-sm btn-pnv px-3">Filter</button>
        <a class="btn btn-sm btn-outline-secondary" href="<?= url('collector/history.php') ?>">Reset</a></div>
    </form>
    <?php if (!$rows): ?>
      <div class="empty-state"><i class="bi bi-inbox"></i><div class="mt-2">No completed pickups found.</div></div>
    <?php else: ?>
      <div class="table-responsive"><table class="table table-hover align-middle">
        <thead><tr><th>Completed</th><th>Pickup</th><th>Category</th><th>Weight</th><th>Waste ID</th><th>Proof</th></tr></thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td class="small"><?= fmt_dt($r['completed_disp']) ?></td>
              <td class="fw-bold"><?= e($r['pickup_code']) ?><div class="small text-muted fw-normal"><?= e(mb_strimwidth($r['address_line'], 0, 40, '…')) ?></div></td>
              <td><span class="dot" style="background:<?= e($r['color']) ?>"></span><?= e($r['category_name']) ?></td>
              <td><?= fmt_kg($r['actual_weight']) ?></td>
              <td class="font-mono font-mono small"><?= e($r['waste_id'] ?? '—') ?></td>
              <td><?php if ($r['proof_image']): ?><a href="<?= e(upload_url($r['proof_image'])) ?>" target="_blank">
                <img alt="Collection proof photo" src="<?= e(upload_url($r['proof_image'])) ?>" style="height:36px" class="rounded border"></a><?php else: echo '—'; endif; ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody></table></div>
      <?= pagination_links($pg) ?>
    <?php endif; ?>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
