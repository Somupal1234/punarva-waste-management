<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_COLLECTOR);
$pageTitle = 'Suggested Route'; $activeMenu = 'route';
$today = date('Y-m-d');
$route = RouteService::suggestForCollector((int) $user['id'], $today);
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="alert alert-light border small">
  <i class="bi bi-info-circle me-1"></i><strong>Suggested Route</strong> is a rule-based MVP: it orders your open pickups
  with nearest-neighbour distance logic (starting from your facility), respecting pickup priority by slot.
  This is rule-based nearest-neighbour routing — an optimisation engine can be plugged in later.
</div>
<div class="row g-4">
  <div class="col-lg-8">
    <div class="card">
      <div class="card-header d-flex align-items-center">
        <i class="text-pnv bi bi-map me-2"></i>Route map — <?= fmt_dt($today, 'D, d M Y') ?>
        <span class="ms-auto badge text-bg-light border">total ≈ <?= e((string) $route['total_km']) ?> km</span>
      </div>
      <div class="card-body">
        <div id="routeMap" class="map-box" style="height:480px"></div>
      </div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card">
      <div class="card-header">Suggested order</div>
      <div class="card-body p-0">
        <?php if (!$route['stops']): ?>
          <div class="empty-state py-4"><i class="bi bi-signpost-split"></i><div>No open pickups for today.</div></div>
        <?php else: foreach ($route['stops'] as $i => $s): ?>
          <div class="notif-item d-flex gap-3 align-items-center">
            <span class="step-num"><?= $i + 1 ?></span>
            <div class="flex-grow-1">
              <div class="d-flex gap-2 align-items-center"><strong style="font-size:.9rem"><?= e($s['pickup_code']) ?></strong>
                <span class="badge text-bg-light border"><?= $s['leg_km'] ?> km</span></div>
              <div class="small text-muted"><?= e($s['time_slot']) ?> · <?= e(mb_strimwidth($s['address_line'], 0, 42, '…')) ?></div>
              <div class="small text-muted"><?= e($s['category_name']) ?> · <?= fmt_kg($s['estimated_weight']) ?> · <?= e(PICKUP_STATUS_LABELS[$s['status']]) ?></div>
            </div>
            <a class="btn btn-sm btn-soft" href="<?= url('collector/assignment-view.php?id=' . (int) $s['assignment_id']) ?>">Go</a>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
  </div>
</div>
<?php $markers = [];
foreach ($route['stops'] as $i => $s) {
    $markers[] = ['lat' => $s['latitude'], 'lng' => $s['longitude'],
        'title' => ($i + 1) . '. ' . $s['pickup_code'],
        'html' => e($s['address_line']), 'color' => 'green', 'glyph' => 'bi-geo-alt-fill'];
}
if (!empty($route['base'])) {
    array_unshift($markers, ['lat' => $route['base']['latitude'], 'lng' => $route['base']['longitude'],
        'title' => 'Your facility: ' . $route['base']['name'], 'color' => 'blue', 'glyph' => 'bi-buildings']);
}
$pageScripts = '<script>
const map = pnvMap("routeMap", { fitAll: true, zoom: 12, markers: ' . json_encode($markers) . ' });
pnvDrawRoute(map, ' . json_encode(array_map(fn($s) => ['latitude' => $s['latitude'], 'longitude' => $s['longitude']], $route['stops'])) . ');
</script>';
require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
