<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_COLLECTOR);
$pageTitle = 'Collector Dashboard'; $activeMenu = 'dash';
$today = date('Y-m-d');

$kpi = [
    'today'   => (int) Database::val('SELECT COUNT(*) FROM pickup_assignments pa JOIN pickup_requests pr ON pr.id = pa.pickup_request_id WHERE pa.collector_id = ? AND pr.preferred_date = ? AND pa.status IN ("ASSIGNED","ACCEPTED","ON_THE_WAY","ARRIVED")', [$user['id'], $today]),
    'pending' => (int) Database::val('SELECT COUNT(*) FROM pickup_assignments WHERE collector_id = ? AND status IN ("ASSIGNED","ACCEPTED","ON_THE_WAY","ARRIVED")', [$user['id']]),
    'collectedToday' => (int) Database::val('SELECT COUNT(*) FROM pickup_assignments WHERE collector_id = ? AND collected_at >= ?', [$user['id'], $today]),
    'weight'  => (float) (Database::val('SELECT COALESCE(SUM(actual_weight),0) FROM pickup_assignments WHERE collector_id = ? AND collected_at >= ?', [$user['id'], $today])),
];
// v2.4.0 — live truck tracking (browser Geolocation API, starts on PUNCH IN)
$tracking = TrackingService::driverStatus((int) $user['id']);
$route = RouteService::suggestForCollector((int) $user['id'], $today);
$activeList = Database::all(
    'SELECT pa.id AS assignment_id, pr.pickup_code, pr.preferred_date, pr.time_slot, pr.address_line, pr.ward,
            pr.status, wc.name AS category_name, wc.icon, wc.color, pr.estimated_weight, u.name AS citizen_name
     FROM pickup_assignments pa
     JOIN pickup_requests pr ON pr.id = pa.pickup_request_id
     JOIN waste_categories wc ON wc.id = pr.category_id
     JOIN users u ON u.id = pr.user_id
     WHERE pa.collector_id = ? AND pa.status IN ("ASSIGNED","ACCEPTED","ON_THE_WAY","ARRIVED")
     ORDER BY pr.preferred_date, pr.time_slot LIMIT 12', [$user['id']]);
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="row g-3 mb-4">
  <?php $cards = [
    ['kpi-blue','bi-calendar-day', fmt_num($kpi['today']), "TODAY'S PICKUPS", 'Scheduled for ' . fmt_dt($today, 'd M')],
    ['kpi-amber','bi-hourglass-split', fmt_num($kpi['pending']), 'PENDING TASKS', 'Assigned & in progress'],
    ['kpi-green','bi-check2-circle', fmt_num($kpi['collectedToday']), 'COLLECTED TODAY', 'Pickups completed'],
    ['kpi-teal','bi-scale', fmt_kg($kpi['weight']), 'WEIGHT COLLECTED TODAY', 'Verified weights'],
  ];
  foreach ($cards as [$c,$i,$v,$l,$s]): ?>
    <div class="col-6 col-lg-3"><div class="kpi-card <?= $c ?> p-3">
      <i class="bi <?= $i ?> kpi-icon"></i><div class="kpi-value"><?= $v ?></div><div class="kpi-label"><?= e($l) ?></div>
      <div class="small opacity-75 mt-1"><?= e($s) ?></div></div></div>
  <?php endforeach; ?>
</div>

<div class="card mb-4" id="trackCard" data-api="<?= e(url('api/driver/track.php')) ?>"
     data-initial="<?= e(json_encode($tracking)) ?>">
  <div class="card-header d-flex align-items-center flex-wrap gap-2">
    <i class="text-pnv bi bi-truck-front me-2"></i><strong>TRUCK TRACKING</strong>
    <span id="trackState" class="badge rounded-pill text-bg-secondary ms-1">NOT STARTED</span>
    <span id="trackNet" class="badge rounded-pill text-bg-warning d-none ms-auto">NETWORK OFFLINE</span>
  </div>
  <div class="card-body">
    <?php if (($tracking['schema_ready'] ?? true) === false): ?>
      <div class="alert alert-warning small mb-0"><i class="bi bi-database-gear me-1"></i>
        Live tracking needs a one-time database upgrade that could not be applied automatically.
        Please ask the administrator to run <code>database/upgrade-v2.4.0.sql</code>. Everything else on this page works normally.</div>
    <?php elseif (!$tracking['vehicle']): ?>
      <div class="alert alert-light border small mb-2"><i class="bi bi-info-circle me-1"></i>
        No truck is assigned to your account yet. Tracking unlocks after the admin assigns a vehicle.</div>
    <?php else: ?>
    <div class="row g-3 align-items-stretch">
      <div class="col-md-7">
        <dl class="row mb-0 small">
          <dt class="col-5">Truck</dt><dd class="col-7 fw-semibold" id="trackVehicle"><?= e($tracking['vehicle']['number']) ?></dd>
          <dt class="col-5">Driver</dt><dd class="col-7" id="trackDriver"><?= e($tracking['driver_name'] ?: $user['name']) ?></dd>
          <dt class="col-5">Shift start</dt><dd class="col-7" id="trackShift">—</dd>
          <dt class="col-5">GPS accuracy</dt><dd class="col-7" id="trackAcc">—</dd>
          <dt class="col-5">Last updated</dt><dd class="col-7" id="trackUpdated">—</dd>
        </dl>
        <div id="trackMsg" class="small text-danger d-none mt-2"></div>
      </div>
      <div class="col-md-5 d-flex flex-column justify-content-end">
        <?php if ($tracking['shift']): ?>
          <button class="btn btn-danger w-100 py-2" id="btnPunch" data-mode="out">
            <i class="bi bi-box-arrow-right me-1"></i>PUNCH OUT</button>
        <?php else: ?>
          <button class="btn btn-pnv w-100 py-2" id="btnPunch" data-mode="in">
            <i class="bi bi-geo-alt me-1"></i>PUNCH IN</button>
        <?php endif; ?>
        <div class="form-text mt-2 mb-0">Tracking uses this phone's location only while your shift is active. Keep this page open while on duty.</div>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>

<div class="row g-4">
  <div class="col-lg-7">
    <div class="card mb-3">
      <div class="card-header d-flex align-items-center">
        <i class="text-pnv bi bi-list-check me-2"></i>Active assignments
        <a class="btn btn-sm btn-soft ms-auto" href="<?= url('collector/assignments.php') ?>">Manage all</a>
      </div>
      <div class="card-body p-0">
        <?php if (!$activeList): ?>
          <div class="empty-state py-4"><i class="bi bi-inbox"></i><div>No active assignments — you're all caught up!</div></div>
        <?php else: foreach ($activeList as $a): ?>
          <div class="notif-item d-flex gap-3 align-items-center">
            <?= pnv_cat_badge($a['icon'], $a['color'], 38) ?>
            <div class="flex-grow-1">
              <div class="d-flex flex-wrap gap-2 align-items-center">
                <strong><?= e($a['pickup_code']) ?></strong><?= pickup_badge($a['status']) ?>
              </div>
              <div class="small text-muted">
                <?= e($a['category_name']) ?> · <?= fmt_kg($a['estimated_weight']) ?> ·
                <i class="bi bi-calendar3"></i> <?= fmt_dt($a['preferred_date'], 'd M') ?> <?= e($a['time_slot']) ?> ·
                <i class="bi bi-geo-alt"></i> <?= e(mb_strimwidth($a['address_line'], 0, 44, '…')) ?>
              </div>
            </div>
            <a class="btn btn-sm btn-pnv" href="<?= url('collector/assignment-view.php?id=' . (int) $a['assignment_id']) ?>">Open</a>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="card mb-3">
      <div class="card-header d-flex align-items-center">
        <i class="text-pnv bi bi-signpost-split me-2"></i>Suggested Route (today)
        <a class="btn btn-sm btn-soft ms-auto" href="<?= url('collector/route.php') ?>">Open map</a>
      </div>
      <div class="card-body">
        <?php if (!$route['stops']): ?>
          <div class="empty-state py-3"><i class="bi bi-map"></i><div>No routed stops today.</div></div>
        <?php else: ?>
          <div class="small text-muted mb-2">Nearest-neighbour order · total ≈ <strong><?= $route['total_km'] ?> km</strong>
            <span class="badge text-bg-light border ms-1">rule-based</span></div>
          <?php foreach (array_slice($route['stops'], 0, 5) as $i => $s): ?>
            <div class="d-flex align-items-center gap-2 py-1 border-bottom">
              <span class="step-num" style="width:26px;height:26px;font-size:.8rem"><?= $i + 1 ?></span>
              <div class="small flex-grow-1"><?= e($s['pickup_code']) ?> <span class="text-muted">· <?= e(mb_strimwidth($s['address_line'], 0, 32, '…')) ?></span></div>
              <span class="badge text-bg-light border"><?= $s['leg_km'] ?> km</span>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
    <div class="panel-dark card">
      <div class="card-body p-4">
        <h6 class="fw-bold"><i class="bi bi-shield-check me-2"></i>Collection protocol</h6>
        <ul class="small opacity-75 mb-0 ps-3">
          <li>Verify the waste matches the requested category</li>
          <li>Enter the <strong>actual weight</strong> on the weighing scale</li>
          <li>Attach a proof photo of the collected load</li>
          <li>Completing a pickup auto-issues the Waste Passport (unique Waste ID)</li>
        </ul>
      </div>
    </div>
  </div>
</div>

<script>
(function () {
  const card = document.getElementById('trackCard');
  if (!card) return;
  const api = card.dataset.api;
  const initial = JSON.parse(card.dataset.initial || '{}');
  const el = {
    state: document.getElementById('trackState'), vehicle: document.getElementById('trackVehicle'),
    driver: document.getElementById('trackDriver'), shift: document.getElementById('trackShift'),
    acc: document.getElementById('trackAcc'), updated: document.getElementById('trackUpdated'),
    msg: document.getElementById('trackMsg'), punch: document.getElementById('btnPunch'),
    net: document.getElementById('trackNet'),
  };
  let watchId = null, lastSent = null, lastSentAt = 0, lastFix = null, offline = false, weakCount = 0;

  function fmtAgo(iso) {
    if (!iso) return '—';
    const s = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
    if (s < 5) return 'just now';
    if (s < 60) return s + ' seconds ago';
    const m = Math.floor(s / 60);
    return m + (m === 1 ? ' minute ago' : ' minutes ago');
  }
  function setState(state, iso) {
    const map = { LIVE: ['text-bg-success', 'LIVE ●'], UPDATING: ['text-bg-warning', 'UPDATING ◐'], OFFLINE: ['text-bg-danger', 'OFFLINE'], 'NOT STARTED': ['text-bg-secondary', 'NOT STARTED'] };
    const [cls, label] = map[state] || map['NOT STARTED'];
    el.state.className = 'badge rounded-pill ms-1 ' + cls;
    el.state.textContent = label;
    if (iso) el.updated.textContent = fmtAgo(iso);
  }
  function render(d) {
    if (d.vehicle) el.vehicle.textContent = d.vehicle.number;
    if (d.driver_name) el.driver.textContent = d.driver_name;
    if (d.shift && d.shift.started_at) el.shift.textContent = new Date(d.shift.started_at.replace(' ', 'T')).toLocaleString();
    if (d.shift && d.shift.accuracy != null) el.acc.textContent = Math.round(d.shift.accuracy) + ' m';
    const st = d.shift ? d.shift.status : 'NOT STARTED';
    setState(st, d.shift && d.shift.last_ping_at ? d.shift.last_ping_at.replace(' ', 'T') : null);
    if (el.punch) el.punch.dataset.mode = d.shift ? 'out' : 'in';
    if (el.punch) el.punch.innerHTML = d.shift ? '<i class="bi bi-box-arrow-right me-1"></i>PUNCH OUT' : '<i class="bi bi-geo-alt me-1"></i>PUNCH IN';
  }
  function msg(t) { if (t === null) { el.msg.classList.add('d-none'); return; } el.msg.textContent = t; el.msg.classList.remove('d-none'); }

  async function post(payload) {
    const out = await pnvApi(api, { method: 'POST', body: payload });
    if (!out.success) throw new Error(out.message || 'Tracking request failed.');
    return out.data;
  }

  // ---- GPS send throttle: >=8s AND (moved >=10m OR >=25s) — battery & data friendly ----
  function movedEnough(a, b) {
    const R = 6371000, d = Math.PI / 180;
    const dLat = (b.lat - a.lat) * d, dLng = (b.lng - a.lng) * d;
    const x = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * d) * Math.cos(b.lat * d) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(x)));
  }
  function onFix(pos) {
    lastFix = pos;
    weakCount = 0;
    const c = { lat: pos.coords.latitude, lng: pos.coords.longitude };
    el.acc.textContent = pos.coords.accuracy != null ? Math.round(pos.coords.accuracy) + ' m' : '—';
    if (offline) return; // show local fix but do not spam; queued send resumes on 'online'
    const now = Date.now();
    if (lastSent) {
      const dt = (now - lastSentAt) / 1000;
      const moved = movedEnough(lastSent, c);
      if (dt < 8) return;
      if (moved < 10 && dt < 25) return;
    }
    lastSent = c; lastSentAt = now;
    post({ action: 'ping', lat: c.lat, lng: c.lng, accuracy: pos.coords.accuracy, speed: pos.coords.speed, heading: pos.coords.heading })
      .then((d) => { render(d); msg(null); })
      .catch((e) => { if (!offline) msg(e.message); });
  }
  function onGpsError(e) {
    const M = {
      1: 'Location permission is required to start vehicle tracking. Allow location access in your browser settings, then PUNCH IN again.',
      2: 'Location is currently unavailable. Please move to an open area.',
      3: 'GPS signal is weak/timed out. Please move to an open area and keep the screen on.',
    };
    msg(M[e.code] || 'Location could not be determined.');
    if (e.code === 1) { stopWatch(); }
  }
  function startWatch() {
    if (!('geolocation' in navigator)) { msg('Your browser does not support location services. Please use a modern Android/iPhone browser.'); return; }
    if (watchId !== null) return;
    msg(null);
    watchId = navigator.geolocation.watchPosition(onFix, onGpsError, { enableHighAccuracy: true, maximumAge: 5000, timeout: 20000 });
  }
  function stopWatch() {
    if (watchId !== null) { navigator.geolocation.clearWatch(watchId); watchId = null; }
  }

  // ---- punch in / out ----
  if (el.punch) el.punch.addEventListener('click', async function () {
    if (this.dataset.mode === 'out') {
      if (!window.confirm('End your shift now? Tracking will stop.')) return;
      this.disabled = true;
      try { stopWatch(); render(await post({ action: 'punch_out' })); msg(null); }
      catch (e) { msg(e.message); } finally { this.disabled = false; }
      return;
    }
    this.disabled = true;
    try {
      // ask permission FIRST (mobile Chrome gates it on the gesture); one soft retry on transient GPS errors
      if ('geolocation' in navigator) {
        const tryFix = () => new Promise((res, rej) => navigator.geolocation.getCurrentPosition(res, rej, { enableHighAccuracy: true, timeout: 15000 }));
        try { await tryFix(); }
        catch (g) {
          if (g && g.code === 1) throw g;
          await new Promise((r) => setTimeout(r, 1500));
          await tryFix(); // second failure propagates with its friendly message below
        }
      }
      render(await post({ action: 'punch_in' }));
      startWatch();
    } catch (e) {
      if (e && e.code === 1) msg('Location permission is required to start vehicle tracking.');
      else if (e && e.code) msg('GPS signal is currently weak. Please move to an open area and try again.');
      else msg(e.message || 'Could not punch in.');
    } finally { this.disabled = false; }
  });

  // ---- offline / online ----
  window.addEventListener('offline', () => { offline = true; el.net.classList.remove('d-none'); msg('Internet connection unavailable. Location updates will resume when connectivity returns.'); });
  window.addEventListener('online', async () => {
    offline = false; el.net.classList.add('d-none');
    msg('CONNECTION RESTORED — tracking resumed.');
    setTimeout(() => { if (!offline && el.msg.textContent.startsWith('CONNECTION RESTORED')) msg(null); }, 5000);
    if (watchId !== null) { // resume + flush one immediate fix
      try { const d = await post({ action: 'status' }); render(d); } catch (e) {}
      if (lastFix) onFix(lastFix);
    }
  });

  // safety retry: if the newest fix was skipped by the throttle (or GPS events stall),
  // give it another chance every 15s — negligible battery cost, no duplicate risk (same throttle)
  setInterval(() => { if (watchId !== null && !offline && lastFix) onFix(lastFix); }, 15000);

  // tick "last updated" + degrade state display when silent
  setInterval(() => {
    if (el.updated && el.updated.dataset && lastSentAt) {
      // local echo: server timestamps govern, but give the driver immediate feedback
    }
    if (el.punch && el.punch.dataset.mode === 'out' && lastSentAt) {
      const s = Math.round((Date.now() - lastSentAt) / 1000);
      el.updated.textContent = s < 5 ? 'just now' : (s < 60 ? s + ' seconds ago' : Math.floor(s / 60) + ' minutes ago');
    }
  }, 1000);

  // initial state + auto-resume watch if shift already active (page refresh mid-shift)
  render(initial);
  if (initial.shift) { if ('geolocation' in navigator) startWatch(); }
})();
</script>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
