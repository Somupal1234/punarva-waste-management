<?php
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_COLLECTOR);
$pageTitle = 'Assigned Pickups'; $activeMenu = 'assignments';

$status = (string) get_val('status', '');
$date   = (string) get_val('date', '');
$where  = 'pa.collector_id = ?';
$params = [$user['id']];
if ($status !== '' && in_array($status, PICKUP_STATUSES, true)) { $where .= ' AND pa.status = ?'; $params[] = $status; }
if ($date !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) { $where .= ' AND pr.preferred_date = ?'; $params[] = $date; }

$total = (int) Database::val("SELECT COUNT(*) FROM pickup_assignments pa JOIN pickup_requests pr ON pr.id = pa.pickup_request_id WHERE $where", $params);
$pg = paginate_request($total);
$rows = Database::all(
    "SELECT pa.id AS assignment_id, pa.status, pa.assigned_at, pa.actual_weight,
            pr.pickup_code, pr.preferred_date, pr.time_slot, pr.address_line, pr.ward, pr.estimated_weight,
            wc.name AS category_name, wc.color, wc.icon, u.name AS citizen_name
     FROM pickup_assignments pa
     JOIN pickup_requests pr ON pr.id = pa.pickup_request_id
     JOIN waste_categories wc ON wc.id = pr.category_id
     JOIN users u ON u.id = pr.user_id
     WHERE $where ORDER BY pr.preferred_date ASC, pr.time_slot ASC LIMIT {$pg['limit']} OFFSET {$pg['offset']}", $params);
require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="card">
  <div class="card-header d-flex align-items-center">
    <i class="text-pnv bi bi-list-check me-2"></i>Assigned Pickups <span class="badge text-bg-light border"><?= $total ?></span>
  </div>
  <div class="card-body">
    <form class="row g-2 mb-3">
      <div class="col-md-3">
        <select class="form-select form-select-sm" name="status">
          <option value="">All statuses</option>
          <?php foreach (PICKUP_STATUSES as $st): ?><option <?= $status === $st ? 'selected' : '' ?>><?= $st ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3"><input type="date" class="form-control form-control-sm" name="date" value="<?= e($date) ?>"></div>
      <div class="col-md-4 d-flex gap-2">
        <button class="btn btn-sm btn-pnv px-3">Filter</button>
        <a class="btn btn-sm btn-outline-secondary" href="<?= url('collector/assignments.php') ?>">Reset</a>
      </div>
    </form>
    <?php if (!$rows): ?>
      <div class="empty-state"><i class="bi bi-inbox"></i><div class="mt-2">No assignments match your filters.</div></div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead><tr><th>Pickup</th><th>Category</th><th>Scheduled</th><th>Address</th><th>Status</th><th>Weight</th><th></th></tr></thead>
          <tbody>
            <?php foreach ($rows as $r): ?>
              <tr>
                <td><div class="fw-bold"><?= e($r['pickup_code']) ?></div><div class="small text-muted">assigned <?= time_ago($r['assigned_at']) ?></div></td>
                <td><span class="dot" style="background:<?= e($r['color']) ?>"></span><?= e($r['category_name']) ?></td>
                <td class="small"><?= fmt_dt($r['preferred_date'], 'd M Y') ?><div class="text-muted"><?= e($r['time_slot']) ?></div></td>
                <td class="small" style="max-width:180px"><?= e(mb_strimwidth($r['address_line'], 0, 60, '…')) ?></td>
                <td><?= pickup_badge($r['status']) ?></td>
                <td class="small"><?= $r['actual_weight'] ? fmt_kg($r['actual_weight']) : 'est. ' . fmt_kg($r['estimated_weight']) ?></td>
                <td><a class="btn btn-sm btn-pnv" href="<?= url('collector/assignment-view.php?id=' . (int) $r['assignment_id']) ?>">Execute</a></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?= pagination_links($pg) ?>
    <?php endif; ?>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
