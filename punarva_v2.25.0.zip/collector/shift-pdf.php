<?php
/**
 * MY SHIFT PDF (collector, v2.11.1) — dedicated own-shift export endpoint.
 * v2.9.0's My PDF button pointed collectors at the admin/ URL; this gives the
 * collector role its own path while the shared service keeps the IDOR rule
 * (a collector can ONLY export their own shift) and the generator in one place.
 */
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/shift_filters.php';

// v2.19.0 — explicit auth guard: an unauthenticated hit now gets a clean 302 to the
// login page instead of a TypeError from passing null into the PDF service.
$user = current_user();
if (!$user) {
    flash('warning', 'Please sign in to download your shift report.');
    redirect('login.php');
}

ShiftPdfService::downloadFor($user, false, (int) get_val('id', 0));
