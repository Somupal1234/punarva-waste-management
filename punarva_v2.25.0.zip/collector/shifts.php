<?php
require_once dirname(__DIR__) . '/includes/init.php';
require_once dirname(__DIR__) . '/includes/shift_filters.php';
$user = require_role(ROLE_COLLECTOR);

// v2.9.0 — MY SHIFTS (Collector): own punch history only. No other driver's records,
// no admin-level filters — just a clean personal shift log with own-shift PDF export.
$pageTitle = 'My Shifts'; $activeMenu = 'myshifts';

$total = (int) Database::val('SELECT COUNT(*) FROM driver_shifts WHERE driver_user_id = ?', [$user['id']]);
$perPage = 20;
$page = max(1, (int) get_val('page', 1));
$offset = ($page - 1) * $perPage;

$rows = Database::all(
    'SELECT ds.*, v.vehicle_number
     FROM driver_shifts ds JOIN vehicles v ON v.id = ds.vehicle_id
     WHERE ds.driver_user_id = ?
     ORDER BY ds.started_at DESC, ds.id DESC
     LIMIT ' . $perPage . ' OFFSET ' . $offset,
    [$user['id']]
);
$lastPage = max(1, (int) ceil($total / $perPage));

require dirname(__DIR__) . '/views/layouts/dash_header.php';
?>
<div class="d-flex flex-wrap align-items-center gap-2 mb-3">
  <h1 class="h4 fw-bold mb-0 me-auto"><i class="text-pnv bi bi-clock-history me-2"></i>My Shifts</h1>
  <a class="btn btn-outline-secondary no-print" href="<?= e(url('collector/dashboard.php')) ?>"><i class="bi bi-arrow-left me-1"></i>Dashboard</a>
</div>

<div class="card">
  <div class="card-body">
    <div class="small text-muted mb-2">Showing <?= $total ? ($offset + 1) : 0 ?>–<?= min($offset + $perPage, $total) ?> of <strong><?= fmt_num($total) ?></strong> shifts</div>
    <div class="table-responsive">
      <table class="table table-sm table-hover align-middle mb-0">
        <thead><tr><th>Date</th><th>Truck</th><th>Punch In</th><th>Punch Out</th><th>Duration</th><th>Status</th><th>GPS</th><th class="text-end"></th></tr></thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td><?= e(shift_date($r['started_at'])) ?></td>
              <td><?= e($r['vehicle_number']) ?></td>
              <td><?= e(shift_time($r['started_at'])) ?></td>
              <td><?= e(shift_time($r['ended_at'])) ?></td>
              <td><?= e(shift_duration($r['started_at'], $r['ended_at'])) ?></td>
              <td><?= $r['status'] === 'ACTIVE' ? '<span class="badge text-bg-success">ACTIVE</span>' : '<span class="badge text-bg-secondary">ENDED</span>' ?></td>
              <td><?= shift_gps_badge($r) ?></td>
              <td class="text-end"><a class="btn btn-sm btn-outline-pnv" href="<?= e(url('collector/shift-pdf.php?id=' . (int) $r['id'])) ?>"><i class="bi bi-file-earmark-pdf me-1"></i>My PDF</a></td>
            </tr>
          <?php endforeach; if (!$rows): ?>
            <tr><td colspan="8" class="text-center text-muted py-4"><i class="bi bi-inbox me-1"></i>No shifts yet — punch in from the dashboard to start tracking.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php if ($lastPage > 1): ?>
      <nav class="mt-3"><ul class="pagination pagination-sm mb-0">
        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="?page=<?= $page - 1 ?>">Previous</a></li>
        <li class="page-item disabled"><span class="page-link"><?= $page ?> / <?= $lastPage ?></span></li>
        <li class="page-item <?= $page >= $lastPage ? 'disabled' : '' ?>"><a class="page-link" href="?page=<?= $page + 1 ?>">Next</a></li>
      </ul></nav>
    <?php endif; ?>
  </div>
</div>
<?php require dirname(__DIR__) . '/views/layouts/dash_footer.php'; ?>
