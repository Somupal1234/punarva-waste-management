<?php
require_once __DIR__ . '/includes/init.php';
$pageTitle = 'Track Waste';
$activeNav = 'track';

$wasteId = strtoupper(trim((string) get_val('id', '')));
$tx = null; $events = []; $impact = null; $found = false; $searched = $wasteId !== '';

// ---- Privacy & Public Access settings: ONLY safe fields are ever shown (server-enforced) ----
$P = fn(string $k, string $d = '1') => (string) setting($k, $d) === '1';
$pub = [
    'waste_id' => $P('show_waste_id'),
    'category' => $P('show_category'),
    'weight'   => $P('show_weight'),
    'status'   => $P('show_status'),
    'timeline' => $P('show_timeline'),
    'facility' => $P('show_facility'),
    'outcome'  => $P('show_outcome'),
    'impact'   => $P('show_impact'),
];
$trackingEnabled = $P('public_tracking_enabled');

if ($searched && !$trackingEnabled) {
    $tx = null; // handled by the disabled-notice below
} elseif ($searched) {
    $tx = WasteJourneyService::trackByWasteId($wasteId);
    if ($tx) {
        $found = true;
        $events = $pub['timeline'] ? WasteJourneyService::timeline((int) $tx['id']) : [];
        $impact = $pub['impact'] ? ImpactService::forTransaction((int) $tx['id']) : null;
        if (!$pub['facility']) { $tx['facility_name'] = null; foreach ($events as &$ev) $ev['facility_name'] = null; unset($ev); }
    }
}
view('layouts/public_header', compact('pageTitle', 'activeNav'));
?>
<section class="container py-5">
  <div class="text-center mb-4">
    <div class="section-eyebrow">Waste Passport · Public tracking</div>
    <h1 class="h2 fw-bold"><?= t('page.track') ?></h1>
    <p class="text-muted small mx-auto" style="max-width:560px">
      Enter a Waste ID (e.g. <code>PNV-2026-000001</code>) or scan the QR code printed on your collection receipt.
      Only safe, non-personal information is shown.</p>
  </div>

<?php if ((string) setting('public_tracking_enabled', '1') !== '1'): ?>
  <div class="alert alert-warning mx-auto" style="max-width:560px"><i class="bi bi-shield-lock me-1"></i>Public tracking is temporarily disabled by the administrator.</div>
<?php endif; ?>
  <form class="row g-2 justify-content-center mb-4" method="get">
    <div class="col-md-6 col-lg-5">
      <div class="input-group input-group-lg">
        <span class="input-group-text bg-white"><i class="bi bi-qr-code"></i></span>
        <input class="form-control text-uppercase" name="id" aria-label="Waste ID" placeholder="PNV-2026-000001" value="<?= e($wasteId) ?>">
        <button class="btn btn-pnv px-4">Track</button>
      </div>
    </div>
  </form>

  <?php if ($searched && !$found): ?>
    <div class="card mx-auto" style="max-width:520px">
      <div class="empty-state">
        <i class="bi bi-binoculars"></i>
        <h5 class="mt-2 fw-bold">Waste Passport not found</h5>
        <p class="small mb-0">No waste transaction exists with ID <code><?= e($wasteId) ?></code>.<br>
        Check the ID on your collection receipt or ask your collector.</p>
      </div>
    </div>
  <?php elseif ($found): ?>

    <div class="row g-4">
      <div class="col-lg-5">
        <div class="passport">
          <div class="passport-head">
            <div class="passport-stamp">
              <i class="bi <?= in_array($tx['final_outcome'], ['RECYCLED','RECOVERED','COMPOSTED','REUSED'], true) ? 'bi-patch-check-fill' : 'bi-hourglass-split' ?>"></i>
              <span><?= e(in_array($tx['final_outcome'], ['RECYCLED','RECOVERED','COMPOSTED','REUSED'], true) ? 'Verified' : 'In progress') ?></span>
            </div>
            <div class="passport-title">Waste Passport</div>
            <?php if ($pub['waste_id']): ?><div class="passport-waste-id mt-2"><?= e($tx['waste_id']) ?></div><?php else: ?><div class="small opacity-75">Passport ID hidden by the administrator</div><?php endif; ?>
            <?php if ($pub['status']): ?><div class="small mt-2 opacity-75">Issued <?= fmt_dt($tx['created_at'], 'd M Y') ?></div><?php endif; ?>
          </div>
          <div class="passport-body">
            <div class="passport-meta">
              <?php if ($pub['category']): ?><div><div class="meta-label">Category</div>
                <div class="meta-value"><span class="dot" style="background:<?= e($tx['category_color']) ?>"></span><?= e($tx['category_name']) ?></div></div><?php endif; ?>
              <div><div class="meta-label">Approx. Quantity</div><div class="meta-value"><?= $pub['weight'] ? fmt_kg($tx['current_weight']) : '—' ?></div></div>
              <?php if ($pub['status']): ?><div><div class="meta-label">Current Status</div><div class="meta-value"><?= waste_badge($tx['current_stage']) ?></div></div><?php endif; ?>
              <div><div class="meta-label">Origin</div><div class="meta-value"><?= $tx['source_type'] === 'BUSINESS' ? 'Business / Institution' : 'Citizen' ?> · <?= e($tx['ward'] ? 'Ward ' . $tx['ward'] : (string) setting('default_city', 'Dumka')) ?></div></div>
              <div><div class="meta-label">Handling Facility</div><div class="meta-value"><?= e($tx['facility_name'] ?? 'To be assigned') ?></div></div>
              <?php if ($pub['outcome']): ?><div><div class="meta-label">Final Outcome</div><div class="meta-value"><?= $tx['final_outcome'] ? waste_badge($tx['final_outcome']) : '—' ?></div></div><?php endif; ?>
            </div>
            <?php if ($impact): ?>
              <div class="alert alert-success small mt-3 mb-0">
                <strong><i class="bi bi-globe-americas me-1"></i>Estimated environmental impact</strong>
                <div class="row text-center mt-2 g-2">
                  <div class="col-4"><div class="fw-bold"><?= number_format((float) $impact['co2_saved_kg'], 2) ?> kg</div><div class="fs-tiny text-muted">CO₂e avoided</div></div>
                  <div class="col-4"><div class="fw-bold"><?= number_format((float) $impact['water_saved_l'], 0) ?> L</div><div class="fs-tiny text-muted">water saved</div></div>
                  <div class="col-4"><div class="fw-bold"><?= number_format((float) $impact['energy_saved_kwh'], 2) ?></div><div class="fs-tiny text-muted">kWh saved</div></div>
                </div>
                <div class="text-muted mt-2" style="font-size:.68rem">Estimated impact = quantity × configured factor (<?= e($impact['methodology_version']) ?>). Indicative values only.</div>
              </div>
            <?php endif; ?>
            <div class="d-flex align-items-center justify-content-between mt-3 flex-wrap gap-2">
              <div class="small text-muted">Scan the QR to open this<br>passport on any device.<br>
                <span class="badge text-bg-light border mt-1"><i class="bi bi-shield-lock me-1"></i>No personal data shown</span></div>
              <?php if ($pub['waste_id']): ?>
              <div class="text-center">
                <div class="qr-box" data-qr="<?= e(absolute_url('track.php?id=' . urlencode($tx['waste_id']))) ?>" data-size="120"></div>
                <button class="btn btn-sm btn-soft mt-2 no-print" onclick="window.print()"><i class="bi bi-printer me-1"></i>Print</button>
              </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-7">
        <div class="card h-100">
          <div class="card-header d-flex align-items-center">
            <i class="text-pnv bi bi-signpost-2 me-2"></i> JOURNEY TIMELINE
            <span class="ms-auto badge text-bg-light border"><?= count($events) ?> events</span>
          </div>
          <div class="card-body">
            <?php view('components/passport_timeline', ['events' => $events, 'tx' => $tx, 'public' => true, 'hideInternalNotes' => true]); ?>
            <?php if ($pub['timeline'] && $tx['latitude'] && $tx['longitude']): ?>
              <?php
              // v2.12.0 privacy: rounding happens SERVER-SIDE — exact coordinates are never
              // sent to the browser (spec: never hide sensitive data with JS/CSS only).
              $pubLat = round((float) $tx['latitude'], 3);
              $pubLng = round((float) $tx['longitude'], 3);
              ?>
              <div class="mt-3">
                <div class="small fw-bold text-muted mb-2"><i class="bi bi-map me-1"></i>ORIGIN AREA (approximate)</div>
                <div id="passportMap" class="map-box" style="height:240px"></div>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <?php if ($pub['timeline'] && $tx['latitude'] && $tx['longitude']): $pageScripts = '<script>
      // values already rounded server-side to ~110 m grid (exact coords never leave the server)
      const lat = ' . json_encode($pubLat) . ', lng = ' . json_encode($pubLng) . ';
      pnvMap("passportMap", { center: [lat, lng], zoom: 13, fitAll: true, markers: [
        { lat, lng, title: ' . json_encode("Origin area – " . ($tx["ward"] ? "Ward " . $tx["ward"] : "Patna")) . ', color: "amber", glyph: "bi-house" },
        ' . ($tx['facility_name'] ? '{ lat: null }' : '') . '
      ]});
    </script>'; endif; ?>

  <?php else: ?>
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="card">
          <div class="card-body p-4 text-center">
            <i class="text-pnv bi bi-passport fs-1"></i>
            <h5 class="fw-bold mt-2">What is a Waste Passport?</h5>
            <p class="text-muted small mb-0 mx-auto" style="max-width:540px">Every waste load collected through PUNARVA receives a unique ID.
              Its passport records each stage — collection, sorting, processing and the final recycling outcome —
              with timestamps and the responsible facility. Try the demo ID <code>PNV-2026-000001</code>.</p>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>
</section>
<?php view('layouts/public_footer', ['pageScripts' => $pageScripts ?? '']); ?>
