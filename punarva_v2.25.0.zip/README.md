# PUNARVA — From Waste to Worth

**Know your waste. Track its journey. Create impact.**

PUNARVA is a complete, production-style **PHP 8 + MySQL + Bootstrap 5** waste-management ecosystem that
connects **citizens, waste collectors, recycling facilities, businesses/institutions and the municipality**
into one traceable loop.

Its core USP is the **Waste Passport**: every collected load receives a unique Waste ID
(e.g. `PNV-2026-000001`) and a verifiable public journey — identified → collected → sorted → processed →
recycled / recovered / composted / reused — with QR tracking, estimated environmental impact and rewards.

---

## 1. Feature overview

| Area | What works (all database-driven, nothing hard-coded) |
|---|---|
| Auth & RBAC | **Dedicated role-tab login** (Admin / Citizen / Collector / Recycler / Business – role mismatch is rejected server-side), Register/Login/Logout, **Forgot/Reset password** (single-use hashed token, 60-min expiry, rate-limited), 5 roles, page + API + record-level (IDOR) authorization, login rate-limiting, audit logs |
| AI Waste Scanner | Upload/capture image → **optional real local AI vision** (separate PUNARVA-AI package: ONNX ViT INT8, CPU-only, ₹0, offline, no API key, photos never leave the server) → item/category/material/confidence/bin/advice → confirm or correct before reporting. Without the package the scanner honestly shows **Unavailable** and manual classification continues. Low confidence → honest manual-review flag. Global **5 MB max** on all image uploads |
| Pickup workflow | `REQUESTED → ASSIGNED → ACCEPTED → ON_THE_WAY → ARRIVED → COLLECTED → COMPLETED` (+ cancellation rules), manual & workload-based auto-assignment |
| Collector console | Today's pickups, Suggested Route (rule-based nearest-neighbour, Leaflet map), accept/start/arrive, actual weight + proof photo, completion |
| Live truck tracking (v2.4.0) | Driver **PUNCH IN/PUNCH OUT** → phone GPS (`watchPosition`, no external GPS API/hardware) streams location while on duty; battery-friendly throttling (skips when barely moved), per-shift history + cached current fix; states 🟢 LIVE / 🟡 UPDATING / 🔴 OFFLINE / ⚪ NOT STARTED (never "LIVE" without a fresh server fix); smooth animated truck marker with heading rotation on the admin **PUNARVA LIVE OPERATIONS** map + per-shift route polyline (authorized admins only) |
| Waste Passport | Unique `PNV-YYYY-NNNNNN` Waste ID, state-machine-validated stages, full journey timeline (time, place, actor, facility, quantity, notes, proof), premium passport UI + QR |
| Recycler console | Intake queue, receive at facility, `SORTED → PROCESSING → PROCESSED → final outcome`, weight tracking, facility & vehicles |
| Reports & hotspots | Citizen/guest waste reports with **in-browser camera capture** (getUserMedia + gallery fallback) and **USE MY LOCATION** GPS (accuracy + capture time stored), `SUBMITTED → VERIFIED → ASSIGNED → IN_PROGRESS → RESOLVED`, rule-based hotspot scoring (clearly labelled MVP); status-filtered report markers on the admin ops map |
| Rewards | Configurable rules, **idempotent** transactions (unique key prevents double awards), balance + history |
| Impact | `Estimated Impact = quantity × configured factor` (methodology versioned), CO₂e / water / energy / landfill-diverted, always labelled **Estimated** |
| Notifications | DB-backed, unread badge + modal, mark-as-read, admin announcements |
| Learning | Articles + quizzes with reward points, admin-managed |
| Business module | Organization profile, bulk (multi-row) pickups, passports, periodic summary (printable), impact |
| Admin console | Dashboard + analytics (Chart.js), users/categories/facilities/organizations/vehicles/reward-rules/impact-factors/articles/quizzes CRUD, pickup assignment, report management, live map with layer filters, hotspots, audit logs, settings |
| Maps | Leaflet + OpenStreetMap tiles; coordinates always stored in DB |
| QR | qrcode.js renders the public tracking URL (`track.php?id=PNV-…`) |
| Multilingual | English / हिन्दी / বাংলা selector (session + per-user preference) |
| Security | PDO prepared statements, `password_hash/verify`, CSRF on every POST + API, XSS escaping, secure session cookies (HttpOnly/SameSite), upload MIME+size validation with random names, PHP execution blocked in uploads, RBAC, ownership checks, audit trail |

---

## 2. Technology stack

- **PHP 8.1+** (tested on 8.4), **MySQL 5.7+ / MariaDB 10.4+**, **Apache** via **XAMPP**
- **Bootstrap 5**, **Bootstrap Icons**, **Chart.js 4**, **Leaflet 1.9**, **qrcode.js** — all vendored
  locally in `assets/vendor/` so the app works **fully offline** (map tiles need internet)
- No Node/React/frameworks — plain HTML5/CSS3/ES6 on the frontend

---

## 3. Installation on XAMPP (Windows)

1. **Install XAMPP** (Apache + MySQL) and start both modules from the XAMPP Control Panel.
2. **Copy the project** folder to:
   ```
   C:\xampp\htdocs\punarva
   ```
3. **Create the database** — open http://localhost/phpmyadmin → *Import* tab:
   - first import `database/schema.sql` (NOTE: this DROPS and recreates the `punarva_db` database — fresh installs only)
   - then import `database/seed.sql`
   - then import `database/settings_defaults.sql`
   - then import `database/migrations/002_create_schema_migrations.sql`, `003_add_ai_meta.sql`, `004_badges_game.sql`, `005_game_removal_badges.sql` in that order (001 is a marker only; 004+005 build the achievements system)
   
   *(or via command line:)*
   ```
   cd C:\xampp\mysql\bin
   mysql -u root -e "CREATE DATABASE IF NOT EXISTS punarva_db"
   mysql -u root punarva_db < C:\xampp\htdocs\punarva\database\schema.sql
   mysql -u root punarva_db < C:\xampp\htdocs\punarva\database\seed.sql
   mysql -u root punarva_db < C:\xampp\htdocs\punarva\database\settings_defaults.sql
   for %M in (002_create_schema_migrations 003_add_ai_meta 004_badges_game 005_game_removal_badges) do mysql -u root punarva_db < C:\xampp\htdocs\punarva\database\migrations\%M.sql
   ```
4. **Open the app**: http://localhost/punarva/

That's it — default XAMPP MySQL credentials (`root`, empty password) are pre-configured in
`config/config.php`.

> **mod_rewrite is NOT required.** All URLs are plain `.php` links.

### Demo accounts (demonstration only — password for all: `Punarva@123`)

The login page has **five dedicated tabs** (one per role) — the system verifies that the selected
tab matches the account's role, so a citizen account cannot sign in through the Admin tab.
**Forgot password?** works out of the box: on XAMPP (no mail server) the reset link is shown
directly on screen; in production it is emailed. Links are single-use and expire in 60 minutes.

| Role | Email |
|---|---|
| Admin / Municipality | `admin@punarva.demo` |
| Citizen | `citizen@punarva.demo` |
| Collector | `collector@punarva.demo` (also `collector2@punarva.demo`) |
| Recycler / Facility | `recycler@punarva.demo` (also `recycler2@punarva.demo`) |
| Business / Institution | `business@punarva.demo` |

Seed data includes 7 waste passports (`PNV-2026-000001` … `000007`), pickups across all workflow
stages, 6 waste reports, hotspot scores, impact records, rewards, articles and two quizzes —
so every dashboard is alive immediately. Track `PNV-2026-000001` publicly at
`http://localhost/punarva/track.php?id=PNV-2026-000001`.

---

## 4. The complete demo workflow (hackathon script)

1. **Citizen** logs in → **AI Waste Scanner** → upload any image → real AI vision analysis (item, category, material, confidence, bin, advice) → confirm or correct the category
2. **Request Pickup** → choose category, weight, date, slot, pin location on map
3. **Admin** → Pickup Requests → **Assign** a collector (or **Auto-assign**)
4. **Collector** → Dashboard → open assignment → **Accept → Start Journey → Mark Arrived**
5. Collector enters **actual weight** + proof photo → **Record Collection**
6. Collector presses **Complete Pickup** → system atomically generates the **Waste ID** (`PNV-2026-000008`…)
   and activates the **Waste Passport**
7. **Recycler** → Incoming Waste → **Receive** → stage it **Sorted → Processing → Processed → Recycled**
   (each step writes a journey event; final outcome auto-calculates **Estimated Impact** and credits **Reward points**)
8. **Citizen** → My Waste Passports → opens the passport → **QR code** → public tracking page
9. **Admin** → Dashboard/Analytics reflect every number live from the database

---

## 5. Folder structure

```
punarva/
├── index.php about.php how-it-works.php waste-guide.php learn.php article.php
├── track.php report.php login.php register.php logout.php 404.php 403.php 500.php
├── config/          config.php · database.php · constants.php
├── includes/        init.php · helpers.php · lang.php · admin_entities.php
├── services/        PickupService · WasteJourneyService · RewardService · ImpactService ·
│                    NotificationService · AIWasteScannerService · RouteService ·
│                    HotspotService · AuditService · AuthService
├── middleware/      AuthMiddleware · RoleMiddleware · CSRFMiddleware · OwnershipMiddleware
├── models/          (Repository pattern base for future extension)
├── repositories/
├── api/             auth/ citizen/ pickups/ collector/ waste/ recycler/ reports/
│                    rewards/ impact/ notifications/ admin/   (JSON: success/message/data/errors)
├── views/           layouts/ · components/ · auth/ · citizen/ · collector/ · recycler/ ·
│                    business/ · admin/
├── citizen/ collector/ recycler/ business/ admin/     (role dashboards)
├── assets/          css/ js/ images/ vendor/ (Bootstrap, Icons, Chart.js, Leaflet, qrcode — local)
├── lang/            en.php · hi.php · bn.php
├── uploads/         waste/ reports/ proofs/ profiles/  (PHP execution blocked via .htaccess)
├── database/        schema.sql · seed.sql
├── storage/logs/    application error log
└── .htaccess
```

---

## 6. Configuration

### Environment (.env) — v2.5.0
Copy **`.env.example`** → **`.env`** and fill real values (DB credentials, `APP_ENV=production`,
`APP_DEBUG=false`). Real environment variables always override `.env`. **No .env?** The app keeps
running with safe XAMPP dev defaults, so an existing install never breaks. `.env` is protected from
web access by `.htaccess` (Apache) and `router.php` (PHP built-in server); `.gitignore` keeps it out
of Git. **No AI/API keys exist and none are required** — the Waste Scanner is fully manual (v2.14.0+): users select the category themselves; external AI services are disabled by design.

### `config/config.php` (advanced overrides only)

| Setting | Default | Notes |
|---|---|---|
| `DB_HOST/PORT/NAME/USER/PASS` | `127.0.0.1 / 3306 / punarva_db / root / ""` | XAMPP defaults; environment variables `PUNARVA_DB_*` override |
| `APP_ENV` / `APP_DEBUG` | `local / true` | **set `APP_DEBUG=false` for production** (errors go to `storage/logs/`) |
| `MAP_*` | Patna centre, OSM tiles | any OpenStreetMap-compatible tile URL |
| `UPLOAD_MAX_BYTES` | 5 MB | **global image limit** — enforced client+server side on every photo upload (JPG/PNG/WebP) |
| `METHODOLOGY_VERSION` | `v1.0-estimate` | stamped on every impact record |

### AI scanner (v2.6.1 — optional local AI, ₹0, lightweight website)
The website package is **lightweight — the 87 MB AI model is NOT inside it** and is
never auto-downloaded. For real on-server AI, install the separate **PUNARVA-AI**
package (`inference_service.py` + `model/waste-vit-v1-int8.onnx` 86,931,422 B +
`requirements.txt`) outside the web root, e.g. `C:\punarva-ai\`.

- **₹0, offline, no API key, no GPU** — CPU-only onnxruntime; ~130–160 ms/image, ~268 MB RAM
- **Photos never leave the server**; the service binds to **127.0.0.1 only**
- Website honestly shows **"AI Scanner: Available"** (service healthy, real model) or
  **"AI Scanner: Unavailable"** (not installed/down) — **never a fake result, never a
  demo classifier, no silent fallback**
- Without AI: upload → **manual category selection → continue** — the full report/pickup workflow stays usable
- With AI: confidence on every result; <55% → manual-review flag; every result confirm/correct-able (`status=corrected` audited)
- Optional cloud OpenAI-compatible setting stays **optional and off by default**


### Live tracking & citizen camera (v2.4.0)
- **No external GPS/API/hardware:** driver tracking uses only the browser Geolocation API
  (`watchPosition`); updates are throttled (min 8 s between pings, skipped if the truck moved
  < 10 m, plus a 15 s retry) so it is battery- and data-friendly. A safety cap of 600 points
  per shift keeps history bounded.
- **Admin ops map** (`admin/map.php`): unified **PUNARVA LIVE OPERATIONS** map — ☑ Active Trucks
  (10 s polling, animated interpolation so trucks glide, heading rotation only when reliable),
  ☑ Routes (per-shift polyline with shift start / latest position, admin-only API), ☑ Waste
  Reports (photo thumbnail + status filter All/Submitted/Verified/Assigned/In Progress/
  Resolved/Rejected), plus the existing facilities/pickups/waste layers.
- **Photo hardening:** every report photo is **re-encoded server-side** with GD before storage
  (strips EXIF and any embedded payloads; PNG/WebP are normalised to JPG). Uploads folder keeps
  its `.htaccess` script-execution block; randomized filenames; MIME + extension + size checks.
- **Upgrade:** run `database/upgrade-v2.4.0.sql` once on an existing v2.3.0+ database
  (idempotent — safe to re-run). It only ADDS: `vehicles.driver_user_id`, `driver_shifts`,
  `driver_locations`, `waste_reports.accuracy_m/location_captured_at`. Existing data untouched.

### CSV exports (v2.4.1 — free browser Blob/File API)
Admin → Analytics (facility + collector performance) and Admin → Waste Reports (the
currently filtered list) have **Download CSV** buttons. The file is generated **locally in
the browser** via `Blob` + `URL.createObjectURL` — no server export endpoint, works offline
once the page is loaded. Format is honest **`.csv`** (Excel-compatible, UTF-8 BOM) — it is
not an `.xlsx` file, and no XLSX generator is used.

### Live-tracking endpoint mapping (this build)
| Master-prompt name | Actual endpoint (existing architecture, no duplicates) |
|---|---|
| `api/collector/live-location.php` | `api/driver/track.php` (POST punch_in / punch_out / ping / status) |
| `api/collector/active-trucks.php` | `api/admin/tracking.php?action=active` |
| route history | `api/admin/tracking.php?action=route&shift_id=` |
| current-location table | `driver_shifts` (cached last fix) — history in `driver_locations` (600 pts/shift) |

### Map tiles — provider and usage policy (honest terms)
Maps use **OpenStreetMap tiles via Leaflet** with the required OSM attribution. The public
OSM tile server is a **shared, free service with a published usage policy and rate limits —
it is not unlimited and not guaranteed for heavy traffic**. The tile layer is configured in
one place (`config/config.php` → `MAP_TILE_URL` / `MAP_ATTRIBUTION`, passed to JS as
`PNV_TILE_URL`), so a self-hosted or alternative open tile provider can be swapped in later
**without touching application code**.

### HTTPS and browser permissions (production requirement)
Geolocation and camera are security-sensitive: browsers grant them only in **secure
contexts** (HTTPS, or `http://localhost` for local development). Deploy PUNARVA behind
HTTPS in production — permissions are never bypassed, and the app degrades with clear
messages when a browser withholds them.

### Browser location — honest accuracy expectations
Browser geolocation may combine **GPS, Wi-Fi, cellular and IP-based** sources; accuracy
varies. PUNARVA therefore stores and displays the **GPS accuracy (± m)**, handles weak
accuracy gracefully, and never promises centimetre-level precision. Browser **background**
tracking is also subject to battery optimization, tab/OS suspension and network loss —
tracking is continuous only while the driver keeps the dashboard page open; status states
(LIVE/UPDATING/OFFLINE) reflect reality instead of pretending otherwise.

### Image upload limits (global)
Every photo upload (scanner, report waste, pickup, collector proof, profile avatar) enforces
**5 MB maximum** (binary 5 × 1024 × 1024), client-side (instant rejection + inline
"Image size must be 5 MB or less.") **and** server-side (`handle_upload()` — size, extension,
finfo MIME sniff, getimagesize; oversized files are never saved or referenced in the DB).
Formats: JPG, PNG, WebP only. For XAMPP the bundled `.user.ini` / `.htaccess` raise PHP's
`upload_max_filesize`/`post_max_size` so the app-level 5 MB policy is the effective gate.

### Map setup
Uses OpenStreetMap tiles via Leaflet (vendored). Markers/coordinates are always loaded from the
database (facilities, reports, pickups, waste origins, hotspots).

### QR setup
Passport pages render a QR of `absolute_url(track.php?id=PNV-…)` using the vendored `qrcode.js` —
no external service needed.

---

## 7. Troubleshooting

### `collector/profile.php` → 404 "Not Found" (fixed in v2.4.4)
The sidebar "Account → Profile" link is role-relative on every dashboard, but the shared account
page only existed under `citizen/` and `business/`. v2.4.4 adds thin per-role wrappers —
`collector/profile.php`, `recycler/profile.php` and `admin/profile.php` — that reuse the one shared
implementation (no duplicated logic; collectors/recyclers/admins were already authorised there),
and the admin sidebar gets the same "Account → Profile" entry as every other role. Profile save
(name/phone/language/avatar), password change and verification all work for every role; the
collector test save verified end-to-end ("Profile updated." + DB row updated).

### `SQLSTATE[23000] … 1062 Duplicate entry '…' for key 'pickup_request_id'` on Complete Pickup (fixed in v2.4.3)
Clicking **Complete Pickup & Issue Waste ID** twice (double-click, retry after a hiccup, or a
pickup whose Waste Transaction already exists from an earlier partial run) used to surface a raw
duplicate-key error and leave the assignment stuck at COLLECTED. **v2.4.3 fixes this at the
source:** completion is now **idempotent** — a locking check finds the existing Waste Transaction,
skips re-creation, heals the stuck status to COMPLETED and shows the already-issued Waste ID.
Plus: every form now has a double-submit guard (buttons disable while submitting) and SQL errors
are never shown to users — they are logged server-side with a clean on-screen message instead.

### Collector login shows `SQLSTATE[42S22] ... Unknown column 'driver_user_id'` (fixed in v2.4.2)
This happened when the app code (v2.4.0+) ran against a database that predated the v2.4.0
tracking migration. **v2.4.2 fixes this at the root:** on boot the app verifies the tracking
schema and, if missing, applies the shipped idempotent migration `database/upgrade-v2.4.0.sql`
once automatically (and records `settings.db_schema_version`). Manual steps are no longer
required; you can still run that file by hand. If the database user has no DDL rights (rare),
the app degrades gracefully: the TRUCK TRACKING card shows a clear "database upgrade required"
note, tracking APIs answer with a clean message, and every other feature keeps working —
no SQL errors are ever shown to users (details go to `logs/`).

| Problem | Fix |
|---|---|
| "Database connection failed" | Start MySQL in XAMPP; import `schema.sql` + `seed.sql`; check credentials in `config/config.php` |
| Blank page / 500 | Check `storage/logs/app-YYYY-MM-DD.log`; set `APP_DEBUG=true` temporarily |
| CSS/JS not loading | Ensure the folder is named `punarva` inside `htdocs`; hard-refresh (Ctrl+F5) |
| Map tiles grey | Tile CDN needs internet; everything else works offline |
| Uploads fail | Ensure `uploads/` is writable; max size governed by `upload_max_filesize` in `php.ini` too |
| Login says "Too many attempts" | Wait 15 minutes or clear the `login_attempts` table |

---

## 8. Security notes
- Uploads: random server-generated filenames, finfo+getimagesize validation, 5 MB cap,
  GD re-encode for report photos, `uploads/.htaccess` blocks script execution + listing.
- Sessions: HttpOnly + SameSite cookies (Secure on HTTPS), idle timeout + hard cap,
  single-session registry for admin/collector, regeneration on login/privilege change.
- CSRF middleware on every state-changing request; rate-limited login; hashed single-use
  reset tokens; security event logging (LOGIN_SUCCESS/FAILED, PASSWORD_CHANGED, …).
- `database/`, `storage/`, dotfiles are web-denied (`.htaccess` + `router.php`).
- Migrations: `database/migrations/` with `schema_migrations` tracking — manual, backup-first
  (see migrations/README.md). The app never auto-destructs the database.

- All SQL uses **PDO prepared statements**; all output is escaped (`e()` / `htmlspecialchars`).
- **CSRF** tokens enforced on every state-changing request (forms and JSON APIs).
- Passwords hashed with `password_hash()` (bcrypt); login rate-limited per IP+email.
- Sessions: HttpOnly + SameSite=Lax cookies, regeneration on login, Secure flag under HTTPS.
- Uploads: MIME sniffing (finfo), extension allow-list, size and dimension checks, random filenames,
  and `uploads/.htaccess` disables PHP execution entirely.
- RBAC on **pages**, **APIs** and **record ownership** (citizens see only their pickups/passports,
  collectors only their assignments, recyclers only their facility's waste).
- Audit log records logins, assignments, stage changes, reward/impact changes, admin edits, settings.
- Never expose: password hashes, DB credentials, API keys, citizen private data (public tracking
  shows ward-level origin only, masked names, no contact info).

## 9. Production deployment notes

- Set `APP_DEBUG=false`, serve over **HTTPS**, use a dedicated DB user with least privilege
  (the app only needs `SELECT/INSERT/UPDATE/DELETE` on `punarva_db`).
- Move `storage/` and `config/config.local.php` outside the web root if possible; keep `uploads/.htaccess`.
- Schedule `HotspotService::recompute()` (e.g. cron hitting an admin-only endpoint) instead of on-request recompute for large datasets.
- Back up `uploads/` and the database regularly.

## 10. Future-ready architecture

The service layer is deliberately provider-based and extensible: real AI vision, SMS/WhatsApp
notification gateways, IoT bin telemetry, advanced route optimization (replacing the rule-based
Suggested Route), ML hotspot prediction, government/municipal API bridges and weighing-scale
integrations can be added without touching the core workflow.

---

**PUNARVA** — From Waste to Worth · Built with PHP · MySQL · Bootstrap 5 · Chart.js · Leaflet
