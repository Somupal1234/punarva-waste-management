<?php
require_once __DIR__ . '/includes/init.php';

// v2.7.0 hardening: logout ab CSRF-protected hai (token GET me YA POST confirm form se).
$t = (string) ($_GET['t'] ?? '');
if (!hash_equals(csrf_token(), $t) && !is_post()) {
    // bina token ke GET (stale link / forced request) -> chhota confirm page
    ?><!DOCTYPE html><html lang="<?= e(current_lang()) ?>"><head><meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Confirm logout · PUNARVA</title>
    <link rel="stylesheet" href="<?= url('assets/vendor/bootstrap/bootstrap.min.css') ?>">
    </head><body class="bg-light"><div class="container" style="max-width:420px;margin-top:12vh">
    <div class="card shadow-sm"><div class="card-body text-center p-4">
      <h1 class="h5 fw-bold mb-2">Log out of PUNARVA?</h1>
      <p class="text-muted small mb-4">For security, please confirm that you want to end this session.</p>
      <form method="post" action="<?= e(url('logout.php')) ?>">
        <?= csrf_field() ?>
        <button class="btn btn-danger w-100 mb-2">Yes, log me out</button>
        <a class="btn btn-outline-secondary w-100" href="<?= e(url('index.php')) ?>">Cancel</a>
      </form>
    </div></div></div></body></html><?php
    exit;
}

AuthService::logout();
session_start();
flash('success', 'You have been logged out securely. See you soon!');
redirect('login.php');
