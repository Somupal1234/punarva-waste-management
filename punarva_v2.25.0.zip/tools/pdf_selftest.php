<?php
/**
 * tools/pdf_selftest.php — v2.14.0 PDF diagnostic (ADMIN only, read-only).
 *
 * Why: if a downloaded shift PDF shows "Failed to load PDF document" in a viewer,
 * one of these is almost always the cause on the hosting machine:
 *   (a) a BOM (byte-order-mark) or stray whitespace before <?php in ANY .php file
 *       of the installed copy → bytes precede %PDF → viewer rejects the file,
 *   (b) a PHP warning/notice printed during PDF generation,
 *   (c) an extension missing on that server (mbstring/gd) → renderer fatal mid-output.
 *
 * ?action=scan  — scans every .php file of THIS installed copy for BOM/leading output
 *                 and lists required extensions. Safe: writes nothing.
 * ?action=pdf   — streams a tiny generated PDF (with the same byte-level checks the
 *                 real shift reports use). If this opens but shift PDFs do not, the
 *                 problem is data-dependent, not environmental.
 * Both actions print plain text / a PDF — nothing else.
 */
require_once dirname(__DIR__) . '/includes/init.php';
$user = require_role(ROLE_ADMIN);

$action = (string) get_val('action', 'scan');

if ($action === 'pdf') {
    require_once dirname(__DIR__) . '/vendor/tfpdf/font/unifont/ttfonts.php';
    require_once dirname(__DIR__) . '/vendor/tfpdf/tfpdf.php';
    $pdf = new tFPDF('P', 'pt', 'A4');
    $pdf->AddFont('DejaVu', '', 'DejaVuSans.ttf', true);   // same UTF-8 setup as the real shift reports
    $pdf->AddFont('DejaVu', 'B', 'DejaVuSans-Bold.ttf', true);
    $pdf->AddPage();
    $pdf->SetFont('DejaVu', 'B', 14);
    $pdf->Cell(0, 20, 'PUNARVA PDF self-test', 0, 1);
    $pdf->SetFont('DejaVu', '', 10);
    $pdf->Cell(0, 16, 'Generated: ' . date('Y-m-d H:i:s') . '  ·  PHP ' . PHP_VERSION, 0, 1);
    $pdf->Cell(0, 16, 'If this document opens, the PDF engine works on this server.', 0, 1);
    $bytes = $pdf->Output('S', 'selftest.pdf');
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="PUNARVA_PDF_selftest.pdf"');
    header('Content-Length: ' . strlen($bytes));
    header('X-Content-Type-Options: nosniff');
    echo $bytes;
    exit;
}

// ---- ?action=scan (default): environment + byte-level source scan ----
header('Content-Type: text/plain; charset=utf-8');
echo "PUNARVA PDF diagnostic — " . date('c') . "\n";
echo "PHP " . PHP_VERSION . " · " . PHP_OS_FAMILY . " · SAPI " . php_sapi_name() . "\n\n";

echo "[extensions]\n";
foreach (['mbstring', 'gd', 'curl', 'mysqli', 'pdo_mysql'] as $ext) {
    echo str_pad($ext, 12) . (extension_loaded($ext) ? 'OK' : '*** MISSING ***') . "\n";
}

echo "\n[output buffering]\n";
echo "output_buffering ini: " . (ini_get('output_buffering') ?: 'off') . "\n";
echo "zlib.output_compression: " . (ini_get('zlib.output_compression') ?: 'off') . "\n";
echo "headers_sent(): " . (headers_sent() ? 'YES (unexpected this early)' : 'no') . "\n";

echo "\n[PDF font files] (Unicode DejaVu — the files the Shift PDF needs)\n";
$fontDir = dirname(__DIR__) . '/vendor/tfpdf/font/unifont/';
foreach (['DejaVuSans.ttf', 'DejaVuSans-Bold.ttf'] as $ff) {
    $fp = $fontDir . $ff;
    if (!is_file($fp)) { echo str_pad($ff, 24) . "*** MISSING — re-copy vendor/tfpdf/font folder from the package ***\n"; continue; }
    $sz = (int) @filesize($fp);
    $magic = (string) @file_get_contents($fp, false, null, 0, 4);
    $magicOk = ($magic === "\x00\x01\x00\x00" || substr($magic, 0, 4) === 'true' || substr($magic, 0, 4) === 'OTTO');
    echo str_pad($ff, 24) . ($sz >= 100000 ? 'OK' : '*** TRUNCATED (' . $sz . ' bytes — re-copy the file) ***')
        . ' · ' . number_format((float) $sz) . ' bytes · header ' . ($magicOk ? 'OK (TrueType)' : '*** CORRUPT (' . bin2hex($magic) . ') ***') . "\n";
}

echo "\n[font cache poisoning check] (.mtx.php files must NOT carry a foreign absolute path)\n";
foreach (glob($fontDir . '*.mtx.php') ?: [] as $cf) {
    $c = (string) file_get_contents($cf);
    if (preg_match('/^\\$ttffile=\'(.*)\';/m', $c, $m2)) {
        $v = $m2[1];
        if ($v !== '' && (str_starts_with($v, '/') || preg_match('/^[A-Za-z]:\\\\/', $v))) {
            echo basename($cf) . ": *** POISONED — records foreign path: " . $v . " (update files from the v2.16.1+ package) ***\n";
        } else {
            echo basename($cf) . ": OK (no absolute path)\n";
        }
    } else {
        echo basename($cf) . ": OK (no ttffile line)\n";
    }
}
if (!glob($fontDir . '*.mtx.php')) echo "no .mtx.php caches (they regenerate on first PDF)\n";

echo "\n[source byte scan] (BOM / bytes before <?php — the #1 cause of broken PDF downloads)\n";
$issues = 0; $files = 0;
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(dirname(__DIR__), FilesystemIterator::SKIP_DOTS));
foreach ($it as $f) {
    $p = $f->getPathname();
    if ($f->isDir() || !str_ends_with($p, '.php')) continue;
    if (preg_match('#/(vendor|node_modules|uploads)/#', $p)) continue;
    $files++;
    $head = (string) file_get_contents($p, false, null, 0, 8);
    if (str_starts_with($head, "\xEF\xBB\xBF")) { echo "  BOM     $p\n"; $issues++; continue; }
    // flag whitespace/newlines BEFORE the opening PHP tag (real output-before-headers
    // risk); templates that legitimately begin with HTML markup are not a PDF risk
    if (preg_match('/^(\xEF\xBB\xBF)?[\s\r\n]+<\?/', $head)) {
        echo "  LEADWS  $p (whitespace before <?php)\n"; $issues++;
    }
}
echo "scanned $files PHP files → issues: $issues\n";
echo $issues === 0
    ? "\nRESULT: installed source is byte-clean. If shift PDFs still fail while the\nself-test PDF (?action=pdf) opens, the failure is data/render specific —\nsend the server log line starting with '[PUNARVA] shift PDF failed'.\n"
    : "\nRESULT: $issues file(s) can emit bytes BEFORE the PDF body — that corrupts downloads.\nRe-upload those files from the original package (byte-identical, no BOM).\n";
