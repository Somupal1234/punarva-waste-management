-- ============================================================
-- PUNARVA – Demo seed data (realistic, database-consistent)
-- All demo accounts use the password:  Punarva@123
-- DEMO CREDENTIALS ARE FOR DEMONSTRATION ONLY.
-- Import ONCE, AFTER schema.sql.
-- (Agar dobara fresh data chahiye: pehle schema.sql dobara import
--  karein, phir seed.sql – isse duplicate-entry error nahi aayega.)
-- ============================================================
USE punarva_db;

SET @pw = '$2y$12$iT1LsiLk/aK5Kefjz.HfWeVz7VmVTqZxQWuo4BFHdfrXTLxEZJBtm';

-- ---------- roles ----------
INSERT INTO roles (id, code, name, description) VALUES
(1,'admin','Administrator','Municipality / platform administrator with full management permissions'),
(2,'citizen','Citizen','Household user who scans, segregates and schedules pickups'),
(3,'collector','Waste Collector','Field crew executing pickup assignments'),
(4,'recycler','Recycler / Facility Operator','Operates sorting & processing facilities'),
(5,'business','Business / Institution','Bulk generators: offices, schools, restaurants, hospitals…');

-- ---------- permissions ----------
INSERT INTO permissions (id, code, name, module) VALUES
(1,'users.manage','Manage users & roles','users'),
(2,'pickups.manage','Assign & manage pickups','pickups'),
(3,'pickups.execute','Execute assigned pickups','pickups'),
(4,'waste.process','Process waste at facility','waste'),
(5,'waste.view','View waste passports','waste'),
(6,'reports.manage','Manage waste reports','reports'),
(7,'rewards.manage','Manage reward rules','rewards'),
(8,'impact.manage','Manage impact factors','impact'),
(9,'learning.manage','Manage learning content','learning'),
(10,'system.manage','Manage system settings & audit','system'),
(11,'pickup.create','Create pickup requests','pickups'),
(12,'map.view','View operational map','analytics');

INSERT INTO role_permissions (role_id, permission_id) VALUES
(1,1),(1,2),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,12),
(2,11),(2,5),(2,12),
(3,3),(3,5),
(4,4),(4,5),
(5,11),(5,5);

-- ---------- facilities ----------
INSERT INTO facilities (id, code, name, facility_type, address_line, city, ward, state, pincode, latitude, longitude, contact_person, phone, email, capacity_kg_day, status) VALUES
(1,'FAC-001','PUNARVA Material Recovery Facility – Station Road, Dumka','MRF','Station Road, near Dumka Railway Station','Dumka','Ward 12','Jharkhand','814101',24.2735000,87.2445000,'Sunita Verma','+91-9830011221','mrf.stationroad@punarva.demo',5000,'ACTIVE'),
(2,'FAC-002','PUNARVA Compost Hub – SkMU Road, Dumka','COMPOST','Sido Kanhu Murmu University Road, Dumka','Dumka','Ward 8','Jharkhand','814101',24.2645000,87.2430000,'Manoj Das','+91-9830022332','compost.skmuroad@punarva.demo',8000,'ACTIVE'),
(3,'FAC-003','E-Suraksha E-Waste Recycling – College Road, Dumka','E-WASTE','College Road, near Santhal Pargana College','Dumka','Ward 5','Jharkhand','814101',24.2705000,87.2510000,'Rakesh Prasad','+91-9830033443','esuraksha.collegeroad@punarva.demo',1500,'ACTIVE');

-- ---------- organizations ----------
INSERT INTO organizations (id, name, org_type, email, phone, address_line, city, status) VALUES
(1,'Santhal Kitchen Restaurant','RESTAURANT','business@punarva.demo','9800000005','Main Market Road, near Tower Chowk, Dumka','Dumka','ACTIVE'),
(2,'St. Joseph''s School, Dumka','SCHOOL','school@punarva.demo','9800000009','Church Road, Dumka','Dumka','ACTIVE');

-- ---------- users (password for ALL demo accounts: Punarva@123) ----------
INSERT INTO users (id, role_id, name, email, phone, password_hash, status, language, facility_id, organization_id, last_login_at, created_at) VALUES
(1,1,'Municipal Admin','admin@punarva.demo','9800000001',@pw,'ACTIVE','en',NULL,NULL,NOW() - INTERVAL 2 HOUR, NOW() - INTERVAL 90 DAY),
(2,2,'Aarav Sharma','citizen@punarva.demo','9800000002',@pw,'ACTIVE','en',NULL,NULL,NOW() - INTERVAL 3 HOUR, NOW() - INTERVAL 75 DAY),
(3,3,'Ravi Kumar','collector@punarva.demo','9800000003',@pw,'ACTIVE','en',1,NULL,NOW() - INTERVAL 1 HOUR, NOW() - INTERVAL 70 DAY),
(4,4,'Sunita Verma','recycler@punarva.demo','9800000004',@pw,'ACTIVE','en',1,NULL,NOW() - INTERVAL 5 HOUR, NOW() - INTERVAL 68 DAY),
(5,5,'Priya Singh','business@punarva.demo','9800000005',@pw,'ACTIVE','en',NULL,1,NOW() - INTERVAL 8 HOUR, NOW() - INTERVAL 60 DAY),
(6,3,'Deepak Yadav','collector2@punarva.demo','9800000006',@pw,'ACTIVE','en',1,NULL,NULL, NOW() - INTERVAL 65 DAY),
(7,2,'Neha Gupta','citizen2@punarva.demo','9800000007',@pw,'ACTIVE','hi',NULL,NULL,NOW() - INTERVAL 26 HOUR, NOW() - INTERVAL 55 DAY),
(8,4,'Manoj Das','recycler2@punarva.demo','9800000008',@pw,'ACTIVE','bn',2,NULL,NULL, NOW() - INTERVAL 50 DAY);
UPDATE users SET organization_id = 1 WHERE id = 5;

-- ---------- addresses ----------
INSERT INTO addresses (user_id, label, address_line, city, state, ward, latitude, longitude, is_default) VALUES
(2,'Home','Housing Board Colony, near Tower Chowk','Dumka','Jharkhand','Ward 18',24.2690000,87.2520000,1),
(2,'Parents','Santhal Pargana College Road, Dumka','Dumka','Jharkhand','Ward 5',24.2705000,87.2510000,0),
(7,'Home','Housing Board Colony, Main Market Road, Dumka','Dumka','Jharkhand','Ward 9',24.2660000,87.2490000,1),
(5,'Restaurant – Main Market Road, Dumka','School Road, near +2 High School, Dumka','Dumka','Jharkhand','Ward 9',24.2655000,87.2485000,1);

-- ---------- waste categories ----------
INSERT INTO waste_categories (id, code, name, description, bin_type, icon, color, is_recyclable, recycling_guidance, status) VALUES
(1,'WET_WASTE','Wet Waste','Food scraps, vegetable peels, cooked leftovers and other biodegradable kitchen waste.','Wet Waste (Green bin)','bi-egg-fried','#7cb342',1,'Compost at source where possible; never mix with plastics or paper.','ACTIVE'),
(2,'DRY_WASTE','Dry Waste','Clean and dry recyclables such as packaging, plastics, paper and metal.','Dry Waste (Blue bin)','bi-box2','#1976d2',1,'Keep clean and dry. Empty, rinse and flatten before disposal.','ACTIVE'),
(3,'PLASTIC','Plastic','PET bottles, containers, plastic packaging and household plastic items.','Dry Waste (Blue bin)','bi-cup-straw','#e91e63',1,'Empty and rinse. Caps and labels removed. Never burn plastic.','ACTIVE'),
(4,'PAPER','Paper','Newspapers, magazines, office paper and clean packaging paper.','Dry Waste (Blue bin)','bi-newspaper','#fbc02d',1,'Keep dry and tied; remove plastic windows and staples where possible.','ACTIVE'),
(5,'CARDBOARD','Cardboard','Corrugated boxes, cartons and cardboard packaging.','Dry Waste (Blue bin)','bi-box-seam','#bf8f30',1,'Flatten boxes and remove tape. Keep away from moisture.','ACTIVE'),
(6,'GLASS','Glass','Bottles, jars and other glass containers.','Dry Waste (Blue bin)','bi-cup','#26a69a',1,'Rinse and remove lids. Wrap broken glass before disposal.','ACTIVE'),
(7,'METAL','Metal','Aluminium cans, metal scraps and steel containers.','Dry Waste (Blue bin)','bi-nut-fill','#78909c',1,'Rinse and crush cans. Metal is infinitely recyclable.','ACTIVE'),
(8,'E_WASTE','E-Waste','Electronic devices, cables, batteries and appliances.','E-Waste (Authorised collector)','bi-cpu','#5e35b1',1,'Never bin with household waste. Hand to authorised e-waste recyclers only.','ACTIVE'),
(9,'TEXTILE','Textile','Clothes, fabrics, shoes and household textiles.','Dry Waste / Donate','bi-bag-heart-fill','#d81b60',1,'Donate wearable items; torn items become cleaning rags or downcycled fibre.','ACTIVE'),
(10,'ORGANIC','Organic / Garden Waste','Leaves, garden trimmings and plant matter.','Wet Waste (Green bin)','bi-tree','#558b2f',1,'Shred and compost; never burn garden waste.','ACTIVE'),
(11,'HAZARDOUS','Hazardous Waste','Batteries, medicines, paints, chemicals, tubelights and sharps.','Domestic Hazardous (Yellow bin)','bi-exclamation-triangle-fill','#e53935',0,'Hand over at hazardous waste collection drives or authorised points only.','ACTIVE'),
(12,'SANITARY','Sanitary Waste','Diapers, sanitary napkins and similar items.','Sanitary Waste (Red bag)','bi-bandaid-fill','#8d6e63',0,'Wrap securely and mark with a red dot; never mix with dry recyclables.','ACTIVE'),
(13,'MIXED','Mixed Waste','Mixed or contaminated waste that cannot be cleanly segregated.','Mixed Waste (Black bin)','bi-trash3-fill','#455a64',0,'Reduce mixed waste by segregating at source into the correct streams.','ACTIVE'),
(14,'OTHER','Other','Waste that does not fit any standard category.','Mixed Waste (Black bin)','bi-question-circle-fill','#90a4ae',0,'Describe the item when booking a pickup so the right crew is assigned.','ACTIVE'),
(15,'WOOD','Wood','Wood, timber, plywood and wooden furniture waste.','Dry Waste (Blue bin)','bi-tree-fill','#8d6e63',1,'Reuse usable timber where possible; untreated wood can be chipped for mulch or composting. Painted/laminated wood goes to dry waste.','ACTIVE');

-- ---------- impact factors (per kg, methodology v1.0-estimate) ----------
INSERT INTO impact_factors (category_id, co2_kg_per_kg, water_l_per_kg, energy_kwh_per_kg, landfill_diverted_pct, methodology_version, status) VALUES
(1,0.9000,0.0000,0.3000,95.00,'v1.0-estimate','ACTIVE'),
(2,0.7000,4.0000,1.8000,90.00,'v1.0-estimate','ACTIVE'),
(3,1.5000,6.0000,5.5000,100.00,'v1.0-estimate','ACTIVE'),
(4,0.9000,8.0000,2.7000,100.00,'v1.0-estimate','ACTIVE'),
(5,0.9000,8.0000,2.7000,100.00,'v1.0-estimate','ACTIVE'),
(6,0.3000,2.0000,1.2000,100.00,'v1.0-estimate','ACTIVE'),
(7,9.0000,15.0000,14.0000,100.00,'v1.0-estimate','ACTIVE'),
(8,1.3000,6.0000,3.0000,85.00,'v1.0-estimate','ACTIVE'),
(9,3.0000,30.0000,3.5000,95.00,'v1.0-estimate','ACTIVE'),
(10,0.9000,0.0000,0.3000,95.00,'v1.0-estimate','ACTIVE'),
(11,0.2000,0.5000,0.1000,30.00,'v1.0-estimate','ACTIVE'),
(12,0.1000,0.0000,0.0000,10.00,'v1.0-estimate','ACTIVE'),
(13,0.3000,0.5000,0.2000,20.00,'v1.0-estimate','ACTIVE'),
(14,0.2000,0.3000,0.1000,15.00,'v1.0-estimate','ACTIVE');

-- ---------- reward rules ----------
INSERT INTO reward_rules (id, code, name, description, action_type, points, status) VALUES
(1,'PICKUP_DONE','Pickup completed','Points for every completed doorstep pickup','pickup_completed',10,'ACTIVE'),
(2,'SEGREGATION_GOOD','Clean stream bonus','Waste arrived properly segregated in a recyclable stream','segregation_good',5,'ACTIVE'),
(3,'RECYCLE_DONE','Recycling journey complete','Your waste completed its journey: recycled / recovered / composted / reused','recycling_completed',25,'ACTIVE'),
(4,'QUIZ_PASS','Learning quiz passed','Passed a knowledge quiz in the learning center','quiz_completed',20,'ACTIVE'),
(5,'REPORT_VERIFIED','Verified waste report','Your community waste report was verified by the municipality','report_verified',15,'ACTIVE');

-- ---------- articles ----------
INSERT INTO articles (id, title, slug, topic, summary, content, status, author_id, views, created_at) VALUES
(1,'The 4-bin rule: segregate like a pro','the-4-bin-rule','Waste Segregation','Green, blue, red and yellow — how every household can hit 90% source segregation with four simple bins.','Segregation is the single most powerful action in waste management.\n\nGREEN (wet): food scraps, peels, leftovers. Compostable.\nBLUE (dry): clean plastics, paper, metal, glass. Recyclable.\nRED (sanitary): diapers and napkins, wrapped and marked.\nYELLOW (domestic hazardous): batteries, medicines, tubelights.\n\nTips:\n- Line bins with newspaper instead of plastic bags.\n- Empty and rinse containers before they go into the blue bin.\n- Keep the green bin away from liquids; drain soupy waste first.\n- A well-segregated dry bin is worth reward points in PUNARVA.','PUBLISHED',1,142, NOW() - INTERVAL 40 DAY),
(2,'Composting in Dumka homes: a 30-day guide','composting-in-dumka-homes','Composting','Turn kitchen waste into black gold on your balcony — even in a small flat.','You need: a container with a lid, dry leaves/sawdust, and a shady balcony corner.\n\n1. Layer: start with dry material.\n2. Add chopped kitchen waste daily.\n3. Cover with dry leaves to control smell.\n4. Stir every 3 days.\n5. In 30 days: dark, earthy compost.\n\nNever add: meat, dairy, oily food, or treated wood. Your compost feeds plants and keeps wet waste out of landfills.','PUBLISHED',1,98, NOW() - INTERVAL 35 DAY),
(3,'Plastic pollution: the problem with multilayer wrappers','plastic-mlp-problem','Plastic Pollution','Chips and candy wrappers are nearly impossible to recycle. Here is what you can do.','Multilayer plastics (MLP) fuse different materials, making separation uneconomical. Most end up in landfills or burnt.\n\nWhat helps:\n- Choose larger packs over many small wrappers.\n- Support brands with take-back programmes.\n- Return MLP to collection drives where they are co-processed in cement kilns.\n- PUNARVA routes MLP to mixed/co-processing streams, flagged on its Waste Passport.','PUBLISHED',1,76, NOW() - INTERVAL 28 DAY),
(4,'E-waste at home: the drawer full of old phones','ewaste-drawer-guide','E-Waste','Every drawer holds toxic value. How to safely clear your e-waste drawer.','Old phones, chargers, dead batteries: e-waste contains gold, copper — and lead, mercury, cadmium.\n\nRules:\n- Never bin batteries or devices with household waste.\n- Factory-reset devices and remove SIM/SD cards.\n- PUNARVA routes e-waste to authorised recyclers like E-Suraksha (College Road, Dumka).\n- Check the Waste Passport: your phone''s materials can actually be recovered.','PUBLISHED',1,64, NOW() - INTERVAL 22 DAY),
(5,'The circular economy, explained with a dosa plate','circular-economy-dosa','Circular Economy','Linear is buy-use-throw. Circular is borrow-repair-return. A tasty analogy.','A steel dosa plate passes through generations; a paper plate dies in minutes. The linear economy turns resources into waste; the circular economy keeps materials in play.\n\nPUNARVA closes the loop in waste: what leaves your kitchen as waste re-enters the economy as recycled material — and your Waste Passport proves it.','PUBLISHED',1,51, NOW() - INTERVAL 18 DAY),
(6,'Sustainable living: 10 swaps that actually matter','sustainable-living-swaps','Sustainable Living','Skip the bamboo cutlery debate — these ten changes move the needle.','1. Carry a water bottle and cloth bag.\n2. Refuse single-use cutlery.\n3. Buy concentrates/refills.\n4. Repair before replacing.\n5. Segregate at source (the PUNARVA way).\n6. Compost wet waste.\n7. Choose rechargeable batteries.\n8. Buy second-hand electronics.\n9. Donate textiles.\n10. Track your impact — measured waste improves.','PUBLISHED',1,89, NOW() - INTERVAL 12 DAY),
(7,'Responsible consumption: read the label','responsible-consumption-labels','Responsible Consumption','Recycling symbols, EPR marks and what they actually guarantee.','That triangle of arrows does not guarantee recycling — it identifies the material. Numbers 1 (PET) and 2 (HDPE) recycle well; 3 (PVC), 6 (PS) rarely.\n\nLook for EPR-registered brands, refills, and mono-material packaging. And when in doubt, scan the item with the PUNARVA AI Waste Scanner before disposal.','PUBLISHED',1,43, NOW() - INTERVAL 7 DAY),
(8,'How the Waste Passport keeps waste honest','waste-passport-explainer','Recycling','Traceability turns invisible disposal into accountable recycling. Here is the technology behind it.','Every collected load in PUNARVA gets a unique ID (PNV-YYYY-NNNNNN).\n\nJourney events record who collected, which facility received, when it was sorted, processed, and its final outcome — recycled, recovered, composted, reused, or residual disposal.\n\nQR codes open a public passport with the full timeline but zero personal data. Estimated environmental impact is calculated from configured factors, clearly labelled as an estimate.','PUBLISHED',1,117, NOW() - INTERVAL 3 DAY);

-- ---------- quizzes ----------
INSERT INTO quizzes (id, title, topic, description, reward_points, pass_score_pct, status) VALUES
(1,'Waste Segregation Basics','Waste Segregation','Test your segregation knowledge — 5 questions, pass with 60%.',20,60,'ACTIVE'),
(2,'Plastic Pollution Challenge','Plastic Pollution','How well do you know your plastics? 4 questions.',20,75,'ACTIVE');

INSERT INTO quiz_questions (quiz_id, question, options, correct_index) VALUES
(1,'Which bin does vegetable peel waste belong to?','["Green bin (wet waste)","Blue bin (dry waste)","Red bag (sanitary)","Yellow bin (hazardous)"]',0),
(1,'A rinsed PET water bottle should go to…','["Wet waste","Dry waste / plastic stream","Sanitary waste","Mixed waste"]',1),
(1,'What should you do with expired medicines?','["Flush them","Mix with wet waste","Return via hazardous waste collection","Burn them"]',2),
(1,'Used sanitary napkins should be…','["Mixed with dry recyclables","Wrapped and marked with a red dot","Composted","Thrown loose in the green bin"]',1),
(1,'Why is source segregation important?','["It looks tidy","It increases recycling value and prevents contamination","It reduces weight","It is only needed for businesses"]',1),
(2,'Which plastic code recycles the best?','["PVC (#3)","PS (#6)","PET (#1)","Mixed (#7)"]',2),
(2,'Multilayer (MLP) wrappers are…','["Easily recycled everywhere","Best composted","Hard to recycle; co-processed or landfilled","Made of paper"]',2),
(2,'Burning plastic in the open…','["Is a good disposal method","Releases toxic pollutants and is illegal","Makes it biodegradable","Saves recycling costs"]',1),
(2,'Best way to reduce plastic waste?','["Carry reusable bottles and bags","Rinse plastic more","Buy smaller packs","Use paper bags for wet items"]',0);

-- ---------- pickups (history) ----------
INSERT INTO pickup_requests (id, pickup_code, user_id, organization_id, category_id, estimated_weight, preferred_date, time_slot, address_line, ward, city, latitude, longitude, notes, status, created_at, updated_at) VALUES
(1,'PNVP-260712-A1B2C3',2,NULL,3,2.50, DATE_SUB(CURDATE(), INTERVAL 60 DAY),'09:00-12:00','Flat 302, Shanti Apartments, Rd No 4, Tower Chowk area','Ward 18','Dumka',24.2690000,87.2520000,'PET bottles collected over a month','COMPLETED', NOW() - INTERVAL 61 DAY, NOW() - INTERVAL 60 DAY),
(2,'PNVP-260728-D4E5F6',2,NULL,1,5.00, DATE_SUB(CURDATE(), INTERVAL 45 DAY),'06:00-09:00','Flat 302, Shanti Apartments, Rd No 4, Tower Chowk area','Ward 18','Dumka',24.2690000,87.2520000,'Kitchen wet waste for composting','COMPLETED', NOW() - INTERVAL 46 DAY, NOW() - INTERVAL 45 DAY),
(3,'PNVP-260812-G7H8I9',7,NULL,4,4.00, DATE_SUB(CURDATE(), INTERVAL 30 DAY),'09:00-12:00','Housing Board Colony, Main Market Road, Dumka','Ward 9','Dumka',24.2660000,87.2490000,'Old newspapers and magazines','COMPLETED', NOW() - INTERVAL 31 DAY, NOW() - INTERVAL 30 DAY),
(4,'PNVP-260817-J1K2L3',5,1,6,12.00, DATE_SUB(CURDATE(), INTERVAL 25 DAY),'18:00-20:00','School Road, near +2 High School, Dumka','Ward 9','Dumka',24.2655000,87.2485000,'Glass bottles from restaurant stock','COMPLETED', NOW() - INTERVAL 26 DAY, NOW() - INTERVAL 25 DAY),
(5,'PNVP-260822-M4N5O6',2,NULL,8,3.00, DATE_SUB(CURDATE(), INTERVAL 20 DAY),'12:00-15:00','Flat 302, Shanti Apartments, Rd No 4, Tower Chowk area','Ward 18','Dumka',24.2690000,87.2520000,'Old phone, charger, dead batteries','COMPLETED', NOW() - INTERVAL 21 DAY, NOW() - INTERVAL 20 DAY),
(6,'PNVP-260831-P7Q8R9',7,NULL,9,2.00, DATE_SUB(CURDATE(), INTERVAL 12 DAY),'09:00-12:00','Housing Board Colony, Main Market Road, Dumka','Ward 9','Dumka',24.2660000,87.2490000,'Bag of old clothes','COMPLETED', NOW() - INTERVAL 13 DAY, NOW() - INTERVAL 12 DAY),
(7,'PNVP-260906-S1T2U3',2,NULL,3,1.80, DATE_SUB(CURDATE(), INTERVAL 6 DAY),'06:00-09:00','Flat 302, Shanti Apartments, Rd No 4, Tower Chowk area','Ward 18','Dumka',24.2690000,87.2520000,'Plastic containers','COLLECTED', NOW() - INTERVAL 7 DAY, NOW() - INTERVAL 6 DAY),
(8,'PNVP-260910-V4W5X6',2,NULL,5,3.50, DATE_ADD(CURDATE(), INTERVAL 1 DAY),'09:00-12:00','Flat 302, Shanti Apartments, Rd No 4, Tower Chowk area','Ward 18','Dumka',24.2690000,87.2520000,'Flattened moving boxes','REQUESTED', NOW() - INTERVAL 6 HOUR, NOW() - INTERVAL 6 HOUR),
(9,'PNVP-260910-Y7Z8A9',7,NULL,2,2.20, DATE_ADD(CURDATE(), INTERVAL 1 DAY),'15:00-18:00','Housing Board Colony, Main Market Road, Dumka','Ward 9','Dumka',24.2660000,87.2490000,NULL,'ASSIGNED', NOW() - INTERVAL 10 HOUR, NOW() - INTERVAL 9 HOUR),
(10,'PNVP-260910-B1C2D3',5,1,1,15.00, DATE_ADD(CURDATE(), INTERVAL 1 DAY),'18:00-20:00','School Road, near +2 High School, Dumka','Ward 9','Dumka',24.2655000,87.2485000,'Kitchen wet waste from restaurant','ACCEPTED', NOW() - INTERVAL 12 HOUR, NOW() - INTERVAL 8 HOUR),
(11,'PNVP-260901-E4F5G6',2,NULL,13,1.00, DATE_SUB(CURDATE(), INTERVAL 10 DAY),'12:00-15:00','College Road Colony, Block C','Ward 5','Dumka',24.2705000,87.2510000,NULL,'CANCELLED', NOW() - INTERVAL 11 DAY, NOW() - INTERVAL 10 DAY),
(12,'PNVP-260911-H7I8J9',7,NULL,4,2.00, CURDATE(),'06:00-09:00','Housing Board Colony, Main Market Road, Dumka','Ward 9','Dumka',24.2660000,87.2490000,'Cardboard + paper mix','ON_THE_WAY', NOW() - INTERVAL 1 DAY, NOW() - INTERVAL 40 MINUTE);

-- ---------- assignments ----------
INSERT INTO pickup_assignments (id, pickup_request_id, collector_id, status, assigned_by, assigned_at, accepted_at, started_at, arrived_at, collected_at, completed_at, actual_weight, remarks) VALUES
(1,1,3,'COMPLETED',1, NOW() - INTERVAL 61 DAY + INTERVAL 3 HOUR, NOW() - INTERVAL 61 DAY + INTERVAL 4 HOUR, NOW() - INTERVAL 60 DAY + INTERVAL 1 HOUR, NOW() - INTERVAL 60 DAY + INTERVAL 2 HOUR, NOW() - INTERVAL 60 DAY + INTERVAL 2 HOUR + INTERVAL 10 MINUTE, NOW() - INTERVAL 60 DAY + INTERVAL 2 HOUR + INTERVAL 15 MINUTE, 2.40,'Clean PET stream'),
(2,2,3,'COMPLETED',1, NOW() - INTERVAL 46 DAY + INTERVAL 2 HOUR, NOW() - INTERVAL 46 DAY + INTERVAL 3 HOUR, NOW() - INTERVAL 45 DAY + INTERVAL 30 MINUTE, NOW() - INTERVAL 45 DAY + INTERVAL 1 HOUR, NOW() - INTERVAL 45 DAY + INTERVAL 1 HOUR + INTERVAL 15 MINUTE, NOW() - INTERVAL 45 DAY + INTERVAL 1 HOUR + INTERVAL 20 MINUTE, 5.20,'Well-drained wet waste'),
(3,3,6,'COMPLETED',1, NOW() - INTERVAL 31 DAY + INTERVAL 4 HOUR, NOW() - INTERVAL 31 DAY + INTERVAL 5 HOUR, NOW() - INTERVAL 30 DAY + INTERVAL 1 HOUR, NOW() - INTERVAL 30 DAY + INTERVAL 2 HOUR, NOW() - INTERVAL 30 DAY + INTERVAL 2 HOUR + INTERVAL 5 MINUTE, NOW() - INTERVAL 30 DAY + INTERVAL 2 HOUR + INTERVAL 10 MINUTE, 4.10,'Dry paper bundle'),
(4,4,6,'COMPLETED',1, NOW() - INTERVAL 26 DAY + INTERVAL 3 HOUR, NOW() - INTERVAL 26 DAY + INTERVAL 3 HOUR + INTERVAL 30 MINUTE, NOW() - INTERVAL 25 DAY + INTERVAL 1 HOUR, NOW() - INTERVAL 25 DAY + INTERVAL 2 HOUR, NOW() - INTERVAL 25 DAY + INTERVAL 2 HOUR + INTERVAL 20 MINUTE, NOW() - INTERVAL 25 DAY + INTERVAL 2 HOUR + INTERVAL 25 MINUTE, 11.80,'Glass crates'),
(5,5,3,'COMPLETED',1, NOW() - INTERVAL 21 DAY + INTERVAL 2 HOUR, NOW() - INTERVAL 21 DAY + INTERVAL 2 HOUR + INTERVAL 30 MINUTE, NOW() - INTERVAL 20 DAY + INTERVAL 30 MINUTE, NOW() - INTERVAL 20 DAY + INTERVAL 1 HOUR, NOW() - INTERVAL 20 DAY + INTERVAL 1 HOUR + INTERVAL 10 MINUTE, NOW() - INTERVAL 20 DAY + INTERVAL 1 HOUR + INTERVAL 15 MINUTE, 3.00,'E-waste boxed'),
(6,6,6,'COMPLETED',1, NOW() - INTERVAL 13 DAY + INTERVAL 3 HOUR, NOW() - INTERVAL 13 DAY + INTERVAL 4 HOUR, NOW() - INTERVAL 12 DAY + INTERVAL 1 HOUR, NOW() - INTERVAL 12 DAY + INTERVAL 2 HOUR, NOW() - INTERVAL 12 DAY + INTERVAL 2 HOUR + INTERVAL 10 MINUTE, NOW() - INTERVAL 12 DAY + INTERVAL 2 HOUR + INTERVAL 15 MINUTE, 2.10,'Clothes bagged'),
(7,7,3,'COLLECTED',1, NOW() - INTERVAL 7 DAY + INTERVAL 2 HOUR, NOW() - INTERVAL 7 DAY + INTERVAL 3 HOUR, NOW() - INTERVAL 6 DAY + INTERVAL 30 MINUTE, NOW() - INTERVAL 6 DAY + INTERVAL 1 HOUR, NOW() - INTERVAL 6 DAY + INTERVAL 1 HOUR + INTERVAL 20 MINUTE, NULL, 1.80,'Containers assorted'),
(8,9,3,'ASSIGNED',1, NOW() - INTERVAL 9 HOUR, NULL, NULL, NULL, NULL, NULL, NULL,NULL),
(9,10,6,'ACCEPTED',1, NOW() - INTERVAL 12 HOUR, NOW() - INTERVAL 8 HOUR, NULL, NULL, NULL, NULL, NULL,NULL),
(10,12,6,'ON_THE_WAY',1, NOW() - INTERVAL 1 DAY + INTERVAL 1 HOUR, NOW() - INTERVAL 1 DAY + INTERVAL 2 HOUR, NOW() - INTERVAL 40 MINUTE, NULL, NULL, NULL, NULL,NULL);

-- ---------- waste transactions (Waste Passports) ----------
INSERT INTO waste_transactions (id, waste_id, pickup_request_id, source_user_id, source_type, category_id, initial_weight, current_weight, current_stage, final_outcome, origin_address, ward, latitude, longitude, facility_id, completed_at, created_at) VALUES
(1,'PNV-2026-000001',1,2,'CITIZEN',3,2.40,2.40,'RECYCLED','RECYCLED','Flat 302, Shanti Apartments, Rd No 4, Tower Chowk area','Ward 18',24.2690000,87.2520000,1, NOW() - INTERVAL 57 DAY, NOW() - INTERVAL 60 DAY),
(2,'PNV-2026-000002',2,2,'CITIZEN',1,5.20,5.20,'COMPOSTED','COMPOSTED','Flat 302, Shanti Apartments, Rd No 4, Tower Chowk area','Ward 18',24.2690000,87.2520000,2, NOW() - INTERVAL 42 DAY, NOW() - INTERVAL 45 DAY),
(3,'PNV-2026-000003',3,7,'CITIZEN',4,4.10,4.10,'RECYCLED','RECYCLED','Housing Board Colony, Main Market Road, Dumka','Ward 9',24.2660000,87.2490000,1, NOW() - INTERVAL 27 DAY, NOW() - INTERVAL 30 DAY),
(4,'PNV-2026-000004',4,5,'BUSINESS',6,11.80,11.80,'RECYCLED','RECYCLED','School Road, near +2 High School, Dumka','Ward 9',24.2655000,87.2485000,1, NOW() - INTERVAL 22 DAY, NOW() - INTERVAL 25 DAY),
(5,'PNV-2026-000005',5,2,'CITIZEN',8,3.00,3.00,'RECOVERED','RECOVERED','Flat 302, Shanti Apartments, Rd No 4, Tower Chowk area','Ward 18',24.2690000,87.2520000,3, NOW() - INTERVAL 17 DAY, NOW() - INTERVAL 20 DAY),
(6,'PNV-2026-000006',6,7,'CITIZEN',9,2.10,2.10,'REUSED','REUSED','Housing Board Colony, Main Market Road, Dumka','Ward 9',24.2660000,87.2490000,1, NOW() - INTERVAL 9 DAY, NOW() - INTERVAL 12 DAY),
(7,'PNV-2026-000007',7,2,'CITIZEN',3,1.80,1.80,'SORTED',NULL,'Flat 302, Shanti Apartments, Rd No 4, Tower Chowk area','Ward 18',24.2690000,87.2520000,1,NULL, NOW() - INTERVAL 6 DAY);

-- ---------- journey events ----------
INSERT INTO waste_journey_events (waste_transaction_id, event_type, event_time, location, actor_id, actor_role, facility_id, quantity, notes) VALUES
(1,'WASTE_IDENTIFIED', NOW() - INTERVAL 61 DAY,'Ward 18, Dumka',2,'CITIZEN',NULL,2.50,'Waste identified and segregation guidance generated'),
(1,'PICKUP_REQUESTED', NOW() - INTERVAL 61 DAY,'Flat 302, Shanti Apartments, Tower Chowk area',2,'CITIZEN',NULL,2.50,'Pickup PNVP-260712-A1B2C3 requested'),
(1,'COLLECTOR_ASSIGNED', NOW() - INTERVAL 61 DAY + INTERVAL 3 HOUR,'Ward 18, Dumka',1,'ADMIN',NULL,NULL,'Collector assigned: Ravi Kumar'),
(1,'COLLECTED', NOW() - INTERVAL 60 DAY + INTERVAL 2 HOUR,'Flat 302, Shanti Apartments, Tower Chowk area',3,'COLLECTOR',NULL,2.40,'Waste collected by Ravi Kumar. Verified weight: 2.4 kg. Clean PET stream.'),
(1,'PICKUP_COMPLETED', NOW() - INTERVAL 60 DAY + INTERVAL 2 HOUR + INTERVAL 15 MINUTE,'Ward 18, Dumka',3,'COLLECTOR',NULL,2.40,'Pickup PNVP-260712-A1B2C3 completed. Waste Passport is now active.'),
(1,'SORTED', NOW() - INTERVAL 59 DAY,'PUNARVA MRF College Road',4,'RECYCLER',1,2.40,'PET separated from caps and labels; baled for reprocessing.'),
(1,'PROCESSING_STARTED', NOW() - INTERVAL 58 DAY,'PUNARVA MRF College Road',4,'RECYCLER',1,2.40,'Bales sent for washing and flaking.'),
(1,'PROCESSED', NOW() - INTERVAL 57 DAY,'PUNARVA MRF College Road',4,'RECYCLER',1,2.40,'Flakes washed, dried and quality-checked.'),
(1,'FINAL_OUTCOME', NOW() - INTERVAL 57 DAY + INTERVAL 2 HOUR,'PUNARVA MRF College Road',4,'RECYCLER',1,2.40,'Material recycled into flake feedstock for new PET products.'),
(1,'IMPACT_CALCULATED', NOW() - INTERVAL 57 DAY + INTERVAL 2 HOUR,NULL,NULL,'SYSTEM',1,2.40,'Estimated impact calculated (v1.0-estimate): CO2e avoided 3.6 kg, water saved 14.4 L.'),
(1,'REWARD_GENERATED', NOW() - INTERVAL 57 DAY + INTERVAL 2 HOUR,NULL,NULL,'SYSTEM',1,NULL,'Reward of 25 points credited to the source account.'),
(2,'WASTE_IDENTIFIED', NOW() - INTERVAL 46 DAY,'Ward 18, Dumka',2,'CITIZEN',NULL,5.00,'Kitchen wet waste identified for composting'),
(2,'PICKUP_REQUESTED', NOW() - INTERVAL 46 DAY,'Flat 302, Shanti Apartments, Tower Chowk area',2,'CITIZEN',NULL,5.00,'Pickup PNVP-260728-D4E5F6 requested'),
(2,'COLLECTOR_ASSIGNED', NOW() - INTERVAL 46 DAY + INTERVAL 2 HOUR,'Ward 18, Dumka',1,'ADMIN',NULL,NULL,'Collector assigned: Ravi Kumar'),
(2,'COLLECTED', NOW() - INTERVAL 45 DAY + INTERVAL 1 HOUR,'Flat 302, Shanti Apartments, Tower Chowk area',3,'COLLECTOR',NULL,5.20,'Wet waste collected, well drained.'),
(2,'PICKUP_COMPLETED', NOW() - INTERVAL 45 DAY + INTERVAL 1 HOUR + INTERVAL 20 MINUTE,'Ward 18, Dumka',3,'COLLECTOR',NULL,5.20,'Pickup completed. Passport active.'),
(2,'SORTED', NOW() - INTERVAL 44 DAY,'PUNARVA Compost Hub SkMU Road, Dumka',8,'RECYCLER',2,5.20,'Wet waste weighed and loaded into windrow 3.'),
(2,'PROCESSING_STARTED', NOW() - INTERVAL 44 DAY + INTERVAL 2 HOUR,'PUNARVA Compost Hub SkMU Road, Dumka',8,'RECYCLER',2,5.20,'Aerobic composting cycle started.'),
(2,'PROCESSED', NOW() - INTERVAL 43 DAY,'PUNARVA Compost Hub SkMU Road, Dumka',8,'RECYCLER',2,5.20,'First-turn composting done; temperature stabilised.'),
(2,'FINAL_OUTCOME', NOW() - INTERVAL 42 DAY,'PUNARVA Compost Hub SkMU Road, Dumka',8,'RECYCLER',2,5.20,'Composted into organic manure.'),
(2,'IMPACT_CALCULATED', NOW() - INTERVAL 42 DAY,NULL,NULL,'SYSTEM',2,5.20,'Estimated impact calculated (v1.0-estimate): CO2e avoided 4.68 kg.'),
(2,'REWARD_GENERATED', NOW() - INTERVAL 42 DAY,NULL,NULL,'SYSTEM',2,NULL,'Reward of 25 points credited to the source account.'),
(3,'WASTE_IDENTIFIED', NOW() - INTERVAL 31 DAY,'Ward 9, Dumka',7,'CITIZEN',NULL,4.00,'Paper bundle identified'),
(3,'PICKUP_REQUESTED', NOW() - INTERVAL 31 DAY,'Housing Board Colony, Main Market Road, Dumka',7,'CITIZEN',NULL,4.00,'Pickup PNVP-260812-G7H8I9 requested'),
(3,'COLLECTOR_ASSIGNED', NOW() - INTERVAL 31 DAY + INTERVAL 4 HOUR,'Ward 9, Dumka',1,'ADMIN',NULL,NULL,'Collector assigned: Deepak Yadav'),
(3,'COLLECTED', NOW() - INTERVAL 30 DAY + INTERVAL 2 HOUR,'Housing Board Colony, Main Market Road, Dumka',6,'COLLECTOR',NULL,4.10,'Dry paper bundle collected.'),
(3,'PICKUP_COMPLETED', NOW() - INTERVAL 30 DAY + INTERVAL 2 HOUR + INTERVAL 10 MINUTE,'Ward 9, Dumka',6,'COLLECTOR',NULL,4.10,'Pickup completed. Passport active.'),
(3,'SORTED', NOW() - INTERVAL 29 DAY,'PUNARVA MRF College Road',4,'RECYCLER',1,4.10,'Paper graded and baled.'),
(3,'PROCESSING_STARTED', NOW() - INTERVAL 29 DAY + INTERVAL 3 HOUR,'PUNARVA MRF College Road',4,'RECYCLER',1,4.10,'Bales dispatched to paper mill partner.'),
(3,'PROCESSED', NOW() - INTERVAL 28 DAY,'PUNARVA MRF College Road',4,'RECYCLER',1,4.10,'Mill confirmed receipt and pulping.'),
(3,'FINAL_OUTCOME', NOW() - INTERVAL 27 DAY,'PUNARVA MRF College Road',4,'RECYCLER',1,4.10,'Recycled into newsprint.'),
(3,'IMPACT_CALCULATED', NOW() - INTERVAL 27 DAY,NULL,NULL,'SYSTEM',1,4.10,'Estimated impact calculated (v1.0-estimate): CO2e avoided 3.69 kg, water saved 32.8 L.'),
(3,'REWARD_GENERATED', NOW() - INTERVAL 27 DAY,NULL,NULL,'SYSTEM',1,NULL,'Reward of 25 points credited to the source account.'),
(4,'WASTE_IDENTIFIED', NOW() - INTERVAL 26 DAY,'Ward 9, Dumka',5,'BUSINESS',NULL,12.00,'Restaurant glass stock identified'),
(4,'PICKUP_REQUESTED', NOW() - INTERVAL 26 DAY,'School Road, near +2 High School, Dumka',5,'BUSINESS',NULL,12.00,'Bulk pickup PNVP-260817-J1K2L3 requested'),
(4,'COLLECTOR_ASSIGNED', NOW() - INTERVAL 26 DAY + INTERVAL 3 HOUR,'Ward 9, Dumka',1,'ADMIN',NULL,NULL,'Collector assigned: Deepak Yadav'),
(4,'COLLECTED', NOW() - INTERVAL 25 DAY + INTERVAL 2 HOUR,'School Road, near +2 High School, Dumka',6,'COLLECTOR',NULL,11.80,'Glass crates collected.'),
(4,'PICKUP_COMPLETED', NOW() - INTERVAL 25 DAY + INTERVAL 2 HOUR + INTERVAL 25 MINUTE,'Ward 9, Dumka',6,'COLLECTOR',NULL,11.80,'Pickup completed. Passport active.'),
(4,'SORTED', NOW() - INTERVAL 24 DAY,'PUNARVA MRF College Road',4,'RECYCLER',1,11.80,'Glass sorted by colour.'),
(4,'PROCESSING_STARTED', NOW() - INTERVAL 24 DAY + INTERVAL 4 HOUR,'PUNARVA MRF College Road',4,'RECYCLER',1,11.80,'Cullet preparation started.'),
(4,'PROCESSED', NOW() - INTERVAL 23 DAY,'PUNARVA MRF College Road',4,'RECYCLER',1,11.80,'Cullet cleaned and graded.'),
(4,'FINAL_OUTCOME', NOW() - INTERVAL 22 DAY,'PUNARVA MRF College Road',4,'RECYCLER',1,11.80,'Recycled into new glass containers.'),
(4,'IMPACT_CALCULATED', NOW() - INTERVAL 22 DAY,NULL,NULL,'SYSTEM',1,11.80,'Estimated impact calculated (v1.0-estimate): CO2e avoided 3.54 kg.'),
(4,'REWARD_GENERATED', NOW() - INTERVAL 22 DAY,NULL,NULL,'SYSTEM',1,NULL,'Reward of 25 points credited to the source account.'),
(5,'WASTE_IDENTIFIED', NOW() - INTERVAL 21 DAY,'Ward 18, Dumka',2,'CITIZEN',NULL,3.00,'E-waste drawer cleaned out'),
(5,'PICKUP_REQUESTED', NOW() - INTERVAL 21 DAY,'Flat 302, Shanti Apartments, Tower Chowk area',2,'CITIZEN',NULL,3.00,'Pickup PNVP-260822-M4N5O6 requested'),
(5,'COLLECTOR_ASSIGNED', NOW() - INTERVAL 21 DAY + INTERVAL 2 HOUR,'Ward 18, Dumka',1,'ADMIN',NULL,NULL,'Collector assigned: Ravi Kumar'),
(5,'COLLECTED', NOW() - INTERVAL 20 DAY + INTERVAL 1 HOUR,'Flat 302, Shanti Apartments, Tower Chowk area',3,'COLLECTOR',NULL,3.00,'Boxed e-waste collected.'),
(5,'PICKUP_COMPLETED', NOW() - INTERVAL 20 DAY + INTERVAL 1 HOUR + INTERVAL 15 MINUTE,'Ward 18, Dumka',3,'COLLECTOR',NULL,3.00,'Pickup completed. Passport active.'),
(5,'SORTED', NOW() - INTERVAL 19 DAY,'E-Suraksha E-Waste Recycling College Road Dumka',NULL,'RECYCLER',3,3.00,'Devices catalogued; batteries isolated.'),
(5,'PROCESSING_STARTED', NOW() - INTERVAL 19 DAY + INTERVAL 5 HOUR,'E-Suraksha E-Waste Recycling College Road Dumka',NULL,'RECYCLER',3,3.00,'Manual dismantling started.'),
(5,'PROCESSED', NOW() - INTERVAL 18 DAY,'E-Suraksha E-Waste Recycling College Road Dumka',NULL,'RECYCLER',3,3.00,'Components separated: PCBs, metals, plastics.'),
(5,'FINAL_OUTCOME', NOW() - INTERVAL 17 DAY,'E-Suraksha E-Waste Recycling College Road Dumka',NULL,'RECYCLER',3,3.00,'Metals recovered through authorised processing; energy recovery from residuals.'),
(5,'IMPACT_CALCULATED', NOW() - INTERVAL 17 DAY,NULL,NULL,'SYSTEM',3,3.00,'Estimated impact calculated (v1.0-estimate): CO2e avoided 3.9 kg.'),
(5,'REWARD_GENERATED', NOW() - INTERVAL 17 DAY,NULL,NULL,'SYSTEM',3,NULL,'Reward of 25 points credited to the source account.'),
(6,'WASTE_IDENTIFIED', NOW() - INTERVAL 13 DAY,'Ward 9, Dumka',7,'CITIZEN',NULL,2.00,'Old clothes identified for donation/reuse'),
(6,'PICKUP_REQUESTED', NOW() - INTERVAL 13 DAY,'Housing Board Colony, Main Market Road, Dumka',7,'CITIZEN',NULL,2.00,'Pickup PNVP-260831-P7Q8R9 requested'),
(6,'COLLECTOR_ASSIGNED', NOW() - INTERVAL 13 DAY + INTERVAL 3 HOUR,'Ward 9, Dumka',1,'ADMIN',NULL,NULL,'Collector assigned: Deepak Yadav'),
(6,'COLLECTED', NOW() - INTERVAL 12 DAY + INTERVAL 2 HOUR,'Housing Board Colony, Main Market Road, Dumka',6,'COLLECTOR',NULL,2.10,'Bagged clothes collected.'),
(6,'PICKUP_COMPLETED', NOW() - INTERVAL 12 DAY + INTERVAL 2 HOUR + INTERVAL 15 MINUTE,'Ward 9, Dumka',6,'COLLECTOR',NULL,2.10,'Pickup completed. Passport active.'),
(6,'SORTED', NOW() - INTERVAL 11 DAY,'PUNARVA MRF College Road',4,'RECYCLER',1,2.10,'Textiles graded: wearable vs rags.'),
(6,'PROCESSING_STARTED', NOW() - INTERVAL 11 DAY + INTERVAL 3 HOUR,'PUNARVA MRF College Road',4,'RECYCLER',1,2.10,'Reuse channel preparation.'),
(6,'PROCESSED', NOW() - INTERVAL 10 DAY,'PUNARVA MRF College Road',4,'RECYCLER',1,2.10,'80% wearable items cleaned and packed for donation drive.'),
(6,'FINAL_OUTCOME', NOW() - INTERVAL 9 DAY,'PUNARVA MRF College Road',4,'RECYCLER',1,2.10,'Reused via community donation drive.'),
(6,'IMPACT_CALCULATED', NOW() - INTERVAL 9 DAY,NULL,NULL,'SYSTEM',1,2.10,'Estimated impact calculated (v1.0-estimate): CO2e avoided 6.3 kg, water saved 63 L.'),
(6,'REWARD_GENERATED', NOW() - INTERVAL 9 DAY,NULL,NULL,'SYSTEM',1,NULL,'Reward of 25 points credited to the source account.'),
(7,'WASTE_IDENTIFIED', NOW() - INTERVAL 7 DAY,'Ward 18, Dumka',2,'CITIZEN',NULL,1.80,'Plastic containers identified'),
(7,'PICKUP_REQUESTED', NOW() - INTERVAL 7 DAY,'Flat 302, Shanti Apartments, Tower Chowk area',2,'CITIZEN',NULL,1.80,'Pickup PNVP-260906-S1T2U3 requested'),
(7,'COLLECTOR_ASSIGNED', NOW() - INTERVAL 7 DAY + INTERVAL 2 HOUR,'Ward 18, Dumka',1,'ADMIN',NULL,NULL,'Collector assigned: Ravi Kumar'),
(7,'COLLECTED', NOW() - INTERVAL 6 DAY + INTERVAL 1 HOUR,'Flat 302, Shanti Apartments, Tower Chowk area',3,'COLLECTOR',NULL,1.80,'Assorted containers collected.'),
(7,'PICKUP_COMPLETED', NOW() - INTERVAL 6 DAY + INTERVAL 1 HOUR + INTERVAL 25 MINUTE,'Ward 18, Dumka',3,'COLLECTOR',NULL,1.80,'Pickup completed. Passport active.'),
(7,'SORTED', NOW() - INTERVAL 5 DAY,'PUNARVA MRF College Road',4,'RECYCLER',1,1.80,'Containers sorted: PET/HDPE/PP separated.');

-- ---------- environmental impacts (quantity × factor) ----------
INSERT INTO environmental_impacts (waste_transaction_id, category_id, quantity, co2_saved_kg, water_saved_l, energy_saved_kwh, landfill_diverted_kg, methodology_version) VALUES
(1,3,2.40,3.600,14.40,13.200,2.400,'v1.0-estimate'),
(2,1,5.20,4.680,0.00,1.560,4.940,'v1.0-estimate'),
(3,4,4.10,3.690,32.80,11.070,4.100,'v1.0-estimate'),
(4,6,11.80,3.540,23.60,14.160,11.800,'v1.0-estimate'),
(5,8,3.00,3.900,18.00,9.000,2.550,'v1.0-estimate'),
(6,9,2.10,6.300,63.00,7.350,1.995,'v1.0-estimate');

-- ---------- reward transactions (idempotent: unique per user+rule+reference) ----------
INSERT INTO reward_transactions (user_id, rule_id, points, reason, reference_type, reference_id, created_at) VALUES
(2,1,10,'Pickup completed – PNVP-260712-A1B2C3','pickup_request',1, NOW() - INTERVAL 60 DAY),
(2,2,5,'Clean stream bonus – Properly segregated Plastic','pickup_request',1, NOW() - INTERVAL 60 DAY),
(2,3,25,'Waste fully recycled / recovered – Waste ID PNV-2026-000001','waste_transaction',1, NOW() - INTERVAL 57 DAY),
(2,1,10,'Pickup completed – PNVP-260728-D4E5F6','pickup_request',2, NOW() - INTERVAL 45 DAY),
(2,3,25,'Waste fully recycled / recovered – Waste ID PNV-2026-000002','waste_transaction',2, NOW() - INTERVAL 42 DAY),
(2,1,10,'Pickup completed – PNVP-260822-M4N5O6','pickup_request',5, NOW() - INTERVAL 20 DAY),
(2,2,5,'Clean stream bonus – Properly segregated E-Waste','pickup_request',5, NOW() - INTERVAL 20 DAY),
(2,3,25,'Waste fully recycled / recovered – Waste ID PNV-2026-000005','waste_transaction',5, NOW() - INTERVAL 17 DAY),
(7,1,10,'Pickup completed – PNVP-260812-G7H8I9','pickup_request',3, NOW() - INTERVAL 30 DAY),
(7,2,5,'Clean stream bonus – Properly segregated Paper','pickup_request',3, NOW() - INTERVAL 30 DAY),
(7,3,25,'Waste fully recycled / recovered – Waste ID PNV-2026-000003','waste_transaction',3, NOW() - INTERVAL 27 DAY),
(7,1,10,'Pickup completed – PNVP-260831-P7Q8R9','pickup_request',6, NOW() - INTERVAL 12 DAY),
(7,3,25,'Waste fully recycled / recovered – Waste ID PNV-2026-000006','waste_transaction',6, NOW() - INTERVAL 9 DAY),
(5,1,10,'Pickup completed – PNVP-260817-J1K2L3','pickup_request',4, NOW() - INTERVAL 25 DAY),
(5,3,25,'Waste fully recycled / recovered – Waste ID PNV-2026-000004','waste_transaction',4, NOW() - INTERVAL 22 DAY),
(2,4,20,'Learning quiz passed – Waste Segregation Basics (100%)','quiz',1, NOW() - INTERVAL 15 DAY),
(2,5,15,'Verified waste report – PNVR-260830-K1L2M3','waste_report',1, NOW() - INTERVAL 12 DAY);

-- ---------- quiz attempts ----------
INSERT INTO quiz_attempts (quiz_id, user_id, score_pct, passed, created_at) VALUES
(1,2,100,1, NOW() - INTERVAL 15 DAY),
(2,2,75,1, NOW() - INTERVAL 10 DAY);

-- ---------- waste reports ----------
INSERT INTO waste_reports (id, report_code, user_id, category_id, description, address_line, ward, city, latitude, longitude, status, assigned_to, verified_at, resolved_at, resolution_notes, created_at) VALUES
(1,'PNVR-260830-K1L2M3',2,13,'Garbage pile not collected for a week near the park gate. Stray animals spreading it.','Gate 2, Tower Chowk area Park, Road No 4','Ward 18','Dumka',24.2700000,87.2540000,'RESOLVED',3, NOW() - INTERVAL 12 DAY + INTERVAL 5 HOUR, NOW() - INTERVAL 10 DAY,'Cleared by ward sanitation crew on 1 Sep.', NOW() - INTERVAL 13 DAY),
(2,'PNVR-260905-N4O5P6',7,11,'Construction debris dumped on the footpath, blocking pedestrians.','Near Housing Board flats, Main Market Road, Dumka','Ward 9','Dumka',24.2665000,87.2500000,'IN_PROGRESS',3, NOW() - INTERVAL 6 DAY, NULL,NULL, NOW() - INTERVAL 7 DAY),
(3,'PNVR-260907-Q7R8S9',NULL,3,'Plastic waste floating in the drain, risk of clogging during rain.','College Road Main Road drain, near Nepal Bhawan','Ward 5','Dumka',24.2725000,87.2455000,'VERIFIED',NULL, NOW() - INTERVAL 4 DAY, NULL,NULL, NOW() - INTERVAL 5 DAY),
(4,'PNVR-260909-T1U2V3',2,1,'Overflowing community bin; wet waste leaking on the road.','Community bin, Block C, College Road','Ward 5','Dumka',24.2715000,87.2505000,'ASSIGNED',6, NOW() - INTERVAL 2 DAY, NULL,NULL, NOW() - INTERVAL 3 DAY),
(5,'PNVR-260910-W4X5Y6',7,8,'E-waste dumped near the school wall – monitors and wires.','Behind St. Joseph''s School, Church Road Dumka','Ward 12','Dumka',24.2710000,87.2530000,'SUBMITTED',NULL,NULL,NULL,NULL, NOW() - INTERVAL 20 HOUR),
(6,'PNVR-260829-Z7A8B9',NULL,10,'Garden waste burnt openly in the evenings; smoke hazard.','SkMU Road vacant plot, Dumka','Ward 8','Dumka',24.2645000,87.2430000,'RESOLVED',6, NOW() - INTERVAL 14 DAY, NOW() - INTERVAL 12 DAY,'Debris and garden waste removed; warning issued.', NOW() - INTERVAL 15 DAY);

-- ---------- hotspot scores (rule-based: reports×10 + recent30d×15 + unresolved×25) ----------
INSERT INTO hotspot_scores (ward, latitude, longitude, report_count, recent_reports, unresolved_reports, estimated_volume_kg, hotspot_score, status, last_calculated_at) VALUES
('Ward 5',24.2705000,87.2510000,2,2,2,24,110,'CRITICAL',NOW()),
('Ward 9',24.2660000,87.2490000,2,2,1,24,95,'CRITICAL',NOW()),
('Ward 18',24.2690000,87.2520000,1,0,0,12,10,'LOW',NOW()),
('Ward 12',24.2705000,87.2510000,1,1,1,12,50,'HIGH',NOW()),
('Ward 8',24.2645000,87.2430000,1,0,0,12,10,'LOW',NOW());

-- ---------- notifications ----------
INSERT INTO notifications (user_id, type, title, message, reference_type, reference_id, is_read, created_at) VALUES
(2,'PICKUP','Pickup request created','Your pickup PNVP-260910-V4W5X6 (Cardboard, 3.5 kg) has been received and is awaiting assignment.','pickup_request',8,0, NOW() - INTERVAL 6 HOUR),
(1,'PICKUP','New pickup request','Aarav Sharma requested a Cardboard pickup (3.5 kg).','pickup_request',8,0, NOW() - INTERVAL 6 HOUR),
(3,'PICKUP','New pickup assigned','Pickup PNVP-260910-Y7Z8A9 (2.2 kg) was assigned to you.','pickup_request',9,0, NOW() - INTERVAL 9 HOUR),
(7,'PICKUP','Collector assigned','A collector has been assigned to your pickup PNVP-260910-Y7Z8A9.','pickup_request',9,0, NOW() - INTERVAL 9 HOUR),
(6,'PICKUP','New pickup assigned','Pickup PNVP-260910-B1C2D3 (15 kg) was assigned to you.','pickup_request',10,1, NOW() - INTERVAL 12 HOUR),
(7,'PICKUP','Pickup on the way','Your collector is on the way for pickup PNVP-260911-H7I8J9.','pickup_request',12,0, NOW() - INTERVAL 40 MINUTE),
(2,'WASTE_PASSPORT','Waste Passport updated: PNV-2026-000007','Waste sorted – PUNARVA MRF College Road','waste_transaction',7,0, NOW() - INTERVAL 5 DAY),
(2,'REWARD','Reward earned: +20 points','Learning quiz passed – Waste Segregation Basics (100%)','quiz',1,1, NOW() - INTERVAL 15 DAY),
(2,'REPORT','Report resolved','Your waste report PNVR-260830-K1L2M3 is now: Resolved.','waste_report',1,1, NOW() - INTERVAL 10 DAY),
(4,'WASTE_PASSPORT','Incoming waste: PNV-2026-000007','Plastic containers (1.8 kg) received at your facility for sorting.','waste_transaction',7,0, NOW() - INTERVAL 5 DAY);


-- ---------- waste scans (demo mode history) ----------
INSERT INTO waste_scans (user_id, image_path, result_item, category_id, material, confidence, bin_type, advice, mode, provider, created_at) VALUES
(2,'waste/demo-scan-1.png','Plastic bottle (PET)',3,'PET plastic',91.4,'Dry Waste (Blue bin)','Empty and rinse the bottle, remove the cap ring, and keep it with dry recyclables.','demo','demo-v1', NOW() - INTERVAL 9 DAY),
(2,'waste/demo-scan-2.png','Food leftovers',1,'Organic matter',88.2,'Wet Waste (Green bin)','Put food scraps in the green wet-waste bin. Excellent feedstock for home composting.','demo','demo-v1', NOW() - INTERVAL 4 DAY),
(7,'waste/demo-scan-3.png','Old newspaper',4,'Newsprint paper',95.1,'Dry Waste (Blue bin)','Stack newspapers neatly and keep them dry. Tie with jute string, not plastic tape.','demo','demo-v1', NOW() - INTERVAL 2 DAY);

-- ---------- map locations ----------
INSERT INTO map_locations (location_type, reference_id, title, latitude, longitude, status) VALUES
('FACILITY',1,'PUNARVA MRF – College Road',24.2735000,87.2445000,'ACTIVE'),
('FACILITY',2,'PUNARVA Compost Hub – SkMU Road, Dumka',24.2645000,87.2430000,'ACTIVE'),
('FACILITY',3,'E-Suraksha E-Waste – College Road, Dumka',24.2705000,87.2510000,'ACTIVE'),
('REPORT',1,'PNVR-260830-K1L2M3',24.2700000,87.2540000,'RESOLVED'),
('REPORT',2,'PNVR-260905-N4O5P6',24.2665000,87.2500000,'IN_PROGRESS'),
('REPORT',3,'PNVR-260907-Q7R8S9',24.2725000,87.2455000,'VERIFIED'),
('REPORT',4,'PNVR-260909-T1U2V3',24.2715000,87.2505000,'ASSIGNED'),
('REPORT',5,'PNVR-260910-W4X5Y6',24.2710000,87.2530000,'SUBMITTED'),
('REPORT',6,'PNVR-260829-Z7A8B9',24.2645000,87.2430000,'RESOLVED'),
('WASTE',1,'PNV-2026-000001',24.2690000,87.2520000,'RECYCLED'),
('WASTE',2,'PNV-2026-000002',24.2690000,87.2520000,'COMPOSTED'),
('WASTE',3,'PNV-2026-000003',24.2660000,87.2490000,'RECYCLED'),
('WASTE',7,'PNV-2026-000007',24.2690000,87.2520000,'RECEIVED');

-- ---------- vehicles ----------
INSERT INTO vehicles (id, facility_id, vehicle_number, vehicle_type, capacity_kg, driver_name, driver_phone, status) VALUES
(1,1,'BR01P-4412','TIPPER',2500,'Mohammed Salim','+91-9830044551','ACTIVE'),
(2,1,'BR01P-4413','TEMPO',800,'Suresh Ram','+91-9830044552','ACTIVE'),
(3,2,'BR01P-7721','DUMPER',5000,'Ranjit Paswan','+91-9830044553','ACTIVE'),
(4,3,'BR01P-9034','TEMPO',700,'Vikram Choudhary','+91-9830044554','MAINTENANCE');

-- ---------- route plan (collector 3, today) ----------
INSERT INTO route_plans (id, collector_id, plan_date, total_distance_km, status) VALUES
(1,3,CURDATE(),6.80,'ACTIVE');
INSERT INTO route_stops (route_plan_id, pickup_request_id, stop_order, distance_from_prev_km, status) VALUES
(1,9,1,2.10,'PENDING'),
(1,10,2,3.40,'PENDING');

-- ---------- settings ----------
INSERT INTO settings (setting_key, setting_value, description) VALUES
('site_announcement','','Banner message shown on dashboards (leave empty to hide)'),
('rewards_enabled','1','Enable reward points (1 = yes, 0 = no)'),
('pickup_slots','06:00-09:00,09:00-12:00,12:00-15:00,15:00-18:00,18:00-20:00','Pickup time slots (comma separated)'),
('hotspot_recent_days','30','Days counted as "recent" for hotspot scoring'),
('default_city','Dumka','Default city for new records');

-- ---------- id sequence: next runtime Waste ID continues after seeded ones ----------
INSERT INTO id_sequences (year, last_number) VALUES (YEAR(CURDATE()), 7);

-- ---------- a few audit entries ----------
-- (v2.13.0: the demo ANNOUNCEMENT audit seed row was removed with the demo content)
INSERT INTO audit_logs (user_id, action, module, record_id, old_value, new_value, ip, user_agent, created_at) VALUES
(1,'PICKUP_ASSIGNED','pickup',9,'REQUESTED','ASSIGNED','127.0.0.1','seed', NOW() - INTERVAL 9 HOUR),
(1,'PICKUP_ASSIGNED','pickup',10,'REQUESTED','ASSIGNED','127.0.0.1','seed', NOW() - INTERVAL 12 HOUR),
(4,'WASTE_STAGE_CHANGE','waste',7,'COLLECTED','SORTED','127.0.0.1','seed', NOW() - INTERVAL 5 DAY);

