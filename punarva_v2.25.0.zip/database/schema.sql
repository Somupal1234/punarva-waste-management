-- ============================================================
-- PUNARVA – From Waste to Worth
-- Database schema (MySQL 5.7+ / MariaDB 10.4+)
-- Import via phpMyAdmin or:  mysql -u root punarva_db < schema.sql
--
-- NOTE: This file safely RESETS punarva_db. You can import it any
-- number of times without foreign-key errors (#1451) – it drops and
-- recreates the whole database from scratch.
-- Import seed.sql AFTER this file, then settings_defaults.sql (System Settings baseline).
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP DATABASE IF EXISTS punarva_db;
CREATE DATABASE punarva_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE punarva_db;

SET FOREIGN_KEY_CHECKS = 1;

-- ---------- RBAC ----------
CREATE TABLE roles (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code        VARCHAR(30)  NOT NULL UNIQUE,
  name        VARCHAR(80)  NOT NULL,
  description VARCHAR(255) NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE permissions (
  id     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code   VARCHAR(80) NOT NULL UNIQUE,
  name   VARCHAR(120) NOT NULL,
  module VARCHAR(60) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE role_permissions (
  role_id       INT UNSIGNED NOT NULL,
  permission_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (role_id, permission_id),
  CONSTRAINT fk_rp_role FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
  CONSTRAINT fk_rp_perm FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- core entities ----------
CREATE TABLE organizations (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(160) NOT NULL,
  org_type     VARCHAR(40)  NOT NULL DEFAULT 'OTHER',
  email        VARCHAR(190) NULL,
  phone        VARCHAR(20)  NULL,
  address_line VARCHAR(255) NULL,
  city         VARCHAR(80)  NULL,
  status       ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_org_type (org_type)
) ENGINE=InnoDB;

CREATE TABLE facilities (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code          VARCHAR(20)  NOT NULL UNIQUE,
  name          VARCHAR(160) NOT NULL,
  facility_type VARCHAR(40)  NOT NULL,           -- SORTING / MRF / COMPOST / E-WASTE ...
  address_line  VARCHAR(255) NULL,
  city          VARCHAR(80)  NULL,
  ward          VARCHAR(40)  NULL,
  state         VARCHAR(80)  NULL,
  pincode       VARCHAR(12)  NULL,
  latitude      DECIMAL(10,7) NULL,
  longitude     DECIMAL(10,7) NULL,
  contact_person VARCHAR(120) NULL,
  phone         VARCHAR(20)  NULL,
  email         VARCHAR(190) NULL,
  capacity_kg_day DECIMAL(10,2) NULL,
  status        ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_fac_city (city), INDEX idx_fac_type (facility_type)
) ENGINE=InnoDB;

CREATE TABLE users (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  role_id        INT UNSIGNED NOT NULL,
  name           VARCHAR(120) NOT NULL,
  email          VARCHAR(190) NOT NULL UNIQUE,
  phone          VARCHAR(10)  NULL UNIQUE,          -- canonical Indian mobile: exactly 10 digits
  phone_verified TINYINT(1)   NOT NULL DEFAULT 0,   -- 1 only after real OTP verification
  phone_verified_at DATETIME  NULL,
  email_verified TINYINT(1)   NOT NULL DEFAULT 0,   -- 1 only after real link/OTP verification
  email_verified_at DATETIME  NULL,
  password_hash  VARCHAR(255) NOT NULL,
  status         ENUM('ACTIVE','INACTIVE','SUSPENDED') NOT NULL DEFAULT 'ACTIVE',
  language       VARCHAR(5)   NOT NULL DEFAULT 'en',
  avatar_path    VARCHAR(255) NULL,
  facility_id    INT UNSIGNED NULL,
  organization_id INT UNSIGNED NULL,
  last_login_at  DATETIME NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_user_role FOREIGN KEY (role_id) REFERENCES roles(id),
  CONSTRAINT fk_user_fac  FOREIGN KEY (facility_id) REFERENCES facilities(id) ON DELETE SET NULL,
  CONSTRAINT fk_user_org  FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE SET NULL,
  INDEX idx_user_status (status)
) ENGINE=InnoDB;

CREATE TABLE addresses (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id      INT UNSIGNED NOT NULL,
  label        VARCHAR(40)  NOT NULL DEFAULT 'Address',
  address_line VARCHAR(255) NOT NULL,
  city         VARCHAR(80)  NULL,
  state        VARCHAR(80)  NULL,
  ward         VARCHAR(40)  NULL,
  latitude     DECIMAL(10,7) NULL,
  longitude    DECIMAL(10,7) NULL,
  is_default   TINYINT(1) NOT NULL DEFAULT 0,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_addr_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_addr_user (user_id)
) ENGINE=InnoDB;

-- ---------- waste taxonomy ----------
CREATE TABLE waste_categories (
  id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code               VARCHAR(30)  NOT NULL UNIQUE,
  name               VARCHAR(80)  NOT NULL,
  description        VARCHAR(500) NULL,
  bin_type           VARCHAR(60)  NOT NULL,
  icon               VARCHAR(60)  NULL,
  color              VARCHAR(9)   NOT NULL DEFAULT '#6c757d',
  is_recyclable      TINYINT(1)   NOT NULL DEFAULT 0,
  recycling_guidance VARCHAR(500) NULL,
  status             ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE waste_scans (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id      INT UNSIGNED NOT NULL,
  image_path   VARCHAR(255) NOT NULL,
  result_item  VARCHAR(150) NOT NULL,
  category_id  INT UNSIGNED NULL,
  material     VARCHAR(80)  NULL,
  confidence   DECIMAL(5,2) NOT NULL DEFAULT 0,
  bin_type     VARCHAR(60)  NULL,
  advice       VARCHAR(500) NULL,
  tips         TEXT NULL,                       -- v2.2.1 JSON array of safety/environment tips
  recyclable   ENUM('yes','no','uncertain') NULL, -- v2.2.1 AI recyclable verdict for the item
  uncertain    TINYINT(1) NOT NULL DEFAULT 0,   -- v2.2.1 low-confidence flag (manual confirm suggested)
  status       ENUM('completed','failed','corrected') NOT NULL DEFAULT 'completed', -- v2.2.1
  corrected_category_id INT UNSIGNED NULL,      -- v2.2.1 user-confirmed/corrected category
  error_note   VARCHAR(255) NULL,               -- v2.2.1 provider failure reason (failed scans)
  mode         ENUM('demo','real') NOT NULL DEFAULT 'demo',
  provider     VARCHAR(40)  NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_scan_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_scan_cat  FOREIGN KEY (category_id) REFERENCES waste_categories(id) ON DELETE SET NULL,
  CONSTRAINT fk_scan_ccat FOREIGN KEY (corrected_category_id) REFERENCES waste_categories(id) ON DELETE SET NULL,
  INDEX idx_scan_user (user_id, created_at)
) ENGINE=InnoDB;

-- ---------- pickup workflow ----------
CREATE TABLE pickup_requests (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pickup_code      VARCHAR(30)  NOT NULL UNIQUE,
  user_id          INT UNSIGNED NOT NULL,
  organization_id  INT UNSIGNED NULL,
  category_id      INT UNSIGNED NOT NULL,
  estimated_weight DECIMAL(8,2) NOT NULL,
  preferred_date   DATE         NOT NULL,
  time_slot        VARCHAR(30)  NOT NULL,
  address_line     VARCHAR(255) NOT NULL,
  ward             VARCHAR(40)  NULL,
  city             VARCHAR(80)  NULL DEFAULT 'Patna',
  latitude         DECIMAL(10,7) NULL,
  longitude        DECIMAL(10,7) NULL,
  notes            VARCHAR(500) NULL,
  image_path       VARCHAR(255) NULL,
  status           ENUM('REQUESTED','ASSIGNED','ACCEPTED','ON_THE_WAY','ARRIVED','COLLECTED','COMPLETED','CANCELLED','REJECTED')
                   NOT NULL DEFAULT 'REQUESTED',
  cancelled_at     DATETIME NULL,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_pr_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_pr_org  FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE SET NULL,
  CONSTRAINT fk_pr_cat  FOREIGN KEY (category_id) REFERENCES waste_categories(id),
  INDEX idx_pr_user (user_id, status), INDEX idx_pr_status (status), INDEX idx_pr_date (preferred_date)
) ENGINE=InnoDB;

CREATE TABLE pickup_assignments (
  id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pickup_request_id INT UNSIGNED NOT NULL UNIQUE,
  collector_id      INT UNSIGNED NOT NULL,
  status            ENUM('ASSIGNED','ACCEPTED','ON_THE_WAY','ARRIVED','COLLECTED','COMPLETED','CANCELLED')
                    NOT NULL DEFAULT 'ASSIGNED',
  assigned_by       INT UNSIGNED NULL,
  assigned_at       DATETIME NULL,
  accepted_at       DATETIME NULL,
  started_at        DATETIME NULL,
  arrived_at        DATETIME NULL,
  collected_at      DATETIME NULL,
  completed_at      DATETIME NULL,
  actual_weight     DECIMAL(8,2) NULL,
  proof_image       VARCHAR(255) NULL,
  remarks           VARCHAR(300) NULL,
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_pa_pickup    FOREIGN KEY (pickup_request_id) REFERENCES pickup_requests(id) ON DELETE CASCADE,
  CONSTRAINT fk_pa_collector FOREIGN KEY (collector_id) REFERENCES users(id),
  INDEX idx_pa_collector (collector_id, status)
) ENGINE=InnoDB;

-- ---------- waste transactions (Waste Passport core) ----------
CREATE TABLE waste_transactions (
  id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  waste_id          VARCHAR(30)  NOT NULL UNIQUE,        -- PNV-2026-000001
  pickup_request_id INT UNSIGNED NULL UNIQUE,
  source_user_id    INT UNSIGNED NOT NULL,
  source_type       ENUM('CITIZEN','BUSINESS') NOT NULL DEFAULT 'CITIZEN',
  category_id       INT UNSIGNED NOT NULL,
  initial_weight    DECIMAL(8,2) NOT NULL,
  current_weight    DECIMAL(8,2) NOT NULL,
  current_stage     ENUM('CREATED','PICKUP_REQUESTED','COLLECTED','SORTED','PROCESSING','PROCESSED',
                         'RECYCLED','RECOVERED','COMPOSTED','REUSED','RESIDUAL_DISPOSAL')
                    NOT NULL DEFAULT 'COLLECTED',
  final_outcome     ENUM('RECYCLED','RECOVERED','COMPOSTED','REUSED','RESIDUAL_DISPOSAL') NULL,
  origin_address    VARCHAR(255) NULL,
  ward              VARCHAR(40)  NULL,
  latitude          DECIMAL(10,7) NULL,
  longitude         DECIMAL(10,7) NULL,
  facility_id       INT UNSIGNED NULL,
  completed_at      DATETIME NULL,
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_wt_pickup   FOREIGN KEY (pickup_request_id) REFERENCES pickup_requests(id) ON DELETE SET NULL,
  CONSTRAINT fk_wt_source   FOREIGN KEY (source_user_id) REFERENCES users(id),
  CONSTRAINT fk_wt_category FOREIGN KEY (category_id) REFERENCES waste_categories(id),
  CONSTRAINT fk_wt_facility FOREIGN KEY (facility_id) REFERENCES facilities(id) ON DELETE SET NULL,
  INDEX idx_wt_source (source_user_id), INDEX idx_wt_stage (current_stage),
  INDEX idx_wt_facility (facility_id), INDEX idx_wt_created (created_at)
) ENGINE=InnoDB;

CREATE TABLE waste_journey_events (
  id                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  waste_transaction_id INT UNSIGNED NOT NULL,
  event_type           VARCHAR(40)  NOT NULL,
  event_time           DATETIME     NOT NULL,
  location             VARCHAR(255) NULL,
  actor_id             INT UNSIGNED NULL,
  actor_role           VARCHAR(30)  NULL,
  facility_id          INT UNSIGNED NULL,
  quantity             DECIMAL(8,2) NULL,
  notes                VARCHAR(500) NULL,
  proof_image          VARCHAR(255) NULL,
  created_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_je_tx       FOREIGN KEY (waste_transaction_id) REFERENCES waste_transactions(id) ON DELETE CASCADE,
  CONSTRAINT fk_je_actor    FOREIGN KEY (actor_id) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_je_facility FOREIGN KEY (facility_id) REFERENCES facilities(id) ON DELETE SET NULL,
  INDEX idx_je_tx (waste_transaction_id, event_time)
) ENGINE=InnoDB;

-- ---------- reports / hotspots ----------
CREATE TABLE waste_reports (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  report_code      VARCHAR(30)  NOT NULL UNIQUE,
  user_id          INT UNSIGNED NULL,               -- NULL = guest report
  category_id      INT UNSIGNED NULL,
  description      VARCHAR(1000) NOT NULL,
  image_path       VARCHAR(255) NULL,
  address_line     VARCHAR(255) NOT NULL,
  ward             VARCHAR(40)  NULL,
  city             VARCHAR(80)  NULL DEFAULT 'Patna',
  latitude         DECIMAL(10,7) NULL,
  longitude        DECIMAL(10,7) NULL,
  status           ENUM('SUBMITTED','VERIFIED','ASSIGNED','IN_PROGRESS','RESOLVED','REJECTED')
                   NOT NULL DEFAULT 'SUBMITTED',
  assigned_to      INT UNSIGNED NULL,
  verified_at      DATETIME NULL,
  resolved_at      DATETIME NULL,
  resolution_notes VARCHAR(300) NULL,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_wr_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_wr_cat  FOREIGN KEY (category_id) REFERENCES waste_categories(id) ON DELETE SET NULL,
  CONSTRAINT fk_wr_col  FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_wr_status (status), INDEX idx_wr_ward (ward)
) ENGINE=InnoDB;

CREATE TABLE hotspot_scores (
  id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ward               VARCHAR(60) NOT NULL UNIQUE,
  latitude           DECIMAL(10,7) NULL,
  longitude          DECIMAL(10,7) NULL,
  report_count       INT NOT NULL DEFAULT 0,
  recent_reports     INT NOT NULL DEFAULT 0,
  unresolved_reports INT NOT NULL DEFAULT 0,
  estimated_volume_kg DECIMAL(10,2) NOT NULL DEFAULT 0,
  hotspot_score      INT NOT NULL DEFAULT 0,
  status             ENUM('LOW','MEDIUM','HIGH','CRITICAL') NOT NULL DEFAULT 'LOW',
  last_calculated_at DATETIME NULL
) ENGINE=InnoDB;

-- ---------- rewards / impact ----------
CREATE TABLE reward_rules (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code        VARCHAR(40)  NOT NULL UNIQUE,
  name        VARCHAR(120) NOT NULL,
  description VARCHAR(255) NULL,
  action_type VARCHAR(40)  NOT NULL,
  points      INT NOT NULL DEFAULT 0,
  status      ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_rr_action (action_type, status)
) ENGINE=InnoDB;

CREATE TABLE reward_transactions (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id        INT UNSIGNED NOT NULL,
  rule_id        INT UNSIGNED NOT NULL,
  points         INT NOT NULL,
  reason         VARCHAR(255) NOT NULL,
  reference_type VARCHAR(40)  NOT NULL,
  reference_id   INT UNSIGNED NOT NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  -- idempotency: one award per (user, rule, reference) – prevents duplicate rewards
  UNIQUE KEY uq_reward_once (user_id, rule_id, reference_type, reference_id),
  CONSTRAINT fk_rt_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_rt_rule FOREIGN KEY (rule_id) REFERENCES reward_rules(id),
  INDEX idx_rt_user (user_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE impact_factors (
  id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id         INT UNSIGNED NOT NULL UNIQUE,
  co2_kg_per_kg       DECIMAL(10,4) NOT NULL DEFAULT 0,
  water_l_per_kg      DECIMAL(10,4) NOT NULL DEFAULT 0,
  energy_kwh_per_kg   DECIMAL(10,4) NOT NULL DEFAULT 0,
  landfill_diverted_pct DECIMAL(5,2) NOT NULL DEFAULT 100,
  methodology_version VARCHAR(20) NOT NULL DEFAULT 'v1.0-estimate',
  status              ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_if_cat FOREIGN KEY (category_id) REFERENCES waste_categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE environmental_impacts (
  id                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  waste_transaction_id INT UNSIGNED NOT NULL UNIQUE,
  category_id          INT UNSIGNED NOT NULL,
  quantity             DECIMAL(8,2) NOT NULL,
  co2_saved_kg         DECIMAL(10,3) NOT NULL DEFAULT 0,
  water_saved_l        DECIMAL(10,2) NOT NULL DEFAULT 0,
  energy_saved_kwh     DECIMAL(10,3) NOT NULL DEFAULT 0,
  landfill_diverted_kg DECIMAL(10,3) NOT NULL DEFAULT 0,
  methodology_version  VARCHAR(20) NOT NULL,
  created_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_ei_tx  FOREIGN KEY (waste_transaction_id) REFERENCES waste_transactions(id) ON DELETE CASCADE,
  CONSTRAINT fk_ei_cat FOREIGN KEY (category_id) REFERENCES waste_categories(id),
  INDEX idx_ei_tx (waste_transaction_id)
) ENGINE=InnoDB;

-- ---------- notifications ----------
CREATE TABLE notifications (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id        INT UNSIGNED NOT NULL,
  type           VARCHAR(30)  NOT NULL DEFAULT 'GENERAL',
  title          VARCHAR(150) NOT NULL,
  message        VARCHAR(500) NOT NULL,
  reference_type VARCHAR(40)  NULL,
  reference_id   INT UNSIGNED NULL,
  is_read        TINYINT(1) NOT NULL DEFAULT 0,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_ntf_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_ntf_user (user_id, is_read, created_at)
) ENGINE=InnoDB;

-- ---------- learning ----------
CREATE TABLE articles (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title      VARCHAR(200) NOT NULL,
  slug       VARCHAR(220) NOT NULL UNIQUE,
  topic      VARCHAR(60)  NOT NULL,
  summary    VARCHAR(500) NOT NULL,
  content    TEXT NOT NULL,
  status     ENUM('PUBLISHED','DRAFT') NOT NULL DEFAULT 'DRAFT',
  author_id  INT UNSIGNED NULL,
  views      INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_art_author FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_art_topic (topic, status)
) ENGINE=InnoDB;

CREATE TABLE quizzes (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title          VARCHAR(160) NOT NULL,
  topic          VARCHAR(60)  NULL,
  description    VARCHAR(500) NULL,
  reward_points  INT NOT NULL DEFAULT 10,
  pass_score_pct TINYINT UNSIGNED NOT NULL DEFAULT 60,
  status         ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE quiz_questions (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  quiz_id       INT UNSIGNED NOT NULL,
  question      VARCHAR(400) NOT NULL,
  options       TEXT NOT NULL,               -- JSON array of strings
  correct_index TINYINT UNSIGNED NOT NULL DEFAULT 0,
  CONSTRAINT fk_qq_quiz FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE,
  INDEX idx_qq_quiz (quiz_id)
) ENGINE=InnoDB;

CREATE TABLE quiz_attempts (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  quiz_id        INT UNSIGNED NOT NULL,
  user_id        INT UNSIGNED NOT NULL,
  score_pct      TINYINT UNSIGNED NOT NULL,
  passed         TINYINT(1) NOT NULL DEFAULT 0,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_qa_quiz FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE,
  CONSTRAINT fk_qa_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_qa_user (user_id, quiz_id)
) ENGINE=InnoDB;

-- ---------- maps / routes ----------
CREATE TABLE map_locations (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  location_type ENUM('FACILITY','REPORT','PICKUP','HOTSPOT','WASTE') NOT NULL,
  reference_id  INT UNSIGNED NOT NULL,
  title         VARCHAR(160) NOT NULL,
  latitude      DECIMAL(10,7) NULL,
  longitude     DECIMAL(10,7) NULL,
  status        VARCHAR(30) NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ml_type (location_type, reference_id)
) ENGINE=InnoDB;

CREATE TABLE route_plans (
  id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  collector_id      INT UNSIGNED NOT NULL,
  plan_date         DATE NOT NULL,
  total_distance_km DECIMAL(8,2) NOT NULL DEFAULT 0,
  status            ENUM('ACTIVE','COMPLETED','CANCELLED') NOT NULL DEFAULT 'ACTIVE',
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_route_day (collector_id, plan_date),
  CONSTRAINT fk_rp_collector FOREIGN KEY (collector_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE route_stops (
  id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  route_plan_id     INT UNSIGNED NOT NULL,
  pickup_request_id INT UNSIGNED NOT NULL,
  stop_order        INT NOT NULL DEFAULT 1,
  distance_from_prev_km DECIMAL(8,2) NOT NULL DEFAULT 0,
  status            ENUM('PENDING','DONE','SKIPPED') NOT NULL DEFAULT 'PENDING',
  UNIQUE KEY uq_stop (route_plan_id, pickup_request_id),
  CONSTRAINT fk_rs_plan   FOREIGN KEY (route_plan_id) REFERENCES route_plans(id) ON DELETE CASCADE,
  CONSTRAINT fk_rs_pickup FOREIGN KEY (pickup_request_id) REFERENCES pickup_requests(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE vehicles (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  facility_id    INT UNSIGNED NULL,
  vehicle_number VARCHAR(30)  NOT NULL UNIQUE,
  vehicle_type   VARCHAR(30)  NULL,
  capacity_kg    DECIMAL(8,2) NULL,
  driver_name    VARCHAR(120) NULL,
  driver_phone   VARCHAR(20)  NULL,
  status         ENUM('ACTIVE','MAINTENANCE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_veh_fac FOREIGN KEY (facility_id) REFERENCES facilities(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------- system ----------
CREATE TABLE audit_logs (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NULL,
  action     VARCHAR(60)  NOT NULL,
  module     VARCHAR(40)  NOT NULL,
  record_id  INT UNSIGNED NULL,
  old_value  TEXT NULL,
  new_value  TEXT NULL,
  ip         VARCHAR(45)  NULL,
  user_agent VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_al_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_al_module (module, created_at), INDEX idx_al_action (action)
) ENGINE=InnoDB;

CREATE TABLE settings (
  setting_key   VARCHAR(60) PRIMARY KEY,
  setting_value VARCHAR(500) NOT NULL DEFAULT '',
  description   VARCHAR(255) NULL,
  setting_group VARCHAR(30) NULL,
  updated_by    INT NULL,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE login_attempts (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email        VARCHAR(190) NOT NULL,
  ip           VARCHAR(45)  NOT NULL,
  attempted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_la (ip, email, attempted_at)
) ENGINE=InnoDB;

CREATE TABLE password_resets (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,      -- sha256 of the emailed token
  expires_at DATETIME NOT NULL,
  used_at    DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_prst_user (user_id),
  CONSTRAINT fk_prst_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE verification_codes (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NOT NULL,
  channel    ENUM('MOBILE','EMAIL') NOT NULL,
  code_hash  CHAR(64) NOT NULL,             -- sha256 of the OTP / email token; plaintext never stored
  attempts   TINYINT UNSIGNED NOT NULL DEFAULT 0,
  expires_at DATETIME NOT NULL,
  consumed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_vcode_user (user_id, channel),
  INDEX idx_vcode_created (created_at),
  CONSTRAINT fk_vcode_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE user_sessions (
  session_id   VARCHAR(191) PRIMARY KEY,       -- PHP session id (post-regeneration)
  user_id      INT UNSIGNED NOT NULL,
  ip           VARCHAR(45)  NULL,
  user_agent   VARCHAR(255) NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  revoked_at   DATETIME NULL,                  -- set on logout / supersede / password reset / disable
  KEY idx_us_user (user_id, revoked_at),
  CONSTRAINT fk_us_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE id_sequences (
  year        SMALLINT UNSIGNED PRIMARY KEY,
  last_number INT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- v2.4.0 tracking tables (verbatim from upgrade-v2.4.0.sql so fresh installs match;
-- includes/schema_check.php verifies these and self-heals older installs)

CREATE TABLE IF NOT EXISTS driver_shifts (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    driver_user_id INT UNSIGNED NOT NULL,
    vehicle_id    INT UNSIGNED NOT NULL,
    started_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ended_at      DATETIME NULL,
    status        ENUM('ACTIVE','ENDED') NOT NULL DEFAULT 'ACTIVE',
    last_lat      DECIMAL(10,7) NULL,
    last_lng      DECIMAL(10,7) NULL,
    last_accuracy DECIMAL(7,2) NULL,
    last_speed    DECIMAL(6,2) NULL,
    last_heading  DECIMAL(5,1) NULL,
    last_ping_at  DATETIME NULL,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_shifts_driver_status (driver_user_id, status),
    INDEX idx_shifts_vehicle_status (vehicle_id, status),
    INDEX idx_shifts_last_ping (last_ping_at),
    CONSTRAINT fk_shift_driver FOREIGN KEY (driver_user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_shift_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS driver_locations (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    shift_id      INT UNSIGNED NOT NULL,
    driver_user_id INT UNSIGNED NOT NULL,
    vehicle_id    INT UNSIGNED NOT NULL,
    latitude      DECIMAL(10,7) NOT NULL,
    longitude     DECIMAL(10,7) NOT NULL,
    accuracy_m    DECIMAL(7,2) NULL,
    speed_mps     DECIMAL(6,2) NULL,
    heading_deg   DECIMAL(5,1) NULL,
    recorded_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_loc_shift_time (shift_id, recorded_at),
    INDEX idx_loc_vehicle_time (vehicle_id, recorded_at),
    INDEX idx_loc_driver (driver_user_id),
    CONSTRAINT fk_loc_shift FOREIGN KEY (shift_id) REFERENCES driver_shifts(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
