-- PUNARVA v2.2.5 upgrade — REAL VISION AI (APInex) round
-- Data-preserving: naya category WOOD (AI classification rules me wood/timber mandate) — existing rows untouched.
-- Idempotent-safe: INSERT ... WHERE NOT EXISTS pattern via INSERT IGNORE on unique code.
INSERT INTO waste_categories (code, name, description, bin_type, icon, color, is_recyclable, recycling_guidance, status)
SELECT 'WOOD','Wood','Wood, timber, plywood and wooden furniture waste.','Dry Waste (Blue bin)','bi-tree-fill','#8d6e63',1,'Reuse usable timber where possible; untreated wood can be chipped for mulch or composting. Painted/laminated wood goes to dry waste.','ACTIVE'
WHERE NOT EXISTS (SELECT 1 FROM waste_categories WHERE code = 'WOOD');

-- Settings consistency: Live AI provider default (idempotent; config.php key takes priority anyway)
INSERT INTO settings (setting_key, setting_value, setting_group, description)
SELECT 'ai_provider_live','openai','ai','Live AI provider (openai = APInex / OpenAI-compatible vision API)'
WHERE NOT EXISTS (SELECT 1 FROM settings WHERE setting_key = 'ai_provider_live');
