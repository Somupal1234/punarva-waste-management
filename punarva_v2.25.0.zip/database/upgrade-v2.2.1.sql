-- PUNARVA upgrade v2.2.1 — AI Waste Scanner: real vision providers + confirmation flow
-- Existing installs par chalein (fresh import ko iski zaroorat nahi — schema.sql pehle se naya hai).
ALTER TABLE waste_scans
  ADD COLUMN tips TEXT NULL AFTER advice,
  ADD COLUMN recyclable ENUM('yes','no','uncertain') NULL AFTER tips,
  ADD COLUMN uncertain TINYINT(1) NOT NULL DEFAULT 0 AFTER recyclable,
  ADD COLUMN status ENUM('completed','failed','corrected') NOT NULL DEFAULT 'completed' AFTER uncertain,
  ADD COLUMN corrected_category_id INT UNSIGNED NULL AFTER status,
  ADD COLUMN error_note VARCHAR(255) NULL AFTER corrected_category_id,
  ADD CONSTRAINT fk_scan_ccat FOREIGN KEY (corrected_category_id) REFERENCES waste_categories(id) ON DELETE SET NULL;
