-- ============================================================
-- PUNARVA v2.4.0 upgrade — Truck/Driver Live Tracking + Citizen report GPS/camera support
-- Data-preserving: only ADDs (columns/tables/links). No renames, no deletions.
-- Reuses existing tables: vehicles (truck registry), users (drivers = collector role),
-- waste_reports (statuses already SUBMITTED/VERIFIED/ASSIGNED/IN_PROGRESS/RESOLVED/REJECTED).
-- Idempotent: safe to run multiple times.
-- ============================================================

-- 1) Link collector LOGIN accounts to trucks (driver_name stays as display fallback)
ALTER TABLE vehicles
    ADD COLUMN IF NOT EXISTS driver_user_id INT UNSIGNED NULL AFTER driver_name,
    ADD INDEX IF NOT EXISTS idx_vehicles_driver_user (driver_user_id);

-- Assign seeded demo collectors to the two active trucks (idempotent)
UPDATE vehicles SET driver_user_id = 3 WHERE vehicle_number = 'BR01P-4412' AND driver_user_id IS NULL;
UPDATE vehicles SET driver_user_id = 6 WHERE vehicle_number = 'BR01P-4413' AND driver_user_id IS NULL;

-- 2) Shift registry: PUNCH IN / PUNCH OUT + latest cached position (fast admin map reads)
CREATE TABLE IF NOT EXISTS driver_shifts (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    driver_user_id INT UNSIGNED NOT NULL,
    vehicle_id    INT UNSIGNED NOT NULL,
    started_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ended_at      DATETIME NULL,
    status        ENUM('ACTIVE','ENDED') NOT NULL DEFAULT 'ACTIVE',
    last_lat      DECIMAL(10,7) NULL,
    last_lng      DECIMAL(10,7) NULL,
    last_accuracy DECIMAL(7,2) NULL,
    last_speed    DECIMAL(6,2) NULL,
    last_heading  DECIMAL(5,1) NULL,
    last_ping_at  DATETIME NULL,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_shifts_driver_status (driver_user_id, status),
    INDEX idx_shifts_vehicle_status (vehicle_id, status),
    INDEX idx_shifts_last_ping (last_ping_at),
    CONSTRAINT fk_shift_driver FOREIGN KEY (driver_user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_shift_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3) Location history (per shift breadcrumb; capped per shift by the service layer)
CREATE TABLE IF NOT EXISTS driver_locations (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    shift_id      INT UNSIGNED NOT NULL,
    driver_user_id INT UNSIGNED NOT NULL,
    vehicle_id    INT UNSIGNED NOT NULL,
    latitude      DECIMAL(10,7) NOT NULL,
    longitude     DECIMAL(10,7) NOT NULL,
    accuracy_m    DECIMAL(7,2) NULL,
    speed_mps     DECIMAL(6,2) NULL,
    heading_deg   DECIMAL(5,1) NULL,
    recorded_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_loc_shift_time (shift_id, recorded_at),
    INDEX idx_loc_vehicle_time (vehicle_id, recorded_at),
    INDEX idx_loc_driver (driver_user_id),
    CONSTRAINT fk_loc_shift FOREIGN KEY (shift_id) REFERENCES driver_shifts(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4) Citizen report: GPS accuracy + capture time (existing lat/lng columns reused)
ALTER TABLE waste_reports
    ADD COLUMN IF NOT EXISTS accuracy_m DECIMAL(7,2) NULL AFTER longitude,
    ADD COLUMN IF NOT EXISTS location_captured_at DATETIME NULL AFTER accuracy_m;
