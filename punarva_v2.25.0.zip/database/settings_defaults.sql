-- System Settings baseline (idempotent-ish: use ON DUPLICATE via unique key on setting_key)
-- Import AFTER schema.sql. Existing values are preserved.
USE punarva_db;
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('platform_name', 'PUNARVA', 'general', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('platform_tagline', 'From Waste to Worth', 'general', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('support_email', 'support@punarva.local', 'general', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('support_phone', '+91-90000-00000', 'general', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('default_city', 'Dumka', 'general', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('default_state', 'Jharkhand', 'general', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('default_country', 'India', 'general', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('default_language', 'en', 'localization', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('timezone', 'Asia/Kolkata', 'localization', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('date_format', 'd M Y', 'localization', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('time_format', '12', 'localization', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('number_format', 'international', 'localization', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('max_login_attempts', '5', 'security', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('login_lock_minutes', '15', 'security', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('session_idle_minutes', '30', 'security', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('password_min_length', '8', 'security', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('registration_enabled', '1', 'authentication', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('citizen_registration_enabled', '1', 'authentication', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('business_registration_enabled', '1', 'authentication', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('password_reset_enabled', '1', 'authentication', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('remember_me_enabled', '1', 'authentication', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('login_session_hours', '0', 'authentication', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('notifications_enabled', '1', 'notifications', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('notif_inapp', '1', 'notifications', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('notif_retention_days', '90', 'notifications', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('announcement_display', '1', 'notifications', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('maps_enabled', '1', 'integrations', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('qr_enabled', '1', 'integrations', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('public_tracking_enabled', '1', 'privacy', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('show_waste_id', '1', 'privacy', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('show_category', '1', 'privacy', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('show_weight', '1', 'privacy', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('show_timeline', '1', 'privacy', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('show_facility', '1', 'privacy', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('show_outcome', '1', 'privacy', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('show_impact', '1', 'privacy', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('maintenance_mode', '0', 'maintenance', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('maintenance_message', 'PUNARVA is undergoing scheduled maintenance. We will be back shortly.', 'maintenance', 'Baseline default') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);

-- v2.1.0 — verification & anti-abuse defaults
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('sms_provider', 'none', 'verification', 'SMS/OTP transport: none | log (DEV ONLY) | webhook') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('sms_webhook_url', '', 'verification', 'Generic HTTP SMS gateway URL (POSTs JSON {to,message})') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('otp_ttl_minutes', '10', 'verification', 'OTP validity in minutes') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('otp_max_attempts', '5', 'verification', 'Max OTP verify attempts per code') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('otp_resend_cooldown_seconds', '60', 'verification', 'Seconds before another OTP can be requested') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('otp_max_per_hour', '3', 'verification', 'Max OTP requests per user per hour') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('email_verification_provider', 'none', 'verification', 'Email transport: none | log (DEV ONLY) | smtp') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('smtp_host', '', 'verification', 'SMTP server host') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('smtp_port', '587', 'verification', 'SMTP server port (587 plain/STARTTLS, 465 SSL)') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('smtp_username', '', 'verification', 'SMTP username') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('smtp_password', '', 'verification', 'SMTP password') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('smtp_from_address', '', 'verification', 'From address for verification emails') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('smtp_from_name', 'PUNARVA', 'verification', 'From name for verification emails') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('registration_max_per_hour', '5', 'security', 'Max registrations per IP per hour') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);

-- v2.1.3 — session lifecycle defaults
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('sessions_epoch', '0', 'security', 'Force-logout-all marker: bumping this value invalidates every existing session') ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
