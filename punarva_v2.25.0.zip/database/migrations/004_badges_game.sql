-- PUNARVA v2.8.0 — Achievements rework: Rewards(Points) → Premium Badges + Real Impact + Game
-- Deprecation (NOT deletion): reward_rules / reward_transactions remain for historical integrity
-- but are no longer written by application code (RewardService is retired from all call sites).

-- ---------------------------------------------------------------- badges
USE punarva_db; -- v2.10.1: import-safe (fixes #1046 No database selected)
CREATE TABLE IF NOT EXISTS badges (
  id INT AUTO_INCREMENT PRIMARY KEY,
  badge_key VARCHAR(60) NOT NULL UNIQUE,
  name VARCHAR(80) NOT NULL,
  description VARCHAR(190) NOT NULL,
  icon VARCHAR(40) NOT NULL DEFAULT 'learner',        -- key into built-in SVG library (views/components/badge-icons.php)
  category ENUM('learning','real_impact') NOT NULL,
  criteria_type VARCHAR(40) NOT NULL,                 -- game_plays|game_accuracy|quiz_passed|pickups_completed|reports_verified|reports_resolved|recycling_completed|verified_activities
  criteria_value INT NOT NULL DEFAULT 1,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------- user_badges (unique => idempotent awards)
CREATE TABLE IF NOT EXISTS user_badges (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  badge_id INT NOT NULL,
  awarded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  source_type VARCHAR(40) NOT NULL DEFAULT 'system',  -- game|quiz|pickup|report|recycling|system
  source_id INT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_user_badge (user_id, badge_id),
  KEY idx_ub_user (user_id),
  KEY idx_ub_badge (badge_id),
  CONSTRAINT fk_ub_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_ub_badge FOREIGN KEY (badge_id) REFERENCES badges(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------- game results (SORT IT — PUNARVA)
CREATE TABLE IF NOT EXISTS game_results (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  items_total INT NOT NULL,
  items_correct INT NOT NULL,
  accuracy_pct DECIMAL(5,2) NOT NULL,
  duration_ms INT NOT NULL,
  mistakes_json TEXT NULL,                            -- [{item, picked}] for admin "common mistakes"
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_gr_user (user_id),
  KEY idx_gr_created (created_at),
  CONSTRAINT fk_gr_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------- game items (admin-managed mapping)
CREATE TABLE IF NOT EXISTS game_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  item_key VARCHAR(60) NOT NULL UNIQUE,
  emoji VARCHAR(16) NOT NULL DEFAULT '♻️',
  correct_bin ENUM('wet','dry','sanitary','special') NOT NULL,
  hint VARCHAR(190) NOT NULL DEFAULT '',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------- seed badges
INSERT INTO badges (badge_key, name, description, icon, category, criteria_type, criteria_value) VALUES
  ('waste_learner',       'Waste Learner',       'Complete your first SORT IT game round.',                 'learner',     'learning',    'game_plays',           1),
  ('sorting_pro',         'Sorting Pro',         'Score 80% or more accuracy in a SORT IT round.',          'sorting_pro', 'learning',    'game_accuracy',        80),
  ('segregation_master',  'Segregation Master',  'Achieve a perfect 100% round in SORT IT.',                'master',      'learning',    'game_accuracy',        100),
  ('quiz_champion',       'Waste Quiz Champion', 'Pass any PUNARVA quiz with 80% or more.',                 'champion',    'learning',    'quiz_passed',          80),
  ('first_pickup',        'First Pickup',        'Your first verified completed pickup.',                   'pickup',      'real_impact', 'pickups_completed',    1),
  ('pickup_participant',  'Pickup Participant',  'Three verified completed pickups.',                       'pickup',      'real_impact', 'pickups_completed',    3),
  ('waste_reporter',      'Waste Reporter',      'Your first verified waste report.',                       'reporter',    'real_impact', 'reports_verified',     1),
  ('recycling_contributor','Recycling Contributor','Your waste was processed at a verified facility.',       'recycle',     'real_impact', 'recycling_completed',  1),
  ('eco_contributor',     'Eco Contributor',     'Five verified real-world activities in total.',           'eco',         'real_impact', 'verified_activities',  5),
  ('community_contributor','Community Contributor','Ten verified real-world activities in total.',           'community',   'real_impact', 'verified_activities', 10)
ON DUPLICATE KEY UPDATE updated_at = updated_at;

-- ---------------------------------------------------------------- seed game items (bin mapping per PUNARVA bins)
INSERT INTO game_items (item_key, emoji, correct_bin, hint, sort_order) VALUES
  ('banana_peel',    '🍌', 'wet',      'Food and peels become wet waste — green bin, ideal for composting.', 1),
  ('food_leftovers', '🍽️', 'wet',      'Leftover food is wet waste — use the green bin.',                     2),
  ('tea_leaves',     '🫖', 'wet',      'Used tea leaves are wet waste — great for compost.',                  3),
  ('plastic_bottle', '🧴', 'dry',      'Empty plastic bottles are dry recyclables — blue bin.',               4),
  ('newspaper',      '📰', 'dry',      'Clean paper is dry waste — blue bin, keep it dry.',                   5),
  ('glass_bottle',   '🍾', 'dry',      'Glass is endlessly recyclable — blue/dry stream.',                    6),
  ('metal_can',      '🥫', 'dry',      'Metal cans are dry recyclables — blue bin.',                          7),
  ('sanitary_pad',   '🩹', 'sanitary', 'Sanitary waste goes in a red bag, never the open bin.',               8),
  ('diaper',         '🍼', 'sanitary', 'Diapers are sanitary waste — red bag, wrapped securely.',             9),
  ('used_tissue',    '🧻', 'sanitary', 'Used tissues are sanitary waste — red bag.',                         10),
  ('old_battery',    '🔋', 'special',  'Batteries need special care — authorised collector / yellow.',       11),
  ('tubelight',      '💡', 'special',  'Tubes and bulbs are domestic hazardous — yellow bin / drop-off.',    12)
ON DUPLICATE KEY UPDATE correct_bin = VALUES(correct_bin);

-- ---------------------------------------------------------------- settings: game switch
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES
  ('game_enabled', '1', 'achievements', 'Enable the SORT IT citizen game (Learning badges source)')
ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
