SET NAMES utf8mb4; -- client charset pin (prevents mojibake on phpMyAdmin imports)
USE punarva_db; -- import-safe (works even when no database is selected in phpMyAdmin)
-- PUNARVA v2.11.0 - FINAL BADGE SYSTEM: REAL IMPACT ONLY.
-- Removes the Learning badge category completely; ships the final 10 Real Impact badges.
-- Safety: additive/guarded + documented deletions only. reward_rules / reward_transactions
-- and all non-badge data are NOT touched. UNIQUE(user_id, badge_id) stays enforced.
-- Run AFTER deploying the v2.11.0 code (learning badge UI/evaluator are removed there).

-- ---- 1. Remove Learning badge awards + badges --------------------------------------
-- Learning achievements are no longer part of PUNARVA, so their awards have no valid
-- source anymore - removing them is required, not optional (documented deletion).
DELETE ub FROM user_badges ub JOIN badges b ON b.id = ub.badge_id WHERE b.category = 'learning';
DELETE FROM badges WHERE category = 'learning';

-- ---- 2. Final 10 Real Impact badges (6 re-confirmed + 4 new) ------------------------
INSERT INTO badges (badge_key, name, description, icon, category, criteria_type, criteria_value, is_active)
SELECT 'collection_champion', 'Collection Champion',
  'Complete 10 pickup requests - your neighbourhood''s collection champion.', 'trophy_truck',
  'real_impact', 'pickups_completed', 10, 1
WHERE NOT EXISTS (SELECT 1 FROM badges WHERE badge_key = 'collection_champion');

INSERT INTO badges (badge_key, name, description, icon, category, criteria_type, criteria_value, is_active)
SELECT 'community_protector', 'Community Protector',
  'Get 5 waste reports verified - a true protector of your community.', 'shield',
  'real_impact', 'reports_verified', 5, 1
WHERE NOT EXISTS (SELECT 1 FROM badges WHERE badge_key = 'community_protector');

INSERT INTO badges (badge_key, name, description, icon, category, criteria_type, criteria_value, is_active)
SELECT 'recycling_hero', 'Recycling Hero',
  'Reach 15 completed recycling transactions with facilities.', 'hero',
  'real_impact', 'recycling_completed', 15, 1
WHERE NOT EXISTS (SELECT 1 FROM badges WHERE badge_key = 'recycling_hero');

INSERT INTO badges (badge_key, name, description, icon, category, criteria_type, criteria_value, is_active)
SELECT 'impact_legend', 'PUNARVA Impact Legend',
  'Reach 50 verified activities - pickups, verified reports and recycling combined. A legend.', 'legend',
  'real_impact', 'verified_activities', 50, 1
WHERE NOT EXISTS (SELECT 1 FROM badges WHERE badge_key = 'impact_legend');

-- ---- 3. Align the 6 existing Real Impact badges with the final spec -----------------
-- (keys/criteria already match; descriptions tuned to the final wording, guarded + idempotent)
UPDATE badges SET name = 'First Contribution',
  description = 'Complete your first pickup request - your first real contribution.',
  icon = 'first'
 WHERE badge_key = 'first_contribution';
UPDATE badges SET name = 'Waste Reporter',
  description = 'Your first verified waste report - the city listens.', icon = 'reporter'
 WHERE badge_key = 'waste_reporter';
UPDATE badges SET name = 'Pickup Contributor',
  description = 'Complete 3 pickup requests in your neighbourhood.', icon = 'truck'
 WHERE badge_key = 'pickup_contributor';
UPDATE badges SET name = 'Recycling Champion',
  description = 'Reach 5 completed recycling transactions with facilities.', icon = 'recycle'
 WHERE badge_key = 'recycling_champion';
UPDATE badges SET name = 'Impact Maker',
  description = 'Reach 10 verified PUNARVA activities - pickups, verified reports and recycling combined.',
  icon = 'globe'
 WHERE badge_key = 'impact_maker';
UPDATE badges SET name = 'Waste Sorter',
  description = 'Sort 10 items correctly with verified scans.', icon = 'sorter'
 WHERE badge_key = 'waste_sorter';

-- ---- 4. No strays: the badge table must hold EXACTLY the final 10 Real Impact badges --
DELETE b FROM badges b
LEFT JOIN (
  SELECT 'first_contribution' k UNION SELECT 'waste_reporter' UNION SELECT 'pickup_contributor'
  UNION SELECT 'recycling_champion' UNION SELECT 'impact_maker' UNION SELECT 'waste_sorter'
  UNION SELECT 'collection_champion' UNION SELECT 'community_protector'
  UNION SELECT 'recycling_hero' UNION SELECT 'impact_legend'
) keep ON keep.k = b.badge_key
WHERE keep.k IS NULL;
DELETE ub FROM user_badges ub LEFT JOIN badges b ON b.id = ub.badge_id WHERE b.id IS NULL;

-- ---------------------------------------------------------------- 5. DDL normalization
-- Drop the retired 'learning' enum value and the 'learner' icon default so the
-- schema itself matches the Real-Impact-only system. Safe: all learning rows were
-- deleted above; re-running is a no-op (same definition re-applied).
ALTER TABLE badges MODIFY category ENUM('real_impact') NOT NULL;
ALTER TABLE badges MODIFY icon VARCHAR(40) NOT NULL DEFAULT 'first';
