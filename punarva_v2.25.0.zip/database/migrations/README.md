# PUNARVA — Database Migrations (v2.5.0)

## Strategy (safe by design)
- The existing database is **never** reset or auto-modified by the app.
- Legacy `database/upgrade-v*.sql` files remain exactly as shipped; on older installs
  they may already have been applied (the app's schema self-heal in v2.4.2+ verifies
  required objects via `information_schema` and only applies the SHIPPED v2.4.0 file
  when objects are actually missing — see `includes/schema_check.php`).
- New changes go into numbered files here and are applied **manually**
  (phpMyAdmin / `mysql < file.sql`) after taking a backup.

## Import-safe (v2.10.1)
Migrations 002-005 include `USE punarva_db;` — they run correctly even when imported
from phpMyAdmin's server-level Import page (fixes `#1046 No database selected`).
Import them **in order 002 -> 003 -> 004 -> 005**, once. They are idempotent and
converge to the same result even if re-imported.

## 006_real_impact_only.sql (v2.11.0 — Final Badge System)
Replaces the Learning + Real-Impact badge set with EXACTLY the 10 Real Impact badges
(no learning badges, no game/quiz criteria — `UNIQUE(user_id, badge_id)` and all
reward tables / historical rows untouched; the deletion of learning badge rows is the
documented requirement of v2.11.0). Also normalizes the `badges` DDL:
`category ENUM('real_impact')`, icon default `first`.
- Includes `USE punarva_db;` + `SET NAMES utf8mb4;` — import-safe at phpMyAdmin's
  server level; string literals are pure ASCII (no charset mojibake).
- Idempotent & convergent: re-importing is a no-op; a fresh install
  (schema -> seed -> settings -> 001..006) converges to the same final state
  (40 tables, 10 real_impact badges, category enum `real_impact` only).


## Tracking
`002_create_schema_migrations.sql` creates the `schema_migrations` tracking table
(idempotent). After applying a migration manually, record it:

    INSERT INTO schema_migrations (migration, applied_at) VALUES ('002_create_schema_migrations.sql', NOW());

## Backup FIRST — always
Before ANY schema-changing statement (XAMPP shell):

    mysqldump -u root -p punarva_db > punarva_backup_$(date +%F).sql

Restore (only if needed):

    mysql -u root -p punarva_db < punarva_backup_YYYY-MM-DD.sql

## Rules
1. Never DROP DATABASE / TRUNCATE production tables.
2. Only additive, idempotent statements (`ADD COLUMN IF NOT EXISTS`, `CREATE TABLE IF NOT EXISTS`).
3. Verify with `DESCRIBE` / `SHOW TABLES` after each step.
4. Never place data-destroying statements in a migration file.

## 007_fix_pickup_completed_at.sql (v2.11.1 — bug fix)
Back-fills `pickup_assignments.completed_at` for rows completed while the app had the
missing-timestamp bug (Collection History showed "—" for date). Uses ONLY real existing
timestamps (`collected_at`, falling back to `updated_at`) — nothing is invented.
Guarded (`completed_at IS NULL`) → re-running is a no-op. Creates/deletes nothing.

## 008_settings_cleanup.sql (v2.12.0 — System Settings cleanup & hardening)
Deletes 13 OBSOLETE setting rows only (see file header for the per-key rationale):
CSRF/HttpOnly/session-regeneration/secure-cookies/SameSite/security-logging are now
ALWAYS ENFORCED in code (read-only indicators in Admin → System Settings), and the
public_website/login toggles + settings-announcement content are removed per the
settings-cleanup spec. No other data is touched. Idempotent (re-run = no-op).
Announcement content now lives in the Announcements module (Admin → Announcements);
System Settings keeps only the dashboard-banner display switch.

## 009_announcements_module.sql (v2.13.0 — Announcements module + demo cleanup)
Creates the `announcements` table (draft/published, optional publish + expiry windows,
target roles) — announcement content is now a REAL module instead of seed/demo
notification rows. Deletes the seed-only demo announcement
("Doorstep plastic drive this weekend…") from `notifications` on existing installs —
it was fake demo content, never admin-created. Genuine admin announcements and all
user/pickup/waste/reward data are untouched. Idempotent (re-run = no-op).
Fresh installs: seed.sql no longer contains the demo row.

### 010_remove_ai_scanner.sql (v2.14.0)
- Extends `waste_scans.mode` to ENUM('demo','real','manual') (guarded — runs once).
- Deletes the retired scanner settings: `ai_scanner_enabled`, `ai_confidence_warn`, `ai_local_port`, `ai_local_timeout`, `ai_provider_live`.
- **Never touches historical `waste_scans` rows** — old provider/ai_model/confidence values stay exactly as recorded (admin Scan Log labels them HISTORICAL).
- Re-run safe (idempotent guards + idempotent DELETE).

### 011_settings_minimal_security.sql (v2.15.0)
- Deletes the 7 retired security TOGGLE rows (brute-force / rate-limiting / login-activity-logging / 4 password-complexity switches) — these protections are now unconditional in code (AuthService).
- Normalizes the 4 configurable thresholds into their validated ranges (attempts 3–10, lock 1–1440 min, idle 5–1440 min, password length 8–128).
- Never touches user data. Idempotent (re-run = no-op).
