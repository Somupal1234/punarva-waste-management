USE punarva_db; -- import-safe (works even when no database is selected in phpMyAdmin)
SET NAMES utf8mb4;

-- ----------------------------------------------------------------------------
-- PUNARVA v2.12.0 — System Settings cleanup (security hardening)
--
-- Removes OBSOLETE setting rows only. No other data is touched — users, pickups,
-- waste passports, reports, rewards, badges and audit logs are fully preserved.
--
-- Why each key is obsolete now:
--   csrf_enabled              → CSRF is now ALWAYS enforced (no toggle can disable it)
--   httponly_cookies          → HttpOnly is always on
--   session_id_regeneration  → regeneration always on (login/privilege change)
--   secure_cookies            → Secure flag is applied automatically under HTTPS
--   samesite_policy           → SameSite=Lax is fixed policy (no None option)
--   security_logging          → security-sensitive events are always audit-logged
--   public_website_enabled    → removed control (Maintenance Mode covers availability)
--   login_enabled             → removed control (per spec: no verified requirement)
--   site_announcement         → announcement content moved to the Announcements module
--   email_verification        → reserved switch removed (no SMTP in local mode; the
--   mobile_verification         status indicators in Integrations cover Email/SMS)
--   notif_email / notif_sms   → same as above
--
-- Idempotent: re-running is a no-op. Application defaults are hardcoded after v2.12.0,
-- so deleting the rows changes nothing at runtime.
-- ----------------------------------------------------------------------------

DELETE FROM settings WHERE setting_key IN (
  'csrf_enabled', 'httponly_cookies', 'session_id_regeneration', 'secure_cookies',
  'samesite_policy', 'security_logging', 'public_website_enabled', 'login_enabled',
  'site_announcement', 'email_verification', 'mobile_verification',
  'notif_email', 'notif_sms'
);
