-- PUNARVA migration 003 — AI scan metadata for the ₹0 local AI scanner (v2.6.0)
-- Additive + idempotent only. Apply manually AFTER a backup (see README in this folder).

USE punarva_db; -- v2.10.1: import-safe (fixes #1046 No database selected)
ALTER TABLE waste_scans ADD COLUMN IF NOT EXISTS ai_model VARCHAR(80) NULL AFTER provider;

-- confidence warn threshold + local inference service settings (defaults; admin-editable)
INSERT IGNORE INTO settings (setting_key, setting_value, description, setting_group) VALUES
  ('ai_confidence_warn', '55', 'Below this confidence % the scanner asks for manual category selection', 'ai'),
  ('ai_local_port', '8761', 'Port of the local AI inference service (127.0.0.1 only)', 'ai'),
  ('ai_local_timeout', '12', 'Seconds to wait for a local AI inference response', 'ai');

-- record the migration (tracking table from 002)
CREATE TABLE IF NOT EXISTS schema_migrations (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    migration   VARCHAR(190) NOT NULL,
    applied_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    applied_by  VARCHAR(80) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_migration (migration)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO schema_migrations (migration, applied_by) VALUES ('003_add_ai_meta.sql', 'manual');
