-- 010_remove_ai_scanner.sql — v2.14.0
-- Scanner becomes fully MANUAL (user selects the category; no AI, no external API).
-- HISTORICAL waste_scans rows are NEVER rewritten: old provider/ai_model/confidence
-- values stay exactly as recorded. Safe to re-run (idempotent guards).
USE punarva_db;

-- 1) allow mode='manual' for new records (historical 'demo'/'real' values remain valid)
SET @emode := (SELECT COLUMN_TYPE FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = 'punarva_db' AND TABLE_NAME = 'waste_scans' AND COLUMN_NAME = 'mode');
SET @sql := IF(@emode = "enum('demo','real')",
  'ALTER TABLE waste_scans MODIFY mode ENUM(''demo'',''real'',''manual'') NOT NULL DEFAULT ''demo''',
  'SELECT 1');
PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;

-- 2) retire scanner AI settings (keys only; user data untouched)
DELETE FROM settings WHERE setting_key IN
  ('ai_scanner_enabled','ai_confidence_warn','ai_local_port','ai_local_timeout','ai_provider_live');

SELECT '010 OK: scanner is manual; historical scans preserved' AS result;
