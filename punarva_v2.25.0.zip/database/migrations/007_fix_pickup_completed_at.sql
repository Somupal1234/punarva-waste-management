USE punarva_db; -- import-safe (works even when no database is selected in phpMyAdmin)
SET NAMES utf8mb4;

-- ----------------------------------------------------------------------------
-- PUNARVA v2.11.1 — Data repair: pickup completion timestamps
--
-- Bug: PickupService::setStatus() never wrote pickup_assignments.completed_at when a
-- collector completed a pickup (the COMPLETED case was missing from the transition
-- switch). Rows completed through the app therefore show "—" in Collection History.
-- Fixed in code (v2.11.1); this migration back-fills the historical rows using ONLY
-- real timestamps that already exist (collected_at, falling back to updated_at) —
-- nothing is invented. Re-running is a no-op (guard: completed_at IS NULL).
-- No rows are created or deleted; all other data is untouched.
-- ----------------------------------------------------------------------------

UPDATE pickup_assignments
SET completed_at = COALESCE(collected_at, updated_at)
WHERE status = 'COMPLETED' AND completed_at IS NULL;

-- pickup_requests has no completed_at column by design (completion time lives on the
-- assignment) — nothing to repair there.
