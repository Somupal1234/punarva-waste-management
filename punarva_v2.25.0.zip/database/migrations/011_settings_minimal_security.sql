-- 011_settings_minimal_security.sql — v2.15.0
-- System Settings redesign: security protections become ALWAYS ENFORCED (no switches).
-- Deletes only the retired TOGGLE rows; configurable thresholds and all user data stay.
-- Re-run safe (idempotent). Applies to existing installs; fresh installs never get these rows.
USE punarva_db;

-- 1) always-enforced protections: switch rows retired (behaviour now unconditional in code)
DELETE FROM settings WHERE setting_key IN
  ('brute_force_protection','rate_limiting','login_activity_logging',
   'password_require_uppercase','password_require_lowercase',
   'password_require_number','password_require_special');

-- 2) bring configurable thresholds inside their new validated ranges (defaults per spec)
UPDATE settings SET setting_value = '5'  WHERE setting_key = 'max_login_attempts'  AND (setting_value + 0 < 3   OR setting_value + 0 > 10);
UPDATE settings SET setting_value = '15' WHERE setting_key = 'login_lock_minutes'  AND (setting_value + 0 < 1   OR setting_value + 0 > 1440);
UPDATE settings SET setting_value = '30' WHERE setting_key = 'session_idle_minutes' AND (setting_value + 0 < 5   OR setting_value + 0 > 1440);
UPDATE settings SET setting_value = '8'  WHERE setting_key = 'password_min_length'  AND (setting_value + 0 < 8   OR setting_value + 0 > 128);

SELECT '011 OK: security always-enforced; thresholds normalized' AS result;
