-- PUNARVA migration 002 — migration tracking table (idempotent, safe to re-run)
USE punarva_db; -- v2.10.1: import-safe (fixes #1046 No database selected)
CREATE TABLE IF NOT EXISTS schema_migrations (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    migration   VARCHAR(190) NOT NULL,
    applied_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    applied_by  VARCHAR(80) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_migration (migration)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Record this migration itself once applied:
INSERT IGNORE INTO schema_migrations (migration, applied_by)
VALUES ('002_create_schema_migrations.sql', 'manual');
