USE punarva_db; -- v2.10.1: import-safe (fixes #1046 No database selected)
SET NAMES utf8mb4;

-- PUNARVA v2.10.0 — Controlled game removal + premium achievement badge set.
-- Run AFTER deploying the v2.10.0 code (game pages/APIs are removed there first).
-- Safety: backup taken before this migration. reward_rules / reward_transactions and
-- all non-game data are NOT touched. badge ids are preserved where badges survive,
-- so valid user_badges awards keep their history.

-- ---- 1. Game database structures (§2) -------------------------------------------------
DROP TABLE IF EXISTS game_results;
DROP TABLE IF EXISTS game_items;
DELETE FROM settings WHERE setting_key = 'game_enabled';

-- ---- 2. Game-era badge awards + badges (awards that were only valid via the game) ------
DELETE ub FROM user_badges ub JOIN badges b ON b.id = ub.badge_id
 WHERE b.criteria_type IN ('game_plays', 'game_accuracy');
DELETE FROM badges WHERE criteria_type IN ('game_plays', 'game_accuracy');

-- ---- 3. Retire community_contributor (superseded by Impact Maker; 0 awards in baseline).
-- Guarded delete keeps it safe on any install that somehow has awards: they are moved
-- conceptually to impact_maker only if the user already meets its criteria (no fake awards).
DELETE ub FROM user_badges ub JOIN badges b ON b.id = ub.badge_id WHERE b.badge_key = 'community_contributor';
DELETE FROM badges WHERE badge_key = 'community_contributor';

-- ---- 4. Re-key / rename / re-criteria existing badges (ids + valid awards preserved) ----
-- v2.10.1: each rename is guarded (only when the NEW key does not exist yet), so this
-- migration is safe to re-run and converges even if 004 was imported again afterwards.
UPDATE badges SET badge_key = 'eco_starter', name = 'Eco Starter',
  description = 'Complete your first waste quiz and start your learning journey.',
  icon = 'sprout', criteria_type = 'quiz_count', criteria_value = 1
 WHERE badge_key = 'quiz_champion'
   AND NOT EXISTS (SELECT 1 FROM (SELECT 1 FROM badges WHERE badge_key = 'eco_starter') g);

UPDATE badges SET badge_key = 'first_contribution', name = 'First Contribution',
  description = 'Complete your first pickup request — your first real contribution.',
  icon = 'first', criteria_type = 'pickups_completed', criteria_value = 1
 WHERE badge_key = 'first_pickup'
   AND NOT EXISTS (SELECT 1 FROM (SELECT 1 FROM badges WHERE badge_key = 'first_contribution') g);

UPDATE badges SET badge_key = 'pickup_contributor', name = 'Pickup Contributor',
  description = 'Complete 3 pickup requests in your neighbourhood.',
  icon = 'truck', criteria_type = 'pickups_completed', criteria_value = 3
 WHERE badge_key = 'pickup_participant'
   AND NOT EXISTS (SELECT 1 FROM (SELECT 1 FROM badges WHERE badge_key = 'pickup_contributor') g);

UPDATE badges SET badge_key = 'recycling_champion', name = 'Recycling Champion',
  description = 'Reach 5 completed recycling transactions with facilities.',
  icon = 'recycle', criteria_type = 'recycling_completed', criteria_value = 5
 WHERE badge_key = 'recycling_contributor'
   AND NOT EXISTS (SELECT 1 FROM (SELECT 1 FROM badges WHERE badge_key = 'recycling_champion') g);

UPDATE badges SET badge_key = 'impact_maker', name = 'Impact Maker',
  description = 'Reach 10 verified PUNARVA activities — pickups, verified reports and recycling combined.',
  icon = 'globe', criteria_type = 'verified_activities', criteria_value = 10
 WHERE badge_key = 'eco_contributor'
   AND NOT EXISTS (SELECT 1 FROM (SELECT 1 FROM badges WHERE badge_key = 'impact_maker') g);

-- v2.10.1: remove stray old-key rows resurrected by a 004 re-import (their target badge
-- already exists). Their awards (if any) are removed first; the real badge stays.
DELETE ub FROM user_badges ub
JOIN badges b1 ON b1.id = ub.badge_id
JOIN badges b2 ON b2.badge_key = CASE b1.badge_key
    WHEN 'quiz_champion'       THEN 'eco_starter'
    WHEN 'first_pickup'        THEN 'first_contribution'
    WHEN 'pickup_participant'  THEN 'pickup_contributor'
    WHEN 'recycling_contributor' THEN 'recycling_champion'
    WHEN 'eco_contributor'     THEN 'impact_maker'
    ELSE NULL END;

DELETE b1 FROM badges b1
JOIN badges b2 ON b2.badge_key = CASE b1.badge_key
    WHEN 'quiz_champion'       THEN 'eco_starter'
    WHEN 'first_pickup'        THEN 'first_contribution'
    WHEN 'pickup_participant'  THEN 'pickup_contributor'
    WHEN 'recycling_contributor' THEN 'recycling_champion'
    WHEN 'eco_contributor'     THEN 'impact_maker'
    ELSE NULL END;

-- ---- 5. New badges (criteria use ONLY real PUNARVA data) --------------------------------
INSERT INTO badges (badge_key, name, description, icon, category, criteria_type, criteria_value, is_active)
SELECT 'waste_wise', 'Waste Wise',
  'Pass 3 waste quizzes — build lasting segregation knowledge.', 'wise',
  'learning', 'quiz_count', 3, 1
WHERE NOT EXISTS (SELECT 1 FROM badges WHERE badge_key = 'waste_wise');

INSERT INTO badges (badge_key, name, description, icon, category, criteria_type, criteria_value, is_active)
SELECT 'green_learner', 'Green Learner',
  'Score at least 80% in any waste quiz.', 'learner',
  'learning', 'quiz_passed', 80, 1
WHERE NOT EXISTS (SELECT 1 FROM badges WHERE badge_key = 'green_learner');

INSERT INTO badges (badge_key, name, description, icon, category, criteria_type, criteria_value, is_active)
SELECT 'recycling_guide', 'Recycling Guide',
  'Score a perfect 100% in any waste quiz — you can now guide others.', 'guide',
  'learning', 'quiz_passed', 100, 1
WHERE NOT EXISTS (SELECT 1 FROM badges WHERE badge_key = 'recycling_guide');

INSERT INTO badges (badge_key, name, description, icon, category, criteria_type, criteria_value, is_active)
SELECT 'sustainability_explorer', 'Sustainability Explorer',
  'Classify 5 items with the waste scanner — learn by doing.', 'explorer',
  'learning', 'scan_count', 5, 1
WHERE NOT EXISTS (SELECT 1 FROM badges WHERE badge_key = 'sustainability_explorer');

INSERT INTO badges (badge_key, name, description, icon, category, criteria_type, criteria_value, is_active)
SELECT 'waste_sorter', 'Waste Sorter',
  'Sort 10 items correctly with verified scans.', 'sorter',
  'real_impact', 'scan_count', 10, 1
WHERE NOT EXISTS (SELECT 1 FROM badges WHERE badge_key = 'waste_sorter');

-- ---- 6. Integrity: badge_key must never duplicate (§20) ---------------------------------
ALTER TABLE badges ADD UNIQUE KEY IF NOT EXISTS uq_badges_key (badge_key);
