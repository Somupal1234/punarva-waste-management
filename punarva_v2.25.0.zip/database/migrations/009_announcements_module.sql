USE punarva_db; -- import-safe (works even when no database is selected in phpMyAdmin)
SET NAMES utf8mb4;

-- ----------------------------------------------------------------------------
-- PUNARVA v2.13.0 — Announcements module + demo announcement cleanup
--
-- 1) NEW TABLE `announcements`: real announcement management (draft / scheduled /
--    published, optional publish + expiry dates, target roles). Replaces the old
--    pattern where announcement CONTENT was stored only as per-user notification
--    rows. Historical notification rows are NOT deleted (user data is preserved).
--
-- 2) DEMO CONTENT REMOVAL (documented deletion): the seed-only demo announcement
--    "Doorstep plastic drive this weekend" is deleted from `notifications` on
--    existing installs. This row came from seed.sql (demo data), was never created
--    by an administrator, and appears as a fake announcement in the admin panel.
--    Genuine admin-created announcements (any other title/content) are NOT touched.
--    seed.sql no longer contains this demo row, so fresh installs stay clean.
--
-- Idempotent: CREATE TABLE IF NOT EXISTS + exact-match DELETE are safe to re-run.
-- No user, pickup, waste, reward or badge data is touched.
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS announcements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(120) NOT NULL,
  message VARCHAR(500) NOT NULL,
  status ENUM('draft','published') NOT NULL DEFAULT 'draft',
  publish_at DATETIME NULL,                -- NULL = immediately when published
  expires_at DATETIME NULL,                -- NULL = never expires
  target_roles VARCHAR(120) NOT NULL DEFAULT 'ALL', -- 'ALL' or comma-separated role codes
  created_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Demo announcement cleanup (exact match with the seed demo content only)
DELETE FROM notifications
WHERE type = 'ANNOUNCEMENT'
  AND title = 'Doorstep plastic drive this weekend'
  AND message LIKE 'Hand over clean plastic waste this Saturday%';
