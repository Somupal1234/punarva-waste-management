-- ============================================================
-- PUNARVA upgrade: v2.0.x → v2.1.0 (Genuine User Data & Verification)
-- Run this on an EXISTING punarva_db to upgrade WITHOUT losing data.
-- Fresh installs should use schema.sql + seed.sql + settings_defaults.sql instead.
-- Idempotent where possible; safe to re-run (checks before altering).
-- ============================================================

-- 1) Normalize existing phone numbers to canonical 10-digit (strips +91/0/spaces/dashes)
UPDATE users
   SET phone = SUBSTRING(REGEXP_REPLACE(phone, '[^0-9]', ''), -10)
 WHERE phone IS NOT NULL AND phone <> '';

-- 2) Phone column: strict 10-digit, UNIQUE, + verification columns
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'phone'
               AND CHARACTER_MAXIMUM_LENGTH = 10);
SET @sql := IF(@col = 0,
  'ALTER TABLE users MODIFY phone VARCHAR(10) NULL DEFAULT NULL',
  'SELECT ''users.phone already VARCHAR(10)'' AS note');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND INDEX_NAME = 'uq_users_phone');
SET @sql := IF(@idx = 0,
  'ALTER TABLE users ADD UNIQUE KEY uq_users_phone (phone)',
  'SELECT ''uq_users_phone already exists'' AS note');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'phone_verified');
SET @sql := IF(@col = 0,
  'ALTER TABLE users ADD COLUMN phone_verified TINYINT(1) NOT NULL DEFAULT 0 AFTER phone, ADD COLUMN phone_verified_at DATETIME NULL DEFAULT NULL AFTER phone_verified',
  'SELECT ''phone_verified already exists'' AS note');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'email_verified');
SET @sql := IF(@col = 0,
  'ALTER TABLE users ADD COLUMN email_verified TINYINT(1) NOT NULL DEFAULT 0 AFTER email, ADD COLUMN email_verified_at DATETIME NULL DEFAULT NULL AFTER email_verified',
  'SELECT ''email_verified already exists'' AS note');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- 3) verification_codes table (hashed OTP / email-link storage)
CREATE TABLE IF NOT EXISTS verification_codes (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  channel     ENUM('MOBILE','EMAIL') NOT NULL,
  code_hash   CHAR(64) NOT NULL,
  attempts    TINYINT UNSIGNED NOT NULL DEFAULT 0,
  expires_at  DATETIME NOT NULL,
  consumed_at DATETIME NULL DEFAULT NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_vcode_user (user_id, channel),
  KEY idx_vcode_created (created_at),
  CONSTRAINT fk_vcode_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4) Verification & anti-abuse settings (adds missing rows only; never overwrites your values)
INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES
  ('sms_provider', 'none', 'verification', 'SMS/OTP transport: none | log (DEV ONLY) | webhook'),
  ('sms_webhook_url', '', 'verification', 'Generic HTTP SMS gateway URL (POSTs JSON {to,message})'),
  ('otp_ttl_minutes', '10', 'verification', 'OTP validity in minutes'),
  ('otp_max_attempts', '5', 'verification', 'Max OTP verify attempts per code'),
  ('otp_resend_cooldown_seconds', '60', 'verification', 'Seconds before another OTP can be requested'),
  ('otp_max_per_hour', '3', 'verification', 'Max OTP requests per user per hour'),
  ('email_verification_provider', 'none', 'verification', 'Email transport: none | log (DEV ONLY) | smtp'),
  ('smtp_host', '', 'verification', 'SMTP server host'),
  ('smtp_port', '587', 'verification', 'SMTP server port (587 plain/STARTTLS, 465 SSL)'),
  ('smtp_username', '', 'verification', 'SMTP username'),
  ('smtp_password', '', 'verification', 'SMTP password'),
  ('smtp_from_address', '', 'verification', 'From address for verification emails'),
  ('smtp_from_name', 'PUNARVA', 'verification', 'From name for verification emails'),
  ('registration_max_per_hour', '5', 'security', 'Max registrations per IP per hour')
ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);
