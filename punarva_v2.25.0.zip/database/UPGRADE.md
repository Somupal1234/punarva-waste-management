# PUNARVA — DB IMPORT GUIDE (हर version के साथ updated)

> **सवाल: DB import करना है या नहीं?**
> उत्तर हमेशा नीचे की table में — नया version install करते समय **सिर्फ वही migration files import करनी हैं जो आपके पिछले version के बाद आई हैं** (हर migration एक ही बार)।
> Schema/seed/settings_defaults **सिर्फ fresh install** (नया/खाली database) पर।

---

## ⚡ Upgrade paths (सबसे common cases)

| आपका पुराना version | नया version | Import करनी हैं |
|---|---|---|
| v2.12.0 | v2.13.0 | **सिर्फ `009_announcements_module.sql`** |
| v2.11.1 | v2.12.0+ | `008_settings_cleanup.sql` → `009_announcements_module.sql` |
| v2.11.0 | v2.12.0+ | `007` → `008` → `009` |
| v2.11.0 | v2.12.0 | `007_fix_pickup_completed_at.sql` → `008_settings_cleanup.sql` |
| v2.10.x | v2.12.0+ | `006` → `007` → `008` → `009` |
| v2.9.x या पुराना | v2.12.0+ | `003` → `004` → `005` → `006` → `007` → `008` → `009` (order में) |
| कुछ भी नहीं (fresh) | ताज़ा version | नीचे "Fresh Install" देखें |

## 🆕 Fresh Install (नया database / पहली बार)

phpMyAdmin में **order से** import करें (server-level Import भी चलेगा — files में `USE punarva_db;` है):

1. `database/schema.sql` ⚠️ *(यह पुराना punarva_db DROP करके नया बनाता है — सिर्फ fresh install पर!)*
2. `database/seed.sql`
3. `database/settings_defaults.sql`
4. `database/migrations/001_initial_baseline.sql` (marker, कुछ नहीं बदलता)
5. `database/migrations/002_create_schema_migrations.sql`
6. `database/migrations/003_add_ai_meta.sql`
7. `database/migrations/004_badges_game.sql`
8. `database/migrations/005_game_removal_badges.sql`
9. `database/migrations/006_real_impact_only.sql`
10. `database/migrations/007_fix_pickup_completed_at.sql`
11. `database/migrations/008_settings_cleanup.sql`
12. `database/migrations/009_announcements_module.sql`

**Expected result:** 41 tables (incl. `announcements`) · 10 badges (सभी Real Impact) · 8 demo users · 67 settings · 0 user_badges · कोई demo announcement नहीं

---

## 📦 Migration → Version (कौन सी file किस version में आई)

| Migration | आया किस version में | क्या करती है |
|---|---|---|
| `009_announcements_module.sql` | **v2.13.0** | announcements table + demo announcement हटाना |
| `008_settings_cleanup.sql` | v2.12.0 | 13 obsolete settings rows delete (security hardening) |
| `007_fix_pickup_completed_at.sql` | v2.11.1 | पुरानी completed pickups की date back-fill |
| `006_real_impact_only.sql` | v2.11.0 | Final 10 Real Impact badges (learning हटा) |
| `005_game_removal_badges.sql` | v2.10.0 | Game tables/awards हटा |
| `004_badges_game.sql` | v2.8.0 | badges/user_badges tables |
| `003_add_ai_meta.sql` | v2.6.x | AI columns/settings |
| `002_create_schema_migrations.sql` | v2.5.0 | tracking table |

---

## ⚠️ Golden Rules

1. **Backup पहले** (हर import से पहले):
   `mysqldump -u root -p punarva_db > punarva_backup_$(date +%F).sql`
2. **`schema.sql` कभी भी पुराने (data वाले) database पर import न करें** — वह `DROP DATABASE` करती है। सिर्फ fresh install के लिए है।
3. Migration files **idempotent** हैं — गलती से दोबारा चल भी गईं तो कुछ नहीं बिगड़ेगा (no-op हो जाती हैं)। लेकिन ज़रूरत नहीं है।
4. Migration कभी reward_rules / reward_transactions / users / waste data नहीं छूतीं — सिर्फ documented changes।
5. Imports के बाद app खोलकर verify करें (admin → System Health में "Database: Connected" दिखना चाहिए)।

## v2.14.0 — Scanner manual, AI retired

| Migration | क्या करती है |
|---|---|
| 010_remove_ai_scanner.sql | `waste_scans.mode` + `'manual'`; retired AI settings delete (`ai_scanner_enabled`, `ai_confidence_warn`, `ai_local_port`, `ai_local_timeout`, `ai_provider_live`)। Historical scans untouched। |

**किसे करना चाहिए:** v2.13.0 से upgrade करने वाले — सिर्फ `010`। v2.12.0 या पुराने — पहले 009, फिर 010 (क्रम में सारी बाकी)।
Fresh install: schema.sql → seed.sql → settings_defaults.sql → migrations 001–010।

**Fresh install expected result (v2.14.0):** 41 tables (announcements सहित) · 63 settings · 0 `ai_*` settings · `waste_scans.mode` ENUM('demo','real','manual') · 10 badges · 8 users · 0 announcements · 0 shifts · 3 seed history scans (HISTORICAL badge admin Scan Log में)।

## v2.15.0 — System Settings redesign (minimal + security-first)

| Migration | क्या करती है |
|---|---|
| 011_settings_minimal_security.sql | 7 retired security-switch rows delete (`brute_force_protection`, `rate_limiting`, `login_activity_logging`, `password_require_uppercase/lowercase/number/special`) — ये protections अब code में हमेशा active हैं; configurable thresholds नई ranges में normalize (max_attempts 3–10→default 5, lock 1–1440, idle 5–1440, pwd length 8–128)। User data untouched। |

**किसे करना चाहिए:** v2.14.0 से upgrade — सिर्फ `011`। Fresh: schema.sql → seed.sql → settings_defaults.sql → migrations 001–011।
**Fresh install expected result (v2.15.0):** 41 tables · 56 settings · 0 security-switch rows · 10 badges · 8 users · `waste_scans.mode` ENUM('demo','real','manual')।

## v2.16.0 — Audit Logs redesign + Shift PDF font root-cause hardening

**DB import: कुछ भी नहीं।** इस version में कोई migration नहीं है — database schema/data untouched. सिर्फ files update करें (zip overwrite)।
(Audit Logs redesign केवल presentation + exports है; नया audit event (ACCOUNT_LOCKED / SHIFT_PDF_FAILED / AUDIT_EXPORT_*) schema change के बिना मौजूदा audit_logs table में लिखता है।)

## v2.16.1 — SHIFT PDF FONT FIX (root cause: font-cache path poisoning)

**यह था असली कारण:** PDF font metrics cache (`vendor/tfpdf/font/unifont/*.mtx.php`) files में उस machine का absolute path record होता है जहाँ package build हुआ था। आपके server पर यह cache include होने पर गलत foreign path (`/home/user/punarva/...`) fopen होता था → `die("Can't open file ...")` — uncatchable plain error.

**क्या ठीक हुआ:** (1) tFPDF patch — cache का path ignore करके हमेशा इस server का path use होता है (metrics वैध रहते हैं)। (2) Shipped caches clean कर दिए। (3) ttfonts.php की सभी `die()` → catchable exceptions (कोई path leak नहीं)। (4) Font validation अब truncated/corrupt files भी पकड़ती है। (5) `tools/pdf_selftest.php` में FONT FILES + CACHE POISONING diagnosis।

**DB import: नहीं** — कोई migration नहीं। सिर्फ files overwrite करें।
**आपके existing install पर:** पूरी `vendor/tfpdf/` folder नई zip से replace करें (पुरानी poisoned caches overwrite हो जाएँगी) — या Admin → tools/pdf_selftest.php चलाकर देखें।

## v2.17.0 — Audit Logs filter cleanup (UI-only, zero data changes)

**DB import: नहीं** — कोई migration नहीं, audit data/schema untouched। सिर्फ files overwrite करें।
बदलाव: filter bar अब सिर्फ **Module + Action + User + Date Range + एक Global Search** (IP filter UI से हटा — IP आगे भी table/details/donों exports में रहेगा)। Action dropdown अब readable **categories** (mapping-only — कोई historical value rewrite नहीं)। From/To सिर्फ Custom Range पर दिखते हैं। Search से **sensitive metadata कभी match नहीं होता** (guard SQL)।

## v2.17.1 — Audit Log PDF export redesign (landscape, no truncation)

**DB import: नहीं** — files-only change।
Audit PDF export अब **A4 landscape** में, सिर्फ ज़रूरी columns (S.No, Time, User, Action, Module, Record, IP) — कोई text कटेगा नहीं (पहले `127.0.0.1 (localhos…` / नाम clip हो रहे थे)। Table header हर page पर repeat होता है। Shared PDF engine (`ShiftPdfService::open`) में optional orientation param — पुराने सारे PDF (shift आदि) portrait में अपरिवर्तित। CSV export अपरिवर्तित।

## v2.18.0 — System Settings section separation + AI wording removal

**DB import: नहीं** — कोई migration नहीं; **कोई setting key/value नहीं बदली** (pure UI regroup)।
System Settings अब 8 sections: **General** (सिर्फ Site Identity + Regional), **Registration & Login**, **Notifications**, **Services & Integrations**, **Maintenance**, **Privacy & Public Access**, **Security** (Login Protection + Session Security + Password Policy + Always-Enforced Protections), **System Health** (read-only)। सारे AI mentions UI से हटे (Scanner: "Manual"; "External AI API: Disabled" वाक्य हटा; Home/Article/Reports/Routes के AI वाक्य ठीक)। Scanner functionality अपरिवर्तित।

## v2.19.0 — Safe file & endpoint audit

**DB import: नहीं** — data/schema untouched।
Audit निष्कर्ष: (1) `admin/shifts-pdf.php` duplicate नहीं — filtered Shifts management report (admin/shifts.php से linked) — KEEP। (2) `about.php` public content page — nav में linked नहीं, पर spec के अनुसार preserve (KEEP)। (3) **REMOVED**: `api/auth/register.php` (zero-reference duplicate registration endpoint — page register.php ही signup करता है; बेकार unauthenticated write-surface हटा) और `deploy-check.php` (खुद अपने docblock में "temporary — DELETE AFTER USE"; zero references)। (4) **HARDENED**: admin/shift-pdf.php + collector/shift-pdf.php — unauthenticated hit अब clean 302 login (पहले TypeError/500)। game.php stubs, scan-confirm 410 stub, wrappers, docs, seed images — सब KEEP (references verified)।

## v2.20.0 — API security audit + tracking verification

**DB import: नहीं** — कोई schema/data change नहीं।
Audit परिणाम: (1) **FIXED — IDOR**: `PickupService::cancel` ownership check पहले सिर्फ CITIZEN पर था; BUSINESS अपना id बदलकर किसी और का pickup cancel कर सकता था (live test से proven)। अब हर non-admin canceller पर ownership। (2) **FIXED (minor)**: `api/collector/complete.php` waste_id lookup गलत id से — अब completed assignment के pickup_request_id से। (3) Tracking (`api/driver/track.php` + TrackingService) **PASS as-is**: session-derived ownership (client IDs कभी trust नहीं), coordinate ranges/clamps, 3s throttle + 8m duplicate-skip, per-shift history cap, indexes मौजूद (idx_loc_shift_time, idx_shifts_driver_status…), CSRF (X-CSRF-Token) enforced, prepared statements everywhere, safe JSON errors (APP_DEBUG=false default)। (4) Guest reporting जानबूझकर design है (public report page)।

## v2.21.0 — Complete production audit (consolidated)

**DB import: नहीं** — कोई migration नहीं।
पूरे audit के निष्कर्ष: Security headers (CSP, X-Frame-Options, nosniff, Referrer-Policy, HttpOnly+SameSite cookie) **पहले से लागू**; robots.txt + sitemap.xml **पहले से**; uploads (finfo MIME+ext cross-check+random name) **सत्यापित** (evil.php + PNG-cloak दोनों reject); i18n **249/249/249** समानता; डिबग आउटपुट **शून्य**; सार्वजनिक ट्रैकिंग PII-क्लीन। **सुधार (FIXED)**: (1) form labels अब programmatic (`for`/`id`) — login/register/report/footer (स्क्रीन रीडर a11y, WCAG 1.3.1); (2) canonical links सार्वजनिक पृष्ठों पर। कोई व्यवहार परिवर्तन नहीं।

## v2.22.0 — Security & core-UX hardening round

**DB import: नहीं** — कोई migration नहीं।
(1) **FIXED (बग):** Community impact-ranking widget कभी update नहीं होता था — JS `esc` helper इस scope में undefined (हर poll पर silent ReferenceError) + API के `data` envelope को unwrap नहीं करता था। अब render + `pnvEsc` escaping (XSS payload browser-test से neutralized verified)। (2) **HARDENED:** `Repository::all()` ORDER BY identifier allowlist (defence-in-depth; कोई existing caller affected नहीं)। (3) **ADDED:** `config/.htaccess` + `includes/.htaccess` (Require all denied — वहाँ कोई legitimate URL नहीं; dev-router पहले से blocked था)। (4) Verified PASS: rewards double-award impossible (UNIQUE(user_id,badge_id) — live test), polling visibilitychange stop/start पहले से, authenticated pages no-store (back-button safe), uploads .htaccess execution-block, 137-row 7-page PDF export 92ms zero truncation/leak।

## v2.23.0 — Ultra-premium UI/UX layer (design system + shell refinement)

**DB import: नहीं** — कोई migration नहीं; backend/API/security **zero changes**।
(1) Refined design tokens: forest/sage/ivory/charcoal/amber palette, spacing scale (4pt), radius system, **3-स्तरीय layered shadows**, hairline borders, focus ring tokens। (2) Component polish (CSS-only, markup compatible): buttons (solid + hover-lift + loading + disabled), cards/KPI hairline+depth, tables (uppercase headers, hover), forms (green focus ring), glass navbar, sidebar pill-indicator, modal/pagination/toast radius, skeleton shimmer, empty-state utility, quiet scrollbars। (3) Fluid editorial typography (clamp) + unified :focus-visible + global prefers-reduced-motion safety। (4) Homepage: i18n headline `home.hero_headline` (तीनों भाषाओं में नई key — parity बरकरार), CTA hierarchy (primary + ghost-light), **original hand-drawn journey-curve SVG** (aria-hidden decorative)।

## v2.24.0 — Product-experience redesign phase (typography + mobile nav + hero + polish)

**DB import: नहीं** — backend/API zero changes।
(1) **Self-hosted Inter font** (3 weights latin woff2, ~72KB, `unicode-range` से Devanagari/Bengali Noto पर) — CSP-safe, no CDN। (2) **Role-aware mobile bottom navigation** (नया `views/layouts/mobile_nav.php`, dash_footer से included): citizen Home/Pickups/Scan/Passport/Profile · collector Home/Route/Pickups/Shifts/Profile · recycler · business · admin — active state `$current` file से + `aria-current`; सिर्फ navigation (authorization pages पर पहले जैसा ही server-side)। (3) Hero: **"From Waste to Worth."** display headline (i18n en/hi/bn) + "Every piece…" editorial subline। (4) Footer circular-loop pattern + map popup/controls polish। i18n parity 251/251/251।

## v2.25.0 — Premium analytics/chart redesign (admin + citizen + business)

**DB import: नहीं** — सिर्फ frontend; queries/roles/auth/APIs untouched।
(1) **नया chart system**: `assets/js/pnv-charts.js` (PNV_CHART: themed Chart.js defaults, Inter, hairline grids, refined tooltips, 420ms easeOutQuart, destroy-before-create — no dup instances/leaks) + `assets/css/charts.css` (chart-card, height system primary 300/md 240/sm 170/spark 150px desktop → mobile 220/190/150, mix-bars, flow-steps, segmented status bar, 7M/6M/12M/All range chips, reduced-motion)। dash_header अब charts.css भी load करता है; dash_footer pnv_chart_assets() से vendor+system load करता है। (2) **Admin dashboard**: 5 giant canvas charts → area chart + range chips (real client-side slice), compact waste-mix bars (kg+%), recycling Collected→Processed→Recycled→Rejected flow (खुद के KPI values से), pickup sparkline (2 series), reports segmented bar + status list। (3) **Admin analytics**: line/bar themed; polarArea → compact outcome flow; ward reports horizontal 2-series। (4) **Citizen**: dashboard doughnut → mix bars; impact page bars+area premium cards में। (5) **Business**: dashboard में नए real-data charts (collection trend area, waste-mix bars, 7-stage pickup progression grid), impact premium dual-series trend (dashed comparison)। (6) panel-dark specificity fix (.card.panel-dark)। सारे numbers DB से (no invented data); empty states पहले जैसे।
