-- ============================================================
-- PUNARVA upgrade: v2.1.2 → v2.1.3 (Role-Based Session Management)
-- Safe on existing data; idempotent (re-run harmless).
-- ============================================================
CREATE TABLE IF NOT EXISTS user_sessions (
  session_id   VARCHAR(191) PRIMARY KEY,
  user_id      INT UNSIGNED NOT NULL,
  ip           VARCHAR(45)  NULL,
  user_agent   VARCHAR(255) NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  revoked_at   DATETIME NULL,
  KEY idx_us_user (user_id, revoked_at),
  CONSTRAINT fk_us_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
