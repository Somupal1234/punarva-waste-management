<?php
require_once __DIR__ . '/includes/init.php';
$pageTitle = 'About'; $activeNav = 'home';
view('layouts/public_header', compact('pageTitle', 'activeNav'));
?>
<section class="py-5">
  <div class="container">
    <div class="row g-4 align-items-center">
      <div class="col-lg-6">
        <img src="<?= url('assets/images/logo-full.png') ?>" alt="PUNARVA – From Waste to Worth" class="mb-4" style="max-width:340px;width:100%">
        <div class="section-eyebrow">About the platform</div>
        <h1 class="h2 text-pnv-dark fw-bold display-6"><?= t('page.about') ?></h1>
        <div class="tagline mb-3" style="color:var(--pnv-amber);font-weight:700;letter-spacing:2px;text-transform:uppercase">From Waste to Worth</div>
        <p class="text-muted">PUNARVA is a smart digital waste-management ecosystem that connects
          <strong>citizens, waste collectors, recycling facilities, businesses/institutions and the municipality</strong>
          into one traceable loop.</p>
        <p class="text-muted">Our core innovation is the <strong>Waste Passport</strong>: every collected load receives a unique
          Waste ID and a verifiable journey history — from the moment waste is identified at a doorstep to its final
          recycling, composting or recovery outcome. Waste stops being invisible and becomes accountable, measurable value.</p>
        <div class="d-flex flex-wrap gap-3 mt-4">
          <div class="text-center px-4"><div class="text-pnv fs-3 fw-bold">5</div><div class="small text-muted">Connected roles</div></div>
          <div class="text-center px-4"><div class="text-pnv fs-3 fw-bold">28+</div><div class="small text-muted">Database tables</div></div>
          <div class="text-center px-4"><div class="text-pnv fs-3 fw-bold">11</div><div class="small text-muted">Passport stages</div></div>
          <div class="text-center px-4"><div class="text-pnv fs-3 fw-bold">100%</div><div class="small text-muted">Traceable waste</div></div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="card p-4">
          <h5 class="fw-bold mb-3"><i class="text-pnv bi bi-diagram-3 me-2"></i>The ecosystem</h5>
          <?php
          $flow = [
              ['bi-person', 'Citizens', 'Scan, segregate and schedule pickups; earn rewards'],
              ['bi-truck', 'Collectors', 'Executed routes, verified weights, proof photos'],
              ['bi-buildings', 'Recycling facilities', 'Sorting, processing, final outcomes & impact'],
              ['bi-bank', 'Businesses & institutions', 'Bulk pickups, compliance & periodic reports'],
              ['bi-shield-check', 'Municipality / Admin', 'Assignments, hotspots, analytics & governance'],
          ];
          foreach ($flow as $f): ?>
            <div class="d-flex align-items-center gap-3 border-bottom py-2">
              <span class="logo-mark" style="width:34px;height:34px;font-size:1rem"><i class="bi <?= $f[0] ?>"></i></span>
              <div><strong><?= $f[1] ?></strong><div class="small text-muted"><?= $f[2] ?></div></div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>
<?php view('layouts/public_footer');
