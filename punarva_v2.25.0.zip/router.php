<?php
/**
 * PUNARVA — dev/preview router for PHP's built-in server (`php -S host:port router.php`).
 * Mirrors the production Apache rules (.htaccess): never expose secrets, SQL files or logs.
 * On XAMPP/Apache this file is NOT used — .htaccess rules apply there.
 */
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '/';
$name = basename($path);
// block dotfiles (.env, .git, …) and sensitive directories
if ($name !== '' && $name[0] === '.') { http_response_code(404); exit('Not Found'); }
foreach (['/database/', '/storage/', '/config/', '/includes/'] as $blocked) {
    if (str_starts_with($path, $blocked)) { http_response_code(404); exit('Not Found'); }
}
$file = __DIR__ . $path;
if ($path !== '/' && is_file($file) && !str_ends_with($path, '.php') && str_starts_with($path, '/assets/')) {
    // v2.7.0: static asset caching for the dev router (php -S drops router headers on `return false`,
    // so /assets/ is served explicitly). XAMPP/Apache: assets/vendor/.htaccess handles caching there.
    $mimes = ['css' => 'text/css; charset=UTF-8', 'js' => 'application/javascript', 'mjs' => 'application/javascript',
              'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'gif' => 'image/gif',
              'svg' => 'image/svg+xml', 'woff' => 'font/woff', 'woff2' => 'font/woff2', 'map' => 'application/json'];
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    $max = str_starts_with($path, '/assets/vendor/') ? 604800 : 3600; // vendor = versioned by release
    header('Content-Type: ' . ($mimes[$ext] ?? 'application/octet-stream'));
    header('Cache-Control: public, max-age=' . $max);
    header('Content-Length: ' . (string) filesize($file));
    http_response_code(200);
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'HEAD') exit;
    readfile($file);
    exit;
}
if ($path !== '/' && is_file($file)) return false; // real files (incl. .php) — built-in server serves/executes natively
require __DIR__ . '/index.php'; // everything else → app front controller
