<?php
require_once __DIR__ . '/includes/init.php';
if (is_logged_in()) redirect(ROLE_HOME[current_role()]);

$token = (string) get_val('token', post_val('token', ''));
$valid = $token !== '' ? AuthService::validateResetToken($token) : null;

$fieldErrors = [];
if (is_post()) {
    try {
        $email = AuthService::resetPassword($token, (string) post_val('password', ''), (string) post_val('password_confirm', ''));
        session_regenerate_id(true);
        flash('success', 'Password updated successfully for ' . e($email) . '. You can now log in with your new password.');
        redirect('login.php');
    } catch (InvalidArgumentException $e) {
        $resetError = $e->getMessage();
        $f = pnv_field_error($resetError, ['confirm' => 'password_confirm', 'password' => 'password']);
        if ($f) $fieldErrors[$f] = $resetError;
        $valid = AuthService::validateResetToken($token); // may be consumed/expired now
    } catch (Throwable $e) {
        $resetError = APP_DEBUG ? $e->getMessage() : 'Could not reset the password. Please try again.';
    }
}
?>
<!DOCTYPE html>
<html lang="<?= e(current_lang()) ?>">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="PUNARVA — From Waste to Worth. A transparent digital waste-management ecosystem with traceable Waste Passports, QR tracking and estimated environmental impact.">
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<title><?= e('Reset Password · ' . APP_NAME) ?></title>
<link rel="icon" type="image/png" href="<?= url('assets/images/favicon.png') ?>">
<link rel="stylesheet" href="<?= url('assets/vendor/bootstrap/bootstrap.min.css') ?>">
<link rel="stylesheet" href="<?= url('assets/vendor/bootstrap-icons/bootstrap-icons.min.css') ?>">
<link rel="stylesheet" href="<?= asset_url('assets/css/style.css') ?>">
</head>
<body>
<a class="skip-link" href="#main-content"><?= t('a11y.skip') ?></a>
<main id="main-content"><div class="auth-page py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-8 col-lg-5">
        <div class="card auth-card">
          <div class="card-body p-4">
            <div class="text-center mb-3"><img class="logo-lg" src="<?= url('assets/images/logo-full.png') ?>" alt="PUNARVA"></div>

            <?php if (!$valid): ?>
              <div class="text-center py-3">
                <div style="font-size:3rem">🔗</div>
                <h1 class="h4 fw-bold">Link invalid or expired</h1>
                <p class="text-muted small">This password reset link is invalid, already used, or older than 60 minutes.</p>
                <a class="btn btn-pnv px-4" href="<?= url('forgot-password.php') ?>"><i class="bi bi-key me-1"></i>Request a new link</a>
              </div>
            <?php else: ?>
              <h4 class="fw-bold mb-1 text-center"><i class="text-pnv bi bi-shield-lock me-2"></i>Set New Password</h4>
              <p class="text-muted small text-center mb-4">for <strong><?= e($valid['email']) ?></strong></p>

              <?php if (!empty($resetError)): ?>
                <div class="alert alert-danger small alert-auto"><?= e($resetError) ?></div>
              <?php endif; ?>

              <?php if (true): ?>
              <form method="post" novalidate>
                <?= csrf_field() ?>
                <input type="hidden" name="token" value="<?= e($token) ?>">
                <div class="mb-3">
                  <label class="form-label fw-semibold small">New password <span class="required-asterisk" aria-hidden="true">*</span></label>
                  <div class="input-group">
                    <span class="input-group-text bg-white"><i class="bi bi-lock"></i></span>
                    <input name="password" type="password" class="form-control<?= isset($fieldErrors['password']) ? ' is-invalid' : '' ?>" aria-invalid="<?= isset($fieldErrors['password']) ? 'true' : 'false' ?>"<?= isset($fieldErrors['password']) ? ' aria-describedby="err-password"' : '' ?> minlength="8" required autofocus><?php if (isset($fieldErrors['password'])): ?><div class="invalid-feedback" id="err-password"><?= e($fieldErrors['password']) ?></div><?php endif; ?>
                  </div>
                  <div class="form-text">Minimum 8 characters.</div>
                </div>
                <div class="mb-3">
                  <label class="form-label fw-semibold small">Confirm new password <span class="required-asterisk" aria-hidden="true">*</span></label>
                  <div class="input-group">
                    <span class="input-group-text bg-white"><i class="bi bi-lock-fill"></i></span>
                    <input name="password_confirm" type="password" class="form-control<?= isset($fieldErrors['password_confirm']) ? ' is-invalid' : '' ?>" aria-invalid="<?= isset($fieldErrors['password_confirm']) ? 'true' : 'false' ?>"<?= isset($fieldErrors['password_confirm']) ? ' aria-describedby="err-password_confirm"' : '' ?> minlength="8" required><?php if (isset($fieldErrors['password_confirm'])): ?><div class="invalid-feedback" id="err-password_confirm"><?= e($fieldErrors['password_confirm']) ?></div><?php endif; ?>
                  </div>
                </div>
                <button class="btn btn-pnv w-100 py-2"><i class="bi bi-check2-circle me-1"></i>Update Password</button>
              </form>
              <?php endif; ?>
            <?php endif; ?>
            <hr>
            <div class="small text-center">
              <a href="<?= url('login.php') ?>" class="text-pnv fw-bold"><i class="bi bi-arrow-left me-1"></i>Back to login</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div></main>
<script src="<?= asset_url('assets/js/password-toggle.js') ?>" defer></script>
</body></html>
